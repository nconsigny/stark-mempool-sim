"""The Python side of the v3 web engine (web-v3/ENGINE.md).

One function per message of the worker: `call(method, args_json)` returns a
JSON string. A run goes through the command line's own functions
(`bench.leansphincs.cli3.run_parser`, `sets_from`, `spec.resolve`,
`starksim.v3.runner.execute`), so its row is the one

    python3 -m bench.leansphincs run <argv>

prints for the same argv; `web-v3/test/determinism.mjs` checks that, field
by field. The animation trace (`trace: true`) is read from the finished
run's context after the row is built: it reads the simulation and changes
nothing.

Also runnable natively, for the build's self-checks and the determinism
test: `python3 -I lsweb3.py <method> '<args json>'` from the bundle root.
"""

import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # the bundle root
SIM_DIR = os.path.join(ROOT, "sims", "stark-mempool-sim-v2")
LIMITS_FILE = os.path.join(HERE, "limits3.json")

PROGRESS_EVENTS = 4000          # look at the wall clock every N events
PROGRESS_SECONDS = 0.25         # at most four ticks a second
# Wall-time columns: the only fields allowed to differ from the CLI's row.
WALL_FIELDS = ("build_s_measured", "wall_s_measured",
               "events_per_s_measured", "runtime_s")

_progress = None


def set_progress(callback):
    global _progress
    _progress = callback


def _report(**event):
    if _progress is not None:
        _progress(json.dumps(event))


def setup():
    if SIM_DIR not in sys.path:
        sys.path.insert(0, SIM_DIR)
    os.environ.setdefault("LEANSPHINCS_DATA", os.path.join(ROOT, "data"))


def _limits():
    with open(LIMITS_FILE, encoding="utf-8") as handle:
        return json.load(handle)


def _manifest():
    path = os.path.join(HERE, "manifest3.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    return {}


# -- argv: the CLI line a config stands for ---------------------------------

def argv_of(config):
    """The `run` argv of a page config. Keys: deployment, candidate,
    gas_limit, nodes, seed, demand ('saturate' or tx/s), sets {key: value}."""
    known = {"deployment", "candidate", "gas_limit", "nodes", "seed",
             "demand", "sets", "trace", "time_limit_s", "override_limits"}
    unknown = sorted(set(config) - known)
    if unknown:
        raise ValueError(f"unknown config keys {unknown}; known: "
                         f"{sorted(known)}")
    argv = ["--deployment", str(config.get("deployment") or "8141")]
    if config.get("candidate") not in (None, ""):
        argv += ["--candidate", str(config["candidate"])]
    if config.get("gas_limit") is not None:
        argv += ["--gas-limit", str(int(config["gas_limit"]))]
    if config.get("nodes") is not None:
        argv += ["--nodes", str(int(config["nodes"]))]
    if config.get("seed") is not None:
        argv += ["--seed", str(int(config["seed"]))]
    if config.get("demand") not in (None, ""):
        argv += ["--demand", str(config["demand"])]
    for key in sorted(config.get("sets") or {}):
        argv += ["--set", f"{key}={json.dumps(config['sets'][key])}"]
    return argv


def command_of(argv):
    def quote(arg):
        if all(c.isalnum() or c in "-_.=/:@" for c in arg):
            return arg
        return "'" + arg.replace("'", "'\\''") + "'"
    return "python3 -m bench.leansphincs run " + " ".join(
        quote(arg) for arg in argv)


def check_limits(config):
    limits = _limits()
    reasons = []
    if config.get("override_limits"):
        return {"reasons": []}
    deployment = config.get("deployment") or "8141"
    entry = limits["deployments"].get(deployment)
    if entry is None:
        return {"reasons": [f"deployment {deployment!r} is not offered in "
                            "the browser"]}
    nodes = config.get("nodes")
    if nodes is None:
        reasons.append("nodes must be given (the CLI default is "
                       f"{limits['cli_default_nodes']})")
    elif not entry["min_nodes"] <= int(nodes) <= entry["max_nodes"]:
        reasons.append(f"nodes {nodes} is outside the browser limit "
                       f"{entry['min_nodes']} to {entry['max_nodes']} for "
                       f"{deployment}")
    sets = config.get("sets") or {}
    measured = sets.get("slots.measured")
    if measured is None:            # the spec's own default applies
        from starksim.v3 import spec as spec_module
        measured = spec_module.FIELDS["slots.measured"][0].default
    if int(measured) > entry["max_measured_slots"]:
        reasons.append(f"slots.measured {measured} is above the browser "
                       f"limit {entry['max_measured_slots']}")
    gas = config.get("gas_limit")
    if gas is not None and int(gas) > entry["max_gas_limit"]:
        reasons.append(f"gas limit {gas} is above the browser limit "
                       f"{entry['max_gas_limit']}")
    return {"reasons": reasons}


# -- methods -----------------------------------------------------------------

def info(_args=None):
    import platform
    manifest = _manifest()
    return {"python": platform.python_version(),
            "platform": sys.platform, "root": ROOT,
            "simulator": manifest.get("simulator", {}),
            "data": manifest.get("data", {})}


def describe(_args=None):
    """Deployments, every --set key with its default and choices, the
    candidates, the browser limits: what a form needs."""
    from starksim.v3 import params as params_module
    from starksim.v3 import spec as spec_module
    params = params_module.default_params()
    keys = []
    for key in spec_module.keys():
        fld = spec_module.FIELDS[key][0]
        meta = fld.metadata
        default = fld.default
        if not isinstance(default, (int, float, str, bool, type(None))):
            continue
        keys.append({"key": key, "default": default, "kind": meta["kind"],
                     "choices": (list(meta["choices"]) if meta["choices"]
                                 else None),
                     "min": meta["min"], "max": meta["max"],
                     "acts_in": list(meta["acts_in"]),
                     "doc": meta["doc"]})
    defaults = {}
    for deployment, entries in spec_module.DEPLOYMENT_DEFAULTS.items():
        defaults[deployment] = {key: {"value": value, "source": source}
                                for key, (value, source) in entries.items()}
    candidates = []
    for name in params.candidate_names():
        entry = params.candidate(name)
        candidates.append({"name": name, "sig_bytes": entry["sig_bytes"],
                           "perms": entry["perms"],
                           "params": entry["params"],
                           "counted": bool(entry["counted"])})
    return {"deployments": list(spec_module.DEPLOYMENTS),
            "keys": keys, "deployment_defaults": defaults,
            "candidates": candidates, "limits": _limits()}


def run(args):
    """One run through the CLI's own functions. Returns the row, the row's
    exact JSON text, the argv and command, timing and (on request) the
    animation trace."""
    from bench.leansphincs import cli3
    from starksim.v3 import params as params_module
    from starksim.v3 import runner
    from starksim.v3 import spec as spec_module
    config = dict(args.get("config") or {})
    reasons = check_limits(config)["reasons"]
    if reasons:
        raise ValueError("; ".join(reasons) +
                         " (pass override_limits to run it anyway)")
    limits = _limits()
    time_limit = config.get("time_limit_s")
    if time_limit is None:
        time_limit = 0 if config.get("override_limits") else \
            limits["time_limit_s"]
    argv = argv_of(config)
    parsed = cli3.run_parser().parse_args(argv)
    params = params_module.default_params().fresh()
    spec = spec_module.resolve(params, parsed.deployment,
                               sets=cli3.sets_from(parsed))
    started = time.perf_counter()
    slots = spec.slots
    horizon = (slots.warmup + slots.measured + slots.drain + 1) \
        * spec.chain.slot_ms
    state = {"reported": started}

    def prepare(ctx):
        engine = ctx.engine
        counter = [0]

        def hook(_kind):
            counter[0] += 1
            if counter[0] % PROGRESS_EVENTS:
                return
            now = time.perf_counter()
            if time_limit and now - started > time_limit:
                raise TimeoutError(
                    f"stopped after {now - started:.0f} s: over the time "
                    f"limit of {time_limit:g} s (simulated "
                    f"{engine.now / 1000.0:.1f} of {horizon / 1000.0:.0f} "
                    "s). Fewer nodes or a smaller gas limit make it shorter")
            if now - state["reported"] >= PROGRESS_SECONDS:
                state["reported"] = now
                _report(event="tick", sim_ms=engine.now,
                        horizon_ms=horizon, elapsed_s=now - started,
                        events=engine.events_processed)

        engine.after_event(hook)

    row, ctx = runner.execute(spec, params, prepare=prepare)
    python_s = time.perf_counter() - started
    row_text = json.dumps(row, indent=1, allow_nan=False, default=str)
    result = {"row": json.loads(row_text), "row_text": row_text,
              "argv": argv, "command": command_of(argv),
              "spec_hash": row.get("spec_hash"),
              "spec": spec_module.as_dict(spec),
              "timing": {"python_s": python_s}}
    if config.get("trace"):
        result["trace"] = trace_of(ctx)
    return result


# -- the animation trace -----------------------------------------------------

TRACE_TX_SAMPLE = 24       # sampled txs drawn in the animation
TRACE_TOPICS = ("beacon_block", "execution_payload")


def trace_of(ctx):
    """What the animation draws, read from a finished run: nodes (region,
    access, roles, uplink), EL peers and the CL mesh, every block and
    payload message (publish time, origin, first receipt per node, and the
    CL copies per edge from the senders' bitsets), a sample of txs with
    their first admission per node (EL reach sample), per-node bytes, and
    the slot records."""
    topo = ctx.topo
    nodes = ctx.nodes
    n = topo.n_total
    region_names = list(topo.region_names)
    node_rows = []
    for node in range(n):
        node_rows.append({
            "region": region_names[nodes.region[node]],
            "home": bool(nodes.home[node]),
            "validator": bool(nodes.is_validator[node]),
            "builder": bool(nodes.is_builder[node]),
            "supernode": bool(nodes.is_supernode[node]),
            "up_mbps": nodes.up_Bpms[node] * 8.0 / 1000.0,
        })
    el_edges = sorted({(min(u, v), max(u, v)) for u in range(n)
                       for v in nodes.el_peers[u]})
    cl_edges = sorted({(min(u, v), max(u, v)) for u in range(n)
                       for v in nodes.cl_mesh[u]})
    edge_bytes = {}
    messages = []
    cl = ctx.cl
    names = list(cl.topic_names)
    for msg in cl.by_id.values():
        topic = names[msg.topic] if msg.topic < len(names) else str(msg.topic)
        if topic not in TRACE_TOPICS:
            continue
        for v in range(n):
            bits = msg.senders[v]
            u = 0
            while bits:
                if bits & 1:
                    key = (min(u, v), max(u, v))
                    edge_bytes[key] = edge_bytes.get(key, 0) + msg.size
                bits >>= 1
                u += 1
        messages.append({"id": str(msg.msg_id), "topic": topic,
                         "size": msg.size, "origin": msg.origin,
                         "t_pub": msg.t_pub,
                         "first": [round(t, 3) for t in msg.first],
                         "copies": list(msg.copies)})
    messages.sort(key=lambda m: (m["t_pub"], m["topic"]))
    txs = []
    el = ctx.el
    for rule in sorted(getattr(el, "rules", {})):
        for obj in el.reach_objects(rule):
            times = el.reach_times(rule, obj)
            if times is None:
                continue
            born = ctx.txs.born[obj] if obj < len(ctx.txs) else None
            txs.append({"rule": rule, "id": obj, "born": born,
                        "kind": ctx.txs.kind[obj] if obj < len(ctx.txs)
                        else None,
                        "first": [round(t, 3) for t in times]})
    if len(txs) > TRACE_TX_SAMPLE:
        step = len(txs) / TRACE_TX_SAMPLE
        txs = [txs[int(i * step)] for i in range(TRACE_TX_SAMPLE)]
    arrays = ctx.counters.arrays
    per_node = {}
    for name in ("links.bytes_up_el", "links.bytes_up_cl",
                 "links.bytes_down", "links.busy_ms_up"):
        if name in arrays:
            per_node[name] = [float(x) for x in arrays[name]][:n]
    records = []
    for record in ctx.slot.records:
        records.append({key: record.get(key) for key in
                        ("slot", "release_ms", "published_ms", "canonical",
                         "txs", "gas_used", "bytes", "binding", "failure",
                         "builder", "proposer")})
    spec = ctx.spec
    return {"n": n, "n_simulated": topo.n, "nodes": node_rows,
            "regions": region_names,
            "el_edges": [list(e) for e in el_edges],
            "cl_edges": [list(e) for e in cl_edges],
            "cl_edge_bytes": [[u, v, b] for (u, v), b in
                              sorted(edge_bytes.items())],
            "messages": messages, "txs": txs, "per_node": per_node,
            "slots": records, "slot_ms": spec.chain.slot_ms,
            "warmup": spec.slots.warmup, "measured": spec.slots.measured,
            "end_ms": ctx.engine.now,
            "note": "Read from the finished run's state, not a separate "
                    "model: first receipts per node, block and payload "
                    "copies per node pair (any gossip route, from each "
                    "message's senders), transactions of the EL reach "
                    "sample."}


METHODS = {"info": info, "describe": describe, "run": run,
           "check_limits": lambda args: check_limits(args.get("config")
                                                     or {}),
           "ping": lambda _args: {"pong": True}}


def call(method, args_json="{}"):
    setup()
    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}; known: "
                         f"{sorted(METHODS)}")
    args = json.loads(args_json or "{}")
    return json.dumps(METHODS[method](args), allow_nan=False, default=str)


if __name__ == "__main__":
    sys.stdout.write(call(sys.argv[1], sys.argv[2] if len(sys.argv) > 2
                          else "{}") + "\n")

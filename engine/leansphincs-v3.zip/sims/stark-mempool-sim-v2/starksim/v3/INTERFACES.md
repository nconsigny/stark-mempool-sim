# starksim/v3 interfaces: the append-only contract

Frozen at stage S0 (2026-11-12) on branch `leansphincs-v3`. Design:
`/projects/leanSPHINCS/notes/phase4/arch.md`. Per-stage work orders:
`STAGES.md` next to this file.

Four engineers build S2a (EL gossip + mempool), S2b (CL gossip), S2c (demand
+ fees) and S2d (provers) in parallel worktrees, then two build the halves of
S3. This file says what each may touch so that their branches merge without
conflicts.

## 1. Ownership

| file | owner | others may |
|---|---|---|
| `detmath.py`, `params.py`, `spec.py`, `state.py`, `deploy.py` | lead (S0) | read; append only, by the rules of section 2 |
| `topology.py`, `links.py`, `testkit.py` | lead (S1) | read; S2b may *call* `topology.build_mesh` |
| `elgossip.py`, `mempool.py` | S2a | read |
| `clgossip.py` | S2b | read |
| `demand.py` | S2c | read |
| `prover.py` | S2d | read |
| `slot.py`, `deploy_8141.py` | S3a | read |
| `deploy_agg.py` | S3b | read |
| `metrics.py`, `attribution.py` | S4 | read |
| `runner.py`, `timeline.py`, `elasticity.py`, `sweep3.py`, `bench/leansphincs/cli3.py` | S5 (lead) | read |
| `tests/v3/test_<module>.py` | the module's owner | — |
| `tests/v3/test_rules.py`, `test_state.py` (frozen signatures) | lead | append a row when you add a public method |

The S2 files exist as **stubs** with the frozen signatures; a stage replaces
its stub's bodies wholesale. Keep every signature listed in
`tests/v3/test_state.py::FROZEN_SIGNATURES`; you may add methods, and keyword
arguments with defaults at the end of a signature.

The frozen v2 core (`starksim/*.py`), upstream `bench/*.py`, `docs/`, `tools/`
and the v2 harness `bench/leansphincs/{scenario,registry,schema,sweep,
validate,models}.py` are never edited on `leansphincs-v3`
(`models.py` is imported, not edited).

## 2. Append-only rules for the shared files

Nothing in a shared file is renamed, removed, re-typed or re-ordered.

- **`spec.py`**: a new setting is a new field appended at the end of its group
  dataclass (or a new group appended at the end of `RunSpec`, before
  `candidate_label`), with `_f(default, kind, doc-with-source, ...,
  acts_in=...)`. `tests/v3/test_spec.py` checks that the S0 keys survive in
  order, so an append needs no test edit. If two stages append to the same
  group, the merge conflict is two adjacent additions: keep both.
  S0 already has the settings arch.md names for every stage; prefer them.
- **`state.py`**: never add a column to `TxTable`/`NodeTable` or a counter
  here. Register at construction time instead:
  `ctx.txs.add_column("<owner>.<name>", default)`,
  `ctx.nodes.add_column(...)`, `ctx.counters.array("<owner>.<name>", n)`,
  `ctx.counters.scalar(...)`. Owners: `links topo el mempool cl demand
  prover slot deploy metrics runner test`.
- **Event kinds**: `ctx.on("<owner>.<name>", handler)`; a handler takes the
  payload only (`handler(payload)`). Duplicate kinds raise. Payloads are
  small tuples. Lazy cancellation by version numbers, never heap deletion.
- **Hooks** (`state.HOOK_NAMES`, frozen): cross-module calls wired by the
  deployment plug-in in S3. A producer calls `ctx.hooks.<name>(...)`; until
  wired it raises. In S2 tests, wire what you need with
  `ctx.hooks.wire(name, fn)`:

  | hook | producer -> consumer | signature |
  |---|---|---|
  | `tx_born` | demand -> deploy | `(tx)` |
  | `el_body_received` | elgossip -> deploy | `(node, rule_name, obj, src)` |
  | `cl_first_receipt` | clgossip -> slot | `(node, topic, msg_id, src)` |
  | `payload_canonical` | slot -> all | `(slot, payload)` |
  | `payload_missed` | slot -> all | `(slot, payload)` |
  | `object_bytes` | elgossip -> deploy | `(rule_name, obj) -> int` |

- **Parameters**: model code never indexes the JSON files. Bind a name to a
  JSON path in **your own module** and register it at import:

  ```python
  from starksim.v3 import params as P
  P.register_bindings({
      "eth68_arrive_timeout_ms": (P.NET, ("el_gossip", "geth.fetcher",
                                          "txArriveTimeout"), None),
  })
  ...
  ctx.params.value("eth68_arrive_timeout_ms")   # 500, recorded with status
  ```

  Paths are tuples (some keys contain dots). `None` = required; an `(value,
  source)` default is used with status `A` when the leaf is absent (say so in
  your notes). Deployment constants: `ctx.params.constant_value(NAME)`.
  Optional sections of `deployments_v3.json` (`tx_shapes`, `forks`,
  `deployments`, `assumptions`; present since schema 2):
  `ctx.params.deployment_entry(id)` and `ctx.params.fork(name)` return an
  entry with its `inherits` chain merged; `ctx.params.section(name)` raises
  `MissingSection` with a clear message while they are not written; catch it
  only to fall back to a documented `[A]` default.
- **`deploy.py`**: `Deployment`, `TxShape`, `Admission`, `Payload`,
  `REGISTRY`, `PBS_OF` are frozen. S3a and S3b subclass `Deployment` in their
  own files.

## 3. Coding rules (enforced by `tests/v3/test_rules.py` on every v3 file)

1. Standard library, `starksim`, `bench` imports only (Pyodide).
2. No `math.log/exp/pow/cos/...`, no `**`: use `detmath.ln/exp/power/
   cos2pi`; integer powers by multiplication or shifts.
3. No `random.expovariate/gammavariate/gauss/...` and no module-level
   `random.*()`: draw from `ctx.stream(purpose, *keys)` with `detmath`
   variates (`exponential`, `normal`, `lognormal`, `gamma`, `geometric`,
   `poisson`). Key every stream by identity (slot, tx, node), never by draw
   order (common random numbers, arch.md 3.13).
4. No wall clock, `id()` or `hash()` in model code.
5. No iteration over a set (order of strings depends on PYTHONHASHSEED):
   `sorted(...)` first. Dict order is insertion order and is fine.
6. A numeric literal other than 0, 1, 2, 0.5, 1000 needs a `# [tag] source`
   comment on its line (`[E] eip-8141.md:37`, `[R] geth tx_fetcher.go:53`,
   `[A] reason`), or comes from params/spec.

Times are ms (floats); sizes bytes (ints); rates bytes per ms.

## 4. What S1 provides (use it, don't re-implement)

- `Topology.build(spec, params)`: `nodes` (`NodeTable`), `n` simulated nodes
  then `builders`, `latency(u, v)` one-way ms (symmetric, memoised),
  `nodes.el_peers[n]` (EL graph), `nodes.cl_mesh[n]` (shared non-column
  gossipsub mesh), `stats`. `topology.build_mesh(members, targets, rng)` for
  column subnets.
- `Links(ctx, topo, lane_weights, background_mbps)`:
  `send(src, dst, lane, kind, size, on_deliver, arg)`,
  `send_at(t, ...)`, `load(node, lane, kind, size)` (fluid bytes, no
  delivery), `control(src, dst, kind, size, on_deliver, arg)` (latency only),
  `cancel(node, lane, predicate(kind, dst, arg)) -> bytes`,
  `backlog(node, lane)`, `settle_all()`, `background_bytes(node, t0, t1)`,
  `kind_bytes`, `kind_cancelled`; `ServingBudget(node_Bps, peer_Bps)
  .reserve(node, peer, now, size) -> t_ready`; counters `links.*`.
- `testkit`: `context(deployment, sets)` builds a campaign topology and
  links; `FixedTopology(n, el_edges, cl_edges, latency_ms, up_mbps,
  down_mbps)` with `line(n)`, `ring(n)`, `star(n)`, and `fixed_context(topo)`
  for analytic tests.

## 5. Checks every stage runs before committing

```
python3 -m unittest discover -s tests       # upstream + fork + v3 (all)
python3 -m unittest discover -s tests/v3    # v3 only, < 60 s
```

One commit per stage on `leansphincs-v3`, worked in `sims/wt-v3-<stage>`;
never on `leansphincs`; never push. Merge order into `leansphincs-v3` is any
order: S2 stages touch disjoint files.

## 6. The S5 entry points (runner, timeline, elasticity, sweep; stable from S5)

The browser engine (`web-v3/src/lsweb3.py`) and the CLI call only these.
Rows are S4's `metrics.ROW_COLUMNS` (228 columns, validated); no wall-clock
value is in a row, so one spec at one commit gives byte-identical
`runner.row_json(row)`.

```python
from starksim.v3 import params as P, spec as S, runner, timeline, elasticity, sweep3
params = P.default_params().fresh()
spec = S.resolve(params, deployment, step=None, sets={"dotted.key": value})   # SpecError on bad input
row, ctx = runner.execute(spec, params, until_extra_slots=1, prepare=None)    # prepare(ctx): before scheduling
row = runner.run(spec, params)                     # execute(...)[0]
text = runner.row_json(row)                        # json.dumps(row, indent=1, allow_nan=False)
ctx.run_info                                       # NOT row: build_s_measured, run_s_measured,
                                                   # wall_s_measured, events, events_per_s_measured,
                                                   # events_per_pq_tx_per_node, offered_pq_tps,
                                                   # bounds_tps, binding_counts, slot_counters,
                                                   # deploy_counters, input_status
records = ctx.slot.slot_records()                  # metrics.SlotRecord per decided slot
runner.code_commit()                               # env LEANSPHINCS_CODE_COMMIT, else .git, else "unknown"

# CLI argv -> sets (unchanged): bench.leansphincs.cli3.run_parser(), cli3.sets_from(args)

tl = timeline.load(path)                           # dict, validated (TimelineError)
pts = timeline.points(tl, branch=None, points_per_step=None, sets=None, variant=None,
                      params=None, hour="mean")    # hour: mean | peak | 0-23 (diurnal demand)
    # -> [timeline.Point(step, branch, month, weight_months, deployment, sets, variant)]
    #    branch None = both I* branches; H* points have branch None
recs = timeline.run_path(tl, params, branch=None, nodes=None, seeds=(0,),
                         points_per_step=None, sets=None, variant=None,
                         jobs=1, cache=None, progress=None, hour="mean")
    # -> list of dicts, each one JSONL line of data/phase4/runs/*.jsonl:
    #    {"record": "point", "timeline": {"step", "branch", "month", "variant"}, "seed", "weight_months", "row"}
    #    {"record": "step",  "timeline": {"step", "branch"}, "months", "means": {...}, "binding": {...}}
    #    {"record": "path",  "timeline": {"branch"}, "months", "means": {...}}
    #    {"record": "branch_diff", ...} when both branches ran
rec = elasticity.estimate(sets, params, deployment, input="sig_bytes"|"perms",
                          seeds=(0, 1, 2), h=0.1, resource=None, metric="pq_tps",
                          jobs=1, cache=None, level=0.95, resource_rule=None)
att = elasticity.attribute(sets, params, deployment, seeds=(0, 1, 2), h=0.1,
                           metric="pq_tps", jobs=1, cache=None, level=0.95, knobs=None)
    # -> {"record": "elasticity", "input", "h", "resource", "s_pq", "eps_supply", "eps_fair",
    #     "per_seed", "base_offered_pq_tps", ...}; eps_* = {"mean","sd","ci_lo","ci_hi","seeds","level"}
rows = sweep3.run_specs(specs, params, jobs=1, cache=None, progress=None, nice=10)
    # rows in input order; <= 8 workers at nice 10; cache key = (spec_hash, code fingerprint)
```

Pinned in `tests/v3/test_state.py::EXTENDED_SIGNATURES`. `variant` (a dict, recorded in each point record): `candidate`, `gas_limit`,
`pq_share` ("default"), `sig_route` (leanPCS points), `dep_cap`.

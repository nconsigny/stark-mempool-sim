"""Demand: arrivals, tx mix, fees, EIP-1559 base fee, ECDSA background.

Stage S2c (arch.md 3.7, 3.13; STAGES.md S2c). Design notes and evidence:
`notes/phase4/build-s2c.md`.

Arrivals. Two compound processes share one slot rate factor:
    G_s ~ Gamma(r, 1/r) from ctx.stream("arrivals", slot)   (1 if not bursty)
    PQ   : Poisson(pq_tps    x slot_s x G_s / E[B]) batches, ("arrivals", "pq", slot)
    ECDSA: Poisson(ecdsa_tps x slot_s x G_s / E[B]) batches, ("arrivals", "ecdsa", slot)
Batch sizes B ~ Geometric(p) (mean 1/p = 1.67), batch times uniform in the
slot, so a slot carries rate x slot_s txs on average and the per-slot count
has index of dispersion E[B^2]/E[B] + mean/r. The superposition of the two
equals the single process of the params `draw` rule (same batch law); keeping
them apart makes the ECDSA arrivals identical across arms that change only
the offered PQ rate (the saturate monotone check). r: by default the
**included-tx** fit (5.13, from the chain's per-block count dispersion 56.4,
calibration in build-s2c.md); `burst_r="raw"` uses the mempool first-seen
fit (1.4), which counts spam and replacements and fills 12-17 % of today's
blocks to the limit against about 1 % measured.

Identity. Arrival j of a process in slot s is keyed ("<proc>", s, j): mix
("mix", proc, s, j), fee ("fee", proc, s, j), entry ("entry", proc, s, j),
shape draws of ECDSA ("ecdsa_shape", s, j). Nothing depends on draw order
or on another tx, so two arms that differ in sig_bytes/perms share every
arrival, kind, tip, fee-cap multiple and entry node (common random numbers,
arch.md 3.13). Tx ids are birth order (TxTable), equal across such arms.

Fees (kind-blind, per gas). Every tx, PQ or ECDSA, draws its effective tip
(wei per gas) and fee-cap multiple m from the same empirical distributions
(demand.fee_willingness [M]); fee_cap = max(base_fee_at_birth x m,
base_fee_at_birth + tip). Builders rank by tip per gas, so under saturation
the fee market rations gas, not txs: each kind loses the share of its gas
that bids below the clearing tip, and a PQ tx is no more likely to be priced
out than an ECDSA tx with the same tip (it pays gas_PQ/gas_ECDSA times more).
`fee_basis="per_tx"` (sensitivity) divides the tip and the headroom by
gas/gas_ref: users value a tx, not gas, and heavy txs are priced out first;
it breaks tip CRN across sig_bytes arms by construction.

Modes. saturate: base fee frozen (on_payload is a no-op); load: EIP-1559
per canonical payload (exact integer rule of the EIP).

ECDSA background. explicit: individual ECDSA txs (gas and size drawn
independently from the [M] histograms) in ctx.txs. fluid: the same arrivals
and draws, held as records in a capped pending set; background_offer(slot)
bins them by effective tip at the current base fee (best first);
background_included(slot, gas) removes what a canonical payload took, best
first; records packed by a payload still awaiting its canonical decision are
not offered to a builder that builds on it (background_offer `undecided`);
background_tick_bytes gives the eth/68 gossip bytes per tick.
"""

import math

from starksim.v3 import detmath
from starksim.v3 import params as P
from starksim.v3.state import (KIND_ECDSA, KIND_NAMES, KIND_PCS, KIND_PQ1,
                               KIND_PQK, ROUTE_PUBLIC)

# Event kinds S2c registers (owner prefix "demand."):
EV_SLOT_ARRIVALS = "demand.slot_arrivals"   # generate one slot's births
EV_BIRTH = "demand.birth"                   # one tx (or batch) is born

PROC_PQ = "pq"
PROC_ECDSA = "ecdsa"

GWEI = 1_000_000_000      # [E] wei per gwei (unit definition)
MS_PER_S = 1000

P.register_bindings({
    "demand_eip1559": (P.NET, ("demand", "eip1559"), None),
    "demand_burst_r_raw": (
        P.NET, ("demand", "arrival_burstiness", "slot_count_negbin_r"), None),
    "demand_burst_r_included": (
        P.NET, ("demand", "arrival_burstiness", "included_negbin_r"),
        (5.13, "[Mo] r = mean/(D - E[B^2]/E[B]) = 277.22/(56.41 - 2.333) on "  # [Mo] build-s2c.md 2
               "chain_baseline.json day.tx_count_index_of_dispersion 56.41 "
               "and tx_per_block.mean 277.22 [M] (7,200 blocks 2026-11-11); "
               "notes/phase4/build-s2c.md section 2")),
    "demand_batch_p": (
        P.NET, ("demand", "arrival_burstiness", "batch_geometric_p"),
        (0.6, "demand.arrival_burstiness.slot_count_negbin_r.draw text: "  # [Mo] params draw text
              "'batches of Geometric(p=0.6) txs (mean 1.67, from the "
              "zero-gap share)' [Mo]")),
    "demand_tx_per_s_included": (
        P.NET, ("traffic_baseline", "tx_per_s_included"), None),
    "demand_base_fee_gwei": (P.NET, ("traffic_baseline", "base_fee_gwei"),
                             None),
    "demand_tip_gwei": (
        P.NET, ("demand", "fee_willingness", "effective_tip_gwei"), None),
    "demand_tip_zero_share": (
        P.NET, ("demand", "fee_willingness", "effective_tip_zero_share"),
        None),
    "demand_fee_cap_multiple": (
        P.NET, ("demand", "fee_willingness", "fee_cap_over_base_fee"), None),
    "demand_ecdsa_gas": (P.NET, ("traffic_baseline", "gas_used_per_tx"),
                         None),
    "demand_ecdsa_gas_histogram": (
        P.NET, ("traffic_baseline", "gas_used_per_tx_histogram"), None),
    "demand_ecdsa_bytes": (P.NET, ("traffic_baseline", "tx_size_bytes"),
                           None),
    "demand_ecdsa_bytes_histogram": (
        P.NET, ("traffic_baseline", "tx_size_histogram"), None),
    "demand_push_max_bytes": (
        P.NET, ("el_gossip", "geth.handler", "txMaxBroadcastSize"), None),
    "demand_pool_slots": (
        P.NET, ("el_gossip", "geth.legacypool", "GlobalSlots"), None),
})

QUANTILE_KEYS = (("p5", 0.05), ("p10", 0.1), ("p25", 0.25),  # [E] key names
                 ("p50", 0.5), ("p75", 0.75), ("p90", 0.9),  # [E] key names
                 ("p95", 0.95), ("p99", 0.99))  # [E] key names
# Elastic demand: the potential process is this many times the level, so the
# born rate can rise to 4 x level when the base fee falls (eta > 0 only).
ELASTIC_HEADROOM = 4.0    # [A] build-s2c.md section 3 (no data on induced demand)
TODAY_ELASTICITY = 0.5    # [A] build-s2c.md section 3: holds today's base fee near its median; 0.5-2 give the same included rate
TIP_BINS_PER_OCTAVE = 4   # [A] offer bins ~19 % wide (one EIP-1559 step 12.5 %)


# ---------------------------------------------------------------- EIP-1559
def eip1559_next(base_fee, gas_used, gas_target, denominator):
    """Next base fee (integer wei) by the EIP-1559 rule, integer
    arithmetic exactly as the EIP's reference code (eip-1559.md, the
    `validate_block` base-fee branch; the fork-block branch is not modelled).
    gas_target 0 (no gas limit) leaves the base fee unchanged."""
    base_fee = int(base_fee)
    gas_used = int(gas_used)
    gas_target = int(gas_target)
    denominator = int(denominator)
    if gas_target <= 0 or gas_used == gas_target:
        return base_fee
    if gas_used > gas_target:
        delta = max(base_fee * (gas_used - gas_target) // gas_target
                    // denominator, 1)
        return base_fee + delta
    delta = base_fee * (gas_target - gas_used) // gas_target // denominator
    return base_fee - delta


# ------------------------------------------------------- empirical draws
class LogLinearQuantiles:
    """Inverse CDF through knots (u_i, x_i), log-linear in x between knots
    (the params' draw rule for tips, gas and sizes); x_i > 0. Optionally the
    last knot's x is lowered so the distribution's mean equals `mean`
    (histograms with a wide top bin over-state the mean otherwise)."""

    def __init__(self, knots, mean=None):
        knots = [(float(u), float(x)) for u, x in knots]
        for (u0, x0), (u1, x1) in zip(knots, knots[1:]):
            if not (u1 > u0 and x1 >= x0 > 0.0):
                raise ValueError(f"knots not increasing: {knots}")
        self.knots = knots
        self.top_adjusted = False
        if mean is not None and self.mean() > mean:
            self._fit_top(mean)

    def __call__(self, u):
        knots = self.knots
        if u <= knots[0][0]:
            return knots[0][1]
        for (u0, x0), (u1, x1) in zip(knots, knots[1:]):
            if u <= u1:
                if x0 == x1:
                    return x0
                f = (u - u0) / (u1 - u0)
                return detmath.exp(detmath.ln(x0)
                                   + f * (detmath.ln(x1) - detmath.ln(x0)))
        return knots[-1][1]

    def mean(self):
        """Exact mean: mass below the first knot sits at x_0; a segment is
        log-uniform, mean (x1 - x0) / ln(x1 / x0)."""
        knots = self.knots
        total = knots[0][0] * knots[0][1]
        for (u0, x0), (u1, x1) in zip(knots, knots[1:]):
            if x1 == x0:
                total += (u1 - u0) * x0
            else:
                total += (u1 - u0) * (x1 - x0) / (detmath.ln(x1)
                                                  - detmath.ln(x0))
        return total

    def _fit_top(self, mean):
        u_top, x_top = self.knots[-1]
        low = self.knots[-2][1]
        self.knots[-1] = (u_top, low)
        if self.mean() > mean:
            raise ValueError(f"mean {mean} unreachable by lowering the top "
                             f"knot (minimum {self.mean()})")
        high = x_top
        for _ in range(80):    # [A] bisection steps (2^-80 relative)
            mid = 0.5 * (low + high)
            self.knots[-1] = (u_top, mid)
            if self.mean() > mean:
                high = mid
            else:
                low = mid
        self.knots[-1] = (u_top, low)
        self.top_adjusted = True


def quantile_knots(leaf_value, lower=None, upper_key="max"):
    """Knots from a {p5..p99, max} quantile leaf: (0, lower) if given, the
    p-keys present, then (1, max)."""
    knots = []
    if lower is not None:
        knots.append((0.0, lower))
    for key, u in QUANTILE_KEYS:
        if key in leaf_value:
            knots.append((u, leaf_value[key]))
    if upper_key in leaf_value:
        knots.append((1.0, leaf_value[upper_key]))
    return knots


def histogram_knots(cumulative, lower):
    """Knots from a {edge: cumulative share <= edge} histogram (keys may be
    '<128'-style strings): (share_at_lowest_edge, edge) ... with the mass
    below the first edge spread log-linearly from `lower`."""
    rows = []
    for key, share in cumulative.items():
        rows.append((float(str(key).lstrip("<")), float(share)))
    rows.sort()
    knots = [(0.0, lower)]
    for edge, share in rows:
        if edge > knots[-1][1] and share > knots[-1][0]:
            knots.append((share, edge))
        elif edge == knots[-1][1]:
            knots[-1] = (share, edge)
    return knots


def merged_knots(quantile_leaf, cumulative):
    """Knots of a quantile leaf (p5..p99, max; exact at its quantiles)
    refined by a cumulative histogram's edges where they keep both u and x
    increasing (the histogram adds shape between the quantiles, e.g. the
    push-limit share at 4,096 B); mass below the first quantile sits at it
    (no invented lower bound; review: size p10 was 95.9 vs 114.5)."""
    knots = quantile_knots(quantile_leaf)
    for u, x in histogram_knots(cumulative, knots[0][1]):
        if u <= 0.0:
            continue
        below = [k for k in knots if k[0] < u]
        above = [k for k in knots if k[0] > u]
        if any(k[0] == u for k in knots):
            continue
        if below and below[-1][1] > x:
            continue
        if above and above[0][1] < x:
            continue
        knots = below + [(u, x)] + above
    # Equal x at increasing u (atoms, e.g. 21,000 gas at p5..p25) is kept;
    # strictly decreasing u never occurs after the filter above.
    return knots


def _open_unit(rng):
    while True:
        u = rng.random()
        if u > 0.0:
            return u


# ------------------------------------------------------------------ Demand
class Demand:
    def __init__(self, ctx, deploy, burst_r="included", fee_basis=None,
                 base_fee_wei=None, price_elasticity=None):
        """`deploy` supplies tx_shape(kind, k). Registers counters
        `demand.*` (born by kind, offered bytes and gas).

        burst_r: "included" (default, r fitted to included txs per block),
        "raw" (mempool first-seen counts, 1.4) or a number.
        fee_basis: "per_gas" (default) or "per_tx"; None reads
        spec.demand.fee_basis when that key exists (proposed in the inbox).
        base_fee_wei: initial base fee; None = today's median [M].
        price_elasticity: eta >= 0 of a constant-elasticity demand curve
        around the reference base fee b_ref (today's median [M]): in load
        mode an arrival is born with probability
        min(H, (b / b_ref)^-eta) / H, H = ELASTIC_HEADROOM, out of a potential
        process ELASTIC_HEADROOM times the level (thinning by a keyed
        uniform per batch: two arms share the uniform, but the threshold
        follows the base fee, so arms whose base-fee paths differ (load
        mode with sig_bytes arms) do NOT keep identical arrivals; review
        R3). 0 (inelastic): the level is the born rate.
        None reads spec.demand.price_elasticity when present, else
        TODAY_ELASTICITY for deployment `today` (a stationary base fee near
        today's median) and 0 for the PQ deployments (the timeline's
        demand_tps stays the born rate; induced demand has no data)."""
        self.ctx = ctx
        self.deploy = deploy
        spec = ctx.spec
        self.spec = spec
        params = ctx.params
        self.slot_ms = float(spec.chain.slot_ms)
        self.saturate = spec.demand.mode == "saturate"
        eip = params.value("demand_eip1559")
        self.elasticity = int(eip["ELASTICITY_MULTIPLIER"])
        self.denominator = int(eip["BASE_FEE_MAX_CHANGE_DENOMINATOR"])
        if burst_r == "included":
            self.r = float(params.value("demand_burst_r_included"))
        elif burst_r == "raw":
            self.r = float(params.value("demand_burst_r_raw"))
        else:
            self.r = float(burst_r)
        self.bursty = bool(spec.demand.burstiness)
        self.batch_p = float(params.value("demand_batch_p"))
        self.mean_batch = 1.0 / self.batch_p
        if fee_basis is None:
            fee_basis = getattr(spec.demand, "fee_basis", None) or "per_gas"
        if fee_basis not in ("per_gas", "per_tx"):
            raise ValueError(f"fee_basis {fee_basis!r}: per_gas or per_tx")
        self.fee_basis = fee_basis
        if price_elasticity is None:
            # The spec key exists since the S3a shared patch; its None
            # means "the deployment default" (lead fix: getattr returned
            # the None itself).
            price_elasticity = getattr(spec.demand, "price_elasticity", None)
        if price_elasticity is None:
            price_elasticity = (TODAY_ELASTICITY
                                if spec.deployment == "today" else 0.0)
        if price_elasticity < 0:
            raise ValueError("price_elasticity must be >= 0")
        self.eta = 0.0 if self.saturate else float(price_elasticity)
        self.headroom = ELASTIC_HEADROOM if self.eta > 0 else 1.0
        self.included_tps = float(params.value("demand_tx_per_s_included"))
        self.base_fee_ref = int(round(
            params.value("demand_base_fee_gwei")["p50"] * GWEI))
        if base_fee_wei is None:
            base_fee_wei = self.base_fee_ref
        self._base_fee = int(base_fee_wei)
        # Fee willingness [M]: effective tip (gwei) with a zero atom; fee-cap
        # multiple m >= 1 (p0 = 1: fee_cap >= base fee at inclusion).
        tip_leaf = params.value("demand_tip_gwei")
        self.tip_zero = float(params.value("demand_tip_zero_share"))
        tip_knots = [(u, x) for u, x in quantile_knots(tip_leaf)
                     if u > self.tip_zero]
        self.tip_gwei = LogLinearQuantiles(
            [(self.tip_zero, tip_knots[0][1])] + tip_knots,
            mean=tip_leaf.get("mean"))
        self.fee_multiple = LogLinearQuantiles(quantile_knots(
            params.value("demand_fee_cap_multiple"), lower=1.0))
        # ECDSA shapes [M]: gas and raw size, drawn independently (the leaves
        # describe one population but are not jointly sampled).
        gas_leaf = params.value("demand_ecdsa_gas")
        self.ecdsa_gas = LogLinearQuantiles(merged_knots(
            gas_leaf, params.value("demand_ecdsa_gas_histogram")),
            mean=gas_leaf["mean"])
        bytes_leaf = params.value("demand_ecdsa_bytes")
        self.ecdsa_bytes = LogLinearQuantiles(merged_knots(
            bytes_leaf, params.value("demand_ecdsa_bytes_histogram")),
            mean=bytes_leaf["mean"])
        self.gas_ref = float(gas_leaf["mean"])
        self.push_max = int(params.value("demand_push_max_bytes"))
        self.announce_bytes = int(params.constant_value(
            "eth68_announcement_bytes_per_tx"))
        self.pool_cap = int(params.value("demand_pool_slots"))
        self._bg_split = None
        # Run state.
        self.background = spec.demand.background
        self.pq_tps = 0.0
        self.ecdsa_tps = 0.0
        self.n_slots = 0
        self.slot_factor = {}
        self._shape_memo = {}
        self._pending = []        # fluid records [eff-tip key, ...]
        self._offers = {}         # slot -> record order of the last offer
        self._n_sim = (ctx.topo.n if ctx.topo is not None else ctx.nodes.n)
        counters = ctx.counters
        self.born = counters.array("demand.born", len(KIND_NAMES))
        self.offered_gas = counters.array("demand.offered_gas",
                                          len(KIND_NAMES))
        self.offered_bytes = counters.array("demand.offered_bytes",
                                            len(KIND_NAMES))
        for name in ("bg_born", "bg_gas_born", "bg_bytes_born",
                     "bg_included", "bg_gas_included", "bg_evicted",
                     "bg_gas_evicted", "priced_out", "bg_undecided_skipped",
                     "bg_gas_undecided_skipped"):
            counters.scalar("demand." + name)
        ctx.on(EV_SLOT_ARRIVALS, self._on_slot)
        ctx.on(EV_BIRTH, self._on_birth)
        ctx.demand = self

    # -------------------------------------------------------- scheduling
    def schedule(self, n_slots, offered_pq_tps, ecdsa_tps,
                 ecdsa_proportional=True):
        """Schedule births over slots 0..n_slots-1. Each birth appends a row
        to ctx.txs (TxTable.add) and calls ctx.hooks.tx_born(tx).

        A None rate takes the spec's: load mode splits level_tps (None =
        traffic_baseline.tx_per_s_included [M]) by pq_share; saturate mode
        needs offered_pq_tps and takes ecdsa_tps from spec.demand.ecdsa_tps
        (None = the included rate [M]).

        Saturate mode offers ECDSA at ecdsa_tps x saturate_factor when
        `ecdsa_proportional` (default): with kind-blind tips both kinds are
        then rationed by one clearing tip at 1/f, so the base point
        includes the residual-gas bound of PQ and all of ecdsa_tps whatever
        f is (build-s2c.md section 4). False offers ecdsa_tps as is: the
        excess PQ then displaces ECDSA and the included PQ rate grows with
        f (1.054 of the bound at f = 1.5, 1.085 at 2)."""
        demand = self.spec.demand
        if self.saturate:
            if offered_pq_tps is None:
                raise ValueError("saturate mode: offered_pq_tps is required "
                                 "(saturate_factor x analytic bound)")
            if ecdsa_tps is None:
                ecdsa_tps = (demand.ecdsa_tps if demand.ecdsa_tps is not None
                             else self.included_tps)
            if ecdsa_proportional:
                ecdsa_tps = ecdsa_tps * demand.saturate_factor
        else:
            level = (demand.level_tps if demand.level_tps is not None
                     else self.included_tps)
            if offered_pq_tps is None:
                offered_pq_tps = level * demand.pq_share
            if ecdsa_tps is None:
                ecdsa_tps = level * (1.0 - demand.pq_share)
        if offered_pq_tps < 0 or ecdsa_tps < 0:
            raise ValueError("rates must be >= 0")
        self.pq_tps = float(offered_pq_tps)
        self.ecdsa_tps = float(ecdsa_tps)
        self.n_slots = int(n_slots)
        for slot in range(self.n_slots):
            self.ctx.at(slot * self.slot_ms, EV_SLOT_ARRIVALS, slot)

    def slot_batches(self, slot, process, tps):
        """[(born_ms, n_txs, batch), ...] of one process in one slot, time
        order (pure: depends only on seed, slot, process, rate and r).

        Batch i takes three draws in a fixed stream position: an Exp(1)
        gap in operational time, its time in the slot and its size; batches
        whose cumulative gap stays below the expected batch count are born
        (a Poisson count, exactly). A higher rate only appends batches, so
        arms that differ in the offered rate share every common batch
        (nested arrivals; review R2)."""
        factor = self.rate_factor(slot)
        mean_txs = tps * self.slot_ms / MS_PER_S * factor * self.headroom
        if mean_txs <= 0.0:
            return []
        mean_batches = mean_txs / self.mean_batch
        rng = self.ctx.stream("arrivals", process, slot)
        batches = []
        start = slot * self.slot_ms
        clock = 0.0
        batch = 0
        while True:
            clock += detmath.exponential(rng, 1.0)
            if clock > mean_batches:
                break
            born = start + rng.random() * self.slot_ms
            size = detmath.geometric(rng, self.batch_p)
            batches.append((born, size, batch))
            batch += 1
        batches.sort()
        return batches

    def rate_factor(self, slot):
        """G_s: the slot's Gamma(r, 1/r) rate factor (1 when not bursty)."""
        if not self.bursty:
            return 1.0
        factor = self.slot_factor.get(slot)
        if factor is None:
            factor = detmath.gamma(self.ctx.stream("arrivals", slot),
                                   self.r, 1.0 / self.r)
            self.slot_factor[slot] = factor
        return factor

    def _on_slot(self, slot):
        for process, tps in ((PROC_PQ, self.pq_tps),
                             (PROC_ECDSA, self.ecdsa_tps)):
            for born, size, batch in self.slot_batches(slot, process, tps):
                self.ctx.at(born, EV_BIRTH, (process, slot, batch, size))

    def _on_birth(self, payload):
        """A batch is born: its txs are arrivals (slot, (batch, m)). Price
        elasticity thins whole batches (keyed by the batch), which keeps
        the Geometric batch law of the born process (review R5)."""
        process, slot, batch, size = payload
        accept = self.accept_probability()
        if (accept < 1.0 and self.ctx.fraction("accept", process, slot, batch)
                >= accept):
            self.ctx.counters.scalars["demand.priced_out"] += size
            return
        for member in range(size):
            index = (batch, member)
            if process == PROC_PQ:
                self._birth_pq(slot, index)
            elif self.background == "explicit":
                self._birth_ecdsa_explicit(slot, index)
            else:
                self._birth_ecdsa_fluid(slot, index)

    def accept_probability(self):
        """Share of potential arrivals born at the current base fee (1 when
        inelastic)."""
        if self.eta <= 0.0:
            return 1.0
        ratio = max(self._base_fee, 1) / self.base_fee_ref
        return min(self.headroom,
                   detmath.power(ratio, -self.eta)) / self.headroom

    # ------------------------------------------------------------- births
    def pq_kind(self, slot, index):
        """(kind, k) of PQ arrival (slot, index) from ("mix", "pq", ...):
        u < pcs_share -> PCS claim (leanpcs), u < pcs + multisig -> k-of-n
        multisig, else single-signer (spec.k)."""
        demand = self.spec.demand
        pcs = demand.pcs_share if self.spec.deployment == "leanpcs" else 0.0
        multisig = demand.multisig_share
        if pcs + multisig > 1.0:
            raise ValueError("pcs_share + multisig_share > 1")
        u = self.ctx.stream("mix", PROC_PQ, slot, index).random()
        if u < pcs:
            return KIND_PCS, self.spec.k
        if u < pcs + multisig:
            return KIND_PQK, demand.multisig_k
        return KIND_PQ1, self.spec.k

    def fee_draw(self, process, slot, index):
        """(tip_gwei, m) of an arrival: kind-blind, per gas [M]."""
        rng = self.ctx.stream("fee", process, slot, index)
        u_tip = rng.random()
        u_cap = rng.random()
        tip = 0.0 if u_tip < self.tip_zero else self.tip_gwei(u_tip)
        return tip, self.fee_multiple(u_cap)

    def fees_at_birth(self, tip_gwei, multiple, gas):
        """(fee_cap, tip) in integer wei per gas at the current base fee."""
        base = self._base_fee
        scale = 1.0
        if self.fee_basis == "per_tx" and gas > 0:
            scale = self.gas_ref / gas
        tip = int(round(tip_gwei * GWEI * scale))
        headroom = int(round(base * (multiple - 1.0) * scale))
        fee_cap = base + max(headroom, tip)
        return fee_cap, tip

    def entry(self, process, slot, index):
        return min(int(self.ctx.fraction("entry", process, slot, index)
                       * self._n_sim), self._n_sim - 1)

    def sender(self, process, slot, index, tx):
        senders = self.spec.demand.senders
        if senders <= 0:
            return tx
        return min(int(self.ctx.fraction("sender", process, slot, index)
                       * senders), senders - 1)

    def shape(self, kind, k):
        key = (kind, k)
        shape = self._shape_memo.get(key)
        if shape is None:
            shape = self.deploy.tx_shape(kind, k)
            self._shape_memo[key] = shape
        return shape

    def ecdsa_shape(self, slot, index):
        """(gas, bytes) of ECDSA arrival (slot, index), from the [M]
        histograms, independently."""
        rng = self.ctx.stream("ecdsa_shape", slot, index)
        gas = int(round(self.ecdsa_gas(_open_unit(rng))))
        size = int(round(self.ecdsa_bytes(_open_unit(rng))))
        return gas, size

    def _add(self, process, slot, index, kind, k, bytes_wire, bytes_chain,
             gas, deps, verify_gas):
        txs = self.ctx.txs
        tip_gwei, multiple = self.fee_draw(process, slot, index)
        fee_cap, tip = self.fees_at_birth(tip_gwei, multiple, gas)
        tx = len(txs)
        txs.add(self.ctx.now(), kind, k, bytes_wire, bytes_chain, gas, deps,
                verify_gas, fee_cap, tip,
                self.sender(process, slot, index, tx),
                self.entry(process, slot, index), ROUTE_PUBLIC)
        self.born[kind] += 1
        self.offered_gas[kind] += gas
        self.offered_bytes[kind] += bytes_wire
        self.ctx.hooks.tx_born(tx)
        return tx

    def _birth_pq(self, slot, index):
        kind, k = self.pq_kind(slot, index)
        shape = self.shape(kind, k)
        self._add(PROC_PQ, slot, index, kind, k, shape.bytes_wire,
                  shape.bytes_chain, shape.gas, shape.deps, shape.verify_gas)

    def _birth_ecdsa_explicit(self, slot, index):
        gas, size = self.ecdsa_shape(slot, index)
        self._add(PROC_ECDSA, slot, index, KIND_ECDSA, 0, size, size, gas, 0,
                  0)

    # ------------------------------------------------- fluid background
    def _birth_ecdsa_fluid(self, slot, index):
        gas, size = self.ecdsa_shape(slot, index)
        tip_gwei, multiple = self.fee_draw(PROC_ECDSA, slot, index)
        fee_cap, tip = self.fees_at_birth(tip_gwei, multiple, gas)
        self._pending.append(_Background(tip, fee_cap, gas, size,
                                         self.ctx.now(), slot, index))
        scalars = self.ctx.counters.scalars
        scalars["demand.bg_born"] += 1
        scalars["demand.bg_gas_born"] += gas
        scalars["demand.bg_bytes_born"] += size
        if len(self._pending) > self.pool_cap:
            self._evict()

    def _order(self, base_fee):
        """Pending records includable at base_fee, best effective tip first
        (ties: older first, then identity), as (eff_tip, record)."""
        rows = []
        for record in self._pending:
            if record.fee_cap < base_fee:
                continue
            rows.append((min(record.tip, record.fee_cap - base_fee), record))
        rows.sort(key=lambda row: (-row[0],) + row[1].identity())
        return rows

    def _evict(self):
        """Pool full: drop the cheapest records (lowest tip, then the
        youngest), as geth discards the cheapest remote txs."""
        excess = len(self._pending) - self.pool_cap
        self._pending.sort(key=_Background.identity, reverse=True)
        self._pending.sort(key=_Background.cheapness)   # stable: youngest first
        scalars = self.ctx.counters.scalars
        for record in self._pending[:excess]:
            scalars["demand.bg_evicted"] += 1
            scalars["demand.bg_gas_evicted"] += record.gas
        del self._pending[:excess]

    def background_offer(self, slot, until_ms=None, undecided=()):
        """Fluid ECDSA demand offered to builders in `slot`:
        [(fee_bin_tip, count, gas, bytes), ...] best fee first, including
        what earlier slots left unincluded (capped at the pool size).

        Pending ECDSA born at or before `until_ms` (default: the slot's
        start) and includable at the current base fee (fee_cap >= base fee),
        binned by effective tip min(tip, fee_cap - base_fee) in bins of
        2^(1/4); a bin's tip is the gas-weighted mean effective tip of its
        members (exact revenue). [] under demand.background=explicit.
        Call background_included(slot, gas) for the canonical payload.

        `undecided`: (earlier_slot, bg_gas) of the payloads the builder
        builds on whose canonical decision is still pending (slot.py
        `undecided_payloads`, the same payloads as `undecided_cover`, oldest
        first). The records each of them packed (`background_packed`: the
        rule background_included will apply) are not offered: the builder
        builds on that parent, as for its PQ txs (`undecided_cover`). They
        stay pending, so they are offered again once that parent is
        orphaned or missed (ghost-ECDSA fix, verify-final.md section 2)."""
        if self.background != "fluid":
            return []
        if until_ms is None:
            until_ms = slot * self.slot_ms
        exclude = self.background_undecided(undecided)
        base = self._base_fee
        rows = [row for row in self._order(base) if row[1].born <= until_ms]
        if exclude:
            scalars = self.ctx.counters.scalars
            kept = []
            for row in rows:
                if row[1].identity() in exclude:
                    scalars["demand.bg_undecided_skipped"] += 1
                    scalars["demand.bg_gas_undecided_skipped"] += row[1].gas
                else:
                    kept.append(row)
            rows = kept
        self._offers[slot] = [row[1] for row in rows]
        for old in [s for s in self._offers if s < slot - 1]:
            del self._offers[old]    # offers of missed slots (review R6)
        bins = []
        key = None
        for eff, record in rows:
            if not bins or _tip_bin(eff) != key:
                key = _tip_bin(eff)
                bins.append([0, 0, 0, 0.0])
            count, gas, size, weighted = bins[-1]
            bins[-1] = [count + 1, gas + record.gas, size + record.size,
                        weighted + eff * record.gas]
        return [(weighted / gas if gas else 0.0, count, gas, size)
                for count, gas, size, weighted in bins]

    def background_packed(self, slot, gas, skip=None):
        """The records a payload of `slot` that packed `gas` of the fluid
        background took: in the order of that slot's offer, best first,
        records no longer pending (or in `skip`) passed over, whole records
        while their gas fits, the marginal one when at least half of it
        fits. The rule `background_included` applies; nothing is removed.
        Returns a list of records."""
        order = self._offers.get(slot)
        if not order or gas <= 0:
            return []
        pending = dict.fromkeys(r.identity() for r in self._pending)
        taken = []
        remaining = gas
        for record in order:
            ident = record.identity()
            if ident not in pending or (skip and ident in skip):
                continue        # included by another payload or evicted (R1)
            if 2 * remaining >= record.gas:
                taken.append(record)
                remaining -= record.gas
                if remaining <= 0:
                    break
            else:
                break
        return taken

    def background_undecided(self, undecided):
        """Identities of the pending records packed by the still-undecided
        payloads `undecided` ((earlier_slot, bg_gas), oldest first; a later
        payload's offer already left out an earlier one's records)."""
        exclude = {}
        for earlier, gas in undecided:
            for record in self.background_packed(earlier, gas, exclude):
                exclude[record.identity()] = None
        return exclude

    def background_included(self, slot, gas):
        """A canonical payload of `slot` packed `gas` of the fluid
        background: remove the records `background_packed(slot, gas)`
        names (best first in the order of that slot's offer). Returns
        (count, gas) removed."""
        taken = self.background_packed(slot, gas)
        self._offers.pop(slot, None)
        if not taken:
            return 0, 0
        drop = dict.fromkeys(r.identity() for r in taken)
        self._pending = [r for r in self._pending
                         if r.identity() not in drop]
        removed_gas = sum(r.gas for r in taken)
        scalars = self.ctx.counters.scalars
        scalars["demand.bg_included"] += len(taken)
        scalars["demand.bg_gas_included"] += removed_gas
        return len(taken), removed_gas

    def background_pending(self):
        """(count, gas, bytes) of fluid background in the pending set."""
        return (len(self._pending), sum(r.gas for r in self._pending),
                sum(r.size for r in self._pending))

    def background_tick_bytes(self, node, tick_ms):
        """Fluid ECDSA gossip bytes `node` sends on its EL lane per announce
        tick (arch.md 3.7 formula); 0 under demand.background=explicit.
        A per-node total over its d peers (arch.md writes it per peer, / d).
        lambda_bg(t) is the born rate: ECDSA rate x G_s x the elastic
        acceptance (review R4); 0 after the scheduled slots.

        lambda_bg(t) x tick_s x [ s_push x ceil(sqrt d) + (1 - q) x (d -
        ceil(sqrt d)) x A + q x (d x A + s_big) ], with lambda_bg the ECDSA
        rate times the current slot's rate factor, d the node's EL degree,
        A the eth/68 announcement bytes per tx (37), q the share of txs
        above the push limit (4,096 B: announced to all peers, the body
        served once), s_push the mean size of pushable txs times (1 - q),
        s_big the mean size of the others."""
        if self.background != "fluid" or self.ecdsa_tps <= 0.0:
            return 0.0
        degree = len(self.ctx.nodes.el_peers[node])
        if degree == 0:
            return 0.0
        q, small_mean, big_mean = self.background_size_split()
        push = int(math.ceil(math.sqrt(degree)))
        per_tx = ((1.0 - q) * (push * small_mean + (degree - push)
                               * self.announce_bytes)
                  + q * (degree * self.announce_bytes + big_mean))
        slot = int(self.ctx.now() // self.slot_ms)
        if slot >= self.n_slots:
            return 0.0
        rate = (self.ecdsa_tps * self.rate_factor(slot) * self.headroom
                * self.accept_probability() / MS_PER_S)
        return rate * tick_ms * per_tx

    def background_size_split(self):
        """(q, mean size <= push limit, mean size > push limit) of the ECDSA
        size distribution (exact log-uniform segment integrals)."""
        if self._bg_split is None:
            self._bg_split = _split_mean(self.ecdsa_bytes.knots,
                                         float(self.push_max))
        return self._bg_split

    # ------------------------------------------------------------- fees
    def base_fee(self):
        """Current base fee (wei per gas)."""
        return self._base_fee

    def on_payload(self, gas_used, gas_limit):
        """EIP-1559 update after a canonical payload (no-op when the base
        fee is frozen: demand.mode=saturate)."""
        if self.saturate:
            return self._base_fee
        self._base_fee = eip1559_next(self._base_fee, gas_used,
                                      int(gas_limit) // self.elasticity,
                                      self.denominator)
        return self._base_fee

    def user_cost_wei(self, tx, base_fee):
        """gas x (base_fee + min(tip, fee_cap - base_fee)) (arch.md 3.7)."""
        txs = self.ctx.txs
        tip = min(txs.tip[tx], txs.fee_cap[tx] - base_fee)
        return txs.gas[tx] * (base_fee + max(tip, 0))


class _Background:
    """One fluid ECDSA tx in the pending set (wei per gas, gas, bytes, ms,
    arrival identity)."""

    __slots__ = ("tip", "fee_cap", "gas", "size", "born", "slot", "index")

    def __init__(self, tip, fee_cap, gas, size, born, slot, index):
        self.tip = tip
        self.fee_cap = fee_cap
        self.gas = gas
        self.size = size
        self.born = born
        self.slot = slot
        self.index = index

    def identity(self):
        return (self.born, self.slot, self.index)

    def cheapness(self):
        return self.tip


def _tip_bin(tip):
    if tip <= 0:
        return -1
    return int(math.floor(detmath.ln(tip) / detmath.ln(2.0)
                          * TIP_BINS_PER_OCTAVE))


def _split_mean(knots, limit):
    """(P(X > limit), E[X; X <= limit] / P(X <= limit), E[X | X > limit])
    for a LogLinearQuantiles knot list."""
    def seg(u0, x0, u1, x1):
        if x1 == x0:
            return (u1 - u0) * x0
        return (u1 - u0) * (x1 - x0) / (detmath.ln(x1) - detmath.ln(x0))
    below_mass = knots[0][0]
    below_sum = knots[0][0] * knots[0][1]
    above_mass = 0.0
    above_sum = 0.0
    for (u0, x0), (u1, x1) in zip(knots, knots[1:]):
        if x1 <= limit:
            below_mass += u1 - u0
            below_sum += seg(u0, x0, u1, x1)
        elif x0 >= limit:
            above_mass += u1 - u0
            above_sum += seg(u0, x0, u1, x1)
        else:
            f = (detmath.ln(limit) - detmath.ln(x0)) / (detmath.ln(x1)
                                                        - detmath.ln(x0))
            um = u0 + f * (u1 - u0)
            below_mass += um - u0
            below_sum += seg(u0, x0, um, limit)
            above_mass += u1 - um
            above_sum += seg(um, limit, u1, x1)
    small = below_sum / below_mass if below_mass > 0 else 0.0
    big = above_sum / above_mass if above_mass > 0 else 0.0
    return above_mass, small, big

# v3 stages S2a-S2d: work orders

Refines `notes/phase4/arch.md` section 4 with what S0/S1 fixed. Read
`INTERFACES.md` first (ownership, append-only rules, hooks, parameter
binding, coding rules). Each stage: its own worktree off `leansphincs-v3`
(`git -C sims/stark-mempool-sim-v2 worktree add -b v3-<stage> ../wt-v3-<stage>
leansphincs-v3`), only the files listed, one commit, both test suites green.

Common facts for all four:

- Build a test world with `starksim.v3.testkit`: `context("8141",
  {"nodes": 200})` (campaign topology + links) or `FixedTopology(n,
  el_edges=line(n), latency_ms=..., up_mbps=..., down_mbps=...)` +
  `fixed_context(topo)` for analytic checks.
- The deployment plug-ins (S3) do not exist yet. Wire the hooks you need by
  hand in your tests (`ctx.hooks.wire("el_body_received", fn)`), exactly as
  S3 will: that wiring is part of your tests, not of your module.
- Parameters you need that are not in `params.BINDINGS`: bind them in your
  module with `params.register_bindings` (JSON paths below were read in
  `data/phase4/*.json` at S0; check them, the researchers are still editing).
  Several params leaves hold combined strings (`"4 / 8 / 8"`, `"8/6/12/6/0.7
  s"`): parse them in your module with a test, or bind the numeric twin if
  the parameter researcher adds one; never retype the number.
- Missing inputs (arch.md 6.3 "missing" rows) get a `(value, source)` default
  in your binding row; the run then reports them as status `A`.
- Acceptance numbers are [M]: give the command, the box load (`uptime`) and
  the output in your stage note `notes/phase4/build-<stage>.md`.
- Acceptance runs go in your test module behind an environment switch, so
  the default suite stays fast:
  `V3_ACCEPT=1 python3 -m unittest tests.v3.test_<module>.TestAcceptance`.

---

## S2a: EL gossip + mempool

**Files**: `starksim/v3/elgossip.py`, `starksim/v3/mempool.py`,
`tests/v3/test_elgossip.py`, `tests/v3/test_mempool.py`.

**Implement** the stub signatures (frozen in `tests/v3/test_state.py`):

- `eth68(params, spec)`, `eth73(params, spec)` -> `GossipRule` from bound
  parameters: `el_gossip / geth.handler / txMaxBroadcastSize` (4,096),
  `geth.fetcher / txArriveTimeout` (500), `txGatherSlack` (100),
  `maxTxRetrievals` (256), `maxTxRetrievalSize` (131,072), `txFetchTimeout`
  (5,000), `maxTxAnnounces` (4,096); deployments constants
  `eth68_announcement_bytes_per_tx` (37), `eth73_announce_tuple_bytes` (106),
  `eth73_announce_max_items` (64), `eth73_get_max_hashes` (32),
  `eth73_soft_response_limit` (2 MiB), `eth73_serving_budget_total`/
  `_per_peer` (32/8 MiB/s, use `links.ServingBudget`). eth/73 fetch wait and
  timeout: `deployments_v3.json deployments.8288.eth73.{fetch_wait_ms,
  fetch_timeout_ms}` (0 ms [PR], 5 s [A]); read them with
  `ctx.params.deployment_entry("8288")["eth73"]` (leanpcs inherits 8288).
- `ElGossip`: arch.md 3.4 algorithm. Announce tick per node
  (`spec.net.announce_tick_ms`, phase `ctx.fraction("phase", "el", node)`)
  sends **one** EL-lane chunk of `item_bytes x items` summed over peers; at
  its completion, per peer the first announcer is recorded and **one**
  `fetch_due` event per (node, object) at `arrival + wait_ms`; later
  announcers go to an alternates list (timeout -> next alternate). Requests
  are `links.control` (latency only); responses are `links.send` on the EL
  lane in chunks <= the byte cap, gated by the serving budget for eth/73.
  Push (size <= `push_max_bytes`) to `ceil(sqrt(peers))` peers chosen by
  `stable_fraction(seed, "push", node, peer, sender)` order. Bodies go to
  `ctx.hooks.el_body_received(node, rule, obj, src)`; sizes from
  `ctx.hooks.object_bytes(rule, obj)`. Known-hash sets as int bitsets.
  `spec.net.el_client_rules = "mixed"`: Reth share uses `round(sqrt(n))` and
  no wait (spec.md Q12).
- `reach_times(rule, obj)`: per-node first admission for a sample of objects
  (all objects when `n_total x objects <= 2e6`, else those with
  `ctx.fraction("reach", rule, obj) < share` chosen to stay under 2e6
  floats); the sample rule goes in the docstring (metrics, S4, reads it).
- `Cpu`: per-node `cores` parallel FIFO slots, earliest-free-core, one event
  per job end, `duration / spec.scale.cpu`. Cores and EVM gas/s per node
  class are missing from the params (arch.md 6.3): bind with `[A]` defaults
  (e.g. 4 cores home / 16 datacentre; 15 M gas/s VERIFY simulation from
  spec.md A11 [M-ext]) and say so.
- `Mempool`: arch.md 3.8. Capacity `el_gossip / geth.legacypool /
  GlobalSlots` x `txSlotSize` (5,120 x 32 KiB; a tx takes
  `ceil(bytes / txSlotSize)` slots); 32 log-spaced fee buckets; eviction
  from the lowest non-empty bucket, oldest first; an arrival below the floor
  when full is `UNDERPRICED`. `fee_order(node, base_fee)` by effective tip
  `min(tip, fee_cap - base_fee)`, ties by tx id.

**Tests** (arch.md row S2a, refined): push only <= 4,096 B, to exactly
`ceil(sqrt(d))` peers; one-hop fetch time on a `FixedTopology` pair =
tick phase + latency + 500 ms + RTT + transfer (exact); requests <= 256
hashes and <= 128 KiB; one request in flight per peer; timeout -> next
alternate; line of 10 nodes: t90 = 9 x hop time (exact on `line(10)`);
eviction drops the lowest bucket; underpriced refused; duplicate bodies
counted; same seed -> identical reach times.

**Acceptance** [M]: 1,000 nodes (campaign topology), 60 s of 8141 PQ txs at
50 tx/s (4,564-B P99r k=1 bodies via `object_bytes`; admission CPU from your
`[A]` EVM rate; hooks wired in the test): median over txs of t90 in 1.5-2.5 s
(prototype 1.75-2.06 s, arch.md 1.4) and <= 5 events per tx per node
(`ctx.engine.events_processed / txs / nodes`); wall time reported.

## S2b: CL gossip

**Files**: `starksim/v3/clgossip.py`, `tests/v3/test_clgossip.py`.

**Implement**: `ClGossip(ctx)` over `ctx.nodes.cl_mesh` (shared mesh for
`beacon_block`, `execution_payload`, `payload_attestation`,
`inclusion_list`) and per-subnet meshes for the 128
`data_column_sidecar_{i}` topics built with `topology.build_mesh(members,
targets, ctx.stream("topo", "column_mesh", i))` over subscribers (targets =
the nodes' `cl_D`). Custody: `CUSTODY_REQUIREMENT` 4, validators
`VALIDATOR_CUSTODY_REQUIREMENT` 8, supernodes (`nodes.is_supernode`) all
128, groups drawn by `stable_fraction(seed, "custody", node, j)`; parse
`cl_gossip / cl.spec / "CUSTODY_REQUIREMENT / VALIDATOR_CUSTODY_REQUIREMENT
/ SAMPLES_PER_SLOT"` (a string). Publish = full message on the CL lane to
every mesh peer; first receipt -> validation delay (2 ms beacon block [R v2];
`[A]` for others) -> forward to mesh peers except the sender and peers that
sent IDONTWANT; duplicates counted (copies and bytes). IDONTWANT: on first
receipt of a message >= 1,000 B (`v2_gossipsub.value.idontwant` / the
`measured_duplicates.draw` text; bind a number), if the node supports it
(adoption 0.95 dealt exactly with `topology.apportion/deal`), a
`links.control` of 40 B [A] to every mesh peer; at the peer
`links.cancel(peer, LANE_CL, predicate)` drops queued copies to that node and
it never enqueues one later. IHAVE/IWANT per arch.md 3.5 (heartbeat
`cl_heartbeat_ms`, `cl_D_lazy`, mcache 3 heartbeats). Columns: sidecar bytes
`blobs x (2,048 + 48) + 200` [Mo, arch.md 3.5; request the exact formula];
`net.columns=background` -> `links.load` chunks, no messages. Record
first-receipt times per message (flat list per message; one message per
topic per slot, so memory is small). Call `on_first_receipt` and
`ctx.hooks.cl_first_receipt` at each first receipt (wire a no-op in tests).

**Tests**: reach on `FixedTopology(ring(n))` equals the analytic hop sum;
IDONTWANT: duplicates with < without, never 0 copies delivered to a node;
IHAVE repair reaches a node whose mesh links were removed; custody counts
per node class; supernodes in every subnet; first-receipt quantiles exact on
a star; `net.idontwant=false` and `net.gossip_repair=false` switch them off.

**Acceptance** [M]: 1,000 nodes, a 1.5 MB message published by a random node
per 12 s, 5 slots: t90 spread in the prototype's 0.6-1.4 s and mean duplicate
copies per node per block about 2 (`cl_gossip.measured_duplicates`, 2.2 in
the prototype); events per block reported.

## S2c: demand + fees

**Files**: `starksim/v3/demand.py`, `tests/v3/test_demand.py`.

**Implement**: `eip1559_next` exactly as EIP-1559's integer reference code
(`ELASTICITY_MULTIPLIER` 2 and `BASE_FEE_MAX_CHANGE_DENOMINATOR` 8 from
`demand / eip1559`). `Demand(ctx, deploy)`: per slot `lambda_s = level x
Gamma(r, 1/r)` with r from `demand / arrival_burstiness /
slot_count_negbin_r` (1.4), Poisson(lambda_s) batches of Geometric(0.6) txs
inside the slot (the leaf's `draw` text; bind p = 0.6 with the text as
source), all from `ctx.stream("arrivals", slot)` with `detmath`;
`spec.demand.burstiness=false` -> plain Poisson. Mix per tx from
`ctx.stream("mix", tx)`: ECDSA with `1 - pq_share` (load mode), PQ
single (k = `spec.k`), multisig (`demand.multisig_share`,
`demand.multisig_k`), PCS-claim (`demand.pcs_share`, leanpcs only). Shapes
from `deploy.tx_shape(kind, k)` (S3; in your tests pass a stub deploy with a
fixed `TxShape`). Entry node `ctx.stream("entry", tx)` uniform over
simulated nodes. Fees `ctx.stream("fee", tx)`: tip and fee cap
(`fee_cap = base_fee x 2 + tip` [A], tip lognormal fitted to
`traffic_baseline` / `chain_baseline.json` [Mo]; fee willingness is missing
in the params, arch.md 6.3). Saturate mode: offered PQ rate is the argument
of `schedule`, base fee frozen (`on_payload` no-op); load mode moves the
base fee. ECDSA background: `fluid` -> `background_tick_bytes` (arch.md 3.7
formula with `traffic_baseline / tx_size_bytes` mean and the eth/68 push
rule) and `background_offer(slot)` (fee bins of count, gas, bytes, carried
over); `explicit` -> individual ECDSA txs of 21,000 gas (spec.md T13) and
sizes drawn from `traffic_baseline / tx_size_histogram`. Each birth:
`ctx.txs.add(...)` then `ctx.hooks.tx_born(tx)`.

**Tests**: per-slot counts over 10^4 slots: mean and dispersion match
`Gamma(r) x Poisson x Geometric` within sampling error; CRN: two specs that
differ only in `sig_bytes` give identical `born`, `fee_cap`, `tip`,
`entry_node`, `kind` columns; `eip1559_next` on hand vectors (target, +12.5 %
at a full block, -12.5 % at empty, the +1 minimum); fluid bytes per tick by
the formula; saturate mode never moves the base fee.

**Acceptance**: the tests; plus the offered rate over 100 slots at 50 tx/s
within 10 % of 50 for seeds 0-2 (report).

## S2d: provers

**Files**: `starksim/v3/prover.py`, `tests/v3/test_prover.py`.

**Implement**: `ProverModel(params, spec)` pricing with
`bench.leansphincs.models.prove_breakdown(model, sigs, perms, sig_bytes,
children, hw)["total_s"]` (load the model with `models._prover_model` as the
v2 harness does; counted rows from `params.counted_rows(candidate params)`
when present), memoised on (sigs bucketed to the power-of-two cliff and 1 %
inside it, children, class); class multipliers from `provers / classes`
(band `[lo, hi]` -> point by `spec.prover.class_point`: low, mid, high),
time divided by `spec.scale.prover`; proof bytes from `provers /
proof_bytes` fits; limits <= 16 children (PR #12654) and <= 2^16 claim slots.
`Provers(ctx, model)`: class per aggregating node dealt from `provers /
class_mix_of_aggregating_nodes` with `topology.apportion/deal` over the
first `agg.share` of nodes; builders get `provers / builder_class` with
`spec.prover.builder_p` parallel provers. `plan_interval` per arch.md 3.10
(priority, budget `spec.agg.budget_ms` or 0.9 x interval, skip + count
`intervals_overrun` when the job cannot finish before the next interval).
`builder_plan` = greedy set cover of `chosen` by held aggregates, uncovered
txs as leaves, then 16-ary merges, level time `ceil(jobs / p) x t(level
job)`. `largest_prefix` = binary search over `builder_plan(...).fits`.

**Tests**: memoised price within 1 % of `prove_breakdown`; > 16 children
and > 2^16 claims refused; planner priority order and budget; builder tree
time hand-computed on 3 cases; prefix search fits the window exactly (n
fits, n + 1 does not); class multipliers applied; same inputs -> same plan.

**Acceptance**: the lone-prover bound reproduces v2's `validate` S2 rows
(435.33 tx/s at 515 perms, 0.993 of 438.5; `python3 -m
bench.leansphincs.validate` at 582169c prints them) within the whole-proof
floor.

---

## After S2: S3 (two halves, `Deployment` frozen in `deploy.py`)

Read `deployments_v3.json` through `params.deployment_entry(id)` and
`params.fork(name)` (both merge `inherits`) and `params.section("tx_shapes")`.
S3a: `slot.py` + `deploy_8141.py` (`DeployToday`, `Deploy8141`); S3b:
`deploy_agg.py` (`Deploy8288`, `DeployLeanPCS`). The registry in `deploy.py`
already names these classes. The hooks of `INTERFACES.md` section 2 are
wired by the plug-in's constructor. arch.md row S3 lists the tests; the
ideal-network limits of arch.md 5.1 are the acceptance.

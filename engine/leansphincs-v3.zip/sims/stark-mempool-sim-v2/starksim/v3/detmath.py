"""Platform-identical math for the v3 simulator.

A v3 row must be byte-identical for one `spec_hash` under CPython on Linux and
under Pyodide (wasm). IEEE-754 basic operations (+ - * /), `math.sqrt`,
`math.floor`, `math.ceil`, `math.frexp`, `math.ldexp` and `math.fsum` are
correctly rounded or exact on every platform; libm's `log`, `exp`, `pow`,
`cos` are not guaranteed identical across glibc and emscripten's musl, and
`float ** float` calls libm `pow`. So model code never calls them: it calls
the functions below, which use only the exact operations above in a fixed
evaluation order.

Random streams are `random.Random` instances seeded by a string. CPython (and
Pyodide, which is CPython) seeds a string through SHA-512 (seed version 2), so
the Mersenne Twister state, `random()`, `getrandbits`, `randrange` and
`shuffle` are platform-independent. The variates built on libm
(`expovariate`, `gammavariate`, `gauss`, `lognormvariate`) are not, and are
banned in model code by tests/v3/test_rules.py.

Accuracy (tests/v3/test_detmath.py): `ln` and `exp` agree with `math.log` and
`math.exp` to within 4 ulp on 10^5 points; they are not correctly rounded,
and need not be: what matters is that they are the same function everywhere.
"""

import math
import random

from starksim.derive import stable_fraction, stable_index

__all__ = ["ln", "exp", "power", "cos2pi", "sin2pi", "stream", "exponential",
           "normal", "lognormal", "gamma", "geometric", "poisson",
           "stable_fraction", "stable_index", "LN2"]

# ln 2 split so that k * LN2_HI is exact for |k| < 2^11 (Cody-Waite).
LN2_HI = 6.93147180369123816490e-01   # [E] fdlibm e_log.c ln2_hi
LN2_LO = 1.90821492927058770002e-10   # [E] fdlibm e_log.c ln2_lo
LN2 = LN2_HI + LN2_LO
SQRT_HALF = 0.70710678118654752440    # [E] 1/sqrt(2), rounded to double
INV_LN2 = 1.44269504088896338700      # [E] 1/ln 2, rounded to double
PI_HALF = 1.57079632679489661923      # [E] pi/2, rounded to double
EXP_MAX_ARG = 709.782712893384        # [E] ln(DBL_MAX), rounded down
EXP_MIN_ARG = -745.1332191019412      # [E] ln(smallest subnormal), rounded


def ln(x):
    """Natural logarithm of a positive finite float.

    x = m * 2^e with m in [sqrt(1/2), sqrt(2)); ln m = 2 atanh(s) with
    s = (m - 1)/(m + 1), |s| <= 0.1716, summed as the odd series
    2 (s + s^3/3 + ... + s^25/25): the first omitted term is below
    2 * 0.1716^27 / 27 < 1e-21, far under one ulp of ln m.
    """
    if not x > 0.0:
        raise ValueError(f"ln of a non-positive number: {x!r}")
    if x == math.inf:
        return math.inf
    mantissa, exponent = math.frexp(x)
    if mantissa < SQRT_HALF:
        mantissa *= 2.0
        exponent -= 1
    s = (mantissa - 1.0) / (mantissa + 1.0)
    s2 = s * s
    # Horner over the odd coefficients 1/25, 1/23, ..., 1/3, 1.
    series = 1.0 / 25.0
    for denominator in (23.0, 21.0, 19.0, 17.0, 15.0, 13.0, 11.0, 9.0, 7.0,
                        5.0, 3.0, 1.0):
        series = series * s2 + 1.0 / denominator
    log_mantissa = 2.0 * s * series
    return (exponent * LN2_HI + (log_mantissa + exponent * LN2_LO))


def exp(x):
    """e^x for a finite float, by x = k ln 2 + r, |r| <= ln2/2, then a Taylor
    polynomial of degree 17 on r (remainder < 0.35^18 / 18! < 1e-23)."""
    if x != x:
        return x
    if x > EXP_MAX_ARG:
        return math.inf
    if x < EXP_MIN_ARG:
        return 0.0
    k = math.floor(x * INV_LN2 + 0.5)
    r = (x - k * LN2_HI) - k * LN2_LO
    term = 1.0
    for degree in range(17, 0, -1):
        term = term * r / degree + 1.0
    return math.ldexp(term, int(k))


def power(base, exponent):
    """base ** exponent for base > 0, as exp(exponent * ln base).

    Relative error grows with |exponent * ln base| (about that many ulp);
    use integer multiplication for integer powers where exactness matters.
    """
    if base == 1.0 or exponent == 0.0:
        return 1.0
    return exp(exponent * ln(base))


def _sin_cos_quarter(angle):
    """(sin a, cos a) for a in [0, pi/2] by Taylor polynomials of degree 21
    and 20 (remainder < (pi/2)^22 / 22! < 2e-17)."""
    a2 = angle * angle
    sine = 1.0
    for n in range(21, 1, -2):
        sine = 1.0 - sine * a2 / (n * (n - 1))
    sine *= angle
    cosine = 1.0
    for n in range(20, 0, -2):
        cosine = 1.0 - cosine * a2 / (n * (n - 1))
    return sine, cosine


def cos2pi(u):
    """cos(2 pi u). Reduction by quadrant in u is exact for u in [0, 1)."""
    sine, cosine, _ = _turn(u)
    return cosine


def sin2pi(u):
    """sin(2 pi u)."""
    sine, cosine, _ = _turn(u)
    return sine


def _turn(u):
    u = u - math.floor(u)
    quarter_turns = u * 4.0
    quadrant = int(quarter_turns)
    fraction = quarter_turns - quadrant
    sine, cosine = _sin_cos_quarter(fraction * PI_HALF)
    sine = min(1.0, sine)
    cosine = min(1.0, cosine)
    if quadrant == 0:
        return sine, cosine, quadrant
    if quadrant == 1:
        return cosine, -sine, quadrant
    if quadrant == 2:
        return -sine, -cosine, quadrant
    return -cosine, sine, quadrant


def stream(seed, purpose, *keys):
    """A `random.Random` seeded by the string `seed:purpose:key1:key2...`.

    The stream depends only on its identity, never on how many draws other
    streams made: two runs that differ in one input share every stream whose
    identity does not mention that input (common random numbers).
    """
    label = ":".join(str(part) for part in (seed, purpose) + keys)
    return random.Random(label)


def _open_unit(rng):
    """A uniform in (0, 1): never 0, so ln() is defined."""
    while True:
        u = rng.random()
        if u > 0.0:
            return u


def exponential(rng, rate):
    """Exponential variate with the given rate (mean 1/rate), by inversion."""
    return -ln(_open_unit(rng)) / rate


def normal(rng, mean=0.0, sd=1.0):
    """Normal variate by Box-Muller (one of the pair; two uniforms per call,
    so the stream position is a fixed function of the number of calls)."""
    u1 = _open_unit(rng)
    u2 = rng.random()
    radius = math.sqrt(-2.0 * ln(u1))
    return mean + sd * radius * cos2pi(u2)


def lognormal(rng, mu, sigma):
    """exp(N(mu, sigma^2))."""
    return exp(normal(rng, mu, sigma))


def gamma(rng, shape, scale=1.0):
    """Gamma(shape, scale) by Marsaglia-Tsang (2000); shape < 1 by the
    boost U^(1/shape) of the same paper. Mean shape * scale."""
    if shape <= 0.0:
        raise ValueError("gamma shape must be > 0")
    if shape < 1.0:
        boost = power(_open_unit(rng), 1.0 / shape)
        return gamma(rng, shape + 1.0, scale) * boost
    d = shape - 1.0 / 3.0
    c = 1.0 / math.sqrt(9.0 * d)
    while True:
        x = normal(rng)
        v = 1.0 + c * x
        if v <= 0.0:
            continue
        v = v * v * v
        u = _open_unit(rng)
        x2 = x * x
        if u < 1.0 - 0.0331 * x2 * x2:
            return d * v * scale
        if ln(u) < 0.5 * x2 + d * (1.0 - v + ln(v)):
            return d * v * scale


def geometric(rng, p):
    """Number of trials to the first success, support {1, 2, ...}, mean 1/p,
    by inversion: 1 + floor(ln U / ln(1 - p))."""
    if not 0.0 < p <= 1.0:
        raise ValueError("geometric p must be in (0, 1]")
    if p == 1.0:
        return 1
    return 1 + int(math.floor(ln(_open_unit(rng)) / _ln_one_minus(p)))


def _ln_one_minus(p):
    """ln(1 - p) for p in (0, 1), accurate for tiny p (where 1 - p rounds
    to 1): the series -(p + p^2/2 + p^3/3 + p^4/4) below 1e-4."""
    if p < 1e-4:
        return -(p + p * p / 2.0 + p * p * p / 3.0 + p * p * p * p / 4.0)
    return ln(1.0 - p)


def poisson(rng, mean):
    """Poisson count. Inversion by sequential search for mean <= 30; above,
    the sum of independent Poisson(30) blocks plus a remainder, which keeps
    the cost O(mean / 30 + 30) and the result exact in distribution."""
    if mean < 0.0:
        raise ValueError("poisson mean must be >= 0")
    total = 0
    while mean > 30.0:
        total += _poisson_small(rng, 30.0)
        mean -= 30.0
    return total + _poisson_small(rng, mean)


def _poisson_small(rng, mean):
    if mean == 0.0:
        return 0
    u = rng.random()
    probability = exp(-mean)
    cumulative = probability
    count = 0
    while u > cumulative:
        count += 1
        probability = probability * mean / count
        cumulative += probability
        if probability == 0.0 and count > mean:
            break
    return count

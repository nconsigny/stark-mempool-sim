"""Provers: hardware classes, the memoised leanVM price, the interval job
planner, the builder's final-proof planner, the block dependency cap, and the
leanPCS client-STARK and bundler proving routes.

Stage S2d (arch.md section 3.10, STAGES.md S2d). Everything priced here is
[Mo]: the campaign's leanVM model, not a measurement.

Price of one leanVM proof over `sigs` raw signatures and `children` child
proofs on a class:

    t = prove_breakdown(model, sigs, P, B, children, "m4",
                        child_claims=cc)["total_s"] x 1000
        x multiplier(class) / spec.scale.prover            [ms]

with bench/leansphincs/models.py `prove_breakdown` (Keccak reduction on
actual rows, rate 1/2, the v2 harness's settings) and the candidate's counted
rows (data/phase2/guest_counts.json) when `params.counted_rows` has them, as
the v2 registry does. The class multiplier is the band of network_params
`provers.classes.<class>` ([lo, hi] -> low / mid / high by
`spec.prover.class_point`). Limits: <= 16 children (leanVM
MAX_RECURSIONS, PR #12654), claims < 2^16 (leanVM MAX_KEYS), mu <= 28.

Memoisation: the staircase is affine in `sigs` between two power-of-two
cliffs (rows are affine in sigs; every padding is constant; the Keccak
reduction is charged on actual rows). `sigs` is bucketed to 1/128 of its
octave (< 1 %); when the padded committed words are equal at both ends of
the bucket, the price inside is the exact affine interpolation, otherwise
the point is evaluated exactly. So the memo equals `prove_breakdown` up to
float rounding (tested within 1e-9; the work order asks for 1 %).

Interfaces: Job, BuilderPlan, ProverModel, Provers (frozen signatures,
tests/v3/test_state.py) plus the pure helpers `tree_plan`,
`lone_prover_bound`, `PcsProving` that analytic bounds (S3, S6) call without
an engine.
"""

from collections import namedtuple

from bench.leansphincs import models as leanvm
from starksim.v3 import detmath
from starksim.v3 import params as P
from starksim.v3.fastbits import WeightSum
from starksim.v3.state import KIND_PCS, bits, members
from starksim.v3.topology import apportion, deal

# A planned interval job: inputs chosen in priority order (arch.md 3.10).
# own: bool (own previous aggregate kept as a child); children: tuple of
# received aggregate ids; raw: bitset of raw signatures' txs proved as
# leaves; removed: bitset dropped; sigs: leaf signatures; duration_ms.
Job = namedtuple("Job", ("node", "own", "children", "raw", "removed",
                         "sigs", "duration_ms", "proof_bytes"))

# The builder's final proof: levels of the merge tree, each
# (jobs, ms per job); total_ms = sum over levels of ceil(jobs / p) x ms.
BuilderPlan = namedtuple("BuilderPlan", ("levels", "total_ms", "fits",
                                         "proof_bytes"))

# Event kinds S2d registers (owner prefix "prover."):
EV_JOB_DONE = "prover.job_done"

# leanVM recursion limits [R] data/prover_model.py:35-36 reading
# rec_aggregation/src/aggregation/mod.rs:71,80 at 04fba03 (16 children per
# proof, PR #12654's MAX_INNER_PROOFS_PER_STEP; claim slots < 2^16).
MAX_CHILDREN = leanvm.LEANVM_MAX_CHILDREN
MAX_CLAIMS = leanvm.LEANVM_MAX_CLAIMS          # 2^16 - 1 claims at most
# Claims of a child proof when the caller does not know them: the v2
# harness's default (models.leanvm_limited child_claims=500).
DEFAULT_CHILD_CLAIMS = 500                     # [R] models.py leanvm_limited
LOG_RATE = 1                                   # [R] scenarios/D.json rate 1/2
KECCAK_ROWS = "actual"                         # [R] models.prove_breakdown
BUCKETS_PER_OCTAVE_LOG2 = 7                    # [A] 1/128 of an octave < 1 %
EXACT_BELOW = 128                              # [A] sigs priced point by point
BUDGET_SHARE = 0.9                             # [Mo] arch.md 3.10 (SIM4)
CLASS_POINTS = {"low": 0.0, "mid": 0.5, "high": 1.0}

# Class names of network_params `provers.classes` bound at import (a class
# named by the mix but missing here is refused with this list). `gpu` is
# left out on purpose: its leaf has no value (no leanVM GPU measurement).
PROVER_CLASS_NAMES = ("laptop_m2_air", "m4_max", "eip7870_attester_box",
                      "eip7870_full_node_box", "server_epyc_9355p")
# Classes whose band is a prover_model ScaledHW (s_leaf, s_merge) pair
# [R] params provers.classes sources (notes/prover-model.md 1.2;
# data/prover_model.py HWS eip7870, eip7870_full, epyc9355p).
CLASS_HW = {"eip7870_attester_box": "eip7870",
            "eip7870_full_node_box": "eip7870_full",
            "server_epyc_9355p": "epyc9355p"}

_BINDINGS = {
    "prover_class_mix": (P.NET, ("provers", "class_mix_of_aggregating_nodes"),
                         None),
    "prover_builder_class": (P.NET, ("provers", "builder_class"), None),
    "prover_proof_bytes": (P.NET, ("provers", "proof_bytes"), None),
    "prover_stark_verify_ms": (P.NET, ("provers", "stark_verify_ms"), None),
    # leanPCS proving (deployments_v3.json `proving`, 2026-11-12 schema 2).
    "pcs_pi1_anchors_s": (P.DEP, ("proving", "pi1_anchors_s"), None),
    "pcs_pi2_s": (P.DEP, ("proving", "pi2_s"), None),
    "pcs_wrap_s": (P.DEP, ("proving", "wrap_s"), None),
    "pcs_claim_perms_per_sig": (P.DEP, ("proving", "claim_perms_per_sig"),
                                None),
    "pcs_default_client_hw": (P.DEP, ("proving", "default_client_hw"), None),
    "pcs_default_bundler_hw": (P.DEP, ("proving", "default_bundler_hw"),
                               None),
    "pcs_bundle_cap": (P.DEP, ("tx_shapes", "leanpcs", "pcs_bundler",
                               "bundle_cap"), None),
    "pcs_claims_per_tx": (P.DEP, ("tx_shapes", "leanpcs", "pcs_bundler",
                                  "claims_per_tx"), None),
    "pcs_bundler_gas": (P.DEP, ("tx_shapes", "leanpcs", "pcs_bundler", "gas"),
                        None),
    "pcs_client_gas": (P.DEP, ("tx_shapes", "leanpcs", "pcs_client", "gas"),
                       None),
    "pcs_leanstark_cap_reading": (P.DEP, ("deployments", "leanpcs",
                                          "pcs_leanstark_cap_reading"), None),
}
for _name in PROVER_CLASS_NAMES:
    _BINDINGS["prover_class." + _name] = (P.NET, ("provers", "classes", _name),
                                          None)
P.register_bindings(_BINDINGS)


class ProverError(ValueError):
    """A proof outside leanVM's limits, or a class without a price."""


def popcount(bitset):
    return bitset.bit_count()


def ceil_div(a, b):
    return -(-a // b)


def log2(x):
    return detmath.ln(x) / detmath.ln(2.0)


def parse_proof_fit(text):
    """'KiB = -129 + 17.87 log2(W)' -> (-129.0, 17.87). Refuses other
    shapes (network_params provers.proof_bytes.fit_rate_half)."""
    compact = text.replace(" ", "")
    head = "KiB="
    tail = "log2(W)"
    if not compact.startswith(head) or not compact.endswith(tail):
        raise ProverError(f"unrecognised proof-size fit {text!r}")
    body = compact[len(head):-len(tail)]
    split = body.rfind("+")
    if split <= 0:
        split = body.rfind("-")
    if split <= 0:
        raise ProverError(f"unrecognised proof-size fit {text!r}")
    return float(body[:split]), float(body[split:].lstrip("+"))


def ceil_claims(claims):
    """A mean claim count rounded up to a whole claim (memo key)."""
    whole = int(claims)
    return whole + 1 if whole < claims else whole


class ProverModel:
    """Pure price model (no engine): usable by analytic bounds.

    Keyword `engine`: "breakdown" (default: models.prove_breakdown on the
    candidate's counted rows) or "v2_linear" (the v2 harness's default
    `leanvm_circuit(calibration="sphincs-el-m4")`: 60 ms + 2.0 ms per
    signature at 515 permutations, scaled by P/515, + 63 ms per child), kept
    to reproduce v2's `validate` rows. `prover_model_path`: directory of
    data/prover_model.py (default: params.data_dir()).

    Classes: a class whose params band is a prover_model `ScaledHW`'s
    (s_leaf, s_merge) pair (`CLASS_HW`) is priced at `class_point` "mid" by
    the model's own rule, the scale interpolated on the job's Keccak share
    (= `prove_breakdown(..., hw)` exactly); "low"/"high" price every job at
    the band's ends (sensitivity). Other bands (the laptop's 6-8 is an
    uncertainty band) take the low/mid/high point.
    """

    def __init__(self, params, spec, engine="breakdown",
                 prover_model_path=None):
        if engine not in ("breakdown", "v2_linear"):
            raise ProverError(f"unknown prover engine {engine!r}")
        if spec.perms is None or spec.sig_bytes is None:
            raise ProverError("ProverModel needs a resolved signature "
                              "(spec.perms, spec.sig_bytes)")
        self.params = params
        self.spec = spec
        self.engine = engine
        self.perms = int(spec.perms)
        self.sig_bytes = int(spec.sig_bytes)
        self.pm = leanvm._prover_model(prover_model_path or P.data_dir())
        self.shape = None
        self.rows_label = "modelled"
        if spec.candidate:
            candidate = params.candidate(spec.candidate)
            if (candidate["counted"] is not None
                    and candidate["perms"] == self.perms
                    and candidate["sig_bytes"] == self.sig_bytes):
                shape_name, rows = candidate["counted"]
                self.shape = leanvm.CountedShape(rows, self.perms,
                                                 self.sig_bytes)
                self.rows_label = "counted " + shape_name
        self.scale = float(spec.scale.prover)
        self.class_point = spec.prover.class_point
        fits = params.value("prover_proof_bytes")
        self.fit_a, self.fit_b = parse_proof_fit(fits["fit_rate_half"])
        self.floor_kib = float(min(fits["leaf_KiB"]))
        self._multipliers = {}
        self._points = {}
        self._max_leaf = None
        if engine == "v2_linear":
            circuit = leanvm.leanvm_circuit(self.perms, 1,
                                            calibration="sphincs-el-m4")
            self._lin = (circuit.ms_per_hash * circuit.overhead_hashes,
                         circuit.ms_per_hash * circuit.sphincs_hashes,
                         circuit.ms_per_hash * circuit.recursive_hashes)

    # -- classes
    def multiplier(self, hw_class):
        """Time multiplier of a class vs the M4 model (the band's
        `class_point`; see the class docstring for the per-job rule)."""
        value = self._multipliers.get(hw_class)
        if value is not None:
            return value
        if hw_class not in PROVER_CLASS_NAMES:
            raise ProverError(f"unknown prover class {hw_class!r}; bound: "
                              f"{', '.join(PROVER_CLASS_NAMES)}")
        band = self.params.value("prover_class." + hw_class)
        if isinstance(band, dict):
            band = band.get("factor_vs_m4")
        if band is None:
            raise ProverError(f"prover class {hw_class!r} has no measured "
                              "multiplier (params provers.classes)")
        if isinstance(band, (list, tuple)):
            low, high = float(min(band)), float(max(band))
            value = low + (high - low) * CLASS_POINTS[self.class_point]
        else:
            value = float(band)
        self._multipliers[hw_class] = value
        return value

    def class_scale(self, hw_class, total_ms, keccak_ms):
        """The class's time factor for a job of M4 time `total_ms` whose
        Keccak reduction takes `keccak_ms` (prover_model's ScaledHW rule)."""
        multiplier = self.multiplier(hw_class)
        name = CLASS_HW.get(hw_class)
        if name is None or self.class_point != "mid" or total_ms <= 0.0:
            return multiplier
        machine = self.pm.HWS[name]
        leaf, merge = self.pm._KSHARE_LEAF, self.pm._KSHARE_MERGE
        weight = min(1.0, max(0.0, (keccak_ms / total_ms - merge)
                              / (leaf - merge)))
        return machine.s_merge + (machine.s_leaf - machine.s_merge) * weight

    # -- price
    def check(self, sigs, children, child_claims=None):
        """Raise ProverError when the proof breaks a leanVM count limit.
        The claim count uses the exact `child_claims` (a mean), so a proof
        at exactly 2^16 - 1 claims passes. mu <= 28 is checked by
        `price_ms` (it needs the proof's committed words)."""
        if sigs < 0 or children < 0:
            raise ProverError("negative proof size")
        if children > MAX_CHILDREN:
            raise ProverError(f"{children} children > {MAX_CHILDREN} "
                              "(leanVM MAX_RECURSIONS, PR #12654)")
        per_child = DEFAULT_CHILD_CLAIMS if child_claims is None \
            else child_claims
        claims = sigs + children * per_child
        if claims > MAX_CLAIMS + 1e-9:         # [A] float mean tolerance
            raise ProverError(f"{claims} claims >= 2^16 (leanVM MAX_KEYS)")

    def price_ms(self, sigs, children, hw_class, child_claims=None):
        """Prover time of one proof over `sigs` leaf signatures and
        `children` child proofs on `hw_class` (memoised). `child_claims`:
        claims per child, a mean over the children (None = 500, the v2
        harness default). Raises ProverError outside leanVM's limits
        (children, claims, mu <= 28)."""
        self.check(sigs, children, child_claims)
        if self.engine == "v2_linear":
            fixed, per_sig, per_child = self._lin
            base = fixed + per_sig * sigs + per_child * children
            return base * self.multiplier(hw_class) / self.scale
        total, keccak, mu = self._m4(sigs, children,
                                     self._child_claims(child_claims))
        if mu > self.pm.MAX_MU:
            raise ProverError(f"proof of {sigs} sigs and {children} "
                              f"children has mu {mu} > {self.pm.MAX_MU}")
        return total * self.class_scale(hw_class, total, keccak) / self.scale

    def m4_ms(self, sigs, children, child_claims=None):
        """The M4 model's milliseconds, no class or scale (memoised)."""
        if self.engine == "v2_linear":
            fixed, per_sig, per_child = self._lin
            return fixed + per_sig * sigs + per_child * children
        return self._m4(sigs, children, self._child_claims(child_claims))[0]

    def _m4(self, sigs, children, claims):
        """(total ms, Keccak-reduction ms, mu) on the M4, memoised by
        exact affine segments (module docstring)."""
        if sigs < EXACT_BELOW:
            return self._point(sigs, children, claims)[:-1]
        octave = sigs.bit_length() - 1
        step = 1 << (octave - BUCKETS_PER_OCTAVE_LOG2)
        low = sigs - (sigs - (1 << octave)) % step
        if low == sigs:
            return self._point(sigs, children, claims)[:-1]
        high = low + step
        t_low, k_low, mu_low, w_low = self._point(low, children, claims)
        t_high, k_high, mu_high, w_high = self._point(high, children, claims)
        if w_high == w_low and mu_high == mu_low:
            share = (sigs - low) / step
            return (t_low + (t_high - t_low) * share,
                    k_low + (k_high - k_low) * share, mu_low)
        return self._point(sigs, children, claims)[:-1]

    def breakdown(self, sigs, children, child_claims=None, smooth=False):
        """models.prove_breakdown at this candidate on the M4 (unmemoised)."""
        return leanvm.prove_breakdown(
            self.pm, sigs, self.perms, self.sig_bytes, children, "m4",
            KECCAK_ROWS, shape=self.shape,
            child_claims=self._child_claims(child_claims), rate=LOG_RATE,
            smooth=smooth)

    def mu(self, sigs, children, child_claims=None):
        return self._point(sigs, children,
                           self._child_claims(child_claims))[2]

    def proof_bytes(self, sigs, children, child_claims=None):
        """Bytes of the proof: provers.proof_bytes rate-1/2 fit on the
        proof's committed words, floored at the smallest leaf seen in
        params `leaf_KiB` (242 KiB; prover_model.proof_bytes uses 250)."""
        words = self._point(sigs, children,
                            self._child_claims(child_claims))[-1]  # W
        kib = max(self.floor_kib, self.fit_a + self.fit_b * log2(words))
        return int(1024 * kib)                 # [E] 1 KiB = 1024 B

    def max_leaf_sigs(self):
        """Largest raw signatures in one leaf proof (mu <= 28, claims)."""
        if self._max_leaf is None:
            low, high = 1, MAX_CLAIMS
            while low < high:
                mid = (low + high + 1) // 2
                if self.mu(mid, 0) <= self.pm.MAX_MU:
                    low = mid
                else:
                    high = mid - 1
            self._max_leaf = low
        return self._max_leaf

    def _child_claims(self, child_claims):
        if child_claims is None:
            return DEFAULT_CHILD_CLAIMS
        return ceil_claims(child_claims)

    def _point(self, sigs, children, claims):
        key = (sigs, children, claims)
        hit = self._points.get(key)
        if hit is None:
            result = leanvm.prove_breakdown(
                self.pm, sigs, self.perms, self.sig_bytes, children, "m4",
                KECCAK_ROWS, shape=self.shape, child_claims=claims,
                rate=LOG_RATE)
            hit = (1000.0 * result["total_s"],
                   1000.0 * result["time"]["keccak_reduction"],
                   result["mu"], result["W"])
            self._points[key] = hit
        return hit


class Provers:
    """Per-node prover resources of a run."""

    def __init__(self, ctx, model):
        """Assigns ctx.nodes.prover_class (class mix of aggregating nodes,
        spec.agg.share; builders: provers.builder_class with
        spec.prover.builder_p parallel provers). Registers `prover.*`
        counters (busy ms per node, proofs, children merged, overruns)."""
        self.ctx = ctx
        self.model = model
        spec = ctx.spec
        nodes = ctx.nodes
        topo = ctx.topo
        n_sim = topo.n if topo is not None else nodes.n
        builders = list(topo.builders) if topo is not None else []
        interval = spec.agg.interval_ms
        if interval is None:
            interval = 1000.0 * float(
                ctx.params.constant_value("AGGREGATION_INTERVAL"))
        self.interval_ms = float(interval)
        self.budget_ms = spec.agg.budget_ms
        if self.budget_ms is None:
            self.budget_ms = BUDGET_SHARE * self.interval_ms
        # Aggregating nodes: the first agg.share of the simulated nodes
        # (nested as the share grows), classes dealt from the mix.
        mix = ctx.params.value("prover_class_mix")
        names = list(mix)
        n_agg = apportion([1.0 - spec.agg.share, spec.agg.share], n_sim)[1]
        labels = deal(apportion([float(mix[name]) for name in names], n_agg),
                      ctx.stream("prover", "class"))
        for node in range(n_agg):
            nodes.prover_class[node] = names[labels[node]]
            model.multiplier(names[labels[node]])
        self.builder_class = ctx.params.value("prover_builder_class")
        model.multiplier(self.builder_class)
        self.free_at = [[] for _ in range(nodes.n)]
        for node in range(n_agg):
            self.free_at[node] = [0.0]
        for node in builders:
            nodes.prover_class[node] = self.builder_class
            self.free_at[node] = [0.0] * spec.prover.builder_p
        self.builders = builders
        n = nodes.n
        counters = ctx.counters
        self.busy = counters.array("prover.busy_ms", n, 0.0)
        self.proofs = counters.array("prover.proofs", n)
        self.merged = counters.array("prover.children_merged", n)
        self.sigs = counters.array("prover.sigs_proved", n)
        self.overrun = counters.array("prover.intervals_overrun", n)
        self.no_fit = counters.array("prover.intervals_no_fit", n)
        for name in ("prover.builder_plans", "prover.dep_cap_truncated"):
            counters.scalar(name)
        counters.scalar("prover.builder_slack_ms", 0.0)
        # Duplicated work (SIM3/SIM7): how many jobs proved a tx as a raw
        # leaf; > 1 is repeated coverage.
        self.times_proved = ctx.txs.add_column("prover.times_proved", 0)
        self._pending = {}
        self._token = 0
        ctx.on(EV_JOB_DONE, self._done)

    # -- helpers
    def has_prover(self, node):
        return bool(self.free_at[node])

    def parallel(self, node):
        return len(self.free_at[node])

    def window_ms(self, parent_seen_ms, bid_ms):
        """The builder's proving window: from seeing the parent payload to
        the bid minus spec.prover.bid_margin_ms (arch.md 3.10, spec B14)."""
        return max(0.0, bid_ms - self.ctx.spec.prover.bid_margin_ms
                   - parent_seen_ms)

    def _split(self, txs):
        """(raw signatures, child claims) of a list of tx ids: a PCS-claim
        tx arrives as a client STARK (one child of `deps` claims), any
        other PQ tx as `k` raw signatures."""
        table = self.ctx.txs
        sigs = 0
        children = []
        for tx in txs:
            if table.kind[tx] == KIND_PCS:
                children.append(table.deps[tx])
            else:
                sigs += table.k[tx]
        return sigs, children

    # -- interval planner (arch.md 3.10)
    def plan_interval(self, node, own, removals, received, raw_by_tip,
                      budget_ms):
        """Choose this interval's job (arch.md 3.10 priority): own previous
        aggregate, removals, received aggregates by marginal coverage
        (<= 15), raw signatures by tip; stop at the budget or a limit.
        `received`: [(aggregate id, cover bitset)]; `raw_by_tip`: tx ids.
        -> Job, or None when nothing is worth proving.

        Claims of an aggregate are its signatures (k per tx; a PCS tx's
        deps). Children are priced at their mean claim count.
        `own`: None or (aggregate id, cover bitset). `removals`: bitset of
        txs known included or evicted (free: they only shrink the claim).
        `budget_ms` None = spec.agg.budget_ms or 0.9 x interval. A raw tx
        of kind PCS is a child (its client STARK), not a leaf. The job is
        skipped (counter `prover.intervals_overrun`) when the node's prover
        is still busy and the job would end after the next interval."""
        if not self.free_at[node]:
            return None
        model = self.model
        hw = self.ctx.nodes.prover_class[node]
        budget = self.budget_ms if budget_ms is None else budget_ms
        removals = removals or 0
        covered = 0
        removed = 0
        child_claims = []
        child_ids = []
        own_flag = own is not None
        if own_flag:
            own_cover = own[1]
            removed = own_cover & removals
            covered = own_cover & ~removals
            child_claims.append(self._sigs_of(own_cover))

        def fits(sigs, claims):
            count = len(claims)
            mean = sum(claims) / count if count else None
            if count > MAX_CHILDREN or sigs + sum(claims) > MAX_CLAIMS:
                return None
            try:
                price = model.price_ms(sigs, count, hw, mean)
            except ProverError:         # mu > 28: a leaf too large
                return None
            return price if price <= budget else None

        if own_flag and fits(0, child_claims) is None:
            self.no_fit[node] += 1
            return None
        # (3) received aggregates, greedy by marginal new coverage.
        pool = list(received or ())
        while pool and len(child_claims) < MAX_CHILDREN:
            best = -1
            best_gain = 0
            for index, (_agg, cover) in enumerate(pool):
                gain = popcount(cover & ~covered & ~removals)
                if gain > best_gain:
                    best, best_gain = index, gain
            if best < 0:
                break
            agg_id, cover = pool.pop(best)
            trial = child_claims + [self._sigs_of(cover)]
            if fits(0, trial) is None:
                break
            child_claims = trial
            child_ids.append(agg_id)
            covered |= cover & ~removals
            removed |= cover & removals
        # (4) raw signatures by tip: the longest prefix that fits.
        raw_list = [tx for tx in (raw_by_tip or ())
                    if not (covered >> tx) & 1 and not (removals >> tx) & 1]
        table = self.ctx.txs
        cum_sigs = [0]
        cum_children = [[]]
        for tx in raw_list:
            if table.kind[tx] == KIND_PCS:
                cum_sigs.append(cum_sigs[-1])
                cum_children.append(cum_children[-1] + [table.deps[tx]])
            else:
                cum_sigs.append(cum_sigs[-1] + table.k[tx])
                cum_children.append(cum_children[-1])
        low, high = 0, len(raw_list)
        while low < high:
            mid = (low + high + 1) // 2
            if fits(cum_sigs[mid], child_claims + cum_children[mid]) is None:
                high = mid - 1
            else:
                low = mid
        taken = raw_list[:low]
        sigs = cum_sigs[low]
        all_claims = child_claims + cum_children[low]
        new_cover = bool(child_ids) or bool(taken)
        if not new_cover and (not removed or not covered):
            # Nothing new, and either nothing to drop or nothing left.
            return None
        duration = fits(sigs, all_claims)
        if duration is None:
            self.no_fit[node] += 1
            return None
        now = self.ctx.now()
        start = max(now, min(self.free_at[node]))
        if start + duration > now + self.interval_ms:
            self.overrun[node] += 1
            return None
        mean = sum(all_claims) / len(all_claims) if all_claims \
            else None
        return Job(node, own_flag, tuple(child_ids), bits(taken), removed,
                   sigs, duration,
                   model.proof_bytes(sigs, len(all_claims), mean))

    def start(self, job, on_done, arg):
        """Run `job` on the node's prover; on_done(arg) at its end.
        Returns the end time (ms). A builder runs it on its earliest-free
        prover of spec.prover.builder_p."""
        node = job.node
        free = self.free_at[node]
        if not free:
            raise ProverError(f"node {node} has no prover")
        index = free.index(min(free))
        begin = max(self.ctx.now(), free[index])
        end = begin + job.duration_ms
        free[index] = end
        self.busy[node] += job.duration_ms
        self.proofs[node] += 1
        self.merged[node] += len(job.children) + (1 if job.own else 0)
        self.sigs[node] += job.sigs
        for tx in members(job.raw):
            self.times_proved[tx] += 1
        self._token += 1
        self._pending[self._token] = (on_done, arg)
        self.ctx.at(end, EV_JOB_DONE, (node, self._token))
        return end

    def _done(self, payload):
        _node, token = payload
        on_done, arg = self._pending.pop(token)
        on_done(arg)

    # -- builder final proof (arch.md 3.10, spec B14)
    def builder_plan(self, builder, chosen, held, window_ms,
                     extra_children=()):
        """Final-proof plan for the bitset `chosen` given held aggregates
        `held` [(aggregate id, cover)] within `window_ms` -> BuilderPlan.

        Greedy set cover of `chosen` by `held` (largest marginal first; an
        aggregate is used only while its marginal signatures cost more to
        prove raw than merging it as a child costs); uncovered txs become
        raw leaves (PCS-claim txs: one child each); `extra_children`
        (claims of each FOCIL IL STARK) are more children; then
        `tree_plan`. One held aggregate whose cover is exactly `chosen`
        and nothing else needs no job (0 ms)."""
        model = self.model
        hw = self.ctx.nodes.prover_class[builder] or self.builder_class
        p = max(1, len(self.free_at[builder]))
        self.ctx.counters.add("prover.builder_plans")
        if not extra_children and any(cover == chosen
                                      for _agg, cover in held or ()):
            return BuilderPlan((), 0.0, True, 0)
        remaining = chosen
        pool = list(held or ())
        picked = []
        break_even = self._break_even(hw)
        while pool and remaining:
            best = -1
            best_gain = 0
            for index, (_agg, cover) in enumerate(pool):
                gain = self._sigs_of(cover & remaining)
                if gain > best_gain:
                    best, best_gain = index, gain
            if best < 0 or best_gain < break_even:
                break
            _agg, cover = pool.pop(best)
            picked.append(cover)
            remaining &= ~cover
        raw_sigs, pcs_children = self._split(members(remaining))
        claims = ([self._sigs_of(cover) for cover in picked] + pcs_children
                  + list(extra_children))
        return tree_plan(model, hw, p, raw_sigs, claims, window_ms)

    def largest_prefix(self, builder, fee_ordered, held, window_ms,
                       extra_children=()):
        """Largest n such that the first n txs of `fee_ordered` fit the
        window (binary search over builder_plan). The block dependency cap
        (spec.chain.dep_cap, spec B18) truncates the list first: the
        longest prefix whose deps sum to <= the cap. `extra_children`
        (FOCIL IL STARKs' claims) ride in every plan.

        "Fits" is not monotone in n: a held aggregate covering a prefix
        exactly costs 0 ms. The search therefore jumps to the largest such
        exact-cover prefix that fits and binary-searches above it again;
        the result satisfies plan(n) fits and plan(n + 1) does not (or n =
        the truncated length)."""
        txs = list(fee_ordered)
        cap = self.ctx.spec.chain.dep_cap
        if cap is not None:
            deps = self.ctx.txs.deps
            total = 0
            limit = len(txs)
            for index, tx in enumerate(txs):
                total += deps[tx]
                if total > cap:
                    limit = index
                    break
            self.ctx.counters.add("prover.dep_cap_truncated",
                                  len(txs) - limit)
            txs = txs[:limit]
        prefix = [0]
        for tx in txs:
            prefix.append(prefix[-1] | (1 << tx))
        index_of = {cover: n for n, cover in enumerate(prefix)}
        exact = sorted(index_of[cover] for _agg, cover in held or ()
                       if cover in index_of)

        def fits(n):
            return self.builder_plan(builder, prefix[n], held, window_ms,
                                     extra_children).fits

        if fits(len(txs)):
            return len(txs)
        low, high = 0, len(txs)          # fits(high) is False throughout
        while True:
            upper = high
            while upper - low > 1:       # fits(low) holds, fits(upper) not
                mid = (low + upper) // 2
                if fits(mid):
                    low = mid
                else:
                    upper = mid
            jump = [n for n in exact if low < n < high and fits(n)]
            if not jump:
                return low
            low = jump[-1]

    def _sigs_of(self, cover):
        summer = getattr(self, "_sigs_sum", None)
        if summer is None:
            summer = WeightSum(self._sigs_weight)
            self._sigs_sum = summer
        return summer.sum(cover)

    def _sigs_weight(self, tx):
        table = self.ctx.txs
        return table.deps[tx] if table.kind[tx] == KIND_PCS else table.k[tx]

    def _break_even(self, hw):
        """Signatures whose raw proving costs one child merge: a held
        aggregate covering fewer new signatures is not worth merging."""
        model = self.model
        child = (model.price_ms(0, 2, hw) - model.price_ms(0, 1, hw))
        span = EXACT_BELOW
        per_sig = (model.price_ms(2 * span, 0, hw)
                   - model.price_ms(span, 0, hw)) / span
        return int(child / per_sig) if per_sig > 0 else 1


def _rounds(jobs, p):
    return ceil_div(jobs, p)


def tree_plan(model, hw_class, p, raw_sigs, child_claims, window_ms):
    """The builder's final proof over `raw_sigs` raw signatures and ready
    child proofs of `child_claims` claims each, on `p` provers of
    `hw_class` -> BuilderPlan (pure; S3 and S6 call it for bounds).

    Two plans, the faster wins (ties: the single job):
    - single: one proof of raw_sigs + all children (if <= 16 children,
      claims < 2^16, mu <= 28);
    - tree: L = max(ceil(raw / max_leaf), min(p, raw)) near-equal leaves,
      then 16-ary merges level by level over children + leaves.
    Level time = ceil(jobs / p) x the level's largest job (arch.md 3.10).
    Infeasible (> 2^16 claims in the final proof): fits False, total inf.
    """
    children = list(child_claims)
    total_claims = raw_sigs + sum(children)
    if raw_sigs == 0 and not children:
        return BuilderPlan((), 0.0, True, 0)
    if total_claims > MAX_CLAIMS:
        return BuilderPlan((), float("inf"), False, 0)
    plans = []
    if len(children) <= MAX_CHILDREN and raw_sigs <= model.max_leaf_sigs():
        mean = sum(children) / len(children) if children else None
        if model.mu(raw_sigs, len(children), mean) <= model.pm.MAX_MU:
            ms = model.price_ms(raw_sigs, len(children), hw_class, mean)
            plans.append(BuilderPlan(((1, ms),), ms, ms <= window_ms,
                                     model.proof_bytes(raw_sigs,
                                                       len(children), mean)))
    if raw_sigs > 0 or len(children) > MAX_CHILDREN:
        levels = []
        items = list(children)
        if raw_sigs > 0:
            leaves = max(ceil_div(raw_sigs, model.max_leaf_sigs()),
                         min(p, raw_sigs))
            size, extra = divmod(raw_sigs, leaves)
            sizes = [size + 1] * extra + [size] * (leaves - extra)
            levels.append((leaves, model.price_ms(sizes[0], 0, hw_class)))
            items += sizes
        final = (0, 0, None)
        while len(items) > 1:
            groups = [items[i:i + MAX_CHILDREN]
                      for i in range(0, len(items), MAX_CHILDREN)]
            worst = 0.0
            for group in groups:
                mean = sum(group) / len(group)
                worst = max(worst, model.price_ms(0, len(group), hw_class,
                                                  mean))
                final = (0, len(group), mean)
            levels.append((len(groups), worst))
            items = [sum(group) for group in groups]
        total = sum(_rounds(jobs, p) * ms for jobs, ms in levels)
        if final[2] is None:
            proof = model.proof_bytes(raw_sigs, 0)
        else:
            proof = model.proof_bytes(*final)
        plans.append(BuilderPlan(tuple(levels), total, total <= window_ms,
                                 proof))
    return min(plans, key=lambda plan: plan.total_ms)


def lone_prover_bound(model, hw_class, budget_ms, interval_ms, batch=1):
    """The lone-prover bound (arch.md 5.1, v2 `validate` S2 rows): one node
    proves every interval its own previous aggregate (one child) plus as
    many raw signatures as fit `budget_ms`.

    -> {"linear_sigs", "merged_sigs", "unmerged_sigs", *_tps}: `linear` is
    v2's bound (budget - fixed - child) / per-signature on the smooth
    model; `merged`/`unmerged` are whole-proof floors (with and without the
    child merge, rounded down to `batch` signatures), between which a
    simulated lone prover lands (v2's `floors`)."""
    def ok(sigs, children):
        try:
            return model.price_ms(sigs, children, hw_class) <= budget_ms
        except ProverError:                 # mu > 28 or claims
            return False

    def largest(children):
        low, high = 0, model.max_leaf_sigs()
        if not ok(0, children):
            return 0
        while low < high:
            mid = (low + high + 1) // 2
            if ok(mid, children):
                low = mid
            else:
                high = mid - 1
        return low

    if model.engine == "v2_linear":
        fixed, per_sig, per_child = model._lin
        scale = model.multiplier(hw_class) / model.scale
        linear = (budget_ms / scale - fixed - per_child) / per_sig
    else:
        def smooth_ms(sigs, children):
            result = model.breakdown(sigs, children, smooth=True)
            total = 1000.0 * result["total_s"]
            keccak = 1000.0 * result["time"]["keccak_reduction"]
            return (total * model.class_scale(hw_class, total, keccak)
                    / model.scale)
        span = EXACT_BELOW
        per_sig = (smooth_ms(2 * span, 1) - smooth_ms(span, 1)) / span
        linear = (budget_ms - smooth_ms(0, 1)) / per_sig
    merged = largest(1) // batch * batch
    unmerged = largest(0) // batch * batch
    per_s = 1000.0 / interval_ms
    return {"linear_sigs": linear, "merged_sigs": merged,
            "unmerged_sigs": unmerged, "linear_tps": linear * per_s,
            "merged_tps": merged * per_s, "unmerged_tps": unmerged * per_s}


# --------------------------------------------------------------- leanPCS
def coefficients(obj, **variables):
    """A deployments_v3.json coefficient object (meta.coefficient_objects):
    {term: coefficient}, or {"max_of": [objects]}; terms const, per_k,
    per_kB, per_kP, per_P, per_c, per_g; keys starting with '_' ignored."""
    if "max_of" in obj:
        return max(coefficients(item, **variables) for item in obj["max_of"])
    total = 0.0
    for term, coefficient in obj.items():
        if term.startswith("_"):
            continue
        if term == "const":
            factor = 1
        else:
            factor = 1
            for name in _TERM_VARIABLES[term]:
                if name not in variables:
                    raise ProverError(f"coefficient term {term} needs "
                                      f"{name}")
                factor *= variables[name]
        total += coefficient * factor
    return total


_TERM_VARIABLES = {"per_k": ("k",), "per_kB": ("k", "B"),
                   "per_kP": ("k", "P"), "per_P": ("P",), "per_c": ("c",),
                   "per_g": ("g",)}


def parse_bundle_cap(text):
    """'floor((65536 - 7.5) / (P + 0.471))' -> (65536.0, 7.5, 0.471)."""
    compact = text.replace(" ", "")
    head, middle, tail = "floor((", ")/(P+", "))"
    if not compact.startswith(head) or not compact.endswith(tail) \
            or middle not in compact:
        raise ProverError(f"unrecognised bundle-cap formula {text!r}")
    numerator, offset = compact[len(head):-len(tail)].split(middle)
    total, minus = numerator.split("-")
    return float(total), float(minus), float(offset)


class PcsProving:
    """leanPCS proving routes (deployments_v3.json `proving` and
    `tx_shapes.leanpcs`, 2026-11-12 corrections; all [Mo] on [M-ext]).

    One pi1/pi2 proof over k signatures takes
    interp(pi1_anchors[hw], k (P + claim_perms)) + pi2[hw] + wrap[hw] s
    (linear between anchors, extrapolated from the last two); it holds at
    most bundle_cap(P) signatures and declares 7 PCS claims; g =
    ceil(k / bundle_cap) proofs run one after another on one host.

    - pcs_client: the wallet host (`default_client_hw`, M4) proves its own
      k signatures before submitting; the mempool merges its client STARK
      as one leanVM child (Provers._split).
    - pcs_bundler: a bundler (`default_bundler_hw`, 8-thread EPYC) proves
      full bundles of bundle_cap signatures; `bundler_capacity` gives the
      bundles per slot (gas, block dependency cap, optional LEANSTARK cap
      reading) and the concurrent bundler jobs that rate needs.
    """

    def __init__(self, params, perms):
        self.perms = int(perms)
        self.anchors = params.value("pcs_pi1_anchors_s")
        self.pi2 = params.value("pcs_pi2_s")
        self.wrap = params.value("pcs_wrap_s")
        self.claim_perms = float(params.value("pcs_claim_perms_per_sig"))
        self.client_hw = params.value("pcs_default_client_hw")
        self.bundler_hw = params.value("pcs_default_bundler_hw")
        total, minus, offset = parse_bundle_cap(
            params.value("pcs_bundle_cap")["formula"])
        self.cap = int((total - minus) // (self.perms + offset))
        self.claims_per_proof = int(params.value("pcs_claims_per_tx")["per_g"])
        self.bundler_gas = params.value("pcs_bundler_gas")
        self.client_gas = params.value("pcs_client_gas")
        self.leanstark_reading = params.value("pcs_leanstark_cap_reading")
        self.max_claims = int(params.constant_value("MAX_PCS_CLAIMS_PER_TX"))

    def proofs(self, k):
        return ceil_div(k, self.cap)

    def claims(self, k):
        """PCS claims of a tx proving k signatures: 7 per proof; refused
        above MAX_PCS_CLAIMS_PER_TX (256, leanPCS draft validity rule)."""
        claims = self.claims_per_proof * self.proofs(k)
        if claims > self.max_claims:
            raise ProverError(f"{claims} PCS claims > MAX_PCS_CLAIMS_PER_TX "
                              f"{self.max_claims} (k = {k})")
        return claims

    def pi1_s(self, hw, perms):
        points = self.anchors[hw]
        for (x0, y0), (x1, y1) in zip(points, points[1:]):
            if perms <= x1:
                return y0 + (y1 - y0) * (perms - x0) / (x1 - x0)
        (x0, y0), (x1, y1) = points[-2], points[-1]
        return y1 + (y1 - y0) * (perms - x1) / (x1 - x0)

    def prove_s(self, k, hw=None):
        """Seconds to prove k signatures (g proofs in sequence) on hw."""
        hw = hw or self.client_hw
        g = self.proofs(k)
        size, extra = divmod(k, g)
        total = 0.0
        for index in range(g):
            share = size + (1 if index < extra else 0)
            perms = share * (self.perms + self.claim_perms)
            total += self.pi1_s(hw, perms) + self.pi2[hw] + self.wrap[hw]
        return total

    def client_prove_ms(self, k, hw=None):
        return 1000.0 * self.prove_s(k, hw or self.client_hw)

    def gas(self, k, route="pcs_bundler"):
        self.claims(k)                          # refuses k over the cap
        obj = self.bundler_gas if route == "pcs_bundler" else self.client_gas
        return int(coefficients(obj, k=k, g=self.proofs(k)))

    def bundler_capacity(self, gas_limit, slot_ms, dep_cap=None, k=None,
                         hw=None, leanstark_cap=None):
        """Bundles per slot and the bundler fleet a full-bundle route needs.

        bundles = min(gas_limit // gas(k), dep_cap // claims(k), and, under
        the 'yes' reading of pcs_leanstark_cap_reading, leanstark_cap //
        claims(k)); sig/s = bundles k / slot. Jobs: `pipelined` = ceil(rate
        x prove time) concurrent jobs at steady state; `per_slot` = the
        smallest p with ceil(bundles / p) x prove time <= slot (each slot's
        bundles proved within one slot)."""
        k = k or self.cap
        hw = hw or self.bundler_hw
        gas = self.gas(k)
        claims = self.claims(k)
        limits = {}
        if gas_limit:
            limits["gas"] = gas_limit // gas
        if dep_cap is not None:
            limits["dep_cap"] = dep_cap // claims
        if leanstark_cap is not None and self.leanstark_reading == "yes":
            limits["leanstark_cap"] = leanstark_cap // claims
        if not limits:
            raise ProverError("bundler_capacity needs a gas limit or a cap")
        bundles = min(limits.values())
        binding = sorted(name for name, value in limits.items()
                         if value == bundles)
        prove_ms = 1000.0 * self.prove_s(k, hw)
        per_slot = 0
        if bundles:
            per_slot = 1
            while ceil_div(bundles, per_slot) * prove_ms > slot_ms:
                per_slot += 1
                if per_slot > bundles:
                    per_slot = None
                    break
        pipelined = ceil_div(int(bundles * prove_ms), int(slot_ms)) \
            if bundles else 0
        return {"k": k, "gas_per_bundle": gas, "claims_per_bundle": claims,
                "bundles_per_slot": bundles, "binding": binding,
                "limits": limits, "sig_per_s": bundles * k * 1000.0 / slot_ms,
                "prove_ms": prove_ms, "jobs_pipelined": pipelined,
                "jobs_per_slot": per_slot, "hw": hw}

"""Outputs of one v3 run: the fixed row schema, exact streaming quantiles,
observer subsets, and the row builder (arch.md 3.11, stage S4).

One row per run, one schema for every deployment. `ROW_COLUMNS` is a fixed,
ordered tuple of `Column(name, type, unit, na)`; `build_row` fills every
column, in that order, with a value of the column's type or `None`. `na`
says when `None` is allowed (the NA rule); `validate_row` enforces both.
Nothing in a row is a label chosen by a threshold except the columns named
`binding*` (attribution.py, which says how it decided).

Window. Slot s covers [s x slot_ms, (s + 1) x slot_ms) (demand.py's
convention). The measured window is slots `warmup ... warmup + measured -
1`; the horizon is the end of the drain slots. Throughput counts canonical
inclusions in window slots; latency counts txs *born* in the window and
follows them to the horizon: a tx not included by then is censored and
enters every quantile as +inf (never dropped), so a quantile that lands on a
censored tx is NA and `censored_*` says how many there were. Counter
columns are window deltas of `Counters.snapshot()` taken by `Recorder` at
the window's two ends (links settled first, so busy times are exact at the
boundary). `mempool.cpu_busy_ms` and `prover.busy_ms` book a job's full
duration when it is queued (mempool.py Cpu.run, prover.py), so `cpu_util_*`
and `prover_util_*` are *offered load* (booked work / capacity): above 1
under a backlog, which is the saturation signal (review F16).

Six old defects (arch.md 1.3) this module makes impossible:
- a collapsed chain cannot count: only `ctx.txs.included_slot` of slots
  whose record says `canonical` counts, and a tx included in a slot that is
  not canonical raises `MetricsError`;
- an unreached block cannot vanish: reach quantiles take never-reached
  observers as +inf, `<topic>_unreached` counts blocks that missed any
  observer, and a quantile over blocks that lands on one is NA;
- no binding label by thresholds: see attribution.py;
- an unknown observer rule, node group or validation target raises.

Quantiles. `quantile(values, q, method)`: `nearest` (default) is the
nearest-rank order statistic x_(ceil(q n)) (q = 0 gives the minimum), the
definition of clgossip.reach_time; `linear` is the Hyndman-Fan type 7
interpolation (numpy's default) on finite data, used where the validation
targets were computed that way; +inf propagates only where it carries
weight (numpy returns nan there; review F2). ceil(q n) is computed in exact decimal arithmetic on
repr(q) (0.9 x 10 is 9, not 10). `Quantiles` is the streaming accumulator:
exact (it keeps every value; a run has at most ~10^5 per accumulator).

Observers (`observer_set`): `all` = simulated nodes (builders excluded);
`datacentre` = simulated nodes with datacentre access; `targets_rule` =
validation_targets.json observer_rule: a 2 % sample (at least one node per
part) weighted 2/3 Europe, 1/3 North America + Oceania, the nodes with the
smallest stable_fraction(seed, "observers", node) in each part. Node groups
for per-class columns: `NODE_GROUPS`.
"""

import math
from array import array
from collections import namedtuple
from fractions import Fraction

from starksim.v3 import detmath
from starksim.v3.state import members as state_members
from starksim.v3.state import (KIND_ECDSA, KIND_NAMES, KIND_PCS, KIND_PQ1,
                               KIND_PQK, NOT_INCLUDED)

INF = float("inf")
MS_PER_S = 1000.0
BITS_PER_BYTE = 8                 # [E] definition
MBIT = 1_000_000                  # [E] SI megabit
WEI_PER_GWEI = 1_000_000_000      # [E] 1 gwei = 10^9 wei
P90 = 0.9                         # [A] arch.md 3.11 "mean and p90"
P95 = 0.95                        # [A] arch.md 3.11 latency p95
P99 = 0.99                        # [A] arch.md 3.11 latency p99
P10 = 0.1                         # [E] validation_targets.json keys p10
# Validation-target definitions (data/phase4/validation_targets.json).
LATE_REACH_MS = 4000.0            # [E] validation_targets block_late_share_reach90_gt_4s
EU_SHARE_OF_OBSERVERS = Fraction(2, 3)   # [E] validation_targets observer_rule
OBSERVER_SAMPLE_SHARE = Fraction(1, 50)  # [E] validation_targets observer_rule (2 %)
SIGHTING_WINDOWS_MS = (("within_100ms", 100.0),   # [E] validation_targets tx_later_sighting
                       ("within_500ms", 500.0),   # [E] same
                       ("within_1s", 1000.0),
                       ("within_5s", 5000.0))     # [E] same
SUPERNODE_BLOB_BINS = (1, 10, 21)  # [E] validation_targets supernode_last_column_ms_by_blobs
# S6b (validation_targets_v2.json): supernode time to the 64th column from
# the block's first sighting, pooled blob bins (calib2 3), and the column
# count that makes the data available by reconstruction.
COL64_BLOB_BINS = ((1, 5), (6, 10), (11, 21))   # [E] validation_targets_v2 supernode_col64_from_first_seen_ms
RECONSTRUCT_COLUMNS = 64           # [E] fulu NUMBER_OF_COLUMNS // 2
BYTES_PER_KB = 1000.0             # [E] slope_ms_per_kB in decimal kB (Xatu)

# Regions (network_params_v3.json regions.names) -> validation continents.
CONTINENT_OF_REGION = {"europe": "EU", "na_east": "NA", "na_west": "NA",
                       "asia_east": "AS", "asia_se_oceania": "OC"}
CONTINENTS = ("EU", "NA", "AS", "OC")
EU_REGIONS = ("europe",)
NA_OC_REGIONS = ("na_east", "na_west", "asia_se_oceania")

OBSERVER_RULES = ("all", "datacentre", "targets_rule")
NODE_GROUPS = ("all", "dc", "home", "validator", "supernode", "builder")
TX_CLASSES = ("pq1", "pqk", "pcs", "ecdsa")
_KIND_OF_CLASS = {"pq1": KIND_PQ1, "pqk": KIND_PQK, "pcs": KIND_PCS,
                  "ecdsa": KIND_ECDSA}
PQ_KINDS = (KIND_PQ1, KIND_PQK, KIND_PCS)
BLOCK_TOPICS = ("block", "payload")

STATUS_CANONICAL = "canonical"
STATUS_ORPHANED = "orphaned"     # built and published, not canonical
STATUS_MISSED = "missed"         # payload withheld or late (ePBS)
STATUS_EMPTY = "empty"           # no block for the slot
SLOT_STATUSES = (STATUS_CANONICAL, STATUS_ORPHANED, STATUS_MISSED,
                 STATUS_EMPTY)


class MetricsError(ValueError):
    """Inconsistent run data (e.g. an inclusion in a non-canonical slot)."""


# --------------------------------------------------------------- quantiles
def _ceil_rank(q, n):
    """ceil(q x n) in exact decimal arithmetic on repr(q); 1 at q = 0."""
    if not 0.0 <= q <= 1.0:
        raise ValueError(f"quantile level {q!r} outside [0, 1]")
    exact = Fraction(repr(float(q))) * n
    rank = exact.numerator // exact.denominator
    if rank * exact.denominator != exact.numerator:
        rank += 1
    return max(rank, 1)


def quantile(values, q, method="nearest", presorted=False):
    """The q-quantile of `values` (may contain +inf); None when empty.

    nearest: x_(ceil(q n)), 1-based order statistic, x_(1) at q = 0.
    linear:  Hyndman-Fan type 7, h = (n - 1) q, x_(floor h) + frac(h) x
             (x_(floor h + 1) - x_(floor h)) (0-based), with +inf
             propagating only when it carries positive weight.
    """
    data = values if presorted else sorted(values)
    n = len(data)
    if n == 0:
        return None
    if method == "nearest":
        return data[_ceil_rank(q, n) - 1]
    if method != "linear":
        raise ValueError(f"unknown quantile method {method!r}")
    if not 0.0 <= q <= 1.0:
        raise ValueError(f"quantile level {q!r} outside [0, 1]")
    h = Fraction(repr(float(q))) * (n - 1)
    lo = h.numerator // h.denominator
    frac = h - lo
    if frac == 0 or lo + 1 >= n:
        return data[lo]
    a, b = data[lo], data[lo + 1]
    if b == INF:
        return INF
    return a + float(frac) * (b - a)


class Quantiles:
    """Streaming, exact quantile accumulator (keeps every value).

    `add(x)`; +inf is allowed (a censored or never-reached sample) and
    counts in n and in the ranks; `mean()` and `finite_mean()` say which
    they average. NaN is refused."""

    __slots__ = ("_data", "_sorted", "n_inf")

    def __init__(self, values=()):
        self._data = array("d")
        self._sorted = True
        self.n_inf = 0
        for value in values:
            self.add(value)

    def add(self, value):
        value = float(value)
        if value != value:
            raise ValueError("NaN sample")
        if value == INF:
            self.n_inf += 1
        if self._data and value < self._data[-1]:
            self._sorted = False
        self._data.append(value)

    def merge(self, other):
        for value in other._data:
            self.add(value)

    def __len__(self):
        return len(self._data)

    def values(self):
        if not self._sorted:
            self._data = array("d", sorted(self._data))
            self._sorted = True
        return self._data

    def quantile(self, q, method="nearest"):
        return quantile(self.values(), q, method, presorted=True)

    def finite_quantile(self, q, method="nearest"):
        """The quantile, or None when empty or when it lands on +inf."""
        value = self.quantile(q, method)
        return None if value is None or value == INF else value

    def mean(self):
        """Mean of all samples; None when empty, +inf with a censored one."""
        if not self._data:
            return None
        if self.n_inf:
            return INF
        return math.fsum(self._data) / len(self._data)

    def finite_mean(self):
        finite = [value for value in self._data if value != INF]
        return math.fsum(finite) / len(finite) if finite else None


def ols_slope(xs, ys):
    """Least-squares slope of ys on xs; None with < 2 distinct xs."""
    n = len(xs)
    if n < 2 or n != len(ys):
        return None
    mx = math.fsum(xs) / n
    my = math.fsum(ys) / n
    sxx = math.fsum((x - mx) * (x - mx) for x in xs)
    if sxx == 0.0:
        return None
    return math.fsum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx


SIZE_BINS = 10   # [E] validation_targets block_spread90_vs_size_slope: size deciles


def binned_median_slope(xs, ys, bins=SIZE_BINS):
    """OLS slope through (median x, median y) of up to `bins` equal-count
    bins of the points sorted by x (the target's decile-median slope);
    None with < 2 bins of distinct median x."""
    points = sorted(zip(xs, ys))
    n = len(points)
    if n < 2:
        return None
    k = min(bins, n)
    mx, my = [], []
    for b in range(k):
        part = points[b * n // k:(b + 1) * n // k]
        mx.append(quantile([p[0] for p in part], 0.5, "linear"))
        my.append(quantile([p[1] for p in part], 0.5, "linear"))
    return ols_slope(mx, my)


# ------------------------------------------------------------- observers
def observer_set(nodes, n_sim, rule, region_names=None, seed=0):
    """Sorted node ids of an observer rule (module docstring)."""
    if rule == "all":
        return list(range(n_sim))
    if rule == "datacentre":
        return [node for node in range(n_sim) if not nodes.home[node]]
    if rule == "targets_rule":
        if region_names is None:
            raise ValueError("targets_rule needs region_names")
        size = _ceil_rank(float(OBSERVER_SAMPLE_SHARE), n_sim)
        eu_size = max(1, int(round(EU_SHARE_OF_OBSERVERS * size)))
        rest_size = max(1, size - eu_size)
        chosen = []
        for wanted, size_part in ((EU_REGIONS, eu_size),
                                  (NA_OC_REGIONS, rest_size)):
            part = [node for node in range(n_sim)
                    if region_names[nodes.region[node]] in wanted]
            part.sort(key=lambda node: (detmath.stable_fraction(
                seed, "observers", node), node))
            chosen.extend(part[:size_part])
        return sorted(chosen)
    raise ValueError(f"unknown observer rule {rule!r}; known: "
                     f"{', '.join(OBSERVER_RULES)}")


def node_group(nodes, n_sim, group):
    """Sorted node ids of a NODE_GROUPS entry (builders only in `builder`)."""
    if group == "builder":
        return [node for node in range(nodes.n) if nodes.is_builder[node]]
    sim = range(n_sim)
    if group == "all":
        return list(sim)
    if group == "dc":
        return [node for node in sim if not nodes.home[node]]
    if group == "home":
        return [node for node in sim if nodes.home[node]]
    if group == "validator":
        return [node for node in sim if nodes.is_validator[node]]
    if group == "supernode":
        return [node for node in sim if nodes.is_supernode[node]]
    raise ValueError(f"unknown node group {group!r}; known: "
                     f"{', '.join(NODE_GROUPS)}")


# ------------------------------------------------------------ row schema
Column = namedtuple("Column", ("name", "type", "unit", "na"))
# na: "never" | a short rule saying when the value is None.

NA_EMPTY = "no sample in the window"
NA_CENSORED = "no sample, or the quantile lands on a censored/unreached one"
NA_DEPLOY = "not this deployment (or input not provided by the run)"


def _c(name, kind, unit, na="never"):
    return Column(name, kind, unit, na)


def _identity_columns():
    return [
        _c("spec_hash", "str", ""), _c("code_commit", "str", ""),
        _c("params_sha256", "str", ""), _c("deployments_sha256", "str", ""),
        _c("deployment", "str", ""),
        _c("candidate", "str", "", "today: no PQ candidate"),
        _c("sig_bytes", "int", "B", "today: no PQ candidate"),
        _c("perms", "int", "perm", "today: no PQ candidate"),
        _c("k", "int", "sig"), _c("nodes", "int", "node"),
        _c("seed", "int", ""), _c("gas_limit", "int", "gas"),
        _c("byte_cap", "int", "B"),
        _c("dep_cap", "int", "dep", "no dependency cap"),
        _c("slot_ms", "int", "ms"), _c("demand_mode", "str", ""),
        _c("offered_tps", "float", "tx/s", NA_DEPLOY),
        _c("observers", "str", ""), _c("window_s", "float", "s"),
        _c("slots_window", "int", "slot"),
    ]


def _throughput_columns():
    cols = [_c("tps_included", "float", "tx/s"),
            _c("pq_tps", "float", "tx/s"),
            _c("sig_per_s", "float", "sig/s")]
    for cls in TX_CLASSES:
        cols.append(_c(f"{cls}_tps", "float", "tx/s", NA_DEPLOY
                       if cls in ("pcs", "ecdsa") else "never"))
    cols += [
        _c("ecdsa_bg_tps", "float", "tx/s", "no fluid background counter"),
        _c("offered_pq_tps_measured", "float", "tx/s", NA_DEPLOY),
        _c("demand_ratio", "float", "", "no PQ offered in the window"),
        _c("gas_per_s", "float", "gas/s"),
        _c("deps_per_s", "float", "dep/s"),
        _c("pq_share_gas", "float", "", "no gas included"),
        _c("pq_share_bytes", "float", "", "no bytes included"),
        _c("blocks_canonical", "int", "block"),
        _c("blocks_orphaned", "int", "block"),
        _c("payloads_missed", "int", "slot"),
        _c("slots_empty", "int", "slot"),
        _c("orphan_share", "float", "", "no block published"),
        _c("txs_requeued", "int", "tx", NA_DEPLOY),
    ]
    return cols


def _latency_columns():
    cols = []
    for cls in TX_CLASSES:
        cols.append(_c(f"incl_{cls}_born", "int", "tx"))
        cols.append(_c(f"incl_{cls}_censored_share", "float", "", NA_EMPTY))
        for tag in ("p50", "p95", "p99"):
            cols.append(_c(f"incl_latency_{cls}_{tag}_s", "float", "s",
                           NA_CENSORED))
    cols.append(_c("censored_share", "float", "", NA_EMPTY))
    for tag in ("t50", "t90", "t99"):
        cols.append(_c(f"tx_reach_{tag}_p50_ms", "float", "ms", NA_CENSORED))
    cols.append(_c("tx_reach_sampled", "int", "tx"))
    return cols


def _block_columns():
    cols = [_c("block_bytes_mean", "float", "B", NA_EMPTY),
            _c("block_gas_fill_mean", "float", "", "no canonical payload "
               "or no gas limit"),
            _c("block_deps_mean", "float", "dep", NA_EMPTY)]
    for topic in BLOCK_TOPICS:
        cols.append(_c(f"{topic}_published", "int", "msg"))
        cols.append(_c(f"{topic}_unreached", "int", "msg"))
        for tag in ("t50", "t90", "t99"):
            for over in ("p50", "p90"):
                cols.append(_c(f"{topic}_reach_{tag}_{over}_ms", "float",
                               "ms", NA_CENSORED))
    cols += [_c("cl_dup_copies_per_node_msg", "float", "copy", NA_EMPTY),
             _c("idontwant_saved_bytes_share", "float", "", NA_EMPTY)]
    # S6b: the after-import event (payload receipt, data available, EL
    # execution) beside the gossip receipt, from the payload's publish.
    for tag in ("t50", "t90", "t99"):
        for over in ("p50", "p90"):
            cols.append(_c(f"import_reach_{tag}_{over}_ms", "float", "ms",
                           NA_CENSORED))
    cols += [_c("import_minus_receipt_p50_ms", "float", "ms", NA_CENSORED),
             _c("import_minus_receipt_p99_ms", "float", "ms", NA_CENSORED),
             _c("local_build_share", "float", "", NA_EMPTY)]
    return cols


BW_STATS = ("up_el_mean", "up_cl_mean", "up_mean", "up_p90", "down_mean",
            "down_p90", "updown_bg_mean")


def _bandwidth_columns():
    cols = []
    for group in NODE_GROUPS:
        for stat in BW_STATS:
            cols.append(_c(f"bw_{group}_{stat}_mbps", "float", "Mbit/s",
                           "empty node group"))
    cols += [_c("dup_bytes_share", "float", "", NA_EMPTY),
             _c("dup_bytes_share_el", "float", "", NA_EMPTY),
             _c("dup_bytes_share_cl", "float", "", NA_EMPTY)]
    return cols


def _compute_columns():
    cols = []
    for group in NODE_GROUPS:
        cols.append(_c(f"cpu_util_{group}_mean", "float", "",
                       "empty node group or no CPU counter"))
        cols.append(_c(f"cpu_util_{group}_p90", "float", "",
                       "empty node group or no CPU counter"))
    cols += [_c("prover_util_agg_mean", "float", "", NA_DEPLOY),
             _c("prover_util_agg_p90", "float", "", NA_DEPLOY),
             _c("prover_util_builder_mean", "float", "", NA_DEPLOY),
             _c("repeated_proving_share", "float", "", NA_DEPLOY),
             _c("intervals_overrun", "int", "interval", NA_DEPLOY),
             _c("builder_proof_slack_ms_mean", "float", "ms", NA_DEPLOY)]
    return cols


def _cost_columns():
    return [_c("base_fee_end_gwei", "float", "gwei/gas", NA_DEPLOY),
            _c("user_price_pq_p50_gwei", "float", "gwei/gas", NA_EMPTY),
            _c("user_price_pq_p90_gwei", "float", "gwei/gas", NA_EMPTY),
            _c("user_fee_pq_p50_gwei", "float", "gwei", NA_EMPTY),
            _c("user_fee_pq_p90_gwei", "float", "gwei", NA_EMPTY),
            _c("user_fee_ecdsa_p50_gwei", "float", "gwei", NA_EMPTY)]


# Validation columns: `val.<target id>.<key>` for every key of every
# target's tolerance in data/phase4/validation_targets.json (schema 2),
# plus the extra observed keys computed for free. test_metrics checks the
# map against the file in both directions.
VALIDATION_KEYS = (
    ("block_spread_first_to_reach90_ms", ("p10", "p50", "p90", "p99")),
    ("block_spread90_vs_size_slope", ("slope_ms_per_kB",)),
    ("block_spread_first_to_reach50_ms", ("p10", "p50", "p90", "p99")),
    ("block_arrival_from_slot_start_ms", ("p10", "p50", "p90", "p99")),
    ("block_arrival_by_continent_lag_ms",
     tuple(f"{c}_{q}" for c in CONTINENTS for q in ("p50", "p90"))),
    ("block_late_share_reach90_gt_4s", ("share_all_nodes",)),
    ("all_nodes_block_reach_p99_ms", ("share_before_4s",)),
    ("column_spread_first_to_reach90_ms", ("p50", "p90", "p99")),
    ("supernode_last_column_ms_by_blobs",
     tuple(f"blobs_{b}_p50" for b in SUPERNODE_BLOB_BINS)),
    ("tx_spread_first_to_reach90_ms",
     ("reach50_p50", "reach50_p90", "reach50_p99", "reach90_p50",
      "reach90_p90", "reach90_p99")),
    ("tx_later_sighting_within_1s_share",
     tuple(name for name, _ms in SIGHTING_WINDOWS_MS)),
    ("orphan_reorg_share", ("share",)),
    ("bandwidth_home_validating_node_mbps", ("mid",)),
    ("bandwidth_supernode_mbps", ("baseline",)),
    ("included_tx_per_s", ("mean",)),
    ("gas_used_over_limit", ("p10", "p50", "p90", "p99", "mean")),
    # S6b: gossip receipt and after-import events side by side, on the
    # run's observers (validation_targets_v2.json; notes/phase4/
    # build-s6b.md). "import" = slot.SlotState.import_at.
    ("block_event_late_share_reach90_gt_4s", ("gossip", "import")),
    ("block_event_share_before_4s", ("gossip", "import")),
    ("block_import_from_slot_start_ms", ("p10", "p50", "p90", "p99")),
    ("block_import_spread_first_to_reach90_ms", ("p50", "p90")),
    ("block_import_minus_gossip_ms", ("p10", "p50", "p90", "p99")),
    ("supernode_col64_from_first_seen_ms",
     tuple(f"blobs_{lo}_{hi}_p50" for lo, hi in COL64_BLOB_BINS) +
     ("slope_ms_per_blob",)),
    ("el_import_ms_per_block", ("p50", "p90")),
)


def _validation_columns():
    cols = []
    for target, keys in VALIDATION_KEYS:
        for key in keys:
            cols.append(_c(f"val.{target}.{key}", "float", "",
                           NA_CENSORED))
    return cols


def _attribution_columns():
    from starksim.v3.attribution import RESOURCES
    cols = [_c(f"util_{name}", "float", "", "resource absent in this "
               "deployment or input not provided") for name in RESOURCES]
    cols += [_c("binding", "str", ""), _c("binding_method", "str", ""),
             _c("binding_margin", "float", "", "fewer than two resources "
                "measured")]
    return cols


def _build_columns():
    cols = (_identity_columns() + _throughput_columns() +
            _latency_columns() + _block_columns() + _bandwidth_columns() +
            _compute_columns() + _cost_columns() + _attribution_columns() +
            _validation_columns())
    names = [col.name for col in cols]
    if len(names) != len(set(names)):
        raise AssertionError("duplicate row column")
    return tuple(cols)


ROW_COLUMNS = _build_columns()
COLUMN_NAMES = tuple(col.name for col in ROW_COLUMNS)
_TYPES = {"int": int, "float": float, "str": str}


def validate_row(row):
    """Raise MetricsError unless `row` has exactly ROW_COLUMNS, in order,
    each value of the column's type (bool is not an int; a float is
    finite) or None where the NA rule allows it."""
    if tuple(row) != COLUMN_NAMES:
        missing = [name for name in COLUMN_NAMES if name not in row]
        extra = [name for name in row if name not in COLUMN_NAMES]
        raise MetricsError(f"row columns differ: missing {missing}, "
                           f"extra {extra}, or order")
    for col in ROW_COLUMNS:
        value = row[col.name]
        if value is None:
            if col.na == "never":
                raise MetricsError(f"{col.name} is None (NA not allowed)")
            continue
        if isinstance(value, bool) or not isinstance(value, _TYPES[col.type]):
            raise MetricsError(f"{col.name}: {value!r} is not {col.type}")
        if col.type == "float" and not math.isfinite(value):
            raise MetricsError(f"{col.name}: {value!r} is not finite")


# --------------------------------------------------------- slot records
# One record per slot of the run, written by the slot clock (S3a). Optional
# fields default to None; a None input makes the dependent columns NA.
SlotRecord = namedtuple("SlotRecord", (
    "slot",                  # int
    "status",                # SLOT_STATUSES
    "payload",               # deploy.Payload or None
    "block_msg",             # CL message id of the beacon block (or None)
    "payload_msg",           # CL message id of the ePBS payload (or None)
    "column_msgs",           # tuple of data-column message ids
    "blobs",                 # blobs in the block
    "base_fee_wei",          # base fee of the block (wei per gas)
    "block_quorum_ms",       # attester quorum reached (abs ms) or None
    "attest_deadline_ms",    # abs ms
    "payload_quorum_ms",     # PTC quorum reached (abs ms) or None
    "ptc_deadline_ms",       # abs ms
    "proof_ms",              # builder final-proof time planned
    "proof_window_ms",       # time available for it
    "tx_undelivered_share",  # eligible txs not at the builder at freeze
    "requeued",              # txs returned to pools by this slot
    "import_at",             # {node: import done, abs ms} (S6b) or None
    "el_ms",                 # {node: EL execution CPU ms} (S6b) or None
    "local_build",           # built and published by the proposer (S6b)
), defaults=(None, None, ()) + (None,) * 13)  # [A] the 13 optional fields after column_msgs

# subs: frozenset of subscribed nodes, or None = every node subscribes.
MsgView = namedtuple("MsgView", ("first", "t_pub", "origin", "size",
                                 "copies", "subs"), defaults=(None,))


class RunData:
    """Everything build_row reads: plain values, no engine. `collect`
    fills it from a live context; tests fill it by hand.

    Attributes (all required unless a default is shown):
    identity      dict of the identity columns' values (see ROW_COLUMNS)
    slot_ms, warmup, measured, horizon_ms
    gas_limit, byte_cap, dep_cap (None = no cap)
    txs           TxTable (or an object with the same column lists)
    nodes         NodeTable-like (n, home, region, is_validator,
                  is_supernode, is_builder)
    n_sim         simulated nodes (builders are n_sim ... nodes.n - 1)
    region_names  list (index = nodes.region value)
    counters      {name: per-node list or scalar}, window deltas
    slots         list of SlotRecord (any order, one per slot)
    msgs          {msg_id: MsgView}
    tx_reach      {tx: list of first-admission times per node} ({} = none)
    cores         per-node verify cores (None = no CPU columns)
    provers       per-node parallel provers (None = no prover columns)
    down_eff_Bpms per-node downlink after background (bytes/ms) or None
    bg_Bpms       per-node (up, down) background bytes/ms or None
    times_proved  per-tx raw-leaf proof count list or None
    base_fee_end_wei, observers (list of nodes), observer_rule (str),
    seed, offered_tps (None)
    """

    def __init__(self, **values):
        self.offered_tps = None
        self.dep_cap = None
        self.msgs = {}
        self.tx_reach = {}
        self.cores = None
        self.provers = None
        self.down_eff_Bpms = None
        self.bg_Bpms = None
        self.times_proved = None
        self.base_fee_end_wei = None
        self.observers = None
        self.observer_rule = "all"
        self.seed = 0
        self.region_names = None
        self.__dict__.update(values)

    def window(self):
        t0 = self.warmup * self.slot_ms
        t1 = (self.warmup + self.measured) * self.slot_ms
        return t0, t1


# ------------------------------------------------------------- row build
def build_row(data):
    """The run's row: every ROW_COLUMNS name in order (validated)."""
    from starksim.v3 import attribution
    row = dict.fromkeys(COLUMN_NAMES)
    t0, t1 = data.window()
    window_s = (t1 - t0) / MS_PER_S
    first, last = data.warmup, data.warmup + data.measured
    records = {}
    for record in data.slots:
        if record.status not in SLOT_STATUSES:
            raise MetricsError(f"slot {record.slot}: unknown status "
                               f"{record.status!r}")
        if record.slot in records:
            raise MetricsError(f"slot {record.slot} recorded twice")
        records[record.slot] = record
    window_slots = [records[s] for s in range(first, last) if s in records]
    if len(window_slots) != data.measured:
        raise MetricsError(f"{data.measured - len(window_slots)} window "
                           "slot(s) without a record")
    observers = (data.observers if data.observers is not None
                 else list(range(data.n_sim)))

    _identity(row, data, window_s)
    canonical = [r for r in window_slots if r.status == STATUS_CANONICAL]
    _throughput(row, data, records, first, last, window_s, canonical,
                window_slots)
    _latency(row, data, records, t0, t1, observers)
    _blocks(row, data, window_slots, canonical, observers)
    _bandwidth(row, data, window_s)
    _compute(row, data, window_s)
    _cost(row, data, records, first, last)
    _validation(row, data, window_slots, canonical, observers, window_s)
    util = attribution.utilisation(data, row)
    for name, value in util.items():
        row[f"util_{name}"] = value
    label = attribution.binding_from_util(util)
    row["binding"] = label.binding
    row["binding_method"] = label.method
    row["binding_margin"] = label.margin
    validate_row(row)
    return row


def _identity(row, data, window_s):
    for key, value in data.identity.items():
        if key not in row:
            raise MetricsError(f"unknown identity column {key!r}")
        row[key] = value
    row["gas_limit"] = int(data.gas_limit)
    row["byte_cap"] = int(data.byte_cap)
    row["dep_cap"] = None if data.dep_cap is None else int(data.dep_cap)
    row["slot_ms"] = int(data.slot_ms)
    row["offered_tps"] = (None if data.offered_tps is None
                          else float(data.offered_tps))
    row["observers"] = data.observer_rule
    row["window_s"] = window_s
    row["slots_window"] = int(data.measured)


def _included_in_window(data, records, first, last):
    """Tx ids included in canonical payloads of window slots; raises when
    a tx is marked included in a slot that is not canonical."""
    txs = data.txs
    chosen = []
    for tx, slot in enumerate(txs.included_slot):
        if slot == NOT_INCLUDED:
            continue
        record = records.get(slot)
        if record is None or record.status != STATUS_CANONICAL:
            raise MetricsError(f"tx {tx} included in slot {slot}, which is "
                               "not canonical")
        if first <= slot < last:
            chosen.append(tx)
    return chosen


def _bundle_columns(txs):
    """(is_bundle, bundle_of) columns of deploy_agg's pcs_bundler route, or
    (None, None). A bundle row is the on-chain tx of a bundle; its users
    (bundle_of >= 0) are the transactions counted in throughput, latency
    and cost, while gas and bytes on chain are the bundle's."""
    extra = getattr(txs, "extra", None) or {}
    flag = extra.get("deploy.is_bundle")
    owner = extra.get("deploy.bundle_of")
    return (None if flag is None else flag[0],
            None if owner is None else owner[0])


def _throughput(row, data, records, first, last, window_s, canonical,
                window_slots):
    txs = data.txs
    included = _included_in_window(data, records, first, last)
    by_kind = [0] * len(KIND_NAMES)
    sigs = 0
    pq_gas = pq_bytes = 0
    is_bundle, bundle_of = _bundle_columns(txs)
    for tx in included:
        kind = txs.kind[tx]
        if is_bundle is not None and is_bundle[tx]:
            # pcs_bundler bundle row: on chain (gas, bytes), but its users
            # are the transactions and signatures (S5: counted once).
            pq_gas += txs.gas[tx]
            pq_bytes += txs.bytes_chain[tx]
            continue
        by_kind[kind] += 1
        sigs += txs.k[tx]
        if kind in PQ_KINDS and (bundle_of is None or bundle_of[tx] < 0):
            pq_gas += txs.gas[tx]
            pq_bytes += txs.bytes_chain[tx]
    deployment = data.identity.get("deployment")
    # Explicit txs (PQ and explicit ECDSA; pcs_bundler bundle rows out,
    # their users in): the fluid ECDSA background is `ecdsa_bg_tps`.
    row["tps_included"] = sum(by_kind) / window_s
    row["pq_tps"] = sum(by_kind[k] for k in PQ_KINDS) / window_s
    row["sig_per_s"] = sigs / window_s
    for cls in TX_CLASSES:
        value = by_kind[_KIND_OF_CLASS[cls]] / window_s
        if cls == "pcs" and deployment != "leanpcs":
            value = None
        row[f"{cls}_tps"] = value
    bg = data.counters.get("demand.bg_included")
    row["ecdsa_bg_tps"] = None if bg is None else bg / window_s
    born = data.counters.get("demand.born")
    if born is not None:
        offered = sum(born[k] for k in PQ_KINDS)
        row["offered_pq_tps_measured"] = offered / window_s
        row["demand_ratio"] = (row["pq_tps"] / row["offered_pq_tps_measured"]
                               if offered else None)
    gas = sum(r.payload.gas_used for r in canonical)
    nbytes = sum(r.payload.bytes for r in canonical)
    row["gas_per_s"] = gas / window_s
    row["deps_per_s"] = sum(r.payload.deps for r in canonical) / window_s
    row["pq_share_gas"] = pq_gas / gas if gas else None
    row["pq_share_bytes"] = pq_bytes / nbytes if nbytes else None
    counts = {status: 0 for status in SLOT_STATUSES}
    for record in window_slots:
        counts[record.status] += 1
    row["blocks_canonical"] = counts[STATUS_CANONICAL]
    row["blocks_orphaned"] = counts[STATUS_ORPHANED]
    row["payloads_missed"] = counts[STATUS_MISSED]
    row["slots_empty"] = counts[STATUS_EMPTY]
    published = len(window_slots) - counts[STATUS_EMPTY]
    row["orphan_share"] = (counts[STATUS_ORPHANED] / published
                           if published else None)
    requeued = [r.requeued for r in window_slots]
    row["txs_requeued"] = (None if any(v is None for v in requeued)
                           else int(sum(requeued)))


def _latency(row, data, records, t0, t1, observers):
    txs = data.txs
    acc = {cls: Quantiles() for cls in TX_CLASSES}
    is_bundle = _bundle_columns(txs)[0]
    for tx, born in enumerate(txs.born):
        if not t0 <= born < t1:
            continue
        if is_bundle is not None and is_bundle[tx]:
            continue
        cls = KIND_NAMES[txs.kind[tx]]
        slot = txs.included_slot[tx]
        at = txs.included_at[tx]
        if slot == NOT_INCLUDED or at > data.horizon_ms:
            acc[cls].add(INF)
        else:
            acc[cls].add((at - born) / MS_PER_S)
    total = censored = 0
    for cls in TX_CLASSES:
        q = acc[cls]
        total += len(q)
        censored += q.n_inf
        row[f"incl_{cls}_born"] = len(q)
        row[f"incl_{cls}_censored_share"] = (q.n_inf / len(q) if len(q)
                                             else None)
        for tag, level in (("p50", 0.5), ("p95", P95), ("p99", P99)):
            row[f"incl_latency_{cls}_{tag}_s"] = q.finite_quantile(level)
    row["censored_share"] = censored / total if total else None
    # Tx reach: time from the first admission anywhere to share q of the
    # observers, for sampled txs born in the window (never reached = inf).
    per_q = {tag: Quantiles() for tag in ("t50", "t90", "t99")}
    sampled = 0
    for tx in sorted(data.tx_reach):
        if not t0 <= txs.born[tx] < t1:
            continue
        times = data.tx_reach[tx]
        seen = [t for t in times if t >= 0.0]
        if not seen:
            continue
        sampled += 1
        start = min(seen)
        sample = sorted(times[v] - start if times[v] >= 0.0 else INF
                        for v in observers)
        for tag, level in (("t50", 0.5), ("t90", P90), ("t99", P99)):
            per_q[tag].add(quantile(sample, level, presorted=True)
                           if sample else INF)
    for tag in ("t50", "t90", "t99"):
        row[f"tx_reach_{tag}_p50_ms"] = per_q[tag].finite_quantile(0.5)
    row["tx_reach_sampled"] = sampled


def _reach_sample(view, observers):
    """Sorted times from publish to first receipt over the observers
    (the publisher excluded), never-received = +inf."""
    first = view.first
    return sorted(first[v] - view.t_pub if first[v] >= 0.0 else INF
                  for v in _subscribed(view, observers) if v != view.origin)


def _subscribed(view, observers):
    if view.subs is None:
        return observers
    return [v for v in observers if v in view.subs]


def _blocks(row, data, window_slots, canonical, observers):
    if canonical:
        row["block_bytes_mean"] = math.fsum(
            r.payload.bytes for r in canonical) / len(canonical)
        row["block_deps_mean"] = math.fsum(
            r.payload.deps for r in canonical) / len(canonical)
        if data.gas_limit:
            row["block_gas_fill_mean"] = math.fsum(
                r.payload.gas_used for r in canonical) / (
                    len(canonical) * data.gas_limit)
    copies = []
    saved = data.counters.get("cl.idontwant_saved_bytes")
    received = data.counters.get("links.bytes_down")
    for topic, field in (("block", "block_msg"), ("payload", "payload_msg")):
        per_q = {tag: Quantiles() for tag in ("t50", "t90", "t99")}
        published = unreached = 0
        for record in window_slots:
            msg_id = getattr(record, field)
            if msg_id is None:
                continue
            view = data.msgs.get(msg_id)
            if view is None:
                raise MetricsError(f"slot {record.slot}: {topic} message "
                                   f"{msg_id!r} has no receipt data")
            published += 1
            sample = _reach_sample(view, observers)
            if sample and sample[-1] == INF:
                unreached += 1
            for tag, level in (("t50", 0.5), ("t90", P90), ("t99", P99)):
                per_q[tag].add(quantile(sample, level, presorted=True)
                               if sample else INF)
            copies.extend(view.copies[v] for v in _subscribed(
                view, observers) if v != view.origin)
        row[f"{topic}_published"] = published
        row[f"{topic}_unreached"] = unreached
        for tag in ("t50", "t90", "t99"):
            row[f"{topic}_reach_{tag}_p50_ms"] = per_q[tag].finite_quantile(
                0.5)
            row[f"{topic}_reach_{tag}_p90_ms"] = per_q[tag].finite_quantile(
                P90)
    row["cl_dup_copies_per_node_msg"] = (math.fsum(copies) / len(copies)
                                         if copies else None)
    _imports(row, data, window_slots, observers)
    if saved is not None and received is not None:
        total = sum(saved) + sum(received)
        row["idontwant_saved_bytes_share"] = (sum(saved) / total
                                              if total else None)


def _payload_view(data, record):
    """The MsgView whose receipt starts the import (the ePBS payload, else
    the MEV-boost block), or None."""
    msg_id = record.payload_msg or record.block_msg
    return None if msg_id is None else data.msgs.get(msg_id)


def _import_times(record, view, nodes):
    """Sorted import times over `nodes` (never = +inf); None without
    import data."""
    if record.import_at is None:
        return None
    return sorted(record.import_at.get(v, INF) for v in nodes)


def _imports(row, data, window_slots, observers):
    """import_reach_* (from the payload's publish, like *_reach_*),
    import minus gossip receipt per (block, observer), local builds."""
    per_q = {tag: Quantiles() for tag in ("t50", "t90", "t99")}
    lag = Quantiles()
    local = blocks = 0
    for record in window_slots:
        view = _payload_view(data, record)
        if view is None:
            continue
        blocks += 1
        local += 1 if record.local_build else 0
        watchers = [v for v in _subscribed(view, observers)
                    if v != view.origin]
        times = _import_times(record, view, watchers)
        if times is None:
            continue
        for tag, level in (("t50", 0.5), ("t90", P90), ("t99", P99)):
            per_q[tag].add(quantile(times, level, presorted=True) -
                           view.t_pub if times else INF)
        for v in watchers:
            at = record.import_at.get(v)
            if at is not None and view.first[v] >= 0.0:
                lag.add(at - view.first[v])
    for tag in ("t50", "t90", "t99"):
        row[f"import_reach_{tag}_p50_ms"] = per_q[tag].finite_quantile(0.5)
        row[f"import_reach_{tag}_p90_ms"] = per_q[tag].finite_quantile(P90)
    row["import_minus_receipt_p50_ms"] = lag.finite_quantile(0.5)
    row["import_minus_receipt_p99_ms"] = lag.finite_quantile(P99)
    row["local_build_share"] = local / blocks if blocks else None


def _mbps(byte_count, window_s):
    return byte_count * BITS_PER_BYTE / (window_s * MBIT)


def _group_stats(values):
    q = Quantiles(values)
    if not len(q):
        return None, None
    return q.mean(), q.quantile(P90)


def _down_bytes(c):
    """Per-node bytes received: links.bytes_down plus the EL announcement
    bytes elgossip stamps without a downlink entry (el.<rule>.ann_bytes_in,
    review F18); None without link counters."""
    down = c.get("links.bytes_down")
    if down is None:
        return None
    total = list(down)
    for name in sorted(c):
        if name.startswith("el.") and name.endswith(".ann_bytes_in"):
            total = [a + b for a, b in zip(total, c[name])]
    return total


def _bandwidth(row, data, window_s):
    c = data.counters
    up_el = c.get("links.bytes_up_el")
    up_cl = c.get("links.bytes_up_cl")
    down = _down_bytes(c)
    ctrl_up = c.get("links.ctrl_bytes_up")
    ctrl_down = c.get("links.ctrl_bytes_down")
    if up_el is None:
        return
    window_ms = window_s * MS_PER_S
    for group in NODE_GROUPS:
        members = node_group(data.nodes, data.n_sim, group)
        if not members:
            continue
        el = [_mbps(up_el[v], window_s) for v in members]
        cl = [_mbps(up_cl[v], window_s) for v in members]
        up = [_mbps(up_el[v] + up_cl[v] + ctrl_up[v], window_s)
              for v in members]
        dn = [_mbps(down[v] + ctrl_down[v], window_s) for v in members]
        row[f"bw_{group}_up_el_mean_mbps"] = _group_stats(el)[0]
        row[f"bw_{group}_up_cl_mean_mbps"] = _group_stats(cl)[0]
        row[f"bw_{group}_up_mean_mbps"], row[f"bw_{group}_up_p90_mbps"] = (
            _group_stats(up))
        row[f"bw_{group}_down_mean_mbps"], row[
            f"bw_{group}_down_p90_mbps"] = _group_stats(dn)
        if data.bg_Bpms is not None:
            total = [up[i] + dn[i] + _mbps(
                (data.bg_Bpms[v][0] + data.bg_Bpms[v][1]) * window_ms,
                window_s) for i, v in enumerate(members)]
            row[f"bw_{group}_updown_bg_mean_mbps"] = _group_stats(total)[0]
    received = sum(down)
    el_dup = sum(sum(values) for name, values in sorted(c.items())
                 if name.startswith("el.") and name.endswith(".dup_bytes"))
    cl_dup = sum(c["cl.dup_bytes"]) if "cl.dup_bytes" in c else 0
    if received:
        row["dup_bytes_share"] = (el_dup + cl_dup) / received
        row["dup_bytes_share_el"] = el_dup / received
        row["dup_bytes_share_cl"] = cl_dup / received


def _compute(row, data, window_s):
    window_ms = window_s * MS_PER_S
    busy = data.counters.get("mempool.cpu_busy_ms")
    if busy is not None and data.cores is not None:
        for group in NODE_GROUPS:
            members = node_group(data.nodes, data.n_sim, group)
            if members:
                util = [busy[v] / (data.cores[v] * window_ms)
                        for v in members]
                mean, p90 = _group_stats(util)
                row[f"cpu_util_{group}_mean"] = mean
                row[f"cpu_util_{group}_p90"] = p90
    pbusy = data.counters.get("prover.busy_ms")
    if pbusy is not None and data.provers is not None:
        agg = [v for v in range(data.n_sim) if data.provers[v] > 0]
        builders = [v for v in range(data.n_sim, data.nodes.n)
                    if data.provers[v] > 0]
        if agg:
            util = [pbusy[v] / (data.provers[v] * window_ms) for v in agg]
            row["prover_util_agg_mean"], row["prover_util_agg_p90"] = (
                _group_stats(util))
        if builders:
            util = [pbusy[v] / (data.provers[v] * window_ms)
                    for v in builders]
            row["prover_util_builder_mean"] = _group_stats(util)[0]
        overrun = data.counters.get("prover.intervals_overrun")
        if overrun is not None:
            row["intervals_overrun"] = int(sum(overrun))
        plans = data.counters.get("prover.builder_plans")
        slack = data.counters.get("prover.builder_slack_ms")
        if plans:
            row["builder_proof_slack_ms_mean"] = slack / plans
    if data.times_proved is not None:
        proved = [n for n in data.times_proved if n > 0]
        if proved:
            row["repeated_proving_share"] = (
                sum(1 for n in proved if n > 1) / len(proved))


def _cost(row, data, records, first, last):
    if data.base_fee_end_wei is not None:
        row["base_fee_end_gwei"] = data.base_fee_end_wei / WEI_PER_GWEI
    txs = data.txs
    price, fee, fee_ecdsa = Quantiles(), Quantiles(), Quantiles()
    is_bundle = _bundle_columns(txs)[0]
    for tx, slot in enumerate(txs.included_slot):
        if slot == NOT_INCLUDED or not first <= slot < last:
            continue
        if is_bundle is not None and is_bundle[tx]:
            continue
        base = records[slot].base_fee_wei
        if base is None:
            continue
        paid = base + min(txs.tip[tx], txs.fee_cap[tx] - base)
        if txs.kind[tx] in PQ_KINDS:
            price.add(paid / WEI_PER_GWEI)
            fee.add(paid * txs.gas[tx] / WEI_PER_GWEI)
        elif txs.kind[tx] == KIND_ECDSA:
            fee_ecdsa.add(paid * txs.gas[tx] / WEI_PER_GWEI)
    row["user_price_pq_p50_gwei"] = price.quantile(0.5)
    row["user_price_pq_p90_gwei"] = price.quantile(P90)
    row["user_fee_pq_p50_gwei"] = fee.quantile(0.5)
    row["user_fee_pq_p90_gwei"] = fee.quantile(P90)
    row["user_fee_ecdsa_p50_gwei"] = fee_ecdsa.quantile(0.5)


def _validation(row, data, window_slots, canonical, observers, window_s):
    """val.<target>.<key> columns, on the run's observer set (S6 runs
    `today` with observers=datacentre or targets_rule)."""
    def put(target, key, value):
        name = f"val.{target}.{key}"
        if name not in row:
            raise MetricsError(f"unknown validation column {name}")
        row[name] = None if value is None or value == INF else float(value)

    spreads = {0.5: Quantiles(), P90: Quantiles()}
    arrivals = Quantiles()
    lags = {c: Quantiles() for c in CONTINENTS}
    sizes, spread90s = [], []
    late = blocks = 0
    pairs = before = 0
    for record in window_slots:
        if record.block_msg is None:
            continue
        view = data.msgs[record.block_msg]
        slot_start = record.slot * data.slot_ms
        # Xatu sentries are not the proposer: the publisher is excluded
        # here as in _reach_sample (review F15).
        watchers = [v for v in observers if v != view.origin]
        everyone = sorted(view.first[v] if view.first[v] >= 0.0 else INF
                          for v in range(data.n_sim) if v != view.origin)
        blocks += 1
        if everyone and quantile(everyone, P90, presorted=True) - \
                slot_start > LATE_REACH_MS:
            late += 1
        for t in everyone:
            pairs += 1
            if t - slot_start < LATE_REACH_MS:
                before += 1
        times = sorted(view.first[v] if view.first[v] >= 0.0 else INF
                       for v in watchers)
        if not times:
            continue
        first_seen = times[0]
        if first_seen == INF:
            # Reached no observer: spreads undefined, counted as +inf so
            # quantiles landing on it are NA (review F14: was inf - inf).
            for level in (0.5, P90):
                spreads[level].add(INF)
            for v in watchers:
                arrivals.add(INF)
            continue
        for level in (0.5, P90):
            spreads[level].add(quantile(times, level, presorted=True) -
                               first_seen)
        reach90 = quantile(times, P90, presorted=True) - first_seen
        if reach90 != INF:
            sizes.append(view.size / BYTES_PER_KB)
            spread90s.append(reach90)
        for v in watchers:
            t = view.first[v]
            arrivals.add(t - slot_start if t >= 0.0 else INF)
            if data.region_names is not None:
                continent = CONTINENT_OF_REGION.get(
                    data.region_names[data.nodes.region[v]])
                if continent is not None:
                    lags[continent].add(t - first_seen if t >= 0.0 else INF)
    for level, target in ((P90, "block_spread_first_to_reach90_ms"),
                          (0.5, "block_spread_first_to_reach50_ms")):
        for key, q in (("p10", P10), ("p50", 0.5), ("p90", P90),
                       ("p99", P99)):
            put(target, key, spreads[level].finite_quantile(q, "linear"))
    put("block_spread90_vs_size_slope", "slope_ms_per_kB",
        binned_median_slope(sizes, spread90s))
    for key, q in (("p10", P10), ("p50", 0.5), ("p90", P90), ("p99", P99)):
        put("block_arrival_from_slot_start_ms", key,
            arrivals.finite_quantile(q, "linear"))
    for c in CONTINENTS:
        for key, q in (("p50", 0.5), ("p90", P90)):
            put("block_arrival_by_continent_lag_ms", f"{c}_{key}",
                lags[c].finite_quantile(q, "linear"))
    put("block_late_share_reach90_gt_4s", "share_all_nodes",
        late / blocks if blocks else None)
    put("all_nodes_block_reach_p99_ms", "share_before_4s",
        before / pairs if pairs else None)
    _validation_events(data, window_slots, observers, put)
    _validation_columns_and_txs(row, data, window_slots, canonical,
                                observers, window_s, put)


def _validation_events(data, window_slots, observers, put):
    """S6b: the same block on the run's observers (Xatu sentries are hosted
    nodes, so datacentre observers compare with the ethPandaOps subset),
    as gossip receipt (libp2p / beacon-API block_gossip) and as import
    (beacon-API `block`, after import): share of (block, observer) before
    4 s and share of blocks whose reach90 is after 4 s, from slot start;
    import arrival quantiles and spread (first import -> 90 %); import
    minus gossip receipt at the same node; EL execution ms per (block,
    node)."""
    shares = {name: {"blocks": 0, "late": 0, "pairs": 0, "before": 0}
              for name in ("gossip", "import")}
    arrivals, spreads, lags, el = (Quantiles(), Quantiles(), Quantiles(),
                                   Quantiles())
    for record in window_slots:
        view = _payload_view(data, record)
        if view is None or record.block_msg is None:
            continue
        slot_start = record.slot * data.slot_ms
        watchers = [v for v in observers if v != view.origin]
        if not watchers:
            continue
        gossip = sorted(view.first[v] if view.first[v] >= 0.0 else INF
                        for v in watchers)
        events = [("gossip", gossip)]
        if record.import_at is not None:
            imported = _import_times(record, view, watchers)
            events.append(("import", imported))
            for t in imported:
                arrivals.add(t - slot_start)
            if imported[0] != INF:
                spreads.add(quantile(imported, P90, presorted=True) -
                            imported[0])
            for v in watchers:
                at = record.import_at.get(v)
                if at is not None and view.first[v] >= 0.0:
                    lags.add(at - view.first[v])
        if record.el_ms is not None:
            for v in watchers:
                if v in record.el_ms:
                    el.add(record.el_ms[v])
        for name, times in events:
            acc = shares[name]
            acc["blocks"] += 1
            if quantile(times, P90, presorted=True) - slot_start > \
                    LATE_REACH_MS:
                acc["late"] += 1
            for t in times:
                acc["pairs"] += 1
                if t - slot_start < LATE_REACH_MS:
                    acc["before"] += 1
    for name, acc in shares.items():
        put("block_event_late_share_reach90_gt_4s", name,
            acc["late"] / acc["blocks"] if acc["blocks"] else None)
        put("block_event_share_before_4s", name,
            acc["before"] / acc["pairs"] if acc["pairs"] else None)
    for key, q in (("p10", P10), ("p50", 0.5), ("p90", P90), ("p99", P99)):
        put("block_import_from_slot_start_ms", key,
            arrivals.finite_quantile(q, "linear"))
        put("block_import_minus_gossip_ms", key,
            lags.finite_quantile(q, "linear"))
    for key, q in (("p50", 0.5), ("p90", P90)):
        put("block_import_spread_first_to_reach90_ms", key,
            spreads.finite_quantile(q, "linear"))
        put("el_import_ms_per_block", key, el.finite_quantile(q, "linear"))


def _validation_columns_and_txs(row, data, window_slots, canonical,
                                observers, window_s, put):
    column_spread = Quantiles()
    last_column = {b: Quantiles() for b in SUPERNODE_BLOB_BINS}
    supernodes = [v for v in range(data.n_sim) if data.nodes.is_supernode[v]]
    for record in window_slots:
        if not record.column_msgs:
            continue
        slot_start = record.slot * data.slot_ms
        for msg_id in record.column_msgs:
            view = data.msgs[msg_id]
            times = sorted(view.first[v] if view.first[v] >= 0.0 else INF
                           for v in _subscribed(view, observers))
            if times and times[0] != INF:
                column_spread.add(quantile(times, P90, presorted=True) -
                                  times[0])
        if record.blobs in last_column and supernodes:
            for v in supernodes:
                worst = max((data.msgs[m].first[v]
                             if data.msgs[m].first[v] >= 0.0 else INF)
                            for m in record.column_msgs)
                last_column[record.blobs].add(worst - slot_start)
    for key, q in (("p50", 0.5), ("p90", P90), ("p99", P99)):
        put("column_spread_first_to_reach90_ms", key,
            column_spread.finite_quantile(q, "linear"))
    for b in SUPERNODE_BLOB_BINS:
        put("supernode_last_column_ms_by_blobs", f"blobs_{b}_p50",
            last_column[b].finite_quantile(0.5, "linear"))
    _validation_col64(data, window_slots, observers, put)
    # Tx spread over EU/OC observers and later sightings, explicit ECDSA.
    txs = data.txs
    t0, t1 = data.window()
    eu_oc = [v for v in observers if data.region_names is not None and
             CONTINENT_OF_REGION.get(data.region_names[
                 data.nodes.region[v]]) in ("EU", "OC")]
    reach = {0.5: Quantiles(), P90: Quantiles()}
    within = {name: 0 for name, _ms in SIGHTING_WINDOWS_MS}
    later = 0
    for tx in sorted(data.tx_reach):
        if txs.kind[tx] != KIND_ECDSA or not t0 <= txs.born[tx] < t1:
            continue
        times = data.tx_reach[tx]
        if eu_oc:
            sample = sorted(times[v] if times[v] >= 0.0 else INF
                            for v in eu_oc)
            if sample[0] != INF:
                for level in (0.5, P90):
                    reach[level].add(quantile(sample, level,
                                              presorted=True) - sample[0])
        seen = sorted(times[v] for v in observers if times[v] >= 0.0)
        for t in seen[1:]:
            later += 1
            for name, limit in SIGHTING_WINDOWS_MS:
                if t - seen[0] <= limit:
                    within[name] += 1
    for level, tag in ((0.5, "reach50"), (P90, "reach90")):
        for key, q in (("p50", 0.5), ("p90", P90), ("p99", P99)):
            put("tx_spread_first_to_reach90_ms", f"{tag}_{key}",
                reach[level].finite_quantile(q, "linear"))
    for name, _limit in SIGHTING_WINDOWS_MS:
        put("tx_later_sighting_within_1s_share", name,
            within[name] / later if later else None)
    put("orphan_reorg_share", "share", row["orphan_share"])
    put("bandwidth_supernode_mbps", "baseline",
        row["bw_supernode_updown_bg_mean_mbps"])
    home_validators = [v for v in range(data.n_sim) if data.nodes.home[v]
                       and data.nodes.is_validator[v]]
    put("bandwidth_home_validating_node_mbps", "mid",
        _home_validator_mbps(data, home_validators, window_s))
    ecdsa = row["ecdsa_tps"] or 0.0
    if row["ecdsa_bg_tps"] is not None:
        ecdsa += row["ecdsa_bg_tps"]
    put("included_tx_per_s", "mean", ecdsa)
    fills = Quantiles(r.payload.gas_used / data.gas_limit
                      for r in canonical if data.gas_limit)
    for key, q in (("p10", P10), ("p50", 0.5), ("p90", P90), ("p99", P99)):
        put("gas_used_over_limit", key, fills.finite_quantile(q, "linear"))
    put("gas_used_over_limit", "mean", fills.finite_mean())


def _validation_col64(data, window_slots, observers, put):
    """S6b: supernode observers' 64th distinct column minus the block's
    first sighting (min over observers of the block and its columns, as
    Xatu's first sighting anywhere; calib2 3), p50 per pooled blob bin,
    and the OLS slope of per-slot medians on the blob count."""
    supers = [v for v in observers if data.nodes.is_supernode[v]]
    bins = {b: Quantiles() for b in COL64_BLOB_BINS}
    xs, ys = [], []
    for record in window_slots:
        if not record.column_msgs or record.block_msg is None or \
                not supers:
            continue
        block = data.msgs[record.block_msg]
        views = [data.msgs[m] for m in record.column_msgs]
        firsts = [block.first[v] for v in observers if block.first[v] >= 0.0
                  and v != block.origin]
        for view in views:
            firsts.extend(view.first[v] for v in _subscribed(view, observers)
                          if view.first[v] >= 0.0 and v != view.origin)
        if not firsts:
            continue
        first_seen = min(firsts)
        values = []
        for v in supers:
            if v == block.origin:
                continue
            times = sorted(view.first[v] if view.first[v] >= 0.0 else INF
                           for view in views)
            if len(times) < RECONSTRUCT_COLUMNS:
                continue
            values.append(times[RECONSTRUCT_COLUMNS - 1] - first_seen)
        for (lo, hi), acc in bins.items():
            if lo <= record.blobs <= hi:
                for value in values:
                    acc.add(value)
        finite = sorted(value for value in values if value != INF)
        if finite:
            xs.append(float(record.blobs))
            ys.append(quantile(finite, 0.5, presorted=True))
    for (lo, hi), acc in bins.items():
        put("supernode_col64_from_first_seen_ms", f"blobs_{lo}_{hi}_p50",
            acc.finite_quantile(0.5, "linear"))
    put("supernode_col64_from_first_seen_ms", "slope_ms_per_blob",
        ols_slope(xs, ys) if len(set(xs)) > 1 else None)


def _home_validator_mbps(data, members, window_s):
    c = data.counters
    if not members or data.bg_Bpms is None or "links.bytes_up_el" not in c:
        return None
    window_ms = window_s * MS_PER_S
    down = _down_bytes(c)
    total = [c["links.bytes_up_el"][v] + c["links.bytes_up_cl"][v] +
             c["links.ctrl_bytes_up"][v] + down[v] +
             c["links.ctrl_bytes_down"][v] +
             (data.bg_Bpms[v][0] + data.bg_Bpms[v][1]) * window_ms
             for v in members]
    return _mbps(math.fsum(total) / len(total), window_s)


# ------------------------------------------------- live-run collection
EV_WINDOW = "metrics.window"


class Recorder:
    """Counter snapshots at the measured window's ends (two events)."""

    def __init__(self, ctx):
        self.ctx = ctx
        spec = ctx.spec
        self.slot_ms = float(spec.chain.slot_ms)
        self.warmup = spec.slots.warmup
        self.measured = spec.slots.measured
        self.snapshots = [None, None]
        ctx.on(EV_WINDOW, self._snap)
        ctx.at(self.warmup * self.slot_ms, EV_WINDOW, 0)
        ctx.at((self.warmup + self.measured) * self.slot_ms, EV_WINDOW, 1)

    def _snap(self, which):
        if self.ctx.links is not None:
            self.ctx.links.settle_all()
        self.snapshots[which] = self.ctx.counters.snapshot()

    def deltas(self):
        """{name: per-node list or scalar}, end minus start."""
        start, end = self.snapshots
        if start is None or end is None:
            raise MetricsError("the run did not reach the window's end")
        result = {}
        for name, values in end["arrays"].items():
            before = start["arrays"].get(name)
            if before is None:
                before = [0] * len(values)
            result[name] = [a - b for a, b in zip(values, before)]
        for name, value in end["scalars"].items():
            result[name] = value - start["scalars"].get(name, 0)
        return result


def collect(ctx, recorder, slots, identity, tx_rule=None, offered_tps=None,
            horizon_ms=None):
    """RunData from a finished live run. `slots`: the slot clock's
    SlotRecord list (S3a); `identity`: the identity column values (S5);
    `tx_rule`: the EL gossip rule whose object ids are tx ids (for tx reach;
    None = no tx reach columns); `horizon_ms`: end of the drain slots
    (None = (warmup + measured + drain) x slot_ms; review F23)."""
    spec = ctx.spec
    topo = ctx.topo
    nodes = ctx.nodes
    n_sim = topo.n if topo is not None else nodes.n
    region_names = getattr(topo, "region_names", None)
    msgs = {}
    if ctx.cl is not None:
        for record in slots:
            ids = [record.block_msg, record.payload_msg]
            ids.extend(record.column_msgs or ())
            for msg_id in ids:
                if msg_id is None or msg_id in msgs:
                    continue
                msg = ctx.cl.by_id[msg_id]
                subs = frozenset(state_members(ctx.cl.sub_bits[msg.topic]))
                msgs[msg_id] = MsgView(list(msg.first), msg.t_pub,
                                       msg.origin, msg.size,
                                       list(msg.copies), subs)
    tx_reach = {}
    if tx_rule is not None and ctx.el is not None:
        for tx in ctx.el.reach_objects(tx_rule):
            tx_reach[tx] = ctx.el.reach_times(tx_rule, tx)
    cores = provers = down_eff = bg = None
    if ctx.mempool is not None and topo is not None:
        from starksim.v3.mempool import node_cpu
        cores = node_cpu(ctx)[0]
    if ctx.prover is not None:
        provers = [len(free) for free in ctx.prover.free_at]
    if ctx.links is not None:
        down_eff = list(ctx.links.down)
        bg = [(ctx.links.bg_up[v], ctx.links.bg_down[v])
              for v in range(nodes.n)]
    times_proved = ctx.txs.extra.get("prover.times_proved")
    observers = observer_set(nodes, n_sim, spec.obs.observers, region_names,
                             spec.seed)
    base_fee = ctx.demand.base_fee() if ctx.demand is not None else None
    return RunData(
        identity=identity, slot_ms=float(spec.chain.slot_ms),
        warmup=spec.slots.warmup, measured=spec.slots.measured,
        horizon_ms=(horizon_ms if horizon_ms is not None else
                    (spec.slots.warmup + spec.slots.measured +
                     spec.slots.drain) * float(spec.chain.slot_ms)),
        gas_limit=spec.chain.gas_limit,
        byte_cap=spec.chain.byte_cap,
        dep_cap=(spec.chain.dep_cap if spec.deployment in ("8288", "leanpcs")
                 else None),
        txs=ctx.txs, nodes=nodes, n_sim=n_sim, region_names=region_names,
        counters=recorder.deltas(), slots=list(slots), msgs=msgs,
        tx_reach=tx_reach, cores=cores, provers=provers,
        down_eff_Bpms=down_eff, bg_Bpms=bg,
        times_proved=None if times_proved is None else times_proved[0],
        base_fee_end_wei=base_fee, observers=observers,
        observer_rule=spec.obs.observers, seed=spec.seed,
        offered_tps=offered_tps)

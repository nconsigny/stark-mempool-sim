"""8288 full and leanPCS full: the aggregation deployment plug-ins.

Stage S3b (arch.md 3.9, 3.10, section 4 row S3, 5.1; spec.md sections 3, 4,
4b; interfaces.md tx_shapes and section 4 corrections; PHASE4-NETSIM.md
section 2 decisions: one engine, `sig_route` dependency | pcs_client |
pcs_bundler, block dependency cap none / 256 / 4096). Notes and evidence:
`notes/phase4/build-s3b.md`. Every number this module produces is [Mo]: the
campaign's model over spec constants, never a measurement.

One engine, two constant sets:

    Deploy8288      tx_shapes.8288.pq            96-B deps, 28,517 + 36,264 k
    DeployLeanPCS   tx_shapes.leanpcs.<route>    65-B deps (Keccak deps hash),
                                                 28,533 + 35,740 k, or a PCS
                                                 route (7 claims per proof)

Flow of a leanSPHINCS-signed tx (spec.md B7-B17, C7):

1. **Submission** (`submit`, hooks.tx_born). Route `dependency`: the user
   sends a mode-0 wrapper `[tx, 0, [deps, sigs]]` (B7) to its entry node,
   which verifies the k signatures natively (B8: k x P x 179 ns of one
   core). Route `pcs_client` (and zk-app PCS-claim txs, demand.pcs_share):
   the wallet proves its signatures in a client STARK
   (`PcsProving.client_prove_ms`, M4 host [A]) and only then sends a mode-1
   wrapper (C6, C9: PCS deps travel only in mode 1). Route `pcs_bundler`:
   the user sends signature + op off-protocol to a bundler (C9), which proves
   bundles of <= bundle_cap(P) signatures (226 for P99r; 7 claims per proof;
   4.86 s per full P99r bundle on the 8-thread EPYC class) and submits one
   mode-1 wrapper per bundle tx.
2. **Relay** (eth/73, PR #12423, spec.md B13): every validated wrapper is
   announced to every eth/73 peer; suppressed toward a peer whose exchanged
   wrappers already cover its txs unless it reduces proof bytes or
   verification work (`_suppress`); a wrapper whose txs the pool rejected is
   relayed unchanged only if it newly admitted >= 1 tx and no fewer than it
   rejected (already pending txs count as neither; an included tx counts as
   a rejection, its nonce is spent).
3. **Admission** (`admit`, B8/B9): mode 0 <= MAX_LEANSIG_DEPS_PER_WRAPPER
   (16) signature deps, each tx <= MAX_SIGS_PER_TX (16); mode 1 <=
   `agg.wrapper_cap_deps` (256, PR #12590) deps and <= `agg.wrapper_cap_bytes`
   (2 MiB); CPU = native verifies of signatures new to the node, or one
   recursive STARK verify (params provers.stark_verify_ms by node class).
4. **Aggregation** (`on_interval`, B10/B11, arch.md 3.10): every
   AGGREGATION_INTERVAL an aggregating node plans one job with
   `Provers.plan_interval` (own open aggregate, removals, received
   aggregates, raw signatures by tip) bounded so the new aggregate fits one
   mode-1 wrapper (<= wrapper cap deps); a full aggregate is sealed and a
   new one opened (PR #12590 "bounded subsets").
5. **Builder** (`build`, B14-B18): kind-blind tip order over the pool and the
   fluid ECDSA background, packed under the gas limit, the EIP-7934 byte cap
   minus the block proof's reservation (proof counts toward the cap: PR
   #12479 body; the master header is part of the RLP block as well), and the
   block dependency cap (none / 256 / 4096); then the final proof must be
   done before the bid (`Provers.largest_prefix` over the window from
   `freeze_ms` to the slot start minus `prover.bid_margin_ms`): what does not
   fit is dropped (counted as a deadline miss), and freed gas goes to ECDSA.
6. **Import** (`import_ms`, B17): one STARK verify + execution of the
   payload (8288 VERIFY + SENDER exec 8,900 + 2,100 per dep, ECDSA gas) at the
   node's EVM rate.

Interfaces beyond the frozen `Deployment` (proposed in notes/phase4/inbox.md):
`install()`, `start_intervals(until_ms)`, `on_payload_canonical(slot,
payload)` (wired to hooks.payload_canonical), `build(..., il_children=())`,
`limits()`, tx columns `deploy.bundle_of`, `deploy.is_bundle`,
`deploy.submit_bytes`.
"""

from starksim.v3 import params as P
from starksim.v3.deploy import (ACCEPT, REFUSE, Admission, Deployment,
                                Payload, TxShape)
from starksim.v3.elgossip import (DROPPED, HELD, RULE_ETH68, RULE_ETH73,
                                  UNSEEN)
from starksim.v3.fastbits import WeightSum, bits_span
from starksim.v3.mempool import ADDED, DUPLICATE
from starksim.v3.prover import (PcsProving, ProverError, ceil_div,
                                coefficients, popcount)
from starksim.v3.state import (KIND_ECDSA, KIND_PCS, KIND_PQ1, KIND_PQK,
                               NOT_INCLUDED, members)

ROUTES = ("dependency", "pcs_client", "pcs_bundler")
MODE0 = 0
MODE1 = 1
NS_PER_MS = 1_000_000          # [E] unit definition
HASH_REF_BYTES = 32            # [PR] eip-8437-pr12423.md:62 compact reference (encoding hash)

# Event kinds S3b registers (owner prefix "deploy."):
EV_INTERVAL = "deploy.interval"          # one node's aggregation interval
EV_CLIENT_READY = "deploy.client_ready"  # a wallet's client STARK is done
EV_TO_BUNDLER = "deploy.to_bundler"      # a user's sig reaches the bundler
EV_BUNDLE_TIMER = "deploy.bundle_timer"  # the bundler's partial-bundle wait
EV_BUNDLE_DONE = "deploy.bundle_done"    # a bundle proof is done

P.register_bindings({
    "agg_stark_verify_ms": (P.NET, ("provers", "stark_verify_ms"), None),
    "agg_native_verify_ns_per_perm": (
        P.NET, ("provers", "native_verify_ns_per_perm"), None),
    "agg_node_classes": (P.NET, ("compute", "node_classes"), None),
    "agg_evm_gas_per_s_per_core": (
        P.NET, ("compute", "evm_gas_per_s_per_core"), None),
    # PR #12590 MAX_AGGREGATED_LEANSTARK_DEPS: only read under the "yes"
    # reading of deployments.leanpcs.pcs_leanstark_cap_reading.
    "agg_leanstark_block_cap": (
        P.DEP, ("constants", "MAX_AGGREGATED_LEANSTARK_DEPS_pr12590"),
        (16, "PR #12590 MAX_AGGREGATED_LEANSTARK_DEPS (16 per block); "  # [PR] eip-8288-pr12590.md
             "notes/phase4/verify-pcs-claims.md section 3")),
    # Execution gas of one PCS proof's PIOP verifier (VERIFY frame), the
    # term the pcs gas coefficient objects price at 35,452 g.
    "agg_pcs_piop_exec_gas": (
        P.DEP, ("tx_shapes", "leanpcs", "pcs_client", "piop_exec_gas"),
        (35_452, "deployments_v3.json tx_shapes.leanpcs.pcs_client.gas "  # [Mo] SPEC-REC.md:42 400-sig shape
                 "standard side '35,452 g' and note 'PIOP exec 35,452 = "
                 "the 400-sig shape (SPEC-REC.md:42)'")),
    # How long the bundler waits for a full bundle before proving a partial
    # one; and the client-STARK proof size of a pcs_client wrapper.
    "agg_bundle_wait_ms": (
        P.DEP, ("deployments", "leanpcs", "bundler_wait_ms"),
        (1000.0, "[A] one AGGREGATION_INTERVAL (E8288:45); no source: a "  # [A] build-s3b.md 4
                 "bundler under load fills a P99r bundle in < 1 s")),
})

# Stark-verify keys of params provers.stark_verify_ms by compute class of
# the node (compute.node_classes cpu text): [Mo] mapping, build-s3b.md 4.
VERIFY_KEY_OF_CLASS = {"datacentre": "box16", "home_700_up": "eip7870",
                       "home_100_699": "eip7870",
                       "home_50_99": "eip7870_full",
                       "home_below_50": "eip7870_full"}


def _value(node):
    return node["value"] if isinstance(node, dict) and "value" in node \
        else node


class _Wrapper:
    """A wrapper object (eth/73 id = index in AggDeployment.wrappers)."""

    __slots__ = ("mode", "cover", "txs", "deps", "claims", "bytes",
                 "proof_bytes", "origin", "born", "kind", "full")

    def __init__(self, mode, cover, deps, claims, size, proof_bytes, origin,
                 born, kind, full):
        self.mode = mode
        self.cover = cover
        self.txs = tuple(members(cover))
        self.deps = deps
        self.claims = claims
        self.bytes = size
        self.proof_bytes = proof_bytes
        self.origin = origin
        self.born = born
        self.kind = kind     # "user0", "client", "bundle", "agg"
        # Complete wrapper bytes (every tx body in full): what the 2 MiB
        # MAX_WRAPPER_BYTES applies to; `bytes` is the compact transfer
        # size (eip-8437-pr12423.md, hash-based omission).
        self.full = full


class AggDeployment(Deployment):
    """The shared aggregation engine; subclasses fix the constant set."""

    id = None
    FORMAT = None

    def __init__(self, ctx):
        super().__init__(ctx)
        spec = self.spec
        params = self.params
        self.route = spec.agg.sig_route if self.FORMAT == "leanpcs" \
            else "dependency"
        if self.route not in ROUTES:
            raise ValueError(f"unknown sig_route {self.route!r}")
        self.B = int(spec.sig_bytes)
        self.P = int(spec.perms)
        self.slot_ms = float(spec.chain.slot_ms)
        # tx_shapes coefficient objects (interfaces.md section 1, 4): every
        # sub-key is a {value, unit, source, status} leaf.
        shapes = params.section("tx_shapes")
        if self.FORMAT == "8288":
            self.dep_shape = shapes["8288"]["pq"]
        else:
            self.dep_shape = shapes["leanpcs"]["pq_dependency"]
        self.client_shape = shapes["leanpcs"]["pcs_client"]
        self.bundler_shape = shapes["leanpcs"]["pcs_bundler"]
        self.dep_bytes = int(_value(self.dep_shape["dep_bytes"]))
        self.deps_per_sig = int(_value(self.dep_shape["deps_per_sig"]))
        self.pcs_dep_bytes = int(_value(self.client_shape["dep_bytes"]))
        self.pcs = PcsProving(params, self.P) if self.FORMAT == "leanpcs" \
            else None
        self.max_sigs_per_tx = int(params.constant_value("MAX_SIGS_PER_TX"))
        self.mode0_cap = int(params.constant_value(
            "MAX_LEANSIG_DEPS_PER_WRAPPER"))
        # Block proof bytes reserved under the EIP-7934 cap (PR #12479:
        # MAX_STARK_PROOF_BYTES "TBD"): the larger of the EIP text's ~256 kB
        # and the leanVM model's largest proof (373 KiB) [Mo], so a planned
        # proof never pushes a packed payload over the cap.
        self.proof_reserve = max(
            int(params.constant_value("block_stark_bytes_eip_text")),
            1024 * int(max(params.constant_value(  # [E] KiB
                "recursive_stark_bytes_leanvm_model"))))
        self.exec_base = int(params.constant_value("verify_8288_exec_base"))
        self.exec_per_dep = int(params.constant_value(
            "verify_8288_exec_per_dep"))
        self.native_ns = float(params.value("agg_native_verify_ns_per_perm"))
        self.client_stark_bytes = int(params.constant_value(
            "client_stark_bytes_model"))
        interval = spec.agg.interval_ms
        if interval is None:
            interval = 1000.0 * float(params.constant_value(
                "AGGREGATION_INTERVAL"))
        self.interval_ms = float(interval)
        self.payload_due_share = float(params.constant_value(
            "PAYLOAD_DUE_BPS")) / 10_000        # [E] basis points per unit
        self.installed = False
        if ctx.topo is not None and ctx.links is not None:
            self.install()

    # ---------------------------------------------------------- shapes
    def tx_shape(self, kind, k):
        """TxShape of a tx of `kind` with k signatures (arch.md 3.9):
        coefficient objects of deployments_v3.json tx_shapes, never string
        formulas. Under pcs_bundler a user's PQ tx is its share of a full
        bundle (gas, chain bytes; its deps ride in the bundle tx, 0 here) and
        bytes_wire is the off-protocol user -> bundler submission."""
        if kind == KIND_ECDSA:
            raise ValueError("ECDSA shapes come from demand (histograms)")
        if kind == KIND_PCS:
            return self._pcs_app_shape()
        if kind not in (KIND_PQ1, KIND_PQK):
            raise ValueError(f"unknown kind {kind}")
        if self.route == "dependency":
            shape = self.dep_shape
            vars_ = {"k": k, "B": self.B, "P": self.P}
            return TxShape(
                int(coefficients(_value(shape["wire_bytes"]), **vars_)),
                int(coefficients(_value(shape["chain_bytes"]), **vars_)),
                int(coefficients(_value(shape["gas"]), **vars_)),
                k * self.deps_per_sig, 0, shape["gas"]["status"])
        if self.route == "pcs_client":
            shape = self.client_shape
            g = self.pcs.proofs(k)
            vars_ = {"k": k, "B": self.B, "P": self.P, "g": g}
            return TxShape(
                int(coefficients(_value(shape["wire_bytes"]), **vars_)),
                int(coefficients(_value(shape["chain_bytes"]), **vars_)),
                self.pcs.gas(k, "pcs_client"), self.pcs.claims(k), 0,
                shape["gas"]["status"])
        # pcs_bundler: the user's share of a full bundle.
        shape = self.bundler_shape
        users = self.users_per_bundle(k)
        sigs = users * k
        g = self.pcs.proofs(sigs)
        vars_ = {"k": sigs, "B": self.B, "P": self.P, "g": g}
        wire = int(coefficients(_value(shape["user_to_bundler_bytes"]),
                                k=k, B=self.B))
        chain = int(coefficients(_value(shape["chain_bytes"]), **vars_))
        return TxShape(wire, chain // users,
                       self.pcs.gas(sigs, "pcs_bundler") // users, 0, 0,
                       shape["gas"]["status"])

    def _pcs_app_shape(self):
        """A zk-app PCS-claim tx (spec.md C8, Q8): one client proof (g = 1,
        7 claims), no per-signature binding (k = 0) [Mo]: the pcs_client
        coefficient objects at k = 0, g = 1."""
        shape = self.client_shape
        vars_ = {"k": 0, "B": self.B, "P": self.P, "g": 1}
        claims = int(_value(shape["claims_per_tx"])["per_g"])
        return TxShape(
            int(coefficients(_value(shape["wire_bytes"]), **vars_)),
            int(coefficients(_value(shape["chain_bytes"]), **vars_)),
            int(coefficients(_value(shape["gas"]), **vars_)), claims, 0,
            shape["gas"]["status"])

    def users_per_bundle(self, k):
        """Users of k signatures in one full bundle: bundle_cap(P) // k."""
        return max(1, self.pcs.cap // k)

    # ---------------------------------------------------------- bounds
    def limits(self, gas_limit=None, dep_cap="spec", k=None):
        """Ideal-network limits in signatures per second (arch.md 5.1,
        interfaces.md section 4 table): {"gas", "bytes", "dep_cap"
        (when a cap is set), "leanstark_cap" (pcs routes under the 'yes'
        reading)}; a value is what that resource alone admits per slot,
        whole txs per block (pcs_bundler: whole users for gas and bytes,
        whole bundles for the dependency caps)."""
        spec = self.spec
        gas_limit = spec.chain.gas_limit if gas_limit is None else gas_limit
        cap = spec.chain.dep_cap if dep_cap == "spec" else dep_cap
        k = spec.k if k is None else k
        per_s = 1000.0 / self.slot_ms
        result = {}
        if self.route == "pcs_bundler":
            # Gas and bytes: whole users at a full bundle's per-user share
            # (tx_shape), an upper bound: bundlers also ship partial
            # bundles, so whole full bundles per block (the earlier figure,
            # 188.3 sig/s at 60 M) is not one (S6 review: 200.1 measured).
            # Deps: whole bundles of <= bundle_cap users (each bundle needs
            # its claims whatever its size), an upper bound as it stands.
            users = self.users_per_bundle(k)
            sigs = users * k
            unit_deps = self.pcs.claims(sigs)
            share = self.tx_shape(KIND_PQ1, k)
            if gas_limit:
                result["gas"] = (gas_limit // share.gas) * k * per_s
            if spec.chain.byte_cap:
                room = spec.chain.byte_cap - self.proof_reserve
                result["bytes"] = (room // share.bytes_chain) * k * per_s
            if cap is not None:
                result["dep_cap"] = (cap // unit_deps) * sigs * per_s
            if self.pcs.leanstark_reading == "yes":
                leanstark = int(self.params.value("agg_leanstark_block_cap"))
                result["leanstark_cap"] = ((leanstark // unit_deps) * sigs
                                           * per_s)
            return result
        else:
            sigs = k
            shape = self.tx_shape(KIND_PQ1, k)
            unit_gas, unit_deps, unit_bytes = shape.gas, shape.deps, \
                shape.bytes_chain
        if gas_limit:
            result["gas"] = (gas_limit // unit_gas) * sigs * per_s
        if spec.chain.byte_cap:
            room = spec.chain.byte_cap - self.proof_reserve
            result["bytes"] = (room // unit_bytes) * sigs * per_s
        if cap is not None:
            result["dep_cap"] = (cap // unit_deps) * sigs * per_s
        if self.route != "dependency" and \
                self.pcs.leanstark_reading == "yes":
            leanstark = int(self.params.value("agg_leanstark_block_cap"))
            result["leanstark_cap"] = (leanstark // unit_deps) * sigs * per_s
        return result

    def analytic_bounds(self):
        """{"gas", "bytes", "dep_cap", ...} in PQ tx/s of the run's base
        kind (k = spec.k; under pcs_bundler a tx is one user's tx), ideal
        network. Proving is not bounded here: the builder-alone bound is a
        lower bound of proving capacity (build-s2d.md section 3), not an
        upper one."""
        k = self.spec.k
        result = {name: value / k for name, value in self.limits().items()}
        # runner.offered_rates: gas per PQ tx (subtracts ECDSA gas).
        result["gas_per_tx"] = self.tx_shape(KIND_PQ1, k).gas
        return result

    # ---------------------------------------------------------- install
    def install(self):
        """Build the run-time pieces (CPU, mempool, eth/68 + eth/73 gossip,
        provers) unless the runner already set them on ctx, register the
        deploy.* columns, counters and events, and wire the hooks."""
        if self.installed:
            return
        self.installed = True
        ctx = self.ctx
        from starksim.v3 import elgossip as E
        from starksim.v3.mempool import Cpu, Mempool, node_cpu
        from starksim.v3.prover import ProverModel, Provers
        n = ctx.topo.n_total
        self.n = n
        self.n_sim = ctx.topo.n
        cores, gas_per_ms = node_cpu(ctx)
        self.gas_per_ms = gas_per_ms
        self.cpu = Cpu(ctx, lambda node: cores[node])
        if ctx.mempool is None:
            Mempool(ctx)
        self.pool = ctx.mempool
        if ctx.el is None:
            E.ElGossip(ctx, {RULE_ETH68: E.eth68(ctx.params, ctx.spec),
                             RULE_ETH73: E.eth73(ctx.params, ctx.spec)})
        self.el = ctx.el
        self.el.set_suppressor(self._suppress)
        self.el.set_batch_suppressor(self._suppress_batch)
        self.el.set_announce_observer(self._announced)
        self.el.set_held_observer(self._now_held)
        if ctx.prover is None:
            ctx.prover = Provers(ctx, ProverModel(ctx.params, ctx.spec))
        self.provers = ctx.prover
        self.verify_ms = self._verify_ms_table()
        spec = self.spec
        self.wrapper_cap_deps = int(spec.agg.wrapper_cap_deps)
        self.wrapper_cap_bytes = int(spec.agg.wrapper_cap_bytes)
        self.wrappers = []
        # wrapper id -> its tx when it is a single-tx non-mode-1 wrapper,
        # else -1 (S7b, performance: the suppressor's and fold's fast path)
        self.single0 = []
        self.single0_unique = True      # no tx has two such wrappers
        self._single0_txs = set()
        # Per-node aggregation state (arch.md 3.9).
        self.raw = [dict() for _ in range(n)]       # tx -> None (tip order later)
        self.cand = [dict() for _ in range(n)]      # agg id -> cover
        self.own = [None] * n                       # (agg id, cover) open
        self.sealed = [dict() for _ in range(n)]    # agg id -> cover
        self.removals = [0] * n
        self.in_flight = [False] * n
        self.last_interval = [-1] * n
        self.known0 = [dict() for _ in range(n)]    # peer -> cover (mode 0)
        self.known1 = [dict() for _ in range(n)]    # peer -> cover (mode 1)
        # peer -> [(arrival, wrapper ids)]: announcements from peer on
        # their way to the node, folded into known0/known1 once arrived.
        self.heard = [dict() for _ in range(n)]
        # S7b (performance, same folds): an arrived announcement of a
        # wrapper the node does not hold yet is parked by wrapper
        # (obj -> [peers]) instead of being rescanned at every fold, and
        # moved to `ready` (peer -> [objs]) when the node starts holding
        # it; the next fold toward that peer credits it if still held.
        self.parked = [dict() for _ in range(n)]
        self.ready = [dict() for _ in range(n)]
        self.verified = [0] * n                     # txs whose sigs node verified
        self.included = 0                           # bitset, canonical txs
        self.proof_plans = {}                       # slot -> (ms, window ms)
        txs = ctx.txs
        self._sum_deps = WeightSum(txs.deps.__getitem__)
        self._sum_bytes = WeightSum(self._tx_wrapper_bytes)
        self._sum_k = WeightSum(txs.k.__getitem__)
        self._tip_key = {}
        # Every tx that can be raw input has >= 1 dep (k x deps_per_sig,
        # or PCS claims): `_plan` stops once no dep room is left (S7).
        self._raw_deps_positive = self.deps_per_sig >= 1 and int(
            _value(self.client_shape["claims_per_tx"])["per_g"]) >= 1
        self.bundle_of = txs.add_column("deploy.bundle_of", -1)
        self.is_bundle = txs.add_column("deploy.is_bundle", False)
        self.submit_bytes = txs.add_column("deploy.submit_bytes", 0)
        # Execution gas a validator spends on the tx at import (B17).
        self.exec_gas = txs.add_column("deploy.exec_gas", 0)
        self.piop_gas = int(self.params.value("agg_pcs_piop_exec_gas"))
        self.e_u = {"pcs_client": int(self.client_shape["gas"]["params"]
                                      ["e_u"]),
                    "pcs_bundler": int(self.bundler_shape["gas"]["params"]
                                       ["e_u"])}
        counters = ctx.counters
        self.c_admit_ms = counters.array("deploy.admit_cpu_ms", n, 0.0)
        self.c_import_ms = counters.array("deploy.import_ms", n, 0.0)
        for name in ("wrappers_user0", "wrappers_client", "wrappers_bundle",
                     "wrappers_agg", "sealed", "refused_mode0_cap",
                     "refused_sigs_per_tx", "refused_mode1_cap",
                     "refused_mode1_bytes", "refused_mode0_bytes",
                     "relayed", "not_relayed", "leanstark_skipped",
                     "il_included", "undecided_skipped",
                     "suppressed", "intervals", "intervals_busy",
                     "intervals_idle", "aggregate_split",
                     "builder_builds", "builder_deadline_miss",
                     "builder_deadline_dropped", "builder_no_window",
                     "dep_cap_skipped", "gas_skipped", "bytes_skipped",
                     "unprovable_skipped", "bundles", "bundle_sigs",
                     "client_proofs", "bundler_jobs_peak", "pcs_txs",
                     "included_pq", "included_sigs"):
            counters.scalar("deploy." + name)
        for name in ("builder_proof_ms", "client_prove_ms",
                     "bundler_prove_ms", "builder_slack_ms_min"):
            counters.scalar("deploy." + name, 0.0)
        counters.scalars["deploy.builder_slack_ms_min"] = float("inf")
        ctx.on(EV_INTERVAL, self._interval_event)
        ctx.on(EV_CLIENT_READY, self._client_ready)
        if self.route == "pcs_bundler":
            self._bundler_init()
        hooks = ctx.hooks
        hooks.wire("tx_born", self.submit)
        hooks.wire("el_body_received", self._received)
        hooks.wire("object_bytes", self._object_bytes)
        hooks.wire("payload_canonical", self.on_payload_canonical)
        hooks.wire("payload_missed", self.on_payload_missed)
        ctx.deploy = self

    def _verify_ms_table(self):
        """Recursive-STARK verify ms per node (params stark_verify_ms by the
        node's compute class, [Mo] mapping VERIFY_KEY_OF_CLASS)."""
        table = self.params.value("agg_stark_verify_ms")
        names = getattr(self.ctx.topo, "class_names", None) or []
        nodes = self.ctx.nodes
        result = []
        for node in range(self.n):
            key = "box16"
            if names and not nodes.is_builder[node]:
                key = VERIFY_KEY_OF_CLASS.get(
                    names[nodes.uplink_class[node]], "box16")
            value = table[key]
            if isinstance(value, list):
                value = sum(value) / len(value)
            result.append(float(value))
        return result

    def _base_fee(self):
        demand = self.ctx.demand
        return demand.base_fee() if demand is not None else 0

    def base_fee(self):
        """Current base fee (slot.py interface, as deploy_8141)."""
        return self._base_fee()

    # ---------------------------------------------------------- wrappers
    def _new_wrapper(self, mode, cover, origin, kind, proof_bytes=0,
                     size=None):
        txs = self.ctx.txs
        deps = 0
        claims = 0
        body = 0
        for tx in members(cover):
            deps += txs.deps[tx]
            claims += txs.deps[tx] if txs.kind[tx] == KIND_PCS \
                else txs.k[tx]
            body += self._tx_wrapper_bytes(tx)
        full = body + proof_bytes
        if size is None:
            size = full
        if mode == MODE0 or kind in ("client", "bundle"):
            full = size          # submitted whole by their sender
        wrapper = _Wrapper(mode, cover, deps, claims, int(size), proof_bytes,
                           origin, self.ctx.now(), kind, int(full))
        self.wrappers.append(wrapper)
        if mode != MODE1 and len(wrapper.txs) == 1:
            first = wrapper.txs[0]
            if first in self._single0_txs:
                self.single0_unique = False
            self._single0_txs.add(first)
            self.single0.append(first)
        else:
            self.single0.append(-1)
        self.ctx.counters.add("deploy.wrappers_" + kind)
        return len(self.wrappers) - 1

    def _tx_wrapper_bytes(self, tx):
        """A tx's share of a mode-1 wrapper in full: its pooled body and
        its deps (96 / 65 B per leanSPHINCS dep, 33 B per PCS claim:
        LPCS:66-79)."""
        txs = self.ctx.txs
        per_dep = self.pcs_dep_bytes if txs.kind[tx] == KIND_PCS \
            else self.dep_bytes
        return txs.bytes_chain[tx] + txs.deps[tx] * per_dep

    def _object_bytes(self, rule_name, obj):
        if rule_name == RULE_ETH73:
            return self.wrappers[obj].bytes
        return self.ctx.txs.bytes_wire[obj]

    # ---------------------------------------------------------- submit
    def submit(self, tx):
        """hooks.tx_born: the tx enters at its entry node (spec.md 4b row
        "user -> first hop")."""
        ctx = self.ctx
        txs = ctx.txs
        kind = txs.kind[tx]
        node = txs.entry_node[tx]
        self.submit_bytes[tx] = txs.bytes_wire[tx]
        if kind == KIND_ECDSA:
            self._pool_add_eth68(node, tx)
            return
        self._tip_key[tx] = (-txs.tip[tx], tx)
        if kind == KIND_PCS or self.route == "pcs_client":
            # The wallet proves first (client host, C9), then submits a
            # mode-1 wrapper. Its signatures arrive as one child STARK.
            # Import exec: PIOP verifier per proof + per-signature user
            # exec e_u (pcs_client.gas params); a zk app: PIOP only.
            k = txs.k[tx] if kind != KIND_PCS else 1
            if kind == KIND_PCS:
                self.exec_gas[tx] = self.piop_gas
            else:
                self.exec_gas[tx] = (self.piop_gas * self.pcs.proofs(k) +
                                     self.e_u["pcs_client"] * k)
            prove_ms = self.pcs_client_ms(k)
            txs.kind[tx] = KIND_PCS
            # The pooled tx is the frame tx; the STARK lives in the wrapper.
            txs.bytes_wire[tx] = txs.bytes_chain[tx]
            ctx.counters.add("deploy.client_proofs")
            ctx.counters.add("deploy.pcs_txs")
            ctx.counters.scalars["deploy.client_prove_ms"] += prove_ms
            ctx.after(prove_ms, EV_CLIENT_READY, tx)
            return
        if self.route == "pcs_bundler":
            delay = ctx.topo.latency(node, self.bundler_node)
            ctx.after(delay, EV_TO_BUNDLER, tx)
            return
        self.exec_gas[tx] = self.exec_base + self.exec_per_dep * txs.deps[tx]
        wrapper = self._new_wrapper(MODE0, 1 << tx, node, "user0",
                                    size=txs.bytes_wire[tx])
        self._deliver(node, wrapper, None)

    def pcs_client_ms(self, k):
        """Client proving time of k signatures on the wallet host
        (deployments_v3.json proving: default_client_hw), ms."""
        if self.pcs is None:
            pcs = PcsProving(self.params, self.P)
            return pcs.client_prove_ms(k)
        return self.pcs.client_prove_ms(k)

    def _client_ready(self, tx):
        txs = self.ctx.txs
        size = self.submit_bytes[tx]
        wrapper = self._new_wrapper(MODE1, 1 << tx, txs.entry_node[tx],
                                    "client", self.client_stark_bytes,
                                    size=size)
        self._deliver(txs.entry_node[tx], wrapper, None)

    def _deliver(self, node, wrapper, src):
        """A wrapper's body is at `node` (from `src`, None = its sender):
        admission check, CPU, then on_admit."""
        verdict = self.admit(node, RULE_ETH73, wrapper)
        if verdict.verdict == REFUSE:
            self.el.drop(node, RULE_ETH73, wrapper)
            self.parked[node].pop(wrapper, None)    # never held (S7b)
            return
        self.c_admit_ms[node] += verdict.cpu_ms
        self.cpu.run(node, verdict.cpu_ms, self._admitted,
                     (node, RULE_ETH73, wrapper, src))

    def _received(self, node, rule_name, obj, src):
        """hooks.el_body_received."""
        if rule_name == RULE_ETH68:
            verdict = self.admit(node, rule_name, obj)
            self.cpu.run(node, verdict.cpu_ms, self._admitted,
                         (node, rule_name, obj, src))
            return
        self._deliver(node, obj, src)

    def _admitted(self, arg):
        node, rule_name, obj, src = arg
        self._on_admit(node, rule_name, obj, src)

    # ---------------------------------------------------------- admission
    def admit(self, node, rule_name, obj):
        """Admission check of a received object -> Admission (spec.md B8,
        B9, E8288:247-261). ECDSA (eth/68): accepted, no PQ CPU."""
        if rule_name == RULE_ETH68:
            return Admission(ACCEPT, None, 0.0)
        wrapper = self.wrappers[obj]
        txs = self.ctx.txs
        counters = self.ctx.counters
        if wrapper.mode == MODE0:
            if wrapper.claims > self.mode0_cap:
                counters.add("deploy.refused_mode0_cap")
                return Admission(REFUSE, "mode0_cap", 0.0)
            new_sigs = 0
            for tx in wrapper.txs:
                if txs.k[tx] > self.max_sigs_per_tx:
                    counters.add("deploy.refused_sigs_per_tx")
                    return Admission(REFUSE, "sigs_per_tx", 0.0)
                if not (self.verified[node] >> tx) & 1:
                    new_sigs += txs.k[tx]
            if wrapper.full > self.wrapper_cap_bytes:
                counters.add("deploy.refused_mode0_bytes")
                return Admission(REFUSE, "mode0_bytes", 0.0)
            cpu = new_sigs * self.P * self.native_ns / NS_PER_MS
            return Admission(ACCEPT, None, cpu)
        if wrapper.deps > self.wrapper_cap_deps:
            counters.add("deploy.refused_mode1_cap")
            return Admission(REFUSE, "mode1_cap", 0.0)
        if wrapper.full > self.wrapper_cap_bytes:
            counters.add("deploy.refused_mode1_bytes")
            return Admission(REFUSE, "mode1_bytes", 0.0)
        return Admission(ACCEPT, None, self.verify_ms[node])

    def on_admit(self, node, rule_name, obj):
        """Frozen entry point (no known sender)."""
        self._on_admit(node, rule_name, obj, None)

    def _on_admit(self, node, rule_name, obj, src):
        if rule_name == RULE_ETH68:
            self._pool_add_eth68(node, obj, src)
            return
        wrapper = self.wrappers[obj]
        txs = self.ctx.txs
        base_fee = self._base_fee()
        new = 0
        rejected = 0
        prover = self.provers.has_prover(node)
        pool = self.pool
        where = pool.where[node]
        included_slot = txs.included_slot
        included = self.included
        for tx in wrapper.txs:
            if included_slot[tx] != NOT_INCLUDED or (included >> tx) & 1:
                rejected += 1            # nonce spent: pool rejects it
                continue
            if tx < len(where) and where[tx]:
                # Mempool.add's DUPLICATE case, inlined (S7).
                pool.c_duplicate[node] += 1
            else:
                outcome, evicted = pool.add(node, tx, base_fee)
                where = pool.where[node]
                if evicted:
                    self._evicted(node, evicted)
                if outcome == ADDED:
                    new += 1
                elif outcome != DUPLICATE:
                    rejected += 1
                    continue
            if wrapper.mode == MODE0:
                self.verified[node] |= 1 << tx
                if prover and not self._covered(node, tx):
                    self.raw[node][tx] = None
        if wrapper.mode == MODE1:
            self.verified[node] |= wrapper.cover
            if wrapper.kind in ("client", "bundle") and prover:
                # A client STARK is a child the node merges (C11): treat
                # the PCS tx as a raw input of its next job.
                for tx in wrapper.txs:
                    if self.pool.holds(node, tx) and \
                            not self._covered(node, tx):
                        self.raw[node][tx] = None
            else:
                self.cand[node][obj] = wrapper.cover
                for tx in wrapper.txs:
                    self.raw[node].pop(tx, None)
        if src is not None:
            self._mark_known(node, src, wrapper)
        relay = rejected == 0 or (new >= 1 and new >= rejected)
        if wrapper.mode == MODE0 and not self.spec.agg.mode0_relay \
                and src is None:
            relay = False
        if relay:
            self.ctx.counters.scalars["deploy.relayed"] += 1
            self.el.admit(node, RULE_ETH73, obj, src)
        else:
            self.ctx.counters.scalars["deploy.not_relayed"] += 1
            self.el.drop(node, RULE_ETH73, obj)
            self.parked[node].pop(obj, None)        # never held (S7b)

    def _covered(self, node, tx):
        own = self.own[node]
        if own is not None and (own[1] >> tx) & 1:
            return True
        for cover in self.sealed[node].values():
            if (cover >> tx) & 1:
                return True
        return False

    def _pool_add_eth68(self, node, tx, src=None):
        outcome, evicted = self.pool.add(node, tx, self._base_fee())
        self._evicted(node, evicted)
        if outcome == ADDED:
            self.el.admit(node, RULE_ETH68, tx, src)
        else:
            self.el.drop(node, RULE_ETH68, tx)

    def _evicted(self, node, evicted):
        txs = self.ctx.txs
        for tx in evicted:
            self.raw[node].pop(tx, None)
            self.removals[node] |= 1 << tx
            if txs.kind[tx] == KIND_ECDSA:
                self.el.drop(node, RULE_ETH68, tx)

    # ---------------------------------------------------------- suppression
    def _mark_known(self, node, peer, wrapper):
        table = self.known1[node] if wrapper.mode == MODE1 \
            else self.known0[node]
        table[peer] = table.get(peer, 0) | wrapper.cover

    def _suppress(self, node, peer, rule_name, obj):
        """eth/73 suppression (eip-8437-pr12423.md:42): do not announce a
        wrapper whose txs are covered by wrappers exchanged with `peer`,
        unless it reduces proof bytes or verification work. Covered by
        mode-1 wrappers: suppressed. Covered only with mode-0 help: a mode-1
        wrapper still goes when, for the part mode 1 does not cover, the
        signatures' bytes exceed its proof bytes or their native verify
        time exceeds one STARK verify at the peer. When it goes, the cover
        counts as exchanged with the peer."""
        if rule_name != RULE_ETH73:
            return False
        self._fold_heard(node, peer)
        wrapper = self.wrappers[obj]
        cover = wrapper.cover
        known1 = self.known1[node].get(peer, 0)
        if not cover & ~known1:
            self.ctx.counters.add("deploy.suppressed")
            return True
        known0 = self.known0[node].get(peer, 0)
        if not cover & ~(known0 | known1):
            if wrapper.mode == MODE0:
                self.ctx.counters.add("deploy.suppressed")
                return True
            part = cover & ~known1
            sigs = self._sigs(part)
            reduces = (sigs * self.B > wrapper.proof_bytes or
                       sigs * self.P * self.native_ns / NS_PER_MS
                       > self.verify_ms[peer])
            if not reduces:
                self.ctx.counters.add("deploy.suppressed")
                return True
        self._mark_known(node, peer, wrapper)
        return False

    def _announced(self, node, peer, objs, arrival):
        """elgossip announce observer: `node`'s eth/73 announcement of
        `objs` reaches `peer` at `arrival`. From then on they count as
        wrappers exchanged with `node` in `peer`'s suppression test
        (eip-8437-pr12423.md:42 "announced by the recipient"; S6 F1)."""
        pending = self.heard[peer].get(node)
        if pending is None:
            self.heard[peer][node] = [(arrival, objs)]
        else:
            pending.append((arrival, objs))

    def _now_held(self, node, obj):
        """elgossip held observer: `node` now holds wrapper `obj`; its
        parked announcements become ready for the next fold (S7b)."""
        peers = self.parked[node].pop(obj, None)
        if peers:
            ready = self.ready[node]
            for peer in peers:
                objs = ready.get(peer)
                if objs is None:
                    ready[peer] = [obj]
                else:
                    objs.append(obj)

    def _fold_heard(self, node, peer):
        """Fold `peer`'s announcements that have reached `node` by now
        into node's covers exchanged with `peer` (mode 0 / mode 1). Only
        wrappers `node` holds count ("held, validated wrappers ...
        announced by the recipient", eip-8437-pr12423.md:42: an
        announcement carries hashes, the cover is known once the body is
        held); one still on its way to `node` waits, one `node` dropped
        never counts (S7 review A8).

        S7b (same result): an arrived wrapper the node does not hold yet
        is parked (`parked[node][obj]`) rather than rescanned at every
        fold; `_now_held` moves it to `ready[node][peer]` when the node
        starts holding it, and the next fold credits it if the node still
        holds it. A wrapper goes HELD at most once and only to DROPPED
        after, so "held at the first fold after it went HELD" is "held at
        some fold", the rescanning loop's rule."""
        pending = self.heard[node].get(peer)
        ready = self.ready[node].pop(peer, None) if self.ready[node] \
            else None
        if not pending and not ready:
            return
        now = self.ctx.now()
        cover0 = []             # mode-0 tx ids (may repeat; OR is a union)
        cover1 = 0
        wrappers = self.wrappers
        single = self.single0
        states = self.el.rules[RULE_ETH73].state[node]
        size = len(states)
        if ready:
            pending = list(pending or ())
            pending.append((now, ready))
        keep = []
        parked = self.parked[node]
        for entry in pending:
            if entry[0] > now:
                keep.append(entry)
                continue
            objs = entry[1]
            try:
                # Every announced id has a state slot at the node
                # (registration grew it); else the loop below.
                held = [obj for obj in objs if states[obj] == HELD]
            except IndexError:
                held = None
            if held is None:
                held = []
                for obj in objs:
                    state = states[obj] if obj < size else UNSEEN
                    if state == HELD:
                        held.append(obj)
                    elif state != DROPPED:
                        _park(parked, obj, peer)
            elif len(held) != len(objs):
                for obj in objs:
                    state = states[obj]
                    if state != HELD and state != DROPPED:
                        _park(parked, obj, peer)
            firsts = [single[obj] for obj in held]
            if -1 not in firsts:
                cover0 += firsts
                continue
            for obj, tx in zip(held, firsts):
                if tx >= 0:
                    cover0.append(tx)
                    continue
                wrapper = wrappers[obj]
                if wrapper.mode == MODE1:
                    cover1 |= wrapper.cover
                else:
                    cover0.extend(wrapper.txs)
        if keep:
            self.heard[node][peer] = keep
        elif peer in self.heard[node]:
            del self.heard[node][peer]
        if cover1:
            table = self.known1[node]
            table[peer] = table.get(peer, 0) | cover1
        if cover0:
            table = self.known0[node]
            table[peer] = table.get(peer, 0) | bits_span(cover0)

    def _sigs(self, cover):
        return self._sum_k.sum(cover)

    def _suppress_batch(self, node, rule_name, peer, objs):
        """`_suppress` of each of `objs` toward `peer`, in order (same
        tests, same side effects): the objects announced to `peer`.
        Single-tx mode-0 marks are collected in a set and OR-ed into the
        mode-0 cover once (before any multi-tx test and at the end)."""
        if rule_name != RULE_ETH73:
            return objs
        self._fold_heard(node, peer)
        table1 = self.known1[node]
        table0 = self.known0[node]
        known1 = table1.get(peer, 0)
        known0 = table0.get(peer, 0)
        marked1 = marked0 = False
        fresh0 = set()          # single-tx mode-0 marks not yet in known0
        wrappers = self.wrappers
        out = []
        suppressed = 0
        single = self.single0
        if self.single0_unique:
            # Fast path (S7b): a batch of single-tx mode-0 wrappers only.
            # Their txs are distinct (one such wrapper per tx, objs
            # distinct), so `fresh0` never suppresses inside the batch and
            # known0 grows only at the end: one test per object against
            # the covers as they stood when the batch began.
            # Distinct objects are an invariant (elgossip appends an
            # object to a node's pending list only at its HELD
            # transition); checked here so a breach falls back to the
            # loop instead of changing the result (S7b review F2b).
            firsts = [single[obj] for obj in objs]
            if -1 not in firsts and len(set(firsts)) == len(firsts):
                known = known0 | known1
                if known:
                    out = [obj for obj, tx in zip(objs, firsts)
                           if not (known >> tx) & 1]
                    suppressed = len(objs) - len(out)
                    if suppressed:
                        self.ctx.counters.add("deploy.suppressed", suppressed)
                        if out:
                            firsts = [single[obj] for obj in out]
                else:
                    out = list(objs)
                if out:
                    table0[peer] = known0 | bits_span(firsts)
                return out
        for obj in objs:
            tx = single[obj]
            if tx >= 0:
                if tx in fresh0 or (known1 >> tx) & 1 or (known0 >> tx) & 1:
                    suppressed += 1
                    continue
                fresh0.add(tx)
                out.append(obj)
                continue
            wrapper = wrappers[obj]
            if fresh0:
                known0 |= bits_span(fresh0)
                fresh0 = set()
                marked0 = True
            cover = wrapper.cover
            if wrapper.mode == MODE1:
                if cover & known1 == cover:
                    suppressed += 1
                    continue
                if cover & (known0 | known1) == cover:
                    part = cover ^ (cover & known1)
                    sigs = self._sigs(part)
                    reduces = (sigs * self.B > wrapper.proof_bytes or
                               sigs * self.P * self.native_ns / NS_PER_MS
                               > self.verify_ms[peer])
                    if not reduces:
                        suppressed += 1
                        continue
                known1 |= cover
                marked1 = True
            else:
                if cover & (known0 | known1) == cover:
                    suppressed += 1
                    continue
                known0 |= cover
                marked0 = True
            out.append(obj)
        if fresh0:
            known0 |= bits_span(fresh0)
            marked0 = True
        if marked1:
            table1[peer] = known1
        if marked0:
            table0[peer] = known0
        if suppressed:
            self.ctx.counters.add("deploy.suppressed", suppressed)
        return out

    # ---------------------------------------------------------- aggregation
    def start_intervals(self, until_ms):
        """Schedule every aggregating node's interval ticks up to
        `until_ms` at its phase (ctx.fraction("phase", "agg", node)): one
        event per node per interval (arch.md 3.17). Call once; or let the
        slot clock call on_interval itself (both are safe: one job per node
        per interval)."""
        for node in range(self.n_sim):
            if not self.provers.has_prover(node):
                continue
            t = self.ctx.fraction("phase", "agg", node) * self.interval_ms
            while t < until_ms:
                self.ctx.at(t, EV_INTERVAL, node)
                t += self.interval_ms

    def _interval_event(self, node):
        self.on_interval(node)

    def on_interval(self, node):
        """One aggregation interval of `node` (spec.md B10, arch.md 3.10):
        plan with Provers.plan_interval, bounded to one mode-1 wrapper
        (<= agg.wrapper_cap_deps deps, PR #12590), and start it."""
        if not self.installed or node >= self.n_sim or \
                not self.provers.has_prover(node):
            return      # builders prove only their final proof
        index = int(self.ctx.now() // self.interval_ms)
        if index == self.last_interval[node]:
            return
        self.last_interval[node] = index
        counters = self.ctx.counters
        counters.add("deploy.intervals")
        if self.in_flight[node]:
            counters.add("deploy.intervals_busy")
            return
        job = self._plan(node)
        if job is None:
            counters.add("deploy.intervals_idle")
            return
        self.in_flight[node] = True
        self.provers.start(job, self._job_done, job)

    def _deps_of(self, cover):
        return self._sum_deps.sum(cover)

    def _bytes_of(self, cover):
        return self._sum_bytes.sum(cover)

    def _plan(self, node):
        """Inputs bounded to one mode-1 wrapper: received aggregates chosen
        greedily by marginal coverage while their new deps fit the room
        left by the open aggregate (<= agg.wrapper_cap_deps deps and <=
        agg.wrapper_cap_bytes complete bytes with the largest proof, PR
        #12590:301), raw txs by tip in what remains; Provers.plan_interval
        then applies the budget and the leanVM limits."""
        cap = self.wrapper_cap_deps
        byte_cap = self.wrapper_cap_bytes - self.proof_reserve
        own = self.own[node]
        removals = self.removals[node]
        covered = 0
        room = cap
        byte_room = byte_cap
        if own is not None:
            covered = own[1] & ~removals
            room = cap - self._deps_of(covered)
            byte_room = byte_cap - self._bytes_of(covered)
            if room <= 0 or byte_room <= 0:
                self._seal(node)
                own = None
                covered = 0
                room = cap
                byte_room = byte_cap
        txs = self.ctx.txs
        deps = txs.deps
        pool = []
        for agg, cover in self.cand[node].items():
            fresh = cover & ~covered & ~removals
            if fresh:
                pool.append((popcount(fresh), agg, cover))
        pool.sort(key=lambda item: (-item[0], item[1]))
        received = []
        waiting = False          # some input with fresh coverage exists
        for _gain, agg, cover in pool:
            fresh = cover & ~covered & ~removals
            if not fresh:
                continue
            waiting = True
            # The child's whole live cover joins the aggregate.
            need = self._deps_of(fresh)
            need_bytes = self._bytes_of(fresh)
            if need > room or need_bytes > byte_room:
                continue
            received.append((agg, cover))
            covered |= cover & ~removals
            room -= need
            byte_room -= need_bytes
        tip_key = self._tip_key
        try:
            order = sorted(self.raw[node], key=tip_key.__getitem__)
        except KeyError:
            order = sorted(self.raw[node], key=self._tip_key_of)
        raw = []
        positive = self._raw_deps_positive
        for tx in order:
            if (covered >> tx) & 1 or (removals >> tx) & 1:
                continue
            waiting = True
            if byte_room <= 0 or (room <= 0 and positive):
                break           # nothing further fits (S7)
            size = self._tx_wrapper_bytes(tx)
            if deps[tx] > room or size > byte_room:
                continue
            raw.append(tx)
            room -= deps[tx]
            byte_room -= size
        if own is not None and not received and not raw and waiting:
            # Fresh inputs wait but none fits the room left: seal, reopen.
            self._seal(node)
            return self._plan(node)
        job = self.provers.plan_interval(node, own, removals, received, raw,
                                         None)
        if job is not None and job.children and \
                self._over_cap(self._job_cover(node, job)):
            # Overlapping children overshot the cap: raw only.
            self.ctx.counters.add("deploy.aggregate_split")
            job = self.provers.plan_interval(node, own, removals, (), raw,
                                             None)
        return job

    def _tip_key_of(self, tx):
        key = self._tip_key.get(tx)
        if key is None:
            key = (-self.ctx.txs.tip[tx], tx)
            self._tip_key[tx] = key
        return key

    def _over_cap(self, cover):
        return (self._deps_of(cover) > self.wrapper_cap_deps or
                self._bytes_of(cover) + self.proof_reserve
                > self.wrapper_cap_bytes)

    def _job_cover(self, node, job):
        cover = job.raw
        if job.own and self.own[node] is not None:
            cover |= self.own[node][1] & ~job.removed
        for agg in job.children:
            cover |= self.cand[node].get(agg, 0) & ~self.removals[node]
        return cover & ~job.removed

    def _job_done(self, job):
        node = job.node
        self.in_flight[node] = False
        cover = self._job_cover(node, job) & ~self.included
        self.removals[node] &= ~job.removed
        for agg in job.children:
            self.cand[node].pop(agg, None)
        for tx in members(job.raw):
            self.raw[node].pop(tx, None)
        old = self.own[node]
        if not cover:
            self.own[node] = None
            return
        wrapper_size = self._agg_bytes(cover, job.proof_bytes,
                                       old[1] if old else 0)
        agg = self._new_wrapper(MODE1, cover, node, "agg", job.proof_bytes,
                                size=wrapper_size)
        self.own[node] = (agg, cover)
        self.verified[node] |= cover
        if self.wrappers[agg].deps >= self.wrapper_cap_deps:
            self._seal(node)
        self.el.admit(node, RULE_ETH73, agg)

    def _agg_bytes(self, cover, proof_bytes, previous):
        """Mode-1 wrapper bytes: proof + deps + tx bodies, compact (txs
        already sent in the node's previous aggregate replaced by 32-B
        references, eip-8437-pr12423.md:62-66) [Mo: the previous aggregate
        stands for 'sent on that connection']."""
        txs = self.ctx.txs
        size = proof_bytes
        for tx in members(cover):
            size += self._tx_wrapper_bytes(tx)
            if (previous >> tx) & 1:
                size += HASH_REF_BYTES - txs.bytes_chain[tx]
        return size

    def _seal(self, node):
        own = self.own[node]
        if own is None:
            return
        self.sealed[node][own[0]] = own[1]
        self.own[node] = None
        self.ctx.counters.add("deploy.sealed")

    # ---------------------------------------------------------- bundler
    def _bundler_init(self):
        ctx = self.ctx
        self.bundler_node = min(int(ctx.fraction("deploy", "bundler")
                                    * self.n_sim), self.n_sim - 1)
        self.bundle_pending = []
        self.bundle_timer = None
        self.bundle_jobs = 0
        self.bundle_users = {}
        self.bundle_wait_ms = float(self.params.value("agg_bundle_wait_ms"))
        ctx.on(EV_TO_BUNDLER, self._to_bundler)
        ctx.on(EV_BUNDLE_TIMER, self._bundle_timer)
        ctx.on(EV_BUNDLE_DONE, self._bundle_done)

    def _to_bundler(self, tx):
        txs = self.ctx.txs
        pending = sum(txs.k[user] for user in self.bundle_pending)
        if pending and pending + txs.k[tx] > self.pcs.cap:
            self._start_bundle()      # full: this user opens the next one
        self.bundle_pending.append(tx)
        if sum(txs.k[user] for user in self.bundle_pending) >= self.pcs.cap:
            self._start_bundle()
        elif self.bundle_timer is None:
            self.bundle_timer = self.ctx.now() + self.bundle_wait_ms
            self.ctx.after(self.bundle_wait_ms, EV_BUNDLE_TIMER,
                           self.bundle_timer)

    def _bundle_timer(self, due):
        if self.bundle_timer != due:
            return
        self.bundle_timer = None
        if self.bundle_pending:
            self._start_bundle()

    def _start_bundle(self):
        """Prove the pending users (<= bundle_cap signatures) on the
        bundler's 8-thread class (proving.default_bundler_hw); the fleet has
        as many parallel jobs as needed [A], the peak is counted."""
        users = list(self.bundle_pending)
        self.bundle_pending = []
        self.bundle_timer = None
        txs = self.ctx.txs
        sigs = sum(txs.k[user] for user in users)
        prove_ms = 1000.0 * self.pcs.prove_s(sigs, self.pcs.bundler_hw)
        scalars = self.ctx.counters.scalars
        scalars["deploy.bundler_prove_ms"] += prove_ms
        self.bundle_jobs += 1
        if self.bundle_jobs > scalars["deploy.bundler_jobs_peak"]:
            scalars["deploy.bundler_jobs_peak"] = self.bundle_jobs
        self.ctx.after(prove_ms, EV_BUNDLE_DONE, tuple(users))

    def _bundle_done(self, users):
        """The bundle tx: one row (kind PCS, k = its signatures, 7 claims per
        proof as deps) and its mode-1 wrapper, submitted at the bundler's
        node. Tip = the users' mean tip, fee cap = their lowest [A]."""
        ctx = self.ctx
        txs = ctx.txs
        self.bundle_jobs -= 1
        sigs = sum(txs.k[user] for user in users)
        g = self.pcs.proofs(sigs)
        shape = self.bundler_shape
        chain = int(coefficients(_value(shape["chain_bytes"]), k=sigs, g=g))
        wire = int(coefficients(_value(shape["wire_bytes"]), k=sigs, g=g))
        gas = self.pcs.gas(sigs, "pcs_bundler")
        claims = self.pcs.claims(sigs)
        # Tip: the users' mean; fee cap: the lowest any user authorised
        # [A] (a bundler never commits a user above its own cap).
        tip = sum(txs.tip[user] for user in users) // len(users)
        fee_cap = min(txs.fee_cap[user] for user in users)
        tip = min(tip, fee_cap)
        bundle = txs.add(ctx.now(), KIND_PCS, sigs, chain, chain, gas, claims,
                         0, fee_cap, tip, len(txs),
                         self.bundler_node)
        self.is_bundle[bundle] = True
        self._tip_key[bundle] = (-txs.tip[bundle], bundle)
        self.submit_bytes[bundle] = wire
        self.exec_gas[bundle] = (self.piop_gas * g +
                                 self.e_u["pcs_bundler"] * sigs)
        for user in users:
            self.bundle_of[user] = bundle
        self.bundle_users[bundle] = users
        ctx.counters.add("deploy.bundles")
        ctx.counters.add("deploy.bundle_sigs", sigs)
        ctx.counters.add("deploy.pcs_txs")
        wrapper = self._new_wrapper(MODE1, 1 << bundle, self.bundler_node,
                                    "bundle", self.client_stark_bytes,
                                    size=wire)
        self._deliver(self.bundler_node, wrapper, None)

    # ---------------------------------------------------------- block side
    def freeze_ms(self, slot, t0, margin):
        """slot.py hook: when the builder of `slot` calls `build`: when the
        parent payload is due, PAYLOAD_DUE_BPS of the previous slot (spec.md
        B14: the proof window opens when the builder sees the parent
        payload; the bid at t0 commits it, T7). `build` starts the window
        at max(now, the builder's actual parent receipt)."""
        del margin
        return t0 - self.slot_ms + self.slot_ms * self.payload_due_share

    def build(self, builder, slot, freeze_ms, il_txs=(), il_children=()):
        """The builder's payload for `slot` (spec.md B14-B18, arch.md 3.6,
        3.10). View: the builder's pool at call time minus txs of payloads
        whose canonical decision is still pending (`ctx.slot.
        undecided_cover`: the builder builds on its parent), and the fluid
        background minus the records those payloads packed
        (`ctx.slot.undecided_payloads`); the final
        proof runs from max(now, freeze_ms, parent payload seen) and must be
        done by the bid at the slot start minus prover.bid_margin_ms.
        `il_txs` (FOCIL, slot.py): IL tx ids, packed first when usable; those
        the builder cannot prove from its own sources ride in their IL's
        STARK, merged as one child (B15) [Mo: one child for all ILs].
        `il_children`: claims of further IL STARKs to merge."""
        ctx = self.ctx
        counters = ctx.counters
        counters.add("deploy.builder_builds")
        base_fee = self._base_fee()
        bid_ms = slot * self.slot_ms
        start_ms = max(ctx.now(), freeze_ms)
        clock = ctx.slot
        pending = 0
        parents = ()
        if clock is not None:
            seen = getattr(clock, "parent_seen_ms", None)
            if callable(seen):
                parent = seen(builder, slot)
                if parent is not None and parent >= 0.0:
                    start_ms = max(start_ms, parent)
            undecided = getattr(clock, "undecided_cover", None)
            if callable(undecided):
                pending = undecided(slot, builder)
            payloads = getattr(clock, "undecided_payloads", None)
            if callable(payloads):
                parents = tuple((earlier, payload.bg_gas) for earlier, payload
                                in payloads(slot, builder))
        window = self.provers.window_ms(start_ms, bid_ms)
        if window <= 0.0:
            counters.add("deploy.builder_no_window")
        held = self._held(builder)
        provable = self.verified[builder]
        txs = ctx.txs

        def usable(tx):
            if txs.included_slot[tx] != NOT_INCLUDED or \
                    (self.included >> tx) & 1:
                return False
            if (pending >> tx) & 1:
                counters.add("deploy.undecided_skipped")
                return False
            return txs.fee_cap[tx] >= base_fee

        il_set = {}
        il_unproven = 0
        for tx in il_txs:
            if tx in il_set or not usable(tx) or \
                    not self.pool.holds(builder, tx):
                continue
            il_set[tx] = None
            if txs.kind[tx] != KIND_ECDSA and not (provable >> tx) & 1:
                il_unproven += txs.deps[tx] if txs.kind[tx] == KIND_PCS \
                    else txs.k[tx]
        extra = tuple(il_children) + ((il_unproven,) if il_unproven else ())
        pq = []
        ecdsa = []
        for tx in self.pool.fee_order(builder, base_fee):
            if tx in il_set or not usable(tx):
                continue
            if txs.kind[tx] == KIND_ECDSA:
                ecdsa.append(tx)
            elif (provable >> tx) & 1:
                pq.append(tx)
            else:
                counters.add("deploy.unprovable_skipped")
        first = list(il_set)
        bins = []
        if ctx.demand is not None:
            # The fluid background packed by the undecided parent is not
            # offered again (ghost-ECDSA fix, verify-final.md section 2),
            # as `pending` keeps out the parent's PQ txs.
            bins = ctx.demand.background_offer(slot, freeze_ms,
                                               undecided=parents)
        packed = self._pack(first, pq, ecdsa, bins, base_fee, extra)
        chosen_pq = packed["pq"]
        binding = packed["binding"]
        n = len(chosen_pq)
        if chosen_pq or extra:
            n = self.provers.largest_prefix(builder, chosen_pq, held, window,
                                            extra)
        if n < len(chosen_pq):
            counters.add("deploy.builder_deadline_miss")
            counters.add("deploy.builder_deadline_dropped",
                         len(chosen_pq) - n)
            keep = chosen_pq[:n]
            packed = self._pack(first, keep, ecdsa, bins, base_fee, extra,
                                pq_fixed=True)
            chosen_pq = keep
            binding = "proof_deadline"
        counters.add("deploy.il_included", sum(1 for tx in packed["txs"]
                                               if tx in il_set))
        cover = 0
        for tx in chosen_pq:
            cover |= 1 << tx
        proof_bytes = 0
        total_ms = 0.0
        if chosen_pq or extra:
            plan = self.provers.builder_plan(builder, cover, held, window,
                                             extra)
            total_ms = plan.total_ms
            proof_bytes = plan.proof_bytes or self._held_proof_bytes(
                builder, cover)
            if not plan.fits:
                # Not even the IL STARKs fit: the payload carries no PQ
                # tx and the proof is late (counted as a miss).
                counters.add("deploy.builder_deadline_miss")
            slack = window - total_ms
            scalars = counters.scalars
            scalars["deploy.builder_proof_ms"] += total_ms
            scalars["prover.builder_slack_ms"] += slack
            if slack < scalars["deploy.builder_slack_ms_min"]:
                scalars["deploy.builder_slack_ms_min"] = slack
        # For metrics.SlotRecord proof_ms / proof_window_ms (S4 inbox).
        self.proof_plans[slot] = (total_ms, window)
        txs_out = list(packed["txs"])
        deps = sum(txs.deps[tx] for tx in chosen_pq)
        size = packed["bytes"] + proof_bytes
        return Payload(slot, builder, txs_out, _bits(txs_out),
                       packed["gas"], size, deps, proof_bytes, binding,
                       packed["bg_count"], packed["bg_gas"],
                       packed["bg_bytes"], start_ms + total_ms)

    def proof_plan(self, slot):
        """(proof_ms, proof_window_ms) of the last build for `slot`, or
        (None, None): metrics.SlotRecord fields (S4)."""
        return self.proof_plans.get(slot, (None, None))

    def _held(self, builder):
        result = list(self.cand[builder].items())
        result += list(self.sealed[builder].items())
        if self.own[builder] is not None:
            result.append(self.own[builder])
        return result

    def _held_proof_bytes(self, builder, cover):
        """Proof bytes when one held aggregate covers the block exactly."""
        for agg, held in self._held(builder):
            if held == cover:
                return self.wrappers[agg].proof_bytes
        return 0

    def _pack(self, first, pq, ecdsa, bins, base_fee, extra,
              pq_fixed=False):
        """Kind-blind greedy packing by effective tip per gas (S2c), after
        the FOCIL IL txs `first`: PQ and explicit ECDSA txs whole (skipped,
        not stopped, when a cap is hit, as geth's miner pops the sender),
        fluid background bins taken fractionally. Caps: gas limit, EIP-7934
        bytes minus the proof reservation (when any PQ tx or IL STARK is
        in), block dependency cap, and under the 'yes' reading of
        pcs_leanstark_cap_reading the PCS deps per block <= PR #12590's 16.
        `pq_fixed`: the PQ list is final (a prefix of an earlier packing),
        take all of it. The returned "pq" holds every PQ tx packed (IL ones
        first), in packing order."""
        spec = self.spec
        txs = self.ctx.txs
        gas_limit = spec.chain.gas_limit or None
        byte_cap = spec.chain.byte_cap or None
        dep_cap = spec.chain.dep_cap
        leanstark_cap = None
        if self.pcs is not None and self.pcs.leanstark_reading == "yes":
            leanstark_cap = int(self.params.value("agg_leanstark_block_cap"))
        any_pq = bool(pq) or bool(extra) or any(
            txs.kind[tx] != KIND_ECDSA for tx in first)
        reserve = self.proof_reserve if any_pq else 0
        items = []
        for tx in first:
            items.append((0, -1, tx, "ecdsa" if txs.kind[tx] == KIND_ECDSA
                          else "pq"))
        ranked = []
        for tx in pq:
            ranked.append((self._eff(tx, base_fee), 0, tx, "pq"))
        for tx in ecdsa:
            ranked.append((self._eff(tx, base_fee), 0, tx, "ecdsa"))
        for index, row in enumerate(bins):
            ranked.append((row[0], 1, index, "bin"))
        ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
        items += ranked
        fixed = dict.fromkeys(pq) if pq_fixed else {}
        gas = 0
        size = reserve
        deps = 0
        pcs_deps = 0
        chosen = []
        chosen_pq = []
        bg = [0.0, 0.0, 0.0]
        binding = "pool"
        counters = self.ctx.counters
        for _eff, _rank, ident, kind in items:
            if kind == "bin":
                _tip, count, bin_gas, bin_bytes = bins[ident]
                share = 1.0
                if gas_limit:
                    share = min(share, (gas_limit - gas) / bin_gas
                                if bin_gas else 1.0)
                if byte_cap:
                    share = min(share, (byte_cap - size) / bin_bytes
                                if bin_bytes else 1.0)
                if share <= 0.0:
                    binding = "gas" if gas_limit and gas >= gas_limit \
                        else "bytes"
                    continue
                if share < 1.0:
                    binding = "gas" if gas_limit and \
                        (gas_limit - gas) / bin_gas <= share else "bytes"
                bg[0] += count * share
                bg[1] += bin_gas * share
                bg[2] += bin_bytes * share
                gas += bin_gas * share
                size += bin_bytes * share
                continue
            tx_gas = txs.gas[ident]
            tx_bytes = txs.bytes_chain[ident]
            tx_deps = txs.deps[ident] if kind == "pq" else 0
            tx_pcs = tx_deps if txs.kind[ident] == KIND_PCS else 0
            if ident not in fixed:
                if gas_limit and gas + tx_gas > gas_limit:
                    counters.add("deploy.gas_skipped")
                    binding = "gas"
                    continue
                if byte_cap and size + tx_bytes > byte_cap:
                    counters.add("deploy.bytes_skipped")
                    binding = "bytes"
                    continue
                if dep_cap is not None and deps + tx_deps > dep_cap:
                    counters.add("deploy.dep_cap_skipped")
                    binding = "deps"
                    continue
                if leanstark_cap is not None and \
                        pcs_deps + tx_pcs > leanstark_cap:
                    counters.add("deploy.leanstark_skipped")
                    binding = "deps"
                    continue
                if pq_fixed and kind == "pq":
                    continue        # dropped by the proof deadline
            gas += tx_gas
            size += tx_bytes
            deps += tx_deps
            pcs_deps += tx_pcs
            chosen.append(ident)
            if kind == "pq":
                chosen_pq.append(ident)
        return {"txs": chosen, "pq": chosen_pq, "gas": int(gas),
                "bytes": int(size - reserve), "binding": binding,
                "bg_count": int(round(bg[0])), "bg_gas": int(round(bg[1])),
                "bg_bytes": int(round(bg[2]))}

    def _eff(self, tx, base_fee):
        txs = self.ctx.txs
        room = txs.fee_cap[tx] - base_fee
        tip = txs.tip[tx]
        return tip if tip < room else room

    def import_ms(self, node, payload):
        """Validator CPU to import a payload (spec.md B17): one recursive
        STARK verify (when it carries deps) + EVM execution of the payload
        on one core: each PQ tx's `deploy.exec_gas` (dependency route: the
        8288 VERIFY + SENDER exec, verify_8288_exec_base + per_dep x deps,
        spec.md B4 [Mo]; PCS routes: the PIOP verifier per proof + e_u per
        signature, the pcs gas objects' terms) and the ECDSA gas (explicit
        txs and the fluid bins)."""
        txs = self.ctx.txs
        gas = payload.bg_gas
        for tx in payload.txs:
            if txs.kind[tx] == KIND_ECDSA:
                gas += txs.gas[tx]
            else:
                gas += self.exec_gas[tx]
        verify = self.verify_ms[node] if (payload.deps or
                                          payload.proof_bytes) else 0.0
        result = verify + gas / self.gas_per_ms[node]
        self.c_import_ms[node] += result
        return result

    # ---------------------------------------------------------- canonical
    def on_payload_canonical(self, slot, payload):
        """hooks.payload_canonical (global bookkeeping): the canonical
        cover, counters, and pcs_bundler users included with their bundle.
        Pools change per node in `drop_included`."""
        ctx = self.ctx
        txs = ctx.txs
        self.included |= payload.cover
        counters = ctx.counters
        for tx in payload.txs:
            if txs.kind[tx] == KIND_ECDSA:
                continue
            counters.add("deploy.included_pq")
            counters.add("deploy.included_sigs", txs.k[tx])
            if self.is_bundle[tx]:
                when = txs.included_at[tx]
                if when < 0:
                    when = ctx.now()
                for user in self.bundle_users.get(tx, ()):
                    txs.included_slot[user] = slot
                    txs.included_at[user] = when

    def drop_included(self, node, payload):
        """slot.py: `node` holds a canonical payload: unpool its txs, stop
        serving its ECDSA txs, turn them into removals of the node's open
        aggregate, retire held aggregates now fully included."""
        cover = payload.cover
        included = self.included | cover
        self.pool.remove(node, cover)
        raw = self.raw[node]
        txs = self.ctx.txs
        for tx in payload.txs:
            raw.pop(tx, None)
            if txs.kind[tx] == KIND_ECDSA:
                self.el.drop(node, RULE_ETH68, tx)
        own = self.own[node]
        if own is not None and own[1] & cover:
            self.removals[node] |= own[1] & cover
        for table in (self.cand[node], self.sealed[node]):
            for agg in [agg for agg, held in table.items()
                        if not held & ~included]:
                del table[agg]

    def on_payload_missed(self, slot, payload):
        """hooks.payload_missed: nothing to undo (txs stay pooled)."""
        return None


class Deploy8288(AggDeployment):
    """EIP-8288 full (spec.md section 3)."""
    id = "8288"
    FORMAT = "8288"


class DeployLeanPCS(AggDeployment):
    """leanPCS full (spec.md section 4; sig_route of PHASE4-NETSIM.md)."""
    id = "leanpcs"
    FORMAT = "leanpcs"


def _park(parked, obj, peer):
    peers = parked.get(obj)
    if peers is None:
        parked[obj] = [peer]
    else:
        peers.append(peer)


def _bits(indices):
    result = 0
    for index in indices:
        result |= 1 << index
    return result


__all__ = ["AggDeployment", "Deploy8288", "DeployLeanPCS", "ROUTES",
           "ProverError", "ceil_div", "popcount"]

"""Deployment plug-ins `8141` (EIP-8141 full, step H*) and `today` (Fulu
mainnet, ECDSA only, for validation). Stage S3a (arch.md 3.8, 3.9).

8141 full (spec.md section 2): every PQ transaction is a frame tx with its
signatures in `ARBITRARY` entries and an EVM verifier in a VERIFY frame. The
shape comes from `deployments_v3.json tx_shapes.8141.pq` (coefficient
objects; gas = max(standard, floor), spec.md A3-A5):

    gas         max(25,474 + 2,100k + 16kB + 146.15kP, 21,446 + 100k + 64kB)
    bytes       135 + 9k + kB       (wire = chain, spec.md A2, A17)
    verify_gas  5,900 + 2,000k + 146.15kP   (EVM at admission and import)
    rule6_gas   declared VERIFY limit + 100 per entry (PR #12617 reading)

Admission (spec.md A9-A12, arch.md 3.8):

1. size > `max_tx_bytes` (geth txMaxSize 131,072 [R]) -> REFUSE "oversize";
2. rule 6: rule6_gas (+ 16kB under `chain.rule6=literal`) > `MAX_VERIFY_GAS`
   -> PRIVATE "rule6" when `chain.private_route` (sent direct to every
   builder), else REFUSE "rule6";
3. else ACCEPT with CPU = verify_gas / the node's EVM gas per ms (one core;
   the simulation of the validation prefix, spec.md A11).

The entry node applies the same deterministic rule at submission, so a PQ tx
refused by rule 6 never enters public gossip; relays still check (a public
object refused later would be dropped, not relayed).

Pool and gossip wiring follows S2a's reference `wire_8141`
(tests/v3/test_elgossip.py): el_body_received -> admit -> Cpu.run ->
Mempool.add -> ElGossip.admit on ADDED, ElGossip.drop otherwise and for every
evicted id. Gossip is eth/68 (txs > 4,096 B announce-only, in elgossip).

Building (arch.md 3.6, build-s2c.md 4-5): the builder ranks its pooled txs
and the fluid ECDSA background bins of `demand.background_offer(slot,
freeze_ms)` together by effective tip per gas (kind-blind), takes FOCIL IL
txs first, and packs under the gas limit and the EIP-7934 byte cap (bins
fractionally). Txs already canonically included are skipped (a global
oracle against double inclusion when a builder's view lags).

Import (spec.md A15-A16): EVM execution of every VERIFY frame
(sum of verify_gas at the node's EVM rate) plus the ECDSA background at the
measured mainnet import rate; under ePBS the block-level access list
(EIP-7928, Glamsterdam) lets the PQ part spread over the node's verify cores.
"""

from starksim.v3 import params as P
from starksim.v3.deploy import (ACCEPT, PRIVATE, REFUSE, Admission,
                                Deployment, Payload, TxShape)
from starksim.v3.elgossip import RULE_ETH68, ElGossip, eth68
from starksim.v3.mempool import ADDED, Cpu, Mempool, node_cpu
from starksim.v3.state import (KIND_ECDSA, KIND_NAMES, KIND_PCS, KIND_PQ1,
                               KIND_PQK, LANE_EL, NOT_INCLUDED,
                               ROUTE_PRIVATE)

P.register_bindings({
    "block_import_ms_median_block": (
        P.NET, ("compute", "block_import_ms_median_block"), None),
})

ECDSA_VERIFY_MS = 0.05      # [Rc] secp256k1 ecrecover ~50 us per tx on one core (libsecp256k1)
IMPORT_REF_BLOCK_GAS = 30_000_000  # [R] compute.block_import_ms_median_block note: ~30 M gas/block
PRIVATE_SUBMIT_BYTES = 0    # [A] latency-only control message to each builder


def coefficient(value, k, B=0, P=0, c=0):
    """Evaluate a deployments_v3.json coefficient object (meta
    coefficient_objects): {term: coefficient} summed, or {"max_of": [...]}
    (per_g is leanPCS-only and refused here)."""
    if isinstance(value, dict) and "max_of" in value:
        return max(coefficient(side, k, B, P, c) for side in value["max_of"])
    if isinstance(value, (int, float)):
        return float(value)
    total = 0.0
    for term, coef in value.items():
        if term.startswith("_"):
            continue
        if term == "const":
            total += coef
        elif term == "per_k":
            total += coef * k
        elif term == "per_kB":
            total += coef * k * B
        elif term == "per_kP":
            total += coef * k * P
        elif term == "per_P":
            total += coef * P
        elif term == "per_c":
            total += coef * c
        else:
            raise ValueError(f"coefficient term {term!r} not supported here")
    return total


class Deploy8141(Deployment):
    id = "8141"
    rule = RULE_ETH68

    def __init__(self, ctx):
        super().__init__(ctx)
        params = ctx.params
        spec = ctx.spec
        self.slot_ms = float(spec.chain.slot_ms)
        shapes = params.section("tx_shapes")["8141"]["pq"]
        self.shape_leaves = shapes
        entry = params.deployment_entry("8141")
        admission = entry["admission"]
        self.max_tx_bytes = int(admission["max_tx_bytes"]["value"])
        fork = params.fork(entry["fork"] if self.id == "8141" else "today")
        self.fork = fork
        self.max_rlp_bytes = int(spec.chain.byte_cap)
        # [A] RLP execution-block header (~540-600 B) counted against 7934
        self.header_bytes = 600  # [A] RLP header of an execution block
        self._shape_memo = {}
        self.counts = {}
        self.payload_ms = {}
        if ctx.links is not None:
            self._attach()

    # ------------------------------------------------------------ shapes
    def tx_shape(self, kind, k):
        key = (kind, k)
        shape = self._shape_memo.get(key)
        if shape is not None:
            return shape
        if kind not in (KIND_PQ1, KIND_PQK):
            raise ValueError(f"deployment {self.id}: no tx shape for kind "
                             f"{KIND_NAMES[kind]} (ECDSA shapes come from "
                             "demand's measured histograms)")
        if self.id == "today":
            raise ValueError("deployment today carries no PQ transaction")
        B = int(self.spec.sig_bytes)
        perms = int(self.spec.perms)
        leaves = self.shape_leaves
        gas = int(round(coefficient(leaves["gas"]["value"], k, B, perms)))
        wire = int(round(coefficient(leaves["wire_bytes"]["value"], k, B)))
        chain = int(round(coefficient(leaves["chain_bytes"]["value"], k, B)))
        verify = coefficient(leaves["verify_gas"]["value"], k, B, perms)
        shape = TxShape(wire, chain, gas, 0, verify,
                        leaves["gas"]["status"])
        self._shape_memo[key] = shape
        return shape

    def rule6_gas(self, k):
        """Gas counted against MAX_VERIFY_GAS (spec.md A8-A9)."""
        memo = self._shape_memo.get(("rule6", k))
        if memo is not None:
            return memo
        B = int(self.spec.sig_bytes)
        perms = int(self.spec.perms)
        gas = coefficient(self.shape_leaves["rule6_gas"]["value"], k, B,
                          perms)
        if self.spec.chain.rule6 == "literal":
            gas += 16 * k * B  # [E] E8141 signature_data_cost: 16 gas per sig byte
        self._shape_memo[("rule6", k)] = gas
        return gas

    def mean_pq_shape(self):
        """(gas, chain bytes) of the run's PQ mix (single k, multisig_k)."""
        demand = self.spec.demand
        single = self.tx_shape(KIND_PQ1, self.spec.k)
        share = demand.multisig_share
        if share <= 0.0:
            return float(single.gas), float(single.bytes_chain)
        multi = self.tx_shape(KIND_PQK, demand.multisig_k)
        return ((1.0 - share) * single.gas + share * multi.gas,
                (1.0 - share) * single.bytes_chain + share * multi.bytes_chain)

    def analytic_bounds(self):
        """Ideal-network PQ tx/s bounds (arch.md 5.1): whole txs per block
        under the gas limit and under the EIP-7934 byte cap, per slot."""
        gas, size = self.mean_pq_shape()
        slot_s = self.slot_ms / 1000.0
        result = {"gas_per_tx": gas, "bytes_per_tx": size}
        if self.spec.chain.gas_limit:
            result["gas"] = int(self.spec.chain.gas_limit // gas) / slot_s
        if self.max_rlp_bytes:
            result["bytes"] = (int((self.max_rlp_bytes - self.header_bytes)
                                   // size) / slot_s)
        return result

    # --------------------------------------------------------- admission
    def admit(self, node, rule_name, obj):
        txs = self.ctx.txs
        kind = txs.kind[obj]
        if kind == KIND_ECDSA:
            return Admission(ACCEPT, None, ECDSA_VERIFY_MS)
        if kind == KIND_PCS:
            return Admission(REFUSE, "kind", 0.0)
        if txs.bytes_wire[obj] > self.max_tx_bytes:
            return Admission(REFUSE, "oversize", 0.0)
        if self.rule6_gas(txs.k[obj]) > self.spec.chain.max_verify_gas:
            if self.spec.chain.private_route:
                return Admission(PRIVATE, "rule6", 0.0)
            return Admission(REFUSE, "rule6", 0.0)
        gas_per_ms = self.gas_per_ms[node] if self.gas_per_ms else 1.0
        return Admission(ACCEPT, None, txs.verify_gas[obj] / gas_per_ms)

    def _count(self, name, amount=1):
        key = "deploy." + name
        scalars = self.ctx.counters.scalars
        if key not in scalars:
            self.ctx.counters.scalar(key)
        scalars[key] += amount

    # ------------------------------------------------------------ wiring
    def _attach(self):
        """Build the pool, CPU and EL gossip of a running world and wire
        the hooks (as tests/v3/test_elgossip.py::wire_8141)."""
        ctx = self.ctx
        self.cores, self.gas_per_ms = node_cpu(ctx)
        self.cpu = Cpu(ctx, lambda node: self.cores[node])
        self.pool = Mempool(ctx)
        self.el = ElGossip(ctx, {RULE_ETH68: eth68(ctx.params, ctx.spec)})
        ctx.el = self.el
        ctx.deploy = self
        classes = ctx.params.value("compute_node_classes")
        import_ms = ctx.params.value("block_import_ms_median_block")
        topo = ctx.topo
        names = getattr(topo, "class_names", None) or []
        fallback = classes.get("datacentre") or next(iter(classes.values()))
        self.bg_ms_per_gas = []
        for node in range(topo.n_total):
            entry = None
            if names and not ctx.nodes.is_builder[node]:
                entry = classes.get(names[ctx.nodes.uplink_class[node]])
            entry = entry or fallback
            tier_ms = float(import_ms[entry["evm_tier"]][0])  # median
            self.bg_ms_per_gas.append(tier_ms / IMPORT_REF_BLOCK_GAS)
        hooks = ctx.hooks
        hooks.wire("object_bytes", self._object_bytes)
        hooks.wire("el_body_received", self._received)
        hooks.wire("tx_born", self.submit)

    def _object_bytes(self, rule_name, obj):
        return self.ctx.txs.bytes_wire[obj]

    def base_fee(self):
        demand = self.ctx.demand
        return demand.base_fee() if demand is not None else 0

    def submit(self, tx):
        """A born tx at its entry node: public (admission CPU, pool, eth/68)
        or private (rule 6 refused: direct to every builder)."""
        ctx = self.ctx
        node = ctx.txs.entry_node[tx]
        verdict = self.admit(node, self.rule, tx)
        if verdict.verdict == PRIVATE:
            ctx.txs.route[tx] = ROUTE_PRIVATE
            self._count("private")
            for builder in ctx.topo.builders:
                ctx.links.control(node, builder, "deploy.private",
                                  PRIVATE_SUBMIT_BYTES, self._private_land,
                                  (builder, tx))
            return
        if verdict.verdict == REFUSE:
            self._count("refused_" + verdict.reason)
            return
        self.cpu.run(node, verdict.cpu_ms, self._admitted_at, (node, tx,
                                                               None))

    def _private_land(self, arg):
        builder, tx = arg
        outcome, evicted = self.pool.add(builder, tx, self.base_fee())
        for victim in evicted:
            self.el.drop(builder, self.rule, victim)

    def _received(self, node, rule_name, obj, src):
        verdict = self.admit(node, rule_name, obj)
        if verdict.verdict != ACCEPT:
            self._count("relay_" + verdict.verdict)
            self.el.drop(node, rule_name, obj)
            return
        self.cpu.run(node, verdict.cpu_ms, self._admitted_at,
                     (node, obj, src))

    def _admitted_at(self, arg):
        node, obj, src = arg
        self.on_admit(node, self.rule, (obj, src))

    def on_admit(self, node, rule_name, obj):
        """After the admission CPU: pool, then gossip (`obj` may be a
        (tx, src) pair from the CPU callback)."""
        if isinstance(obj, tuple):
            tx, src = obj
        else:
            tx, src = obj, None
        if self.ctx.txs.included_slot[tx] != NOT_INCLUDED:
            self.el.drop(node, rule_name, tx)
            return
        outcome, evicted = self.pool.add(node, tx, self.base_fee())
        for victim in evicted:
            self.el.drop(node, rule_name, victim)
        if outcome == ADDED:
            self.el.admit(node, rule_name, tx, src)
        else:
            self.el.drop(node, rule_name, tx)

    def on_interval(self, node):
        raise NotImplementedError("8141 does not aggregate")

    # ---------------------------------------------------------- building
    def build(self, builder, slot, freeze_ms, il_txs=()):
        """Payload of `slot` from `builder`'s pool now (called at the freeze
        time) and the fluid background born by `freeze_ms`."""
        ctx = self.ctx
        txs = ctx.txs
        base = self.base_fee()
        gas_left = self.spec.chain.gas_limit or float("inf")
        bytes_left = (self.max_rlp_bytes - self.header_bytes
                      if self.max_rlp_bytes else float("inf"))
        chosen = []
        taken = set()
        cut = {"gas": 0, "bytes": 0}
        pending = (ctx.slot.undecided_cover(slot, builder)
                   if ctx.slot is not None else 0)
        # Fluid background packed by an undecided parent: not offered again
        # (as `pending` for explicit txs; empty at 8141's freeze, after the
        # parent's PTC decision).
        parents = (tuple((earlier, payload.bg_gas) for earlier, payload
                         in ctx.slot.undecided_payloads(slot, builder))
                   if ctx.slot is not None else ())

        def fits(tx):
            return txs.gas[tx] <= gas_left and txs.bytes_chain[tx] <= bytes_left

        def usable(tx):
            return (tx not in taken and not (pending >> tx) & 1 and
                    txs.included_slot[tx] == NOT_INCLUDED and
                    txs.fee_cap[tx] >= base)

        il_used = 0
        for tx in il_txs:
            if usable(tx) and fits(tx):
                chosen.append(tx)
                taken.add(tx)
                gas_left -= txs.gas[tx]
                bytes_left -= txs.bytes_chain[tx]
                il_used += 1
        explicit = []
        for tx in self.pool.fee_order(builder, base):
            if not usable(tx):
                continue
            eff = min(txs.tip[tx], txs.fee_cap[tx] - base)
            explicit.append((eff, 0, tx))
        bins = []
        if ctx.demand is not None:
            for row in ctx.demand.background_offer(slot, until_ms=freeze_ms,
                                                   undecided=parents):
                bins.append(row)
        merged = sorted(explicit + [(row[0], 1, index)
                                    for index, row in enumerate(bins)],
                        key=lambda item: (-item[0], item[1], item[2]))
        bg_count = 0.0
        bg_gas = 0
        bg_bytes = 0.0
        for eff, is_bin, ident in merged:
            if gas_left <= 0 or bytes_left <= 0:
                break
            if is_bin:
                _tip, count, gas, size = bins[ident]
                if gas <= 0:
                    continue
                share = min(1.0, gas_left / gas,
                            bytes_left / size if size else 1.0)
                if share < 1.0:
                    cut["gas" if gas_left / gas <= (
                        bytes_left / size if size else 1.0) else "bytes"] += 1
                take_gas = int(gas * share)
                bg_count += count * share
                bg_gas += take_gas
                bg_bytes += size * share
                gas_left -= take_gas
                bytes_left -= size * share
                continue
            tx = ident
            if txs.gas[tx] > gas_left:
                cut["gas"] += 1
                continue
            if txs.bytes_chain[tx] > bytes_left:
                cut["bytes"] += 1
                continue
            chosen.append(tx)
            taken.add(tx)
            gas_left -= txs.gas[tx]
            bytes_left -= txs.bytes_chain[tx]
        gas_used = sum(txs.gas[tx] for tx in chosen) + bg_gas
        size = sum(txs.bytes_chain[tx] for tx in chosen) + bg_bytes
        if cut["gas"] or cut["bytes"]:
            binding = "gas" if cut["gas"] >= cut["bytes"] else "bytes"
        else:
            binding = "pool"
        cover = 0
        for tx in chosen:
            cover |= 1 << tx
        if il_used:
            self._count("il_included", il_used)
        return Payload(slot, builder, chosen, cover, gas_used,
                       int(round(size)) + self.header_bytes, 0, 0, binding,
                       bg_count, bg_gas, int(round(bg_bytes)), freeze_ms)

    def import_ms(self, node, payload):
        """EVM import of `payload` at `node` (ms, before scale.cpu)."""
        pq_gas = self.payload_ms.get(payload.slot)
        if pq_gas is None or pq_gas[0] is not payload:
            txs = self.ctx.txs
            pq = sum(txs.verify_gas[tx] for tx in payload.txs
                     if txs.kind[tx] != KIND_ECDSA)
            ecdsa = sum(txs.gas[tx] for tx in payload.txs
                        if txs.kind[tx] == KIND_ECDSA)
            pq_gas = (payload, pq, ecdsa)
            self.payload_ms[payload.slot] = pq_gas
        lanes = self.cores[node] if self.pbs == "epbs" else 1
        pq_ms = pq_gas[1] / self.gas_per_ms[node] / lanes
        # Ordinary (ECDSA) gas, fluid or explicit, at the measured mainnet
        # import rate (review F6: explicit txs were free).
        return pq_ms + (payload.bg_gas + pq_gas[2]) * self.bg_ms_per_gas[node]

    def drop_included(self, node, payload):
        """A node saw `payload` canonical: unpool and stop serving its txs."""
        self.pool.remove(node, payload.cover)
        el = self.el
        for tx in payload.txs:
            el.drop(node, self.rule, tx)


class DeployToday(Deploy8141):
    """Fulu mainnet today (MEV-boost, 60 M gas, ECDSA only): validation of
    the network model against mainnet (arch.md 5.3)."""

    id = "today"

    def analytic_bounds(self):
        slot_s = self.slot_ms / 1000.0
        demand = self.ctx.demand
        gas = float(demand.gas_ref) if demand is not None else None
        result = {}
        if gas and self.spec.chain.gas_limit:
            result["gas_ecdsa"] = int(self.spec.chain.gas_limit // gas) / slot_s
        return result


__all__ = ["Deploy8141", "DeployToday", "coefficient", "LANE_EL"]

"""Run many specs: <= 8 worker processes at nice 10, a JSONL cache, output
in input order (arch.md 3.0, 4 row S5; PHASE4-NETSIM.md 3: at most 8 worker
processes per sweep).

    rows = run_specs(specs, params, jobs=1, cache=None)

`specs` are resolved RunSpecs. Identical specs (same spec_hash) run once.
The cache is a JSONL file of `{"spec_hash", "code", "row"}` lines; a line is
reused only when both the spec_hash (spec + the parameter files + the
candidate table, counted rows and prover_model.py: params.data_sha256) and
the code fingerprint (runner.code_fingerprint: sha256 of every source file
the v3 runner imports, so an uncommitted edit invalidates it too) match. A
line that does not parse (a sweep killed mid-write) is skipped and counted
in `LAST_SKIPPED`. New lines are appended in input order after the
batch, so `--jobs 1` and `--jobs 8` write identical files and return
identical rows (each row is a pure function of its spec, runner.py).

multiprocessing is imported only for jobs > 1 (Pyodide has none).
"""

import json
import os

from starksim.v3 import runner
from starksim.v3 import spec as spec_module

MAX_JOBS = 8          # [E] PHASE4-NETSIM.md 3: at most 8 worker processes
NICE = 10             # [E] task brief: sweeps run at nice 10


def code_fingerprint():
    """runner.code_fingerprint (kept here for callers of S5's first
    commit)."""
    return runner.code_fingerprint()


def load_cache(path):
    """{(spec_hash, code): row} from a JSONL cache (missing file = {})."""
    stored = {}
    LAST_SKIPPED[:] = [0]
    if not path or not os.path.isfile(path):
        return stored
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                stored[(entry["spec_hash"], entry["code"])] = entry["row"]
            except (ValueError, KeyError, TypeError):
                LAST_SKIPPED[0] += 1
    return stored


def cache_line(spec_hash, code, row):
    return json.dumps({"spec_hash": spec_hash, "code": code, "row": row},
                      separators=(",", ":"), allow_nan=False)


_WORKER_PARAMS = []
LAST_SKIPPED = [0]


def _init_worker(params, nice, commit=None):
    if commit is not None:
        runner._COMMIT[:] = [commit]   # the parent's code_commit (spawn too)
    if nice:
        try:
            os.nice(nice)
        except (OSError, AttributeError):
            pass
    _WORKER_PARAMS[:] = [params]


def _work(spec):
    return runner.run(spec, _WORKER_PARAMS[0])


def clamp_jobs(jobs):
    return max(1, min(int(jobs), MAX_JOBS))


def run_specs(specs, params, jobs=1, cache=None, progress=None, nice=NICE):
    """Rows of `specs` in input order (module docstring). `progress(done,
    total)` is called in the parent after each new row. jobs > 1 runs
    workers at `nice`; jobs = 1 runs in this process (not reniced)."""
    specs = list(specs)
    jobs = clamp_jobs(jobs)
    runner.code_commit()    # fixed in the parent; forked workers inherit
    code = code_fingerprint()
    keys = [spec_module.spec_hash(spec, params) for spec in specs]
    stored = load_cache(cache)
    rows = {}
    todo = []
    queued = set()
    for spec, key in zip(specs, keys):
        if key in rows or key in queued:
            continue
        queued.add(key)
        if (key, code) in stored:
            rows[key] = stored[(key, code)]
        else:
            todo.append((key, spec))
    fresh = []
    if todo:
        if jobs == 1 or len(todo) == 1:
            for done, (key, spec) in enumerate(todo, 1):
                rows[key] = runner.run(spec, params)
                fresh.append(key)
                if progress is not None:
                    progress(done, len(todo))
        else:
            import multiprocessing
            method = ("fork" if "fork" in
                      multiprocessing.get_all_start_methods() else "spawn")
            context = multiprocessing.get_context(method)
            with context.Pool(min(jobs, len(todo)), initializer=_init_worker,
                              initargs=(params, nice,
                                        runner.code_commit())) as pool:
                results = pool.imap(_work, [spec for _key, spec in todo])
                for done, ((key, _spec), row) in enumerate(
                        zip(todo, results), 1):
                    rows[key] = row
                    fresh.append(key)
                    if progress is not None:
                        progress(done, len(todo))
    if cache and fresh:
        with open(cache, "a", encoding="utf-8") as handle:
            for key in fresh:
                handle.write(cache_line(key, code, rows[key]) + "\n")
    return [rows[key] for key in keys]

"""EL gossip: one announce/fetch engine for eth/68 txs and eth/73 wrappers.

Stage S2a (arch.md 3.4, STAGES.md S2a). Objects are identified per rule: an
eth/68 object is a tx id (int); an eth/73 object is a wrapper id (int,
issued by the deployment plug-in). The deployment answers
`ctx.hooks.object_bytes(rule_name, obj)` for sizes and receives every
fetched or pushed body through `ctx.hooks.el_body_received(node, rule_name,
obj, src)`; when it decides to keep the object (after admission CPU) it
calls `ElGossip.admit`. A refused or evicted object is reported with
`ElGossip.drop` (the node no longer serves it and never re-fetches it).

What one node does, per rule (geth eth/handler.go and eth/fetcher/
tx_fetcher.go @ 4721b2cc, copies under data/phase4/sources/clients/):

- **Admission** (`admit`): an object of at most `push_max_bytes` is sent
  whole at once to the ceil(sqrt(peers)) peers with the lowest score
  `stable_fraction(seed, "push", node, peer, sender)` among *all* peers
  (geth `choosePeers`, handler.go:784-806: the set is drawn over all peers,
  then peers known to hold the tx are skipped, so fewer may receive it).
  Every object is queued for the node's next announce tick.
- **Announce tick** (every `spec.net.announce_tick_ms`, per-node phase
  `ctx.fraction("phase", "el", node)`; ticks are scheduled only while
  something is pending): one fluid EL-lane load of `item_bytes` per (peer,
  item) for the peers not known to hold the item (they announced it to us,
  pushed it to us, or we pushed it to them). Each peer registers the
  announcement with its arrival time `now + chunk_bytes / up[node] +
  latency(node, peer)`. See the module notes for why the chunk is a load.
- **Fetcher** (receiver side, geth tx_fetcher.go): a new hash enters the
  wait list at its first announcement's arrival `a`. One wait timer per
  node fires at `earliest a + wait_ms` and moves every hash with
  `a <= now - (wait_ms - gather_ms)` to the queue (geth :720-741, the
  100 ms `txGatherSlack` gathers hashes that would expire within 100 ms).
  The queue is served by idle announcers (one request in flight per peer,
  :1114): peers are visited in sorted order rotated by a per-node random
  offset (geth's deterministic test order, :1124-1140; production uses Go
  map order), and each idle peer takes its queued hashes in announcement
  order while `items < request_max_items` and `bytes < request_max_bytes`
  (sizes as announced; the request may exceed the byte cap by its last
  item, as geth's :1105-1110). Requests are control messages (latency
  only).
- **Serving**: the peer answers with the objects it holds, stopping once the
  response reaches `response_soft_bytes` (geth answerGetPooledTransactions);
  the response is one EL-lane message. An empty response is a control
  message. eth/73: a responder whose serving budget (32 / 8 MiB/s) cannot
  cover the response answers empty (PR :68) and is asked again when it
  could; other announcers are asked first.
- **Delivery**: each object not yet held goes to `el_body_received`; one
  already held, in admission, or dropped is a duplicate (counted, bytes
  wasted); a late answer still delivers an object the node does not hold.
  Missing objects go back to the queue (the responder is removed from
  their announcers when the item precedes a delivered one, geth's cutoff
  :897-925); an object left with no announcer is forgotten (state UNSEEN,
  :909-921), so a later announcement starts a new wait.
- **Timeout**: one timer per node at the earliest live request + timeout;
  expired requests' undelivered hashes go back to the queue without that
  peer, and the peer stays busy until its late response arrives (geth
  :756-789: a timed-out request is kept as dangling).
- **Mixed client rules** (`spec.net.el_client_rules = "mixed"`, spec.md
  Q12): Reth nodes push every tx up to 128 KiB whole to round(sqrt(peers))
  (reth transactions/mod.rs; blob txs excluded there, none simulated) and
  request without waiting.

Module notes and deviations (notes/phase4/build-s2a.md):

1. Announcements are a fluid load on the EL lane (`links.load`) and reach
   peers after the chunk's own serialisation at the full uplink rate plus
   latency, not after the EL-lane FIFO ahead of them. `Links.send` with no
   destination never calls back (links.py `_up_done`), so a single chunk
   with a completion callback is not available; and geth sends
   announcements on per-peer queues (broadcast.go), so a small announcement
   does not wait behind bodies queued for other peers. Uplink bytes and
   busy time are exact; receivers' announcement bytes are counted in
   `el.<rule>.ann_bytes_in` (not in `links.bytes_down`).
2. Announcements are registered at the receiver when the sender's tick
   runs, stamped with their arrival time; every decision that depends on
   them (wait expiry, choice of announcer, known-peer filters) compares the
   arrival time with `now`, so registering early changes nothing except
   that a queued hash re-announced by an idle peer is kicked by one
   `el.kick` event at the arrival time.
3. Known-hash state is a per-node `bytearray` of object states (one byte
   per object id), not an int bitset: O(1) reads and writes, 1 byte per
   (node, object). Per-object announcer lists live only until the node's
   own announce tick for that object.
4. geth ignores announcements beyond 4,096 unfetched hashes per peer
   (`maxTxAnnounces`, tx_fetcher.go:579-590); the limit is recorded in the
   rule and not enforced (a peer would need > 4,096 hashes outstanding at
   one node, far above the simulated rates).
"""

import heapq
from array import array
from dataclasses import dataclass
from math import isqrt

from starksim.v3 import params as P
from starksim.v3.links import ServingBudget
from starksim.v3.state import LANE_EL

RULE_ETH68 = "eth68"
RULE_ETH73 = "eth73"

# Event kinds S2a registers (owner prefix "el."):
EV_TICK = "el.tick"            # per-node announce tick
EV_FETCH_DUE = "el.fetch_due"  # a node's wait for announced hashes ended
EV_TIMEOUT = "el.timeout"      # a request was not answered in time
EV_KICK = "el.kick"            # a queued hash's new announcer arrived

# Object states at a node (one byte per object id).
UNSEEN = 0
WAITING = 1      # announced, in the wait list
QUEUED = 2       # wait over, not yet requested
FETCHING = 3     # [A] state code: requested from one peer
PROCESSING = 4   # [A] state code: body received, admission running (deploy)
HELD = 5         # [A] state code: admitted: announced and served
DROPPED = 6      # [A] state code: refused, evicted or included: never served or re-fetched

REQUEST_BYTES_PER_HASH = 33   # [A] RLP of a 32-B hash (devp2p caps/eth.md GetPooledTransactions)
REQUEST_OVERHEAD_BYTES = 16   # [A] request id + list headers (devp2p caps/eth.md)
REACH_BUDGET_FLOATS = 2_000_000  # [A] STAGES.md S2a: reach sample <= 2e6 floats
PUSH_CACHE_LIMIT = 65_536     # [A] performance only: (node, sender) push-set cache size
_GROW = 4096                  # [A] performance only: bytearray growth step
BUDGET_SLACK = 1e-9           # [A] numerical: relative token shortfall treated as none

P.register_bindings({
    "eth68_push_max_bytes": (
        P.NET, ("el_gossip", "geth.handler", "txMaxBroadcastSize"), None),
    "eth68_arrive_timeout_ms": (
        P.NET, ("el_gossip", "geth.fetcher", "txArriveTimeout"), None),
    "eth68_gather_slack_ms": (
        P.NET, ("el_gossip", "geth.fetcher", "txGatherSlack"), None),
    "eth68_max_retrievals": (
        P.NET, ("el_gossip", "geth.fetcher", "maxTxRetrievals"), None),
    "eth68_max_retrieval_bytes": (
        P.NET, ("el_gossip", "geth.fetcher", "maxTxRetrievalSize"), None),
    "eth68_fetch_timeout_ms": (
        P.NET, ("el_gossip", "geth.fetcher", "txFetchTimeout"), None),
    "eth68_max_announces": (
        P.NET, ("el_gossip", "geth.fetcher", "maxTxAnnounces"), None),
    "eth68_in_flight_per_peer": (
        P.NET, ("el_gossip", "geth.fetcher", "requests per peer in flight"),
        None),
    "eth68_soft_response_bytes": (
        P.NET, ("el_gossip", "geth.proto", "softResponseLimit"), None),
    "reth_broadcast_soft_bytes": (
        P.NET, ("el_gossip", "reth.net",
                "DEFAULT_SOFT_LIMIT_BYTE_SIZE_TRANSACTIONS_BROADCAST_MESSAGE"),
        None),
})


@dataclass(frozen=True)
class GossipRule:
    """Per-object-kind announce/fetch parameters (arch.md 3.4 table).

    push_max_bytes: objects up to this size are pushed to ceil(sqrt(peers))
    peers (0 = never push). item_bytes: bytes per announced hash.
    items_per_announce: hashes per announcement message. wait_ms: delay from
    the first announcement to the first request. request_max_items /
    request_max_bytes: request caps. timeout_ms: request timeout, then the
    next announcer. in_flight_per_peer: concurrent requests per peer.
    suppress_covered: eth/73 suppression of wrappers whose txs the peer is
    believed to hold. Values come from params/deployments constants in
    `eth68(...)` / `eth73(...)`, never literals.

    Appended in S2a: gather_ms (geth txGatherSlack: hashes due within this
    long are requested together), response_soft_bytes (the server stops
    adding objects once the response reaches it; 0 = no limit),
    serve_node_Bps / serve_peer_Bps (eth/73 serving budget in bytes per
    second; 0 = none), reth_push_max_bytes (push limit of Reth nodes
    under mixed client rules: reth pushes every non-blob tx whole, up to its
    128 KiB broadcast-message soft limit; 0 = never push). A request byte
    cap of 0 means none.
    """
    name: str
    push_max_bytes: int
    item_bytes: int
    items_per_announce: int
    wait_ms: float
    request_max_items: int
    request_max_bytes: int
    timeout_ms: float
    in_flight_per_peer: int
    suppress_covered: bool
    gather_ms: float = 0.0
    response_soft_bytes: int = 0
    serve_node_Bps: float = 0.0
    serve_peer_Bps: float = 0.0
    reth_push_max_bytes: int = 0


def eth68(params, spec):
    """GossipRule for eth/68+ transactions (geth rules, spec.md A13)."""
    del spec  # same rules for every spec; per-node client rules in ElGossip
    return GossipRule(
        name=RULE_ETH68,
        push_max_bytes=int(params.value("eth68_push_max_bytes")),
        item_bytes=int(params.constant_value(
            "eth68_announcement_bytes_per_tx")),
        items_per_announce=int(params.value("eth68_max_announces")),
        wait_ms=float(params.value("eth68_arrive_timeout_ms")),
        request_max_items=int(params.value("eth68_max_retrievals")),
        request_max_bytes=int(params.value("eth68_max_retrieval_bytes")),
        timeout_ms=float(params.value("eth68_fetch_timeout_ms")),
        in_flight_per_peer=int(params.value("eth68_in_flight_per_peer")),
        suppress_covered=False,
        gather_ms=float(params.value("eth68_gather_slack_ms")),
        response_soft_bytes=int(params.value("eth68_soft_response_bytes")),
        reth_push_max_bytes=int(params.value("reth_broadcast_soft_bytes")),
    )


def eth73(params, spec):
    """GossipRule for eth/73 wrappers (PR #12423, spec.md B13).

    Announce to every peer (never push), 106-B tuples, <= 64 per message,
    <= 32 hashes per request, responses soft-capped at 2 MiB, serving
    budget 32 MiB/s per node and 8 MiB/s per peer; fetch wait (0 ms [PR])
    and timeout (5 s [A]) from `deployments.8288.eth73` (leanpcs inherits
    it). No byte cap on a request (`request_max_bytes = 0`): the response's
    soft limit bounds it. A responder whose serving budget is spent answers
    empty (PR :68 SHOULD); the requester keeps it as an announcer and asks
    it again when its budget would allow, other announcers first.
    """
    del spec
    entry = params.deployment_entry("8288")["eth73"]
    soft = int(params.constant_value("eth73_soft_response_limit"))
    return GossipRule(
        name=RULE_ETH73,
        push_max_bytes=0,
        item_bytes=int(params.constant_value("eth73_announce_tuple_bytes")),
        items_per_announce=int(params.constant_value(
            "eth73_announce_max_items")),
        wait_ms=float(_leaf_value(entry["fetch_wait_ms"])),
        request_max_items=int(params.constant_value("eth73_get_max_hashes")),
        request_max_bytes=0,  # [PR] eip-8437-pr12423.md:50 caps hashes only
        timeout_ms=float(_leaf_value(entry["fetch_timeout_ms"])),
        in_flight_per_peer=1,  # [PR] eip-8437-pr12423.md:58 one announcer at a time
        suppress_covered=True,
        gather_ms=0.0,
        response_soft_bytes=soft,
        serve_node_Bps=float(params.constant_value(
            "eth73_serving_budget_total")),
        serve_peer_Bps=float(params.constant_value(
            "eth73_serving_budget_per_peer")),
    )


def _leaf_value(node):
    return node["value"] if isinstance(node, dict) and "value" in node \
        else node


def push_count(peers, reth=False):
    """Peers that get a full copy: ceil(sqrt(peers)) (geth handler.go:803),
    round(sqrt(peers)) for Reth (spec.md Q12). Integer arithmetic only."""
    if peers <= 0:
        return 0
    if reth:
        root = isqrt(peers)
        # round(sqrt(n)): up when n > root^2 + root (n is an integer).
        return root + 1 if peers > root * root + root else root
    return isqrt(peers - 1) + 1


class _RuleState:
    """Per-rule fetcher and announcer state of every node."""

    def __init__(self, index, rule, n):
        self.index = index
        self.rule = rule
        self.kind_ann = "el.ann." + rule.name
        self.kind_req = "el.req." + rule.name
        self.kind_body = "el.body." + rule.name
        self.kind_push = "el.push." + rule.name
        self.state = [bytearray() for _ in range(n)]
        self.announcers = [{} for _ in range(n)]   # obj -> [(arrival, peer)]
        self.wait_heap = [[] for _ in range(n)]    # (arrival, obj)
        self.wait_due = [None] * n
        self.wait_version = [0] * n
        self.queued = [{} for _ in range(n)]       # obj -> None (ordered)
        self.by_peer = [{} for _ in range(n)]      # peer -> [(arrival, obj)]
        self.kick_due = [{} for _ in range(n)]     # peer -> kick time
        # eth/73: peer -> time its serving budget allows asking again
        # (set by an empty budget answer; S3b livelock fix).
        self.blocked = [{} for _ in range(n)]
        self.fetching = [{} for _ in range(n)]     # obj -> peer
        self.requests = [{} for _ in range(n)]     # peer -> _Request
        self.timeout_due = [None] * n
        self.timeout_version = [0] * n
        self.pending = [[] for _ in range(n)]      # admitted, not announced
        self.tick_pending = [False] * n
        self.pushed = [{} for _ in range(n)]       # obj -> [peers pushed to]
        self.reach = {}                            # obj -> array or None
        self.reach_floats = 0
        self.budget = None


class _Request:
    __slots__ = ("items", "sent", "live")

    def __init__(self, items, sent):
        self.items = items
        self.sent = sent
        self.live = True


class ElGossip:
    """Announce/fetch over the EL graph (ctx.nodes.el_peers) on the EL lane
    of ctx.links. One instance serves every rule of the run."""

    def __init__(self, ctx, rules, expected_objects=None,
                 reach_budget=REACH_BUDGET_FLOATS):
        """`rules`: {rule name: GossipRule}. Registers EV_* kinds and the
        counters `el.<rule>.*` per node: announced (items sent), ann_bytes
        (uplink), ann_bytes_in, requests, requested (items), req_bytes,
        fetched (first bodies received by request), pushed_in (first bodies
        received by push), dup_bodies, dup_bytes, served (items), missing
        (requested items not served), pushed (copies sent), timeouts,
        late (responses that arrived after their request timed out),
        budget_empty (eth/73 requests answered empty, serving budget spent).

        `expected_objects` ({rule: count}, optional) sizes the reach sample
        and `reach_budget` caps its floats (see `reach_times`)."""
        self.reach_budget = int(reach_budget)
        self.ctx = ctx
        self.links = ctx.links
        self.engine = ctx.engine
        topo = ctx.topo
        self.n = topo.n_total
        self.latency = topo.latency
        self.ideal = bool(getattr(topo, "ideal", False))
        self.peers = ctx.nodes.el_peers
        self.tick_ms = float(ctx.spec.net.announce_tick_ms)
        mixed = ctx.spec.net.el_client_rules == "mixed"
        clients = ctx.nodes.el_client
        self.reth = [mixed and clients[node] == "reth"
                     for node in range(self.n)]
        self.phase = [ctx.fraction("phase", "el", node) * self.tick_ms
                      for node in range(self.n)]
        self.rng = [ctx.stream("el.fetch_order", node)
                    for node in range(self.n)]
        self.suppressor = None
        self.batch_suppressor = None
        self.announce_observer = None
        self.held_observer = None
        self.lat_rows = [None] * self.n
        self.peer_sets = [None] * self.n
        self.push_cache = {}
        self.rules = {}
        self.order = []
        expected = expected_objects or {}
        counters = ctx.counters
        for index, name in enumerate(rules):
            rule = rules[name]
            if rule.name != name:
                raise ValueError(f"rule key {name!r} != rule.name "
                                 f"{rule.name!r}")
            state = _RuleState(index, rule, self.n)
            if rule.serve_node_Bps > 0.0 and rule.serve_peer_Bps > 0.0:
                state.budget = ServingBudget(rule.serve_node_Bps,
                                             rule.serve_peer_Bps)
            count = expected.get(name)
            if count:
                state.reach_share = min(
                    1.0, self.reach_budget / float(self.n * count))
            else:
                state.reach_share = 1.0
            state.c = {}
            for metric in ("announced", "ann_bytes", "ann_bytes_in",
                           "requests", "requested", "req_bytes", "fetched",
                           "pushed_in", "dup_bodies", "dup_bytes", "served",
                           "missing", "pushed", "timeouts", "late",
                           "budget_empty"):
                state.c[metric] = counters.array(
                    f"el.{name}.{metric}", self.n, 0)
            self.rules[name] = state
            self.order.append(state)
        ctx.on(EV_TICK, self._tick)
        ctx.on(EV_FETCH_DUE, self._wait_expired)
        ctx.on(EV_TIMEOUT, self._timeout)
        ctx.on(EV_KICK, self._kick)
        ctx.el = self

    # ------------------------------------------------------------ public
    def start(self):
        """Ticks are scheduled on demand (only while a node has something
        to announce), at the node's phase on the tick grid; nothing to do
        until the first admission. Kept for the frozen interface."""
        return None

    def set_suppressor(self, function):
        """eth/73 suppression (spec.md B13), wired by the 8288/leanPCS
        plug-in: `function(node, peer, rule_name, obj) -> bool`, True when
        `node` must not announce `obj` to `peer` (its txs are covered by
        wrappers exchanged with `peer`). Applies to rules with
        suppress_covered."""
        self.suppressor = function

    def set_announce_observer(self, function):
        """For rules with suppress_covered: `function(node, peer, objs,
        arrival)` is told that `node`'s announcement of `objs` reaches
        `peer` at `arrival` (eth/73 coverage of wrappers "announced by the
        recipient", eip-8437-pr12423.md:42)."""
        self.announce_observer = function

    def set_held_observer(self, function):
        """For rules with suppress_covered (S7b, performance):
        `function(node, obj)` is told when `node` starts holding `obj`
        (the HELD transition in `admit`)."""
        self.held_observer = function

    def set_batch_suppressor(self, function):
        """Optional batch form of the suppressor (S7, performance):
        `function(node, rule_name, peer, objs) -> objs` returns the objects
        of `objs` (in order) the suppressor lets through to `peer`, with the
        side effects of calling it on each in turn."""
        self.batch_suppressor = function

    def admit(self, node, rule_name, obj, src=None):
        """`node` now holds `obj`: push it if small enough, queue it for the
        next announce tick, mark it known for `src`."""
        rs = self.rules[rule_name]
        states = rs.state[node]
        if obj >= len(states):
            _grow(states, obj)
        if states[obj] == HELD:
            return
        if states[obj] == DROPPED:
            # A dropped object is never admitted again at this node.
            return
        now = self.engine.now
        states[obj] = HELD
        if self.held_observer is not None and rs.rule.suppress_covered:
            self.held_observer(node, obj)
        rs.queued[node].pop(obj, None)
        rs.fetching[node].pop(obj, None)
        if obj not in rs.announcers[node]:
            # Present until this node's announce tick: later announcers are
            # recorded so the node does not announce back to them.
            rs.announcers[node][obj] = []
        if src is not None:
            self._mark_known(rs, node, obj, src, now)
        self._record_reach(rs, node, obj, now)
        rule = rs.rule
        push_max = rule.reth_push_max_bytes if self.reth[node] \
            else rule.push_max_bytes
        if push_max > 0:
            size = self.ctx.hooks.object_bytes(rule_name, obj)
            if size <= push_max:
                self._push(rs, node, obj, size, now)
        if self.tick_ms <= 0.0:
            rs.pending[node].append(obj)
            self._announce(rs, node)
            return
        rs.pending[node].append(obj)
        if not rs.tick_pending[node]:
            rs.tick_pending[node] = True
            self.ctx.at(self._next_tick(node, now), EV_TICK,
                        (rs.index, node))

    def drop(self, node, rule_name, obj):
        """`node` no longer holds `obj` (refused at admission, evicted,
        included): never serve it, never fetch it again."""
        rs = self.rules[rule_name]
        states = rs.state[node]
        if obj >= len(states):
            _grow(states, obj)
        states[obj] = DROPPED
        rs.queued[node].pop(obj, None)
        rs.fetching[node].pop(obj, None)
        rs.announcers[node].pop(obj, None)
        rs.pushed[node].pop(obj, None)

    def knows(self, node, rule_name, obj):
        """True once `node` holds or has requested `obj` (state FETCHING or
        later, incl. a body in admission and a dropped object)."""
        states = self.rules[rule_name].state[node]
        return obj < len(states) and states[obj] >= FETCHING

    def state_of(self, node, rule_name, obj):
        """The object's state code at `node` (UNSEEN ... DROPPED)."""
        states = self.rules[rule_name].state[node]
        return states[obj] if obj < len(states) else UNSEEN

    def holds(self, node, rule_name, obj):
        """True while `node` holds `obj` (admitted, not dropped)."""
        return self.state_of(node, rule_name, obj) == HELD

    def reach_times(self, rule_name, obj):
        """First-admission time per node (list of floats, -1.0 = never) for
        an object of the reach sample, else None.

        Sample rule: an object is in the sample when
        `ctx.fraction("reach", rule_name, obj) < share`, with share =
        min(1, B / (n_total x expected objects)) when the constructor got
        `expected_objects[rule]`, else 1 (every object); in both cases
        recording stops for objects first admitted after B floats are in
        use (so an unsized run keeps its first B / n_total objects).
        B = `reach_budget`, default 2e6 (STAGES.md S2a).
        Times are absolute (ms); subtract the birth time for latencies."""
        rs = self.rules[rule_name]
        times = rs.reach.get(obj)
        if times is None:
            return None
        return times.tolist()

    def reach_objects(self, rule_name):
        """Object ids in the reach sample, in first-admission order."""
        rs = self.rules[rule_name]
        return [obj for obj, times in rs.reach.items() if times is not None]

    # ---------------------------------------------------------- internals
    def _next_tick(self, node, now):
        tick = self.tick_ms
        phase = self.phase[node]
        steps = int((now - phase) // tick) + 1
        when = phase + steps * tick
        if when <= now:
            when += tick
        return when

    def _record_reach(self, rs, node, obj, now):
        times = rs.reach.get(obj, 0)
        if times == 0:
            times = None
            if rs.reach_floats + self.n <= self.reach_budget and (
                    rs.reach_share >= 1.0 or self.ctx.fraction(
                        "reach", rs.rule.name, obj) < rs.reach_share):
                times = array("d", [-1.0]) * self.n
                rs.reach_floats += self.n
            rs.reach[obj] = times
        if times is not None and times[node] < 0.0:
            times[node] = now

    def _mark_known(self, rs, node, obj, peer, arrival):
        entries = rs.announcers[node].get(obj)
        if entries is None:
            rs.announcers[node][obj] = [(arrival, peer)]
        else:
            _add_entry(entries, arrival, peer)

    def _push(self, rs, node, obj, size, now):
        peers = self.peers[node]
        if not peers:
            return
        sender = self.ctx.txs.sender[obj] if rs.rule.name == RULE_ETH68 \
            else obj
        key = (node, sender)
        chosen = self.push_cache.get(key)
        if chosen is None:
            count = push_count(len(peers), self.reth[node])
            fraction = self.ctx.fraction
            scored = sorted((fraction("push", node, peer, sender), peer)
                            for peer in peers)
            chosen = tuple(peer for _score, peer in scored[:count])
            if len(self.push_cache) >= PUSH_CACHE_LIMIT:
                self.push_cache.clear()
            self.push_cache[key] = chosen
        known = self._known_peers(rs, node, obj, now)
        sent = []
        links = self.links
        for peer in chosen:
            if peer in known:
                continue
            sent.append(peer)
            links.send(node, peer, LANE_EL, rs.kind_push, size,
                       self._on_push, (rs.index, peer, node, obj, size))
        if sent:
            rs.c["pushed"][node] += len(sent)
            rs.pushed[node][obj] = sent

    def _known_peers(self, rs, node, obj, now):
        """Peers `node` knows to hold `obj` at `now` (a set of ints, used
        for membership only)."""
        entries = rs.announcers[node].get(obj)
        if entries:
            known = {peer for arrival, peer in entries if arrival <= now}
        else:
            known = set()
        pushed = rs.pushed[node].get(obj)
        if pushed:
            known.update(pushed)
        return known

    def _tick(self, payload):
        index, node = payload
        rs = self.order[index]
        rs.tick_pending[node] = False
        self._announce(rs, node)

    def _announce(self, rs, node):
        objs = rs.pending[node]
        if not objs:
            return
        rs.pending[node] = []
        now = self.engine.now
        peers = self.peers[node]
        if not peers:
            for obj in objs:
                rs.announcers[node].pop(obj, None)
                rs.pushed[node].pop(obj, None)
            return
        rule = rs.rule
        suppress = self.suppressor if rule.suppress_covered else None
        states = rs.state[node]
        # Per object, the peers that must not get it.
        plan = []
        for obj in objs:
            if obj < len(states) and states[obj] != HELD:
                rs.announcers[node].pop(obj, None)
                rs.pushed[node].pop(obj, None)
                continue
            known = self._known_peers(rs, node, obj, now)
            rs.announcers[node].pop(obj, None)
            rs.pushed[node].pop(obj, None)
            plan.append((obj, known))
        if not plan:
            return
        if suppress is None:
            self._announce_all(rs, node, plan, peers, now)
            return
        targets = {}
        total = 0
        batch = self.batch_suppressor if suppress is not None else None
        rule_name = rule.name
        if batch is not None:
            # Peer-major (S7): the same lists, and the suppressor's side
            # effects are per (node, peer); peers ordered by their first
            # object as the object-major loop inserts them. S7b: a peer's
            # list is `objs` minus the objects it is known to hold, cut
            # out by slices (known sets inverted once per tick).
            objs = [obj for obj, _known in plan]
            excluded = {}
            for index, (_obj, known) in enumerate(plan):
                for peer in known:
                    marks = excluded.get(peer)
                    if marks is None:
                        excluded[peer] = [index]
                    else:
                        marks.append(index)
            first = {obj: index for index, obj in enumerate(objs)}
            lists = []
            for position, peer in enumerate(peers):
                marks = excluded.get(peer)
                if marks is None:
                    items = objs
                else:
                    items = []
                    previous = 0
                    for index in marks:
                        if index > previous:
                            items += objs[previous:index]
                        previous = index + 1
                    if previous < len(objs):
                        items += objs[previous:]
                if items:
                    items = batch(node, rule_name, peer, items)
                if items:
                    lists.append((first[items[0]], position, peer, items))
                    total += len(items)
            lists.sort()
            for _first, _position, peer, items in lists:
                targets[peer] = items
        else:
            for obj, known in plan:
                for peer in peers:
                    if peer in known:
                        continue
                    if suppress(node, peer, rule_name, obj):
                        continue
                    items = targets.get(peer)
                    if items is None:
                        targets[peer] = [obj]
                    else:
                        items.append(obj)
                    total += 1
        if not total:
            return
        chunk = total * rule.item_bytes
        rs.c["announced"][node] += total
        rs.c["ann_bytes"][node] += chunk
        self.links.load(node, LANE_EL, rs.kind_ann, chunk)
        serialise = 0.0
        if not self.ideal:
            serialise = chunk / self.links.up[node]
        lat_row = self.lat_rows[node]
        if lat_row is None:
            latency = self.latency
            lat_row = {peer: latency(node, peer) for peer in peers}
            self.lat_rows[node] = lat_row
        ann_in = rs.c["ann_bytes_in"]
        item_bytes = rule.item_bytes
        state = rs.state
        announcers = rs.announcers
        register = self._register
        observer = self.announce_observer
        processing = PROCESSING
        held = HELD
        waiting = WAITING
        fetching = FETCHING
        for peer, items in targets.items():
            arrival = now + serialise + lat_row[peer]
            ann_in[peer] += len(items) * item_bytes
            if observer is not None:
                observer(node, peer, items, arrival)
            peer_states = state[peer]
            size = len(peer_states)
            peer_announcers = announcers[peer]
            mine = (arrival, node)      # S7b: one entry tuple per peer
            for obj in items:
                # Fast paths of _register: already past fetching, or a
                # later announcer of a hash still waiting (not the earliest).
                if obj < size:
                    code = peer_states[obj]
                    if code >= processing:
                        if code <= held:
                            entries = peer_announcers.get(obj)
                            if entries is not None:
                                if entries and arrival < entries[0][0]:
                                    entries.append(entries[0])
                                    entries[0] = mine
                                else:
                                    entries.append(mine)
                        continue
                    if code == waiting:
                        entries = peer_announcers[obj]
                        if arrival >= entries[0][0]:
                            entries.append(mine)
                            continue
                    elif code == fetching:
                        # _register's FETCHING case: an alternate.
                        entries = peer_announcers.get(obj)
                        if entries is None:
                            peer_announcers[obj] = [mine]
                        elif entries and arrival < entries[0][0]:
                            entries.append(entries[0])
                            entries[0] = mine
                        else:
                            entries.append(mine)
                        continue
                register(rs, peer, node, obj, arrival)

    def _announce_all(self, rs, node, plan, peers, now):
        """`_announce` without a suppressor (S7, one pass per peer): every
        peer gets the plan's objects it is not known to hold. Same total,
        same peer order (by first object, then position) and the same
        per-peer object order as the two-pass form."""
        peer_set = self.peer_sets[node]
        if peer_set is None:
            peer_set = frozenset(peers)
            self.peer_sets[node] = peer_set
        count = len(peers)
        total = 0
        order = []
        for obj, known in plan:
            total += count - (len(known & peer_set) if known else 0)
        if not total:
            return
        for position, peer in enumerate(peers):
            for index, (_obj, known) in enumerate(plan):
                if peer not in known:
                    order.append((index, position, peer))
                    break
        order.sort()
        rule = rs.rule
        chunk = total * rule.item_bytes
        rs.c["announced"][node] += total
        rs.c["ann_bytes"][node] += chunk
        self.links.load(node, LANE_EL, rs.kind_ann, chunk)
        serialise = 0.0
        if not self.ideal:
            serialise = chunk / self.links.up[node]
        lat_row = self.lat_rows[node]
        if lat_row is None:
            latency = self.latency
            lat_row = {peer: latency(node, peer) for peer in peers}
            self.lat_rows[node] = lat_row
        ann_in = rs.c["ann_bytes_in"]
        item_bytes = rule.item_bytes
        state = rs.state
        announcers = rs.announcers
        register = self._register
        processing = PROCESSING
        held = HELD
        waiting = WAITING
        fetching = FETCHING
        for start, _position, peer in order:
            arrival = now + serialise + lat_row[peer]
            peer_states = state[peer]
            size = len(peer_states)
            peer_announcers = announcers[peer]
            mine = (arrival, node)      # S7b: one entry tuple per peer
            sent = 0
            for obj, known in (plan if not start else plan[start:]):
                if peer in known:
                    continue
                sent += 1
                # Fast paths of _register: already past fetching, or a
                # later announcer of a hash still waiting (not the earliest).
                if obj < size:
                    code = peer_states[obj]
                    if code >= processing:
                        if code <= held:
                            entries = peer_announcers.get(obj)
                            if entries is not None:
                                if entries and arrival < entries[0][0]:
                                    entries.append(entries[0])
                                    entries[0] = mine
                                else:
                                    entries.append(mine)
                        continue
                    if code == waiting:
                        entries = peer_announcers[obj]
                        if arrival >= entries[0][0]:
                            entries.append(mine)
                            continue
                    elif code == fetching:
                        # _register's FETCHING case: an alternate.
                        entries = peer_announcers.get(obj)
                        if entries is None:
                            peer_announcers[obj] = [mine]
                        elif entries and arrival < entries[0][0]:
                            entries.append(entries[0])
                            entries[0] = mine
                        else:
                            entries.append(mine)
                        continue
                register(rs, peer, node, obj, arrival)
            ann_in[peer] += sent * item_bytes

    def _register(self, rs, node, peer, obj, arrival):
        """`peer`'s announcement of `obj` reaches `node` at `arrival`."""
        states = rs.state[node]
        if obj >= len(states):
            _grow(states, obj)
        state = states[obj]
        if state == UNSEEN:
            states[obj] = WAITING
            rs.announcers[node][obj] = [(arrival, peer)]
            heapq.heappush(rs.wait_heap[node], (arrival, obj))
            self._arm_wait(rs, node, arrival + self._wait_ms(rs, node))
            return
        if state >= PROCESSING:
            if state <= HELD:
                # In admission or not yet announced: remember the announcer
                # (geth MarkTransaction on receipt, handlers.go).
                entries = rs.announcers[node].get(obj)
                if entries is not None:
                    _add_entry(entries, arrival, peer)
            return
        entries = rs.announcers[node].get(obj)
        if entries is None:
            entries = []
            rs.announcers[node][obj] = entries
        if state == WAITING:
            if not entries or arrival < entries[0][0]:
                heapq.heappush(rs.wait_heap[node], (arrival, obj))
                self._arm_wait(rs, node, arrival + self._wait_ms(rs, node))
            _add_entry(entries, arrival, peer)
            return
        _add_entry(entries, arrival, peer)
        if state == QUEUED:
            # geth :703-706: a peer announcing an already queued hash may be
            # asked for it at once (here from the announcement's arrival).
            self._offer(rs, node, peer, obj, arrival, self.engine.now)
        # FETCHING: the peer is an alternate for a timeout or a miss.

    def _wait_ms(self, rs, node):
        if self.reth[node]:
            return 0.0
        return rs.rule.wait_ms

    def _arm_wait(self, rs, node, due):
        current = rs.wait_due[node]
        if current is not None and current <= due:
            return
        rs.wait_due[node] = due
        rs.wait_version[node] += 1
        self.ctx.at(max(due, self.engine.now), EV_FETCH_DUE,
                    (rs.index, node, rs.wait_version[node]))

    def _wait_expired(self, payload):
        index, node, version = payload
        rs = self.order[index]
        if version != rs.wait_version[node]:
            return
        rs.wait_due[node] = None
        now = self.engine.now
        wait = self._wait_ms(rs, node)
        gather = min(rs.rule.gather_ms, wait)
        hold = wait - gather
        heap = rs.wait_heap[node]
        states = rs.state[node]
        queued = rs.queued[node]
        moved = []
        # arrival + hold <= now (not arrival <= now - hold): the timer is
        # armed at arrival + wait, and the same float form never misses it.
        while heap and heap[0][0] + hold <= now:
            _arrival, obj = heapq.heappop(heap)
            if states[obj] != WAITING:
                continue
            states[obj] = QUEUED
            queued[obj] = None
            moved.append(obj)
        while heap and states[heap[0][1]] != WAITING:
            heapq.heappop(heap)
        if heap:
            self._arm_wait(rs, node, heap[0][0] + wait)
        if moved:
            self._enqueue_for_peers(rs, node, moved, now)

    def _requeue(self, rs, node, objs, now, exclude=None):
        """Undelivered hashes back from FETCHING (state already QUEUED).
        A hash left with no arrived announcer is forgotten (geth deletes it
        when no alternates remain, tx_fetcher.go:909-921): state UNSEEN, and
        announcements still on their way register afresh (a new wait)."""
        keep = []
        states = rs.state[node]
        for obj in objs:
            entries = rs.announcers[node].get(obj)
            if entries and any(arrival <= now for arrival, _peer in entries):
                keep.append(obj)
                continue
            states[obj] = UNSEEN
            rs.queued[node].pop(obj, None)
            rs.announcers[node].pop(obj, None)
            for arrival, peer in sorted(entries or ()):
                self._register(rs, node, peer, obj, arrival)
        if keep:
            self._enqueue_for_peers(rs, node, keep, now, exclude)

    def _enqueue_for_peers(self, rs, node, objs, now, exclude=None):
        """Put queued `objs` on their arrived announcers' lists; ask the
        idle ones, in rotated sorted order (geth forEachPeer). `exclude`
        gets the entries but is not asked now."""
        active = {}
        later = []
        announcers = rs.announcers[node]
        by_peer = rs.by_peer[node]
        requests = rs.requests[node]
        for obj in objs:
            entries = announcers.get(obj)
            if not entries:
                continue
            for entry in entries:
                arrival, peer = entry
                # _offer(..., kick=False), inlined (S7).
                lst = by_peer.get(peer)
                if lst is None:
                    by_peer[peer] = [(arrival, obj)]
                else:
                    lst.append((arrival, obj))
                if peer not in requests and arrival <= now:
                    if peer != exclude:
                        active[peer] = True
                elif arrival > now:
                    later.append((obj, peer, arrival))
        if active:
            self._schedule_peers(rs, node, sorted(active))
        # Announcers still on their way matter only for hashes nobody idle
        # could take now.
        states = rs.state[node]
        for obj, peer, arrival in later:
            if states[obj] == QUEUED and peer not in rs.requests[node]:
                self._kick_at(rs, node, peer, arrival)

    def _offer(self, rs, node, peer, obj, arrival, now, kick=True):
        """Queue `obj` on `peer`'s list at `node` (stamped with the
        announcement's arrival). True when the peer can be asked now; when
        it is idle but the announcement is still on its way, one kick per
        (node, peer) asks it at the arrival."""
        lst = rs.by_peer[node].get(peer)
        if lst is None:
            rs.by_peer[node][peer] = [(arrival, obj)]
        else:
            lst.append((arrival, obj))
        if peer in rs.requests[node]:
            return False   # busy: asked again when its response arrives
        if arrival <= now:
            return True
        if kick:
            self._kick_at(rs, node, peer, arrival)
        return False

    def _kick_at(self, rs, node, peer, arrival):
        due = rs.kick_due[node].get(peer)
        if due is None or arrival < due:
            rs.kick_due[node][peer] = arrival
            self.ctx.at(arrival, EV_KICK, (rs.index, node, peer))

    def _schedule_peers(self, rs, node, peers):
        if len(peers) > 1:
            offset = int(self.rng[node].random() * len(peers))
            peers = peers[offset:] + peers[:offset]
        requests = rs.requests[node]
        for peer in peers:
            if peer not in requests:
                self._request(rs, node, peer)

    def _request(self, rs, node, peer):
        lst = rs.by_peer[node].get(peer)
        if not lst:
            return
        blocked = rs.blocked[node].get(peer)
        if blocked is not None:
            if blocked > self.engine.now:
                # Budget spent at this peer: not before its retry time,
                # else two budget-spent announcers ping-pong empty answers
                # forever at one timestamp (S3b livelock fix). [A] eth/73
                # has no retry-after hint (eip-8437-pr12423.md ProofWrappers:
                # "a future version may add" one): the requester is assumed
                # to back off until the responder's budget refills.
                self._kick_at(rs, node, peer, blocked)
                return
            del rs.blocked[node][peer]
        rule = rs.rule
        states = rs.state[node]
        queued = rs.queued[node]
        fetching = rs.fetching[node]
        object_bytes = self.ctx.hooks.object_bytes
        now = self.engine.now
        items = []
        size = 0
        keep = []
        max_items = rule.request_max_items
        max_bytes = rule.request_max_bytes
        rule_name = rule.name
        full = max_items <= 0
        # S7b: the queued entries first (one comprehension); only the
        # objects taken below leave QUEUED meanwhile, so a re-check skips
        # a repeated entry exactly as the loop over `lst` did.
        queued_code = QUEUED
        lst = [entry for entry in lst if states[entry[1]] == queued_code]
        count = len(lst)
        index = 0
        while index < count and not full:
            entry = lst[index]
            index += 1
            obj = entry[1]
            if states[obj] != queued_code:
                continue
            if entry[0] > now:
                keep.append(entry)
                continue
            items.append(obj)
            states[obj] = FETCHING
            del queued[obj]
            fetching[obj] = peer
            size += object_bytes(rule_name, obj)
            full = len(items) >= max_items or (
                bool(max_bytes) and size >= max_bytes)
        if index < count:
            # Request full (S7): the rest is only filtered, as the loop
            # would (queued entries kept in order, the others dropped).
            keep.extend([entry for entry in lst[index:]
                         if states[entry[1]] == QUEUED])
        if keep:
            rs.by_peer[node][peer] = keep
        else:
            del rs.by_peer[node][peer]
        if not items:
            # Idle with announcements still on their way: ask at the
            # earliest arrival (else nothing would wake this peer up).
            later = [entry[0] for entry in keep if entry[0] > now]
            if later:
                self._kick_at(rs, node, peer, min(later))
            return
        requests = rs.requests[node]
        idle = not any(request.live for request in requests.values())
        requests[peer] = _Request(items, now)
        req_bytes = REQUEST_OVERHEAD_BYTES + \
            REQUEST_BYTES_PER_HASH * len(items)
        rs.c["requests"][node] += 1
        rs.c["requested"][node] += len(items)
        rs.c["req_bytes"][node] += req_bytes
        self.links.control(node, peer, rs.kind_req, req_bytes,
                           self._on_request, (rs.index, node, peer, items))
        if idle:
            self._arm_timeout(rs, node, now + rule.timeout_ms)

    def _arm_timeout(self, rs, node, due):
        current = rs.timeout_due[node]
        if current is not None and current <= due:
            return
        rs.timeout_due[node] = due
        rs.timeout_version[node] += 1
        self.ctx.at(due, EV_TIMEOUT, (rs.index, node,
                                      rs.timeout_version[node]))

    def _on_request(self, payload):
        """A request from `node` reaches `peer`: serve what it holds."""
        index, node, peer, items = payload
        rs = self.order[index]
        rule = rs.rule
        states = rs.state[peer]
        object_bytes = self.ctx.hooks.object_bytes
        soft = rule.response_soft_bytes
        served = []
        size = 0
        for obj in items:
            if soft and size >= soft:
                break
            if obj < len(states) and states[obj] == HELD:
                served.append(obj)
                size += object_bytes(rule.name, obj)
        now = self.engine.now
        if served and rs.budget is not None:
            ready = _budget_ready(rs.budget, peer, node, now, size)
            if ready > now:
                # Spent: answer empty (PR :68), say when to come back.
                rs.c["budget_empty"][peer] += 1
                self.links.control(peer, node, rs.kind_body,
                                   REQUEST_OVERHEAD_BYTES, self._on_response,
                                   (index, node, peer, items, (), 0, ready))
                return
        rs.c["served"][peer] += len(served)
        rs.c["missing"][peer] += len(items) - len(served)
        args = (index, node, peer, items, served, size, None)
        if not served:
            self.links.control(peer, node, rs.kind_body,
                               REQUEST_OVERHEAD_BYTES, self._on_response,
                               args)
            return
        if rs.budget is not None:
            ready = rs.budget.reserve(peer, node, now, size)
            self.links.send_at(ready, peer, node, LANE_EL, rs.kind_body,
                               size, self._on_response, args)
        else:
            self.links.send(peer, node, LANE_EL, rs.kind_body, size,
                            self._on_response, args)

    def _on_response(self, payload):
        index, node, peer, items, served, size, retry_at = payload
        rs = self.order[index]
        request = rs.requests[node].pop(peer, None)
        live = request is not None and request.live
        if request is not None and not request.live:
            rs.c["late"][node] += 1
        states = rs.state[node]
        hooks = self.ctx.hooks
        rule_name = rs.rule.name
        object_bytes = hooks.object_bytes
        fetching = rs.fetching[node]
        queued = rs.queued[node]
        delivered = {}
        for obj in served:
            delivered[obj] = True
            state = states[obj]
            if state <= FETCHING:
                # Also a late answer for a forgotten hash: geth's Enqueue
                # adds whatever arrives (tx_fetcher.go:361-420).
                states[obj] = PROCESSING
                fetching.pop(obj, None)
                queued.pop(obj, None)
                rs.c["fetched"][node] += 1
                self._mark_known(rs, node, obj, peer, self.engine.now)
                hooks.el_body_received(node, rule_name, obj, peer)
            else:
                rs.c["dup_bodies"][node] += 1
                rs.c["dup_bytes"][node] += object_bytes(rule_name, obj)
        requeue = []
        if live:
            cutoff = len(items)
            if retry_at is None:
                for position, obj in enumerate(items):
                    if obj in delivered:
                        cutoff = position
            for position, obj in enumerate(items):
                if obj in delivered:
                    continue
                if states[obj] == FETCHING and fetching.get(obj) == peer:
                    del fetching[obj]
                    states[obj] = QUEUED
                    queued[obj] = None
                    if retry_at is None and position < cutoff:
                        self._forget_announcer(rs, node, obj, peer)
                    requeue.append(obj)
        now = self.engine.now
        if retry_at is not None:
            # Budget spent at the peer: other announcers first, this one
            # again once its budget would allow.
            if requeue:
                self._requeue(rs, node, requeue, now, exclude=peer)
            retry_at = max(retry_at, now)
            rs.blocked[node][peer] = retry_at
            if peer not in rs.requests[node]:
                # retry_at was computed at the responder when it served;
                # the empty answer arrives a latency later (S3b fix).
                self._kick_at(rs, node, peer, retry_at)
            return
        if requeue:
            self._requeue(rs, node, requeue, now)
        if peer not in rs.requests[node]:
            self._request(rs, node, peer)

    def _forget_announcer(self, rs, node, obj, peer):
        entries = rs.announcers[node].get(obj)
        if entries:
            rs.announcers[node][obj] = [entry for entry in entries
                                        if entry[1] != peer]

    def _timeout(self, payload):
        index, node, version = payload
        rs = self.order[index]
        if version != rs.timeout_version[node]:
            return
        rs.timeout_due[node] = None
        now = self.engine.now
        rule = rs.rule
        slack = min(rule.gather_ms, rule.timeout_ms)
        states = rs.state[node]
        fetching = rs.fetching[node]
        queued = rs.queued[node]
        requeue = []
        earliest = None
        for peer, request in rs.requests[node].items():
            if not request.live:
                continue
            # Same float expression as the armed due time (sent +
            # timeout), so a request due now always expires now.
            if request.sent + rule.timeout_ms <= now + slack:
                request.live = False
                rs.c["timeouts"][node] += 1
                for obj in request.items:
                    if states[obj] == FETCHING and fetching.get(obj) == peer:
                        del fetching[obj]
                        states[obj] = QUEUED
                        queued[obj] = None
                        self._forget_announcer(rs, node, obj, peer)
                        requeue.append(obj)
            elif earliest is None or request.sent < earliest:
                earliest = request.sent
        if requeue:
            self._requeue(rs, node, requeue, now)
        if earliest is not None:
            self._arm_timeout(rs, node, earliest + rule.timeout_ms)

    def _kick(self, payload):
        index, node, peer = payload
        rs = self.order[index]
        due = rs.kick_due[node].get(peer)
        if due is not None and due <= self.engine.now:
            del rs.kick_due[node][peer]
        if peer not in rs.requests[node]:
            self._request(rs, node, peer)
        lst = rs.by_peer[node].get(peer)
        if lst and peer not in rs.requests[node]:
            # Entries still on their way: kick again at the earliest.
            now = self.engine.now
            later = [entry[0] for entry in lst if entry[0] > now]
            if later and peer not in rs.kick_due[node]:
                rs.kick_due[node][peer] = min(later)
                self.ctx.at(min(later), EV_KICK, (index, node, peer))

    def _on_push(self, payload):
        """A pushed body reaches `node` from `src`."""
        index, node, src, obj, size = payload
        rs = self.order[index]
        states = rs.state[node]
        if obj >= len(states):
            _grow(states, obj)
        state = states[obj]
        now = self.engine.now
        if state <= FETCHING:
            states[obj] = PROCESSING
            rs.queued[node].pop(obj, None)
            # A request in flight for it now returns a duplicate (geth
            # "stolen" delivery, :858-866): keep the fetching record so the
            # response is not re-queued.
            self._mark_known(rs, node, obj, src, now)
            rs.c["pushed_in"][node] += 1
            self.ctx.hooks.el_body_received(node, rs.rule.name, obj, src)
        else:
            rs.c["dup_bodies"][node] += 1
            rs.c["dup_bytes"][node] += size


def _budget_ready(budget, node, peer, now, size):
    """When `node` could serve `size` bytes to `peer` under `budget`
    without debt (read-only view of links.ServingBudget's token buckets).
    A response larger than a bucket's burst is never 'ready': it returns
    `now` and the caller reserves it with debt (served late)."""
    ready = now
    for bucket, rate, burst in (
            (budget.nodes.get(node), budget.node_rate, budget.node_burst),
            (budget.pairs.get((node, peer)), budget.peer_rate,
             budget.peer_burst)):
        if size > burst:
            return now
        if bucket is None:
            continue
        tokens = bucket.tokens
        if now > bucket.last:
            tokens = min(burst, tokens + rate * (now - bucket.last))
        # Relative slack: at the computed refill time float rounding can
        # leave the bucket a few ulps short, which would retry forever.
        if tokens < size * (1.0 - BUDGET_SLACK):
            ready = max(ready, now + (size - tokens) / rate)
    return ready


def _add_entry(entries, arrival, peer):
    """Append an (arrival, peer) announcer entry, keeping the earliest
    arrival first (the rest is unordered)."""
    if entries and arrival < entries[0][0]:
        entries.append(entries[0])
        entries[0] = (arrival, peer)
    else:
        entries.append((arrival, peer))


def _grow(buffer, index):
    """Extend a state bytearray so that `index` is valid."""
    missing = index + 1 - len(buffer)
    if missing > 0:
        buffer.extend(bytes(max(missing, _GROW)))

"""Links of one v3 run: per-node uplink with two GPS lanes, downlink FIFO,
control messages, cancellation and serving budgets (arch.md 3.3).

Uplink. Each node has two FIFO lanes, EL and CL, sharing its uplink rate by
generalised processor sharing: while both lanes hold a message, lane l is
served at `up * w_l / (w_el + w_cl)`; a lone backlogged lane gets the whole
uplink. Only the head of a lane is in service. Per node there is one pending
completion event carrying a version; `send` settles the progress of the
active heads since the last change, appends, and reschedules. A completion
whose version is stale returns at once (lazy cancellation).

Downlink. Computed without events, as a list of busy intervals per node.
A message whose uplink transmission started at `t_start` and ended at
`t_done` has its first byte at the receiver at `t_start + lat`; it occupies
the downlink for `size / down[v]` in the earliest idle gap starting at or
after that first byte, and its last byte is the gap's end `last`. It is
delivered at

    arrival = max(t_done + lat, last)

The first term is a fast downlink (bytes stream through, cut-through); the
second a slow or busy one. Latency is not downlink time, and a message is
placed by when its bytes reach the receiver, not by when it was computed: a
near peer's message can use the gap before a far peer's message arrives.
(arch.md 3.3 wrote `max(t_done + lat, down_free[v] + size/down[v])`, a FIFO
in computation order: with a stale `down_free` a large message arrives
faster than the downlink can carry it, and with a fresh one a far peer's
latency blocks a near peer.) Intervals ending before `now` are dropped, so
the list holds only the next few hundred ms of bookings.

Background. The residual background load (`bandwidth.background_load.
recommended_background_mbps`, by datacentre/home) is a constant-rate flow on
both directions: it takes its rate off the uplink and the downlink (never
below `MIN_RATE_SHARE` of the link) and is counted as bytes = rate x time.
That is exact for a constant-rate flow and costs no events (arch.md 3.3 had
100 ms chunks; see notes/phase4/build-s0s1.md). EL fluid ECDSA traffic (S2c)
uses `load()`: a queued entry that consumes uplink time and delivers nothing.

Control messages (announcements' replies, requests, IDONTWANT) are latency
only: bytes counted at both ends, no queueing (arch.md 3.4, 3.5).

Cancellation (IDONTWANT): `cancel(node, lane, predicate)` zeroes queued
entries that match and are not yet in service; the head is never cancelled
(a started stream finishes).

Serving budgets (eth/73, spec.md B13): `ServingBudget.reserve(node, peer,
now, size)` returns when a response of `size` bytes may enter the lane under
a per-node and a per-(node, peer) token bucket; `send_at(t, ...)` enqueues
then.

Ideal mode (net.mode=ideal): zero latency, unmetered: a message is delivered
by one event at the send time.

Events per message: one completion (plus a stale one when a lane turns
active while the other is busy) and one delivery. Appending behind a busy
head reschedules nothing.
"""

from bisect import bisect_right
from operator import itemgetter

from starksim.v3.state import LANE_CL, LANE_EL
from starksim.v3.topology import MBIT_TO_BYTES_PER_MS

EV_UP_DONE = "links.up_done"
EV_DELIVER = "links.deliver"
EV_ENQUEUE = "links.enqueue"
DONE_EPSILON_BYTES = 1e-6     # [A] numerical: a head with less left is done
MIN_RATE_SHARE = 0.05         # [A] background never takes more than 95 %
COMPACT_AFTER = 64            # [A] list compaction threshold, performance only

# Entry layout (a list, mutated in place).
_REMAINING, _SIZE, _KIND, _DST, _ON_DELIVER, _ARG, _START = range(7)  # [A] layout
_END = itemgetter(1)  # [A] end of a [start, end] busy interval


class TokenBucket:
    """Token bucket with debt: `reserve(now, size)` takes `size` tokens and
    returns when they are available (now, or when the debt is repaid)."""

    __slots__ = ("rate", "burst", "tokens", "last")

    def __init__(self, rate_bytes_per_ms, burst_bytes):
        self.rate = rate_bytes_per_ms
        self.burst = burst_bytes
        self.tokens = burst_bytes
        self.last = 0.0

    def reserve(self, now, size):
        if now > self.last:
            self.tokens = min(self.burst,
                              self.tokens + self.rate * (now - self.last))
            self.last = now
        self.tokens -= size
        if self.tokens >= 0.0:
            return now
        return now + (-self.tokens) / self.rate


class ServingBudget:
    """eth/73 serving budget: a bucket per node and one per (node, peer),
    each with one second of burst (spec.md B13: 32 MiB/s, 8 MiB/s)."""

    def __init__(self, node_bytes_per_s, peer_bytes_per_s):
        self.node_rate = node_bytes_per_s / 1000.0
        self.peer_rate = peer_bytes_per_s / 1000.0
        self.node_burst = float(node_bytes_per_s)
        self.peer_burst = float(peer_bytes_per_s)
        self.nodes = {}
        self.pairs = {}

    def reserve(self, node, peer, now, size):
        bucket = self.nodes.get(node)
        if bucket is None:
            bucket = TokenBucket(self.node_rate, self.node_burst)
            self.nodes[node] = bucket
        pair = self.pairs.get((node, peer))
        if pair is None:
            pair = TokenBucket(self.peer_rate, self.peer_burst)
            self.pairs[(node, peer)] = pair
        return max(bucket.reserve(now, size), pair.reserve(now, size))


class Links:
    """The uplinks and downlinks of every node of `topo`."""

    def __init__(self, ctx, topo, lane_weights=None, background_mbps=None):
        self.ctx = ctx
        self.engine = ctx.engine
        self.topo = topo
        self.latency = topo.latency
        self.ideal = topo.ideal
        n = topo.n_total
        self.n = n
        nodes = topo.nodes
        if lane_weights is None:
            lane_weights = (1.0, 1.0)
        self.weights = (float(lane_weights[0]), float(lane_weights[1]))
        if self.weights[0] <= 0.0 or self.weights[1] <= 0.0:
            raise ValueError("lane weights must be > 0")
        # Background: bytes per ms per node, both directions.
        self.bg_rate = [0.0] * n
        if background_mbps and not self.ideal:
            for node in range(n):
                key = "home" if nodes.home[node] else "datacentre"
                self.bg_rate[node] = (float(background_mbps[key]) *
                                      MBIT_TO_BYTES_PER_MS)
        self.up = [0.0] * n
        self.down = [0.0] * n
        self.bg_up = [0.0] * n
        self.bg_down = [0.0] * n
        for node in range(n):
            up = nodes.up_Bpms[node]
            down = nodes.down_Bpms[node]
            self.bg_up[node] = min(self.bg_rate[node],
                                   (1.0 - MIN_RATE_SHARE) * up)
            self.bg_down[node] = min(self.bg_rate[node],
                                     (1.0 - MIN_RATE_SHARE) * down)
            self.up[node] = up - self.bg_up[node]
            self.down[node] = down - self.bg_down[node]
        self.queues = [[[], []] for _ in range(n)]
        self.heads = [[0, 0] for _ in range(n)]
        self.queued = [[0.0, 0.0] for _ in range(n)]
        self.last = [0.0] * n
        self.version = [0] * n
        self.down_busy = [[] for _ in range(n)]   # sorted [start, end]
        self.lat_rows = [{} for _ in range(n)]    # dst -> latency (cache)
        counters = ctx.counters
        self.bytes_up_el = counters.array("links.bytes_up_el", n, 0)
        self.bytes_up_cl = counters.array("links.bytes_up_cl", n, 0)
        self.bytes_down = counters.array("links.bytes_down", n, 0)
        self.ctrl_bytes_up = counters.array("links.ctrl_bytes_up", n, 0)
        self.ctrl_bytes_down = counters.array("links.ctrl_bytes_down", n, 0)
        self.busy_el = counters.array("links.busy_ms_el", n, 0.0)
        self.busy_cl = counters.array("links.busy_ms_cl", n, 0.0)
        self.busy_up = counters.array("links.busy_ms_up", n, 0.0)
        self.queue_hwm_el = counters.array("links.queue_hwm_el", n, 0.0)
        self.queue_hwm_cl = counters.array("links.queue_hwm_cl", n, 0.0)
        self.cancelled = counters.array("links.cancelled_bytes", n, 0)
        counters.scalar("links.messages", 0)
        counters.scalar("links.stale_events", 0)
        self.kind_bytes = {}       # kind -> bytes sent (uplink completions)
        self.kind_cancelled = {}   # kind -> bytes cancelled before sending
        ctx.on(EV_UP_DONE, self._up_done)
        ctx.on(EV_DELIVER, _deliver)
        ctx.on(EV_ENQUEUE, self._enqueue)

    # -- public interface
    def send(self, src, dst, lane, kind, size, on_deliver, arg):
        """Queue `size` bytes from src to dst on `lane`; `on_deliver(arg)`
        runs when the last byte is at dst. With dst None (no receiver) it
        runs when the last byte has left src's uplink."""
        engine = self.engine
        self.ctx.counters.scalars["links.messages"] += 1
        if self.ideal:
            self._count_up(src, lane, kind, size)
            if dst is not None:
                self.bytes_down[dst] += size
            if on_deliver is not None:
                engine.schedule_at(engine.now, EV_DELIVER, (on_deliver, arg))
            return
        lane_queue = self.queues[src][lane]
        idle = self.heads[src][lane] >= len(lane_queue)
        if idle:
            # The active set changes: settle progress at the old rates.
            self._settle(src)
        entry = [float(size), size, kind, dst, on_deliver, arg,
                 engine.now if idle else -1.0]
        lane_queue.append(entry)
        queued = self.queued[src]
        queued[lane] += size
        if lane == LANE_EL:
            if queued[lane] > self.queue_hwm_el[src]:
                self.queue_hwm_el[src] = queued[lane]
        elif queued[lane] > self.queue_hwm_cl[src]:
            self.queue_hwm_cl[src] = queued[lane]
        if idle:
            # Appending behind a busy head changes no rate and no
            # completion time, so only a newly active lane reschedules.
            self._reschedule(src)

    def load(self, node, lane, kind, size):
        """Consume `size` bytes of `node`'s uplink on `lane`, delivering
        nothing (fluid background traffic)."""
        self.send(node, None, lane, kind, size, None, None)

    def send_at(self, t, src, dst, lane, kind, size, on_deliver, arg):
        """`send` at time t >= now (one event when t > now)."""
        if t <= self.engine.now:
            self.send(src, dst, lane, kind, size, on_deliver, arg)
        else:
            self.engine.schedule_at(t, EV_ENQUEUE,
                                    (src, dst, lane, kind, size, on_deliver,
                                     arg))

    def control(self, src, dst, kind, size, on_deliver, arg):
        """A control message: latency only, bytes counted at both ends."""
        self.ctrl_bytes_up[src] += size
        self.ctrl_bytes_down[dst] += size
        self.kind_bytes[kind] = self.kind_bytes.get(kind, 0) + size
        engine = self.engine
        row = self.lat_rows[src]
        latency = row.get(dst)
        if latency is None:
            latency = self.latency(src, dst)
            row[dst] = latency
        engine.schedule_at(engine.now + latency, EV_DELIVER,
                           (on_deliver, arg))

    def cancel(self, node, lane, predicate):
        """Drop queued, not-started entries of `node`'s lane for which
        predicate(kind, dst, arg) is true. Returns the bytes dropped."""
        lane_queue = self.queues[node][lane]
        head = self.heads[node][lane]
        dropped = 0
        for index in range(head + 1, len(lane_queue)):
            entry = lane_queue[index]
            if entry[_ON_DELIVER] is None and entry[_DST] is None:
                continue
            if entry[_REMAINING] > 0.0 and predicate(entry[_KIND],
                                                     entry[_DST],
                                                     entry[_ARG]):
                size = entry[_SIZE]
                dropped += size
                self.kind_cancelled[entry[_KIND]] = (
                    self.kind_cancelled.get(entry[_KIND], 0) + size)
                self.queued[node][lane] -= size
                entry[_REMAINING] = 0.0
                entry[_ON_DELIVER] = None
                entry[_DST] = None
                entry[_SIZE] = 0
        self.cancelled[node] += dropped
        return dropped

    def backlog(self, node, lane):
        """Bytes queued on a lane, counting the head in service whole."""
        return self.queued[node][lane]

    def settle_all(self):
        """Bring every node's busy and progress counters to `now`."""
        for node in range(self.n):
            self._settle(node)

    def background_bytes(self, node, t0, t1):
        """Background bytes (uplink, downlink) of a node over [t0, t1]."""
        span = max(0.0, t1 - t0)
        return self.bg_up[node] * span, self.bg_down[node] * span

    # -- internals
    def _count_up(self, node, lane, kind, size):
        if lane == LANE_EL:
            self.bytes_up_el[node] += size
        else:
            self.bytes_up_cl[node] += size
        self.kind_bytes[kind] = self.kind_bytes.get(kind, 0) + size

    def _settle(self, node):
        now = self.engine.now
        elapsed = now - self.last[node]
        if elapsed <= 0.0:
            return
        self.last[node] = now
        queues = self.queues[node]
        heads = self.heads[node]
        el_active = heads[LANE_EL] < len(queues[LANE_EL])
        cl_active = heads[LANE_CL] < len(queues[LANE_CL])
        if not el_active and not cl_active:
            return
        rate = self.up[node]
        self.busy_up[node] += elapsed
        if el_active and cl_active:
            total = self.weights[0] + self.weights[1]
            queues[LANE_EL][heads[LANE_EL]][_REMAINING] -= (
                rate * self.weights[0] / total * elapsed)
            queues[LANE_CL][heads[LANE_CL]][_REMAINING] -= (
                rate * self.weights[1] / total * elapsed)
            self.busy_el[node] += elapsed
            self.busy_cl[node] += elapsed
        elif el_active:
            queues[LANE_EL][heads[LANE_EL]][_REMAINING] -= rate * elapsed
            self.busy_el[node] += elapsed
        else:
            queues[LANE_CL][heads[LANE_CL]][_REMAINING] -= rate * elapsed
            self.busy_cl[node] += elapsed

    def _reschedule(self, node):
        queues = self.queues[node]
        heads = self.heads[node]
        self.version[node] += 1
        el_active = heads[LANE_EL] < len(queues[LANE_EL])
        cl_active = heads[LANE_CL] < len(queues[LANE_CL])
        if not el_active and not cl_active:
            return
        rate = self.up[node]
        if el_active and cl_active:
            total = self.weights[0] + self.weights[1]
            el_left = max(queues[LANE_EL][heads[LANE_EL]][_REMAINING], 0.0)
            cl_left = max(queues[LANE_CL][heads[LANE_CL]][_REMAINING], 0.0)
            wait = min(el_left / (rate * self.weights[0] / total),
                       cl_left / (rate * self.weights[1] / total))
        elif el_active:
            wait = max(queues[LANE_EL][heads[LANE_EL]][_REMAINING], 0.0) / rate
        else:
            wait = max(queues[LANE_CL][heads[LANE_CL]][_REMAINING], 0.0) / rate
        engine = self.engine
        engine.schedule_at(engine.now + wait, EV_UP_DONE,
                           (node, self.version[node]))

    def _lane_rates(self, node):
        """Service rate of each lane's head now (0 for an idle lane)."""
        queues = self.queues[node]
        heads = self.heads[node]
        el_active = heads[LANE_EL] < len(queues[LANE_EL])
        cl_active = heads[LANE_CL] < len(queues[LANE_CL])
        rate = self.up[node]
        if el_active and cl_active:
            total = self.weights[0] + self.weights[1]
            return (rate * self.weights[0] / total,
                    rate * self.weights[1] / total)
        return (rate if el_active else 0.0, rate if cl_active else 0.0)

    def _up_done(self, payload):
        node, version = payload
        if version != self.version[node]:
            self.ctx.counters.scalars["links.stale_events"] += 1
            return
        self._settle(node)
        engine = self.engine
        now = engine.now
        queues = self.queues[node]
        heads = self.heads[node]
        rates = self._lane_rates(node)
        for lane in (LANE_EL, LANE_CL):
            lane_queue = queues[lane]
            head = heads[lane]
            lane_rate = rates[lane]
            while head < len(lane_queue) and \
                    _finished(lane_queue[head][_REMAINING], lane_rate, now):
                entry = lane_queue[head]
                head += 1
                size = entry[_SIZE]
                if size:
                    self.queued[node][lane] -= size
                    self._count_up(node, lane, entry[_KIND], size)
                dst = entry[_DST]
                if dst is not None:
                    self._downlink(node, dst, entry, now)
                elif entry[_ON_DELIVER] is not None:
                    # A destination-less send with a callback (e.g. one
                    # announcement chunk): call back when its last byte
                    # leaves the uplink (inbox S2a item 1).
                    engine.schedule_at(now, EV_DELIVER,
                                       (entry[_ON_DELIVER], entry[_ARG]))
                if head < len(lane_queue):
                    lane_queue[head][_START] = now
            if head > COMPACT_AFTER and head * 2 > len(lane_queue):
                del lane_queue[:head]
                head = 0
            heads[lane] = head
        self._reschedule(node)

    def _downlink(self, src, dst, entry, now):
        size = entry[_SIZE]
        row = self.lat_rows[src]
        latency = row.get(dst)
        if latency is None:
            latency = self.latency(src, dst)
            row[dst] = latency
        last_byte = _book(self.down_busy[dst], entry[_START] + latency,
                          size / self.down[dst], now)
        arrival = last_byte
        if now + latency > arrival:
            arrival = now + latency
        self.bytes_down[dst] += size
        on_deliver = entry[_ON_DELIVER]
        if on_deliver is not None:
            self.engine.schedule_at(arrival, EV_DELIVER,
                                    (on_deliver, entry[_ARG]))

    def _enqueue(self, payload):
        src, dst, lane, kind, size, on_deliver, arg = payload
        self.send(src, dst, lane, kind, size, on_deliver, arg)


def _book(busy, earliest, duration, now):
    """Book `duration` on a busy-interval list (sorted, disjoint [start,
    end] pairs) in the first gap at or after `earliest`; returns the end.
    Intervals that ended by `now` are dropped first."""
    if busy and busy[0][1] <= now:
        del busy[:bisect_right(busy, now, key=_END)]
    start = earliest
    # Intervals ending by `start` (a prefix: sorted, disjoint) are skipped.
    index = bisect_right(busy, start, key=_END) if busy else 0
    while index < len(busy):
        begin, end = busy[index]
        if end <= start:
            index += 1
            continue
        if begin >= start + duration:
            break
        start = end
        index += 1
    end = start + duration
    # Merge with touching neighbours to keep the list short.
    if index > 0 and busy[index - 1][1] == start:
        busy[index - 1][1] = end
        if index < len(busy) and busy[index][0] == end:
            busy[index - 1][1] = busy[index][1]
            del busy[index]
    elif index < len(busy) and busy[index][0] == end:
        busy[index][0] = start
    else:
        busy.insert(index, [start, end])
    return end


def _finished(remaining, rate, now):
    """A head is done when what is left is below the numerical floor, or
    so small that the time to send it does not advance the clock: with an
    absolute floor alone, rate x ulp(now) can exceed the floor late in a
    run, and the completion event would be rescheduled at `now` forever."""
    if remaining <= DONE_EPSILON_BYTES:
        return True
    return rate > 0.0 and now + remaining / rate <= now


def _deliver(payload):
    on_deliver, arg = payload
    if on_deliver is not None:
        on_deliver(arg)


def busy_fraction(before, after, name, node, t0, t1):
    """Busy share of a lane counter (`links.busy_ms_el|cl|up`) between two
    `Counters.snapshot()`s taken after `Links.settle_all()` at t0 and t1."""
    span = t1 - t0
    if span <= 0.0:
        return 0.0
    used = after["arrays"][name][node] - before["arrays"][name][node]
    return min(1.0, max(0.0, used / span))

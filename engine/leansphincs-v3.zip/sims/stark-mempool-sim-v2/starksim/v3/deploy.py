"""Deployment plug-ins: the rule set of one deployment over the shared engine.

This file freezes the interface the two halves of stage S3 implement in
parallel (arch.md 3.9, section 4 row S3): `slot.py` + `deploy_8141.py` in one
worktree, `deploy_agg.py` in the other. Both import only this module's
names; neither edits it except to append (INTERFACES.md).

    registry id   class                                    file (stage)
    today         starksim.v3.deploy_8141:DeployToday      S3a
    8141          starksim.v3.deploy_8141:Deploy8141       S3a
    8288          starksim.v3.deploy_agg:Deploy8288        S3b
    leanpcs       starksim.v3.deploy_agg:DeployLeanPCS     S3b

Who calls what (the slot clock, S3a, is the only caller of `build` and
`import_ms`; demand, S2c, calls `tx_shape` through `shape_of`; the gossip
hooks of state.HOOK_NAMES reach `admit` and `on_admit`):

    demand    -> deploy.tx_shape(kind, k)              at birth
    demand    -> ctx.hooks.tx_born(tx)  -> deploy.submit(tx)
    elgossip  -> ctx.hooks.el_body_received(node, rule, obj, src)
                 -> deploy.admit(node, rule, obj) -> Admission
                 -> (after Admission.cpu_ms on mempool.cpu) deploy.on_admit
    slot      -> deploy.on_interval(node)              agg: every interval
    slot      -> deploy.build(builder, slot, freeze_ms) -> Payload
    slot      -> deploy.import_ms(node, payload)        on payload receipt
    runner    -> deploy.analytic_bounds()               saturation and limits

Call order on each canonical payload (S3a shared patch, inbox S2c): the slot
clock first calls `demand.background_included(slot, payload.bg_gas)`, then
`demand.on_payload(payload.gas_used, gas_limit)`, then
`ctx.hooks.payload_canonical(slot, payload)` (pools drop the txs, gossip
`drop`s them). The builder ranks PQ txs and the fluid background bins of
`demand.background_offer(slot, freeze_ms)` together by effective tip per
gas (kind-blind) and takes a bin fractionally.
"""

import importlib
from collections import namedtuple

# Bytes, gas and verification cost of one transaction of a kind.
# `status`: the evidence tag of the formula's constants (arch.md 3.9), e.g.
# "E" for spec text, "Mo on E" for campaign arithmetic over spec constants.
TxShape = namedtuple("TxShape", ("bytes_wire", "bytes_chain", "gas", "deps",
                                 "verify_gas", "status"))

ACCEPT = "accept"
REFUSE = "refuse"
PRIVATE = "private"    # refused by the public pool, sent direct to builders

# Admission verdict: ACCEPT | REFUSE | PRIVATE, a reason for REFUSE/PRIVATE
# (counter key, e.g. "rule6", "oversize", "underpriced"), and the CPU time
# the check costs at this node (ms, before scale.cpu).
Admission = namedtuple("Admission", ("verdict", "reason", "cpu_ms"))

# One execution payload as built. `txs` is the tx-id list in block order,
# `cover` the same set as a bitset; `binding` is what stopped the packer
# ("gas", "bytes", "deps", "proof_deadline", "pool" ...); `bg_*` are the
# fluid ECDSA background aggregates packed; `proof_bytes` 0 for 8141.
Payload = namedtuple("Payload", ("slot", "builder", "txs", "cover",
                                 "gas_used", "bytes", "deps", "proof_bytes",
                                 "binding", "bg_count", "bg_gas", "bg_bytes",
                                 "ready_at"))

PBS_OF = {"today": "mevboost", "8141": "epbs", "8288": "epbs",
          "leanpcs": "epbs"}

REGISTRY = {
    "today": "starksim.v3.deploy_8141:DeployToday",
    "8141": "starksim.v3.deploy_8141:Deploy8141",
    "8288": "starksim.v3.deploy_agg:Deploy8288",
    "leanpcs": "starksim.v3.deploy_agg:DeployLeanPCS",
}


class Deployment:
    """Base class. Subclasses set `id` and implement every method."""

    id = None

    def __init__(self, ctx):
        self.ctx = ctx
        self.spec = ctx.spec
        self.params = ctx.params
        self.pbs = ctx.spec.chain.pbs or PBS_OF[ctx.spec.deployment]

    # -- shapes and bounds (pure; usable without a running engine)
    def tx_shape(self, kind, k):
        """TxShape of a tx of `kind` (state.KIND_*) carrying k signatures of
        the run's candidate (spec.sig_bytes, spec.perms)."""
        raise NotImplementedError

    def analytic_bounds(self):
        """{"gas": tx/s, "bytes": tx/s, "dep_cap": tx/s, "prover": tx/s, ...}
        for the run's spec on an ideal network (arch.md 5.1); absent keys
        do not bind in this deployment."""
        raise NotImplementedError

    # -- mempool side
    def submit(self, tx):
        """A newly born tx enters the network at ctx.txs.entry_node[tx]
        (public) or at the builders (private). Wired to hooks.tx_born."""
        raise NotImplementedError

    def admit(self, node, rule_name, obj):
        """Admission check of a received gossip object -> Admission."""
        raise NotImplementedError

    def on_admit(self, node, rule_name, obj):
        """After the admission CPU: pool it, gossip it (8141: elgossip.admit;
        agg: add to raw/aggregate state)."""
        raise NotImplementedError

    def on_interval(self, node):
        """Aggregation deployments: plan the node's proof job for this
        AGGREGATION_INTERVAL (prover.plan_interval) and, when it completes,
        announce the new wrapper. 8141/today: never called."""
        raise NotImplementedError

    # -- block side
    def build(self, builder, slot, freeze_ms):
        """The builder's payload for `slot` from its own view frozen at
        `freeze_ms` -> Payload."""
        raise NotImplementedError

    def import_ms(self, node, payload):
        """CPU time to import (execute and verify) `payload` at `node`."""
        raise NotImplementedError


def deployment_class(deployment_id):
    """The plug-in class of a deployment id (imported on first use, so the
    registry can name stage-S3 modules before they exist)."""
    if deployment_id not in REGISTRY:
        raise ValueError(f"unknown deployment {deployment_id!r}; known: "
                         f"{', '.join(REGISTRY)}")
    module_name, class_name = REGISTRY[deployment_id].split(":")
    try:
        module = importlib.import_module(module_name)
    except ModuleNotFoundError as error:
        raise NotImplementedError(
            f"deployment {deployment_id} is built in stage S3 "
            f"({module_name} not present yet)") from error
    return getattr(module, class_name)

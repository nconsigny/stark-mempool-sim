"""Exact weighted sums over bitset members without walking the members.
Stage S7 (performance only; no model content).

`WeightSum(weight)` answers `sum(weight(i) for i in members(cover))` for a
bitset `cover` of tx ids. Each index's weight is read once, at the first
query whose cover contains it, and must not change afterwards (true of the
tx columns it is used on: deps, wrapper bytes, signatures are fixed when a
tx first enters a wrapper). Indices are grouped by weight value into one
bitset per value, so a query costs one AND and one popcount per distinct
value (a handful per run) instead of a Python loop over the members.
With more than MAX_VALUES distinct values it falls back to the member walk
(same result).
"""

from starksim.v3.state import members

MAX_VALUES = 32   # [A] perf only: beyond this the member walk is used


class WeightSum:
    __slots__ = ("weight", "seen", "masks", "overflow")

    def __init__(self, weight):
        self.weight = weight
        self.seen = 0
        self.masks = {}
        self.overflow = False

    def _register(self, new):
        weight = self.weight
        groups = {}
        for index in members(new):
            value = weight(index)
            group = groups.get(value)
            if group is None:
                groups[value] = [index]
            else:
                group.append(index)
        masks = self.masks
        for value, group in groups.items():
            mask = 0
            for index in group:
                mask |= 1 << index
            masks[value] = masks.get(value, 0) | mask
        self.seen |= new
        if len(masks) > MAX_VALUES:
            self.overflow = True

    def sum(self, cover):
        if not cover:
            return 0
        if self.overflow:
            weight = self.weight
            return sum(weight(index) for index in members(cover))
        known = cover & self.seen
        if known != cover:
            self._register(cover ^ known)
            if self.overflow:
                return self.sum(cover)
        total = 0
        for value, mask in self.masks.items():
            if value:
                total += value * (cover & mask).bit_count()
        return total


def bits_of(indices):
    """Bitset of a non-empty collection of non-negative ints, built in one
    pass over a byte buffer (`state.bits` ORs one shifted int per index)."""
    top = max(indices)
    buffer = bytearray(top // 8 + 1)    # [E] bits per byte
    for index in indices:
        buffer[index >> 3] |= 1 << (index & 7)   # [E] byte, bit in byte
    return int.from_bytes(buffer, "little")


def bits_span(indices):
    """`bits_of(indices)` built over the span [min, max] only and shifted
    into place (S7b): indices of recent txs sit near the top of a long
    bitset, so the buffer is short."""
    low = min(indices)
    top = max(indices)
    if top - low < 64:          # [A] perf only: one small int, no buffer
        result = 0
        for index in indices:
            result |= 1 << (index - low)
        return result << low
    buffer = bytearray((top - low) // 8 + 1)    # [E] bits per byte
    for index in indices:
        index -= low
        buffer[index >> 3] |= 1 << (index & 7)   # [E] byte, bit in byte
    return int.from_bytes(buffer, "little") << low

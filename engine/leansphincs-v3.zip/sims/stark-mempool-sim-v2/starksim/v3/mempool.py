"""Per-node mempools and the per-node verification CPU.

Stage S2a (arch.md 3.8, STAGES.md S2a).

Pool (geth core/txpool/legacypool/legacypool.go @ 4721b2cc, copy under
data/phase4/sources/clients/):

- Capacity in 32 KiB slots: a tx takes ceil(bytes / txSlotSize) slots
  (:1801-1802). The pool is full when `slots + slots(tx) > GlobalSlots +
  GlobalQueue` = 6,144 (:702, params `pool_full_threshold`). Every simulated
  tx is executable (one pending tx per sender), so `truncatePending`
  (:1431-1508, trims only accounts above AccountSlots = 16) never acts and
  the whole 6,144 slots hold pending txs. STAGES.md wrote GlobalSlots
  (5,120) x txSlotSize; the threshold geth checks is 6,144.
- Order: the effective tip at a base fee, `min(tip, fee_cap - base_fee)`.
  Txs sit in 32 buckets by the bit length of the effective tip in wei
  (bucket 0: below 64 wei, incl. fee caps under the base fee; bucket 31:
  2^36 wei = 68.7 gwei and up), i.e. a factor 2 per bucket. The buckets
  only find the floor fast: inside the lowest non-empty bucket the victim
  is the exact cheapest (effective tip, then the earliest arrival at this
  node), as geth's heap.
- Full pool: an arrival whose effective tip is <= the cheapest held tx's
  is refused as UNDERPRICED (geth `Underpriced`: "as cheap as" the
  cheapest is refused). Otherwise the cheapest txs are evicted until it
  fits (geth `priced.Discard`). Buckets are keyed at one base fee per node
  and re-keyed (keeping arrival order) when an eviction runs at another
  base fee (geth re-heaps on a base-fee change, `SetBaseFee`).
- Not modelled: the urgent/floating 4:1 heap split of geth's `pricedList`
  (eviction uses the effective tip only), the replacement throttle
  (`changesSinceReorg > GlobalSlots/4`), local-tx exemptions, nonce gaps,
  the 3 h lifetime of queued txs. Sizes above `txMaxSize` (128 KiB) are
  refused as OVERSIZED (ErrOversizedData, validation.go).

Each bucket maps tx -> (effective tip at the node's keying base fee,
arrival sequence at the node). Membership is one byte per (node, tx)
(bucket + 1, 0 = not held); `pool`
builds the bitset on demand. Fee order is by the effective tip at a base
fee, ties by lower tx id (older first).

CPU: per node `cores` parallel FIFO slots; a job starts on the earliest free
core at or after now, runs `duration / spec.scale.cpu`, and fires one event
at its end. Verification jobs and import jobs share the cores in the order
they are submitted (arch.md 3.8: proving runs on its own resource).
"""

import heapq

from starksim.v3 import params as P

ADDED = "added"
DUPLICATE = "duplicate"
UNDERPRICED = "underpriced"
OVERSIZED = "oversized"

# Event kinds S2a registers (owner prefix "mempool."):
EV_CPU_DONE = "mempool.cpu_done"

N_BUCKETS = 32          # [A] arch.md 3.8: 32 log-spaced fee buckets
BUCKET_SHIFT = 6        # [A] bucket = bit_length(eff tip wei) - 6: 64 wei .. 2^37 wei
_GROW = 4096            # [A] performance only: bytearray growth step

P.register_bindings({
    "pool_full_slots": (
        P.NET, ("el_gossip", "geth.legacypool", "pool_full_threshold"), None),
    "pool_slot_bytes": (
        P.NET, ("el_gossip", "geth.legacypool", "txSlotSize"), None),
    "pool_tx_max_bytes": (
        P.NET, ("el_gossip", "geth.legacypool", "txMaxSize"), None),
    "compute_node_classes": (
        P.NET, ("compute", "node_classes"), None),
    "evm_gas_per_s_per_core": (
        P.NET, ("compute", "evm_gas_per_s_per_core"), None),
})


def node_cpu(ctx):
    """Per-node (verify cores, EVM gas per ms per core) from the params'
    `compute.node_classes` (by uplink class; builders: the datacentre
    class) and `compute.evm_gas_per_s_per_core` (by tier). Both leaves are
    [Mo] assumptions of the parameter researcher (EIP-7870 tiers, the
    26224 DoS benchmark)."""
    classes = ctx.params.value("compute_node_classes")
    tiers = ctx.params.value("evm_gas_per_s_per_core")
    topo = ctx.topo
    names = getattr(topo, "class_names", None) or []
    nodes = ctx.nodes
    cores = []
    gas_per_ms = []
    fallback = classes.get("datacentre") or next(iter(classes.values()))
    for node in range(topo.n_total):
        entry = None
        if names and not nodes.is_builder[node]:
            entry = classes.get(names[nodes.uplink_class[node]])
        if entry is None:
            entry = fallback
        cores.append(int(entry["verify_cores"]))
        gas_per_ms.append(float(tiers[entry["evm_tier"]]) / 1000.0)
    return cores, gas_per_ms


class Cpu:
    """Per-node verification/import CPU: `cores` parallel FIFO slots per
    node, computed without per-job events (earliest free core); one event at
    the end of each job. Verification before import (arch.md 3.8)."""

    def __init__(self, ctx, cores_of):
        """`cores_of(node) -> int`. Counters `mempool.cpu_busy_ms` (job
        time booked, incl. jobs still running) and `mempool.cpu_jobs`."""
        self.ctx = ctx
        self.engine = ctx.engine
        n = ctx.topo.n_total
        self.speed = float(ctx.spec.scale.cpu)
        self.free = []
        for node in range(n):
            cores = int(cores_of(node))
            if cores < 1:
                raise ValueError(f"node {node}: cores must be >= 1")
            self.free.append([0.0] * cores)
        self.busy = ctx.counters.array("mempool.cpu_busy_ms", n, 0.0)
        self.jobs = ctx.counters.array("mempool.cpu_jobs", n, 0)
        ctx.on(EV_CPU_DONE, _cpu_done)

    def run(self, node, duration_ms, on_done, arg):
        """Queue a job of `duration_ms / spec.scale.cpu` at `node`; calls
        on_done(arg) when it finishes; returns the finish time."""
        now = self.engine.now
        cores = self.free[node]
        earliest = heapq.heappop(cores)
        start = earliest if earliest > now else now
        duration = duration_ms / self.speed
        finish = start + duration
        heapq.heappush(cores, finish)
        self.busy[node] += duration
        self.jobs[node] += 1
        self.engine.schedule_at(finish, EV_CPU_DONE, (on_done, arg))
        return finish

    def busy_ms(self, node):
        """Job time booked on the node's cores (including the unfinished
        part of running or queued jobs)."""
        return self.busy[node]

    def backlog_ms(self, node):
        """How long a new job would wait for a core now."""
        wait = self.free[node][0] - self.engine.now
        return wait if wait > 0.0 else 0.0


def _cpu_done(payload):
    on_done, arg = payload
    if on_done is not None:
        on_done(arg)


def effective_tip(tip, fee_cap, base_fee):
    """min(tip, fee_cap - base_fee): what a block producer earns per gas."""
    room = fee_cap - base_fee
    return tip if tip < room else room


def fee_bucket(eff_tip):
    """Bucket 0..31 of an effective tip in wei (factor 2 per bucket)."""
    if eff_tip < 1:
        return 0
    bucket = int(eff_tip).bit_length() - BUCKET_SHIFT
    if bucket < 0:
        return 0
    if bucket >= N_BUCKETS:
        return N_BUCKETS - 1
    return bucket


class Mempool:
    def __init__(self, ctx, capacity_slots=None):
        """Registers counters `mempool.*` (admitted, duplicate, underpriced,
        oversized, evicted, removed per node). `capacity_slots` overrides
        the params' 6,144 (tests)."""
        self.ctx = ctx
        params = ctx.params
        n = ctx.topo.n_total
        self.n = n
        self.capacity = int(capacity_slots if capacity_slots is not None
                            else params.value("pool_full_slots"))
        self.slot_bytes = int(params.value("pool_slot_bytes"))
        self.max_bytes = int(params.value("pool_tx_max_bytes"))
        self.where = [bytearray() for _ in range(n)]    # bucket + 1
        self.buckets = [[{} for _ in range(N_BUCKETS)] for _ in range(n)]
        self.base = [None] * n
        self.seq = [0] * n
        self.slots = [0] * n
        self.count = [0] * n
        self.bytes = [0] * n
        counters = ctx.counters
        self.c_admitted = counters.array("mempool.admitted", n, 0)
        self.c_duplicate = counters.array("mempool.duplicate", n, 0)
        self.c_underpriced = counters.array("mempool.underpriced", n, 0)
        self.c_oversized = counters.array("mempool.oversized", n, 0)
        self.c_evicted = counters.array("mempool.evicted", n, 0)
        self.c_removed = counters.array("mempool.removed", n, 0)
        self._cover = None
        self._cover_members = ()
        ctx.mempool = self

    # -- helpers
    def _slots_of(self, size):
        return (size + self.slot_bytes - 1) // self.slot_bytes

    def _eff(self, tx, base_fee):
        txs = self.ctx.txs
        return effective_tip(txs.tip[tx], txs.fee_cap[tx], base_fee)

    def _rekey(self, node, base_fee):
        """Re-bucket every held tx at `base_fee`, in arrival order."""
        held = []
        for bucket in self.buckets[node]:
            for tx, (_eff, seq) in bucket.items():
                held.append((seq, tx))
        held.sort()
        buckets = [{} for _ in range(N_BUCKETS)]
        where = self.where[node]
        for seq, tx in held:
            eff = self._eff(tx, base_fee)
            bucket = fee_bucket(eff)
            buckets[bucket][tx] = (eff, seq)
            where[tx] = bucket + 1
        self.buckets[node] = buckets
        self.base[node] = base_fee

    def _held(self, node):
        result = []
        for bucket in self.buckets[node]:
            result.extend(bucket)
        return result

    def _drop(self, node, tx, bucket):
        del self.buckets[node][bucket][tx]
        self.where[node][tx] = 0
        size = self.ctx.txs.bytes_wire[tx]
        self.slots[node] -= self._slots_of(size)
        self.count[node] -= 1
        self.bytes[node] -= size

    # -- interface
    def add(self, node, tx, base_fee):
        """-> (ADDED | DUPLICATE | UNDERPRICED | OVERSIZED, [evicted ids])."""
        where = self.where[node]
        if tx >= len(where):
            where.extend(bytes(max(tx + 1 - len(where), _GROW)))
        if where[tx]:
            self.c_duplicate[node] += 1
            return DUPLICATE, []
        size = self.ctx.txs.bytes_wire[tx]
        if size > self.max_bytes:
            self.c_oversized[node] += 1
            return OVERSIZED, []
        slots = self._slots_of(size)
        if self.base[node] is None:
            self.base[node] = base_fee
        evicted = []
        if self.slots[node] + slots > self.capacity:
            if slots > self.capacity:
                self.c_underpriced[node] += 1
                return UNDERPRICED, []
            if self.base[node] != base_fee:
                self._rekey(node, base_fee)
            eff = self._eff(tx, base_fee)
            buckets = self.buckets[node]
            # The floor: the cheapest tx of the lowest non-empty bucket.
            floor = 0
            while not buckets[floor]:
                floor += 1
            cheapest = buckets[floor]
            victim = min(cheapest, key=cheapest.get)
            if eff <= cheapest[victim][0]:
                self.c_underpriced[node] += 1
                return UNDERPRICED, []
            while True:
                self._drop(node, victim, floor)
                evicted.append(victim)
                if self.slots[node] + slots <= self.capacity:
                    break
                while not buckets[floor]:
                    floor += 1
                cheapest = buckets[floor]
                victim = min(cheapest, key=cheapest.get)
            self.c_evicted[node] += len(evicted)
        eff = self._eff(tx, self.base[node])
        key = fee_bucket(eff)
        self.buckets[node][key][tx] = (eff, self.seq[node])
        self.seq[node] += 1
        where[tx] = key + 1
        self.slots[node] += slots
        self.count[node] += 1
        self.bytes[node] += size
        self.c_admitted[node] += 1
        return ADDED, evicted

    def remove(self, node, cover):
        """Drop the txs of bitset `cover` (included in a canonical payload,
        or replaced). Returns the number dropped. The cover's members are
        computed once per cover object (one payload, many nodes)."""
        if cover is not self._cover:
            self._cover = cover
            self._cover_members = _members(cover)
        where = self.where[node]
        size = len(where)
        dropped = 0
        for tx in self._cover_members:
            if tx < size and where[tx]:
                self._drop(node, tx, where[tx] - 1)
                dropped += 1
        self.c_removed[node] += dropped
        return dropped

    def remove_tx(self, node, tx):
        """Drop one tx if held; True if it was."""
        where = self.where[node]
        if tx < len(where) and where[tx]:
            self._drop(node, tx, where[tx] - 1)
            self.c_removed[node] += 1
            return True
        return False

    def holds(self, node, tx):
        where = self.where[node]
        return tx < len(where) and where[tx] != 0

    def pool(self, node):
        """Bitset of the txs `node` holds."""
        where = self.where[node]
        bitmap = bytearray((len(where) + 7) // 8)  # [A] 8 bits per byte
        for tx in self._held(node):
            bitmap[tx >> 3] |= 1 << (tx & 7)  # [A] 8 bits per byte
        return int.from_bytes(bytes(bitmap), "little")

    def fee_order(self, node, base_fee):
        """Tx ids held by `node`, best effective tip first (ties: lower id)."""
        txs = self.ctx.txs
        tips = txs.tip
        caps = txs.fee_cap
        return sorted(self._held(node),
                      key=lambda tx: (-effective_tip(tips[tx], caps[tx],
                                                     base_fee), tx))

    def size(self, node):
        """(tx count, bytes) held by `node`."""
        return self.count[node], self.bytes[node]

    def slots_used(self, node):
        return self.slots[node]


def _members(bitset):
    """Indices of the set bits, ascending, in O(bits) via bytes."""
    if bitset <= 0:
        return ()
    data = bitset.to_bytes((bitset.bit_length() + 7) // 8, "little")  # [A] 8 bits per byte
    result = []
    for index, byte in enumerate(data):
        if byte:
            base = index << 3  # [A] 8 bits per byte
            bit = 0
            while byte:
                if byte & 1:
                    result.append(base + bit)
                byte >>= 1
                bit += 1
    return result

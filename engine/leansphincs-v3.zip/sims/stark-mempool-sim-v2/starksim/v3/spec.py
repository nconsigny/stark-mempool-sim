"""RunSpec: every setting of one v3 run, resolved and validated.

A run is a pure function of its resolved `RunSpec`, the two parameter files
and the code commit; `spec_hash` names that triple's first two parts.

Resolution, later layers win (arch.md section 3.12):

    field defaults  <-  deployment defaults  <-  timeline step  <-  --set

- field defaults are the dataclass defaults below, each with its source;
- deployment defaults are `DEPLOYMENT_DEFAULTS[deployment]`, then the keys
  `deployments_v3.json` section `deployments.<id>` sets (when the section
  exists; `DEPLOYMENT_FILE_KEYS` maps them);
- a timeline step and `--set` are flat dicts `{"dotted.key": value}`.

Validation refuses an unknown key (with the nearest names), a value of the
wrong type or outside its choices/range, and an *inert* key: one set by a
step or `--set` that cannot act in this deployment or network mode (v2's
rule: a chosen value that cannot act is an error, not a silent no-op).

FROZEN FIELD LIST (starksim/v3/INTERFACES.md): fields may be appended to a
group, never renamed, removed or re-typed; a new group is appended at the end
of `RunSpec`.
"""

import dataclasses
import difflib
import hashlib
import json
import math
from dataclasses import dataclass, field

from starksim.v3.params import UnknownCandidate

DEPLOYMENTS = ("today", "8141", "8288", "leanpcs")
PQ_DEPLOYMENTS = ("8141", "8288", "leanpcs")
AGG_DEPLOYMENTS = ("8288", "leanpcs")
ALL = DEPLOYMENTS


def _f(default, kind, doc, choices=None, minimum=None, maximum=None,
       acts_in=ALL, realistic_only=False, demand_mode=None):
    """A spec field with its validation metadata.

    kind: int | float | bool | str | opt_int | opt_float | opt_str.
    acts_in: deployments where the field can act (inert elsewhere).
    realistic_only: inert under net.mode=ideal.
    demand_mode: "load" or "saturate" when the field acts in one demand
    mode only.
    """
    return field(default=default, metadata={
        "kind": kind, "doc": doc, "choices": choices, "min": minimum,
        "max": maximum, "acts_in": tuple(acts_in),
        "realistic_only": realistic_only, "demand_mode": demand_mode})


@dataclass(frozen=True)
class SlotsSpec:
    warmup: int = _f(2, "int", "slots before the measured window "
                     "[A] arch.md 3.12", minimum=0)
    measured: int = _f(8, "int", "measured slots [A] arch.md 3.12",
                       minimum=1)
    drain: int = _f(2, "int", "slots after the window: inclusion of txs born "
                    "in it [A] arch.md 3.12", minimum=0)


@dataclass(frozen=True)
class DemandSpec:
    mode: str = _f("saturate", "str", "saturate: offered PQ rate = "
                   "saturate_factor x min(analytic bounds), base fee frozen; "
                   "load: level_tps total with pq_share (arch.md 3.13)",
                   choices=("saturate", "load"))
    level_tps: object = _f(None, "opt_float", "load mode: offered tx/s, all "
                           "kinds; None = traffic_baseline.tx_per_s_included",
                           minimum=0.0, demand_mode="load")
    pq_share: float = _f(1.0, "float", "load mode: share of arrivals that "
                         "are PQ (the rest ECDSA background)", minimum=0.0,
                         maximum=1.0, acts_in=PQ_DEPLOYMENTS,
                         demand_mode="load")
    ecdsa_tps: object = _f(None, "opt_float", "saturate mode: ECDSA "
                           "background tx/s; None = traffic_baseline "
                           "[M] 23.04", minimum=0.0,
                           demand_mode="saturate")
    multisig_share: float = _f(0.0, "float", "share of PQ txs that are "
                               "k-of-n multisigs", minimum=0.0, maximum=1.0,
                               acts_in=PQ_DEPLOYMENTS)
    multisig_k: int = _f(2, "int", "signatures of a multisig PQ tx",
                         minimum=1, maximum=256, acts_in=PQ_DEPLOYMENTS)
    pcs_share: float = _f(0.0, "float", "share of PQ txs that are PCS-claim "
                          "txs (spec.md Q8 default 0)", minimum=0.0,
                          maximum=1.0, acts_in=("leanpcs",))
    saturate_factor: float = _f(1.5, "float", "saturate mode: offered / "
                                "min(analytic bounds) [A] arch.md 3.13",
                                minimum=0.0, demand_mode="saturate")
    background: str = _f("fluid", "str", "ECDSA background: fluid (byte and "
                         "gas aggregates) or explicit (individual txs)",
                         choices=("fluid", "explicit"))
    senders: int = _f(0, "int", "0 = every tx from a distinct sender; n = "
                      "a population of n senders (one pending tx each, "
                      "spec.md A10)", minimum=0)
    burstiness: bool = _f(True, "bool", "Gamma-Poisson slot rates "
                          "(demand.arrival_burstiness); False = Poisson")
    # Appended at the S3a shared-patch commit (inbox, S2c 07:38 UTC).
    fee_basis: str = _f("per_gas", "str", "tip per gas (kind-blind) or "
                        "per tx (scaled by 109 K / gas) [Mo] build-s2c.md 4",
                        choices=("per_gas", "per_tx"))
    price_elasticity: object = _f(None, "opt_float", "load mode: demand "
                                  "curve slope around today's base fee; None "
                                  "= 0.5 for today, 0 for PQ deployments [A] "
                                  "build-s2c.md 3", minimum=0.0,
                                  demand_mode="load")
    saturate_ecdsa: str = _f("proportional", "str", "saturate mode: ECDSA "
                             "offered x saturate_factor (proportional) or as "
                             "is (fixed) [Mo] build-s2c.md 4",
                             choices=("proportional", "fixed"),
                             demand_mode="saturate")
    burst_r: str = _f("included", "str", "slot-rate Gamma r: included "
                      "(5.13, per-block counts) or raw (1.4, first-seen) "
                      "[Mo] build-s2c.md 2", choices=("included", "raw"))
    offered_pq_tps: object = _f(None, "opt_float", "saturate mode: offered "
                                "PQ tx/s fixed; None = saturate_factor x "
                                "min(analytic bounds). Elasticity and "
                                "shadow-price arms carry the base point's "
                                "rate (arch.md 3.13: the offered rate of "
                                "every arm is the base point's)",
                                minimum=0.0, acts_in=PQ_DEPLOYMENTS,
                                demand_mode="saturate")


@dataclass(frozen=True)
class ChainSpec:
    gas_limit: int = _f(60_000_000, "int", "block gas limit; 0 = none",
                        minimum=0)
    slot_ms: int = _f(12_000, "int", "slot length (spec.md T5, Q10)",
                      choices=(6_000, 10_000, 12_000))
    byte_cap: int = _f(8_388_608, "int", "EIP-7934 RLP block cap "
                       "[E] spec.md T9; 0 = none", minimum=0)
    focil: bool = _f(False, "bool", "EIP-7805 inclusion lists (Hegota, "
                     "spec.md T8)", acts_in=PQ_DEPLOYMENTS)
    dep_cap: object = _f(None, "opt_int", "8288 dependencies per block: None "
                         "(master), 256 (PR #12590), 4096 (PR #12654); "
                         "spec.md B18, Q4", minimum=1, acts_in=AGG_DEPLOYMENTS)
    max_verify_gas: int = _f(100_000, "int", "EIP-8141 MAX_VERIFY_GAS "
                             "(spec.md A9, Q2)", minimum=0,
                             acts_in=PQ_DEPLOYMENTS)
    rule6: str = _f("pr12617", "str", "8141 rule-6 reading: pr12617 "
                    "(signature bytes excluded) or literal (spec.md Q1)",
                    choices=("pr12617", "literal"), acts_in=("8141",))
    private_route: bool = _f(True, "bool", "txs the public mempool refuses "
                             "go direct to builders [A] arch.md 3.8",
                             acts_in=("8141",))
    builder_choice: str = _f("round_robin", "str", "which builder wins a "
                             "slot (arch.md 3.6)",
                             choices=("round_robin", "max_fee"))
    late_import: str = _f("count", "str", "a validator that has not "
                          "imported the payload by the next attestation "
                          "deadline: count it, or also drop its vote",
                          choices=("count", "orphan_vote"))
    pbs: object = _f(None, "opt_str", "None = the deployment's fork; "
                     "mevboost | epbs to force", choices=(None, "mevboost",
                                                          "epbs"))
    # Appended by S6b (calibration v3, calib2 M3).
    local_build_share: object = _f(None, "opt_float", "MEV-boost only: "
                                   "share of slots built and published by "
                                   "the proposer from its own node; None = "
                                   "params local_build_share (0.088 [C] "
                                   "relayscan 7d)", minimum=0.0, maximum=1.0)


@dataclass(frozen=True)
class NetSpec:
    mode: str = _f("realistic", "str", "ideal = zero latency, unmetered "
                   "links (analytic-limit tests)",
                   choices=("realistic", "ideal"))
    within_class: str = _f("fixed", "str", "uplink within a class: the "
                           "class rate, or uniform up to the next class",
                           choices=("fixed", "uniform"), realistic_only=True)
    latency_percentile: str = _f("p50", "str", "RTT matrix used",
                                 choices=("p50", "p90"), realistic_only=True)
    announce_tick_ms: float = _f(100.0, "float", "EL announce packetisation "
                                 "tick [Mo] arch.md 3.4", minimum=0.0)
    lane_weight_el: object = _f(None, "opt_float", "uplink GPS weight of "
                                "the EL lane; None = params lane_weights",
                                minimum=1e-9, realistic_only=True)
    lane_weight_cl: object = _f(None, "opt_float", "uplink GPS weight of "
                                "the CL lane; None = params lane_weights",
                                minimum=1e-9, realistic_only=True)
    columns: str = _f("explicit", "str", "data columns as gossip messages or "
                      "as CL-lane background bytes",
                      choices=("explicit", "background"))
    background: bool = _f(True, "bool", "residual CL/EL background load "
                          "(bandwidth.background_load) on the links",
                          realistic_only=True)
    idontwant: bool = _f(True, "bool", "gossipsub v1.2 IDONTWANT",
                         realistic_only=True)
    gossip_repair: bool = _f(True, "bool", "gossipsub IHAVE/IWANT repair")
    el_client_rules: str = _f("geth", "str", "eth/68 rules for every node "
                              "(geth) or per client share (mixed; spec.md "
                              "Q12)", choices=("geth", "mixed"))
    builders: object = _f(None, "opt_int", "builder nodes; None = params "
                          "builder_count", minimum=1)
    validator_share: object = _f(None, "opt_float", "share of nodes hosting "
                                 "validators; None = params",
                                 minimum=0.0, maximum=1.0)
    supernode_share: object = _f(None, "opt_float", "share of full-custody "
                                 "nodes; None = params", minimum=0.0,
                                 maximum=1.0)
    cl_slow_start: str = _f("conn", "str", "CL congestion windows: conn = "
                            "per directed connection, a share "
                            "cl_restart_share restarts from IW10 per burst, "
                            "the rest keep a persistent window (S6b, "
                            "calib2 M1); iw10 = every copy from IW10 (S6 "
                            "sensitivity); off = no window limit",
                            choices=("off", "iw10", "conn"),
                            realistic_only=True)
    # Appended by S6b (calibration v3, notes/phase4/build-s6b.md).
    cl_restart_share: object = _f(None, "opt_float", "conn: share of "
                                  "directed CL connections whose window "
                                  "restarts at IW10 per block; None = params "
                                  "cl_restart_share (0.57 [Mo] calib2 1.5)",
                                  minimum=0.0, maximum=1.0,
                                  realistic_only=True)
    cl_persistent_window: object = _f(None, "opt_int", "conn: initial "
                                      "persistent window in bytes; None = "
                                      "params cl_persistent_window_bytes "
                                      "(14,720 B [R] quinn), 0 = unbounded "
                                      "(sensitivity)", minimum=0,
                                      realistic_only=True)
    import_waits_for_columns: bool = _f(True, "bool", "block import waits "
                                        "for data availability: the node's "
                                        "sampled columns, or 64 for "
                                        "reconstruction (fulu fork-choice "
                                        "is_data_available; S6b, calib2 M2)")


@dataclass(frozen=True)
class AggSpec:
    share: float = _f(1.0, "float", "share of mempool nodes that aggregate "
                      "(spec.md B10: every node)", minimum=0.0, maximum=1.0,
                      acts_in=AGG_DEPLOYMENTS)
    budget_ms: object = _f(None, "opt_float", "prover time per interval; "
                           "None = 0.9 x AGGREGATION_INTERVAL [Mo] arch.md "
                           "3.10", minimum=0.0, acts_in=AGG_DEPLOYMENTS)
    interval_ms: object = _f(None, "opt_float", "None = AGGREGATION_INTERVAL "
                             "[E] 1 s", minimum=1.0, acts_in=AGG_DEPLOYMENTS)
    wrapper_cap_deps: int = _f(256, "int", "deps per mode-1 wrapper "
                               "(spec.md Q3: 256 PR #12590, 16 literal)",
                               minimum=1, acts_in=AGG_DEPLOYMENTS)
    wrapper_cap_bytes: int = _f(2_097_152, "int", "bytes per mode-1 wrapper "
                                "(spec.md B9)", minimum=1,
                                acts_in=AGG_DEPLOYMENTS)
    mode0_relay: bool = _f(True, "bool", "user mode-0 wrappers announced "
                           "over eth/73 [A] arch.md 3.9",
                           acts_in=AGG_DEPLOYMENTS)
    sig_route: str = _f("dependency", "str", "leanPCS: dependency (draft "
                        "default), pcs_client (wallet proves its signature), "
                        "pcs_bundler (PHASE4 section 2 decision)",
                        choices=("dependency", "pcs_client", "pcs_bundler"),
                        acts_in=("leanpcs",))


@dataclass(frozen=True)
class ProverSpec:
    builder_p: int = _f(1, "int", "parallel provers of a builder [A] arch.md "
                        "3.10", minimum=1, acts_in=AGG_DEPLOYMENTS)
    bid_margin_ms: float = _f(200.0, "float", "builder final proof done this "
                              "long before the bid [A] arch.md 3.10; 8141: "
                              "the payload freeze before the bid (S3a)",
                              minimum=0.0, acts_in=PQ_DEPLOYMENTS)
    class_point: str = _f("mid", "str", "point inside a prover class's "
                          "multiplier band [lo, hi]",
                          choices=("low", "mid", "high"),
                          acts_in=AGG_DEPLOYMENTS)


@dataclass(frozen=True)
class ScaleSpec:
    """Capacity multipliers for shadow prices (arch.md 3.14)."""
    uplink: float = _f(1.0, "float", "every uplink rate x this (> 0)",
                       minimum=1e-9, realistic_only=True)
    downlink: float = _f(1.0, "float", "every downlink rate x this (> 0)",
                         minimum=1e-9, realistic_only=True)
    cpu: float = _f(1.0, "float", "node CPU speed x this (> 0)",
                    minimum=1e-9)
    prover: float = _f(1.0, "float", "prover speed x this (time / this)",
                       minimum=1e-9, acts_in=AGG_DEPLOYMENTS)


@dataclass(frozen=True)
class ObsSpec:
    observers: str = _f("all", "str", "nodes whose first-receipt times feed "
                        "reach quantiles",
                        choices=("all", "datacentre", "targets_rule"))


@dataclass(frozen=True)
class RunSpec:
    deployment: str = _f("8141", "str", "rule plug-in", choices=DEPLOYMENTS)
    candidate: object = _f(None, "opt_str", "candidate name (params "
                           "candidate table); None = deployment default or "
                           "custom sig_bytes/perms")
    sig_bytes: object = _f(None, "opt_int", "signature bytes; resolved from "
                           "the candidate unless set", minimum=1)
    perms: object = _f(None, "opt_int", "Keccak-f permutations to verify one "
                       "signature; resolved from the candidate unless set",
                       minimum=1)
    k: int = _f(1, "int", "signatures per (non-multisig) PQ tx", minimum=1,
                maximum=256, acts_in=PQ_DEPLOYMENTS)
    nodes: int = _f(1000, "int", "simulated nodes, builders excluded "
                    "(arch.md 3.2)", minimum=2)
    seed: int = _f(0, "int", "root of every random stream", minimum=0)
    slots: SlotsSpec = field(default_factory=SlotsSpec)
    demand: DemandSpec = field(default_factory=DemandSpec)
    chain: ChainSpec = field(default_factory=ChainSpec)
    net: NetSpec = field(default_factory=NetSpec)
    agg: AggSpec = field(default_factory=AggSpec)
    prover: ProverSpec = field(default_factory=ProverSpec)
    scale: ScaleSpec = field(default_factory=ScaleSpec)
    obs: ObsSpec = field(default_factory=ObsSpec)
    # Derived by resolve(), never set: the row's candidate label.
    candidate_label: str = _f("", "str", "derived: name, name@B<b>/P<p>, or "
                              "custom@B<b>/P<p>")


GROUPS = ("slots", "demand", "chain", "net", "agg", "prover", "scale", "obs")
DERIVED = ("candidate_label",)

# Deployment defaults: (value, source). Timeline facts of spec.md section 1.
DEPLOYMENT_DEFAULTS = {
    "today": {
        "chain.gas_limit": (60_000_000, "[M] params slot.gas_limit"),
        "demand.pq_share": (0.0, "Fulu today: no PQ deployment"),
        "demand.mode": ("load", "[M] today = the measured demand level "
                        "(traffic_baseline.tx_per_s_included), not a "
                        "saturation (S3a)"),
        "candidate": (None, "no PQ signature today"),
    },
    "8141": {
        "chain.gas_limit": (200_000_000, "[A] spec.md T11: 200 M at H*"),
        "chain.focil": (True, "[E] spec.md T2/T8: FOCIL scheduled for "
                        "Hegota with 8141"),
        "candidate": ("P99r", "[A] campaign headline candidate"),
    },
    "8288": {
        "chain.gas_limit": (200_000_000, "[A] deployments_v3.json assumptions "
                            "Q11 and timeline_default.json I* (task brief "
                            "2026-11-12: 200 M at H* and I*; spec.md T11 "
                            "had 300 M)"),
        "chain.focil": (True, "[A] FOCIL in force since H*"),
        "candidate": ("P99r", "[A] campaign headline candidate"),
    },
    "leanpcs": {
        "chain.gas_limit": (200_000_000, "[A] as 8288"),
        "chain.focil": (True, "[A] FOCIL in force since H*"),
        "candidate": ("P99r", "[A] campaign headline candidate"),
    },
}

# deployments_v3.json `deployments.<id>` paths (arch.md 6.1, as the spec
# researcher wrote them; `inherits` merged) -> spec keys. A path listed twice
# maps an older and a newer name of one setting; the later one wins.
DEPLOYMENT_FILE_KEYS = (
    (("admission", "max_verify_gas"), "chain.max_verify_gas"),
    (("admission", "rule6"), "chain.rule6"),
    (("admission", "private_route"), "chain.private_route"),
    (("wrapper", "cap_deps"), "agg.wrapper_cap_deps"),
    (("wrapper", "mode1_cap_deps"), "agg.wrapper_cap_deps"),
    (("wrapper", "cap_bytes"), "agg.wrapper_cap_bytes"),
    (("wrapper", "mode0_relayed"), "agg.mode0_relay"),
    (("wrapper", "interval_ms"), "agg.interval_ms"),
    (("block", "dep_cap"), "chain.dep_cap"),
    (("builder_deadline", "bid_margin_ms"), "prover.bid_margin_ms"),
    (("sig_route",), "agg.sig_route"),
    (("pcs_claim_share",), "demand.pcs_share"),
)


class SpecError(ValueError):
    """An invalid, unknown or inert setting."""


class InertSetting(SpecError):
    """A setting that cannot act in this deployment or network mode."""


# ------------------------------------------------------------ field table
def _field_table():
    """dotted key -> (dataclass field, group name or None)."""
    table = {}
    for top in dataclasses.fields(RunSpec):
        if top.name in GROUPS:
            for inner in dataclasses.fields(top.default_factory):
                table[f"{top.name}.{inner.name}"] = (inner, top.name)
        else:
            table[top.name] = (top, None)
    return table


FIELDS = _field_table()


def keys():
    """Every settable dotted key, in declaration order."""
    return [key for key in FIELDS if key not in DERIVED]


def describe(key):
    meta = FIELDS[key][0].metadata
    return meta["doc"]


def _coerce(key, value):
    meta = FIELDS[key][0].metadata
    kind = meta["kind"]
    optional = kind.startswith("opt_")
    base = kind[4:] if optional else kind
    if value is None:
        if not optional:
            raise SpecError(f"{key}: null is not allowed")
        return None
    if base == "bool":
        if isinstance(value, bool):
            result = value
        elif isinstance(value, str) and value.lower() in ("true", "on",
                                                          "false", "off"):
            result = value.lower() in ("true", "on")
        else:
            raise SpecError(f"{key}: expected true/false, got {value!r}")
    elif base in ("int", "float") and isinstance(value, float) and \
            not math.isfinite(value):
        raise SpecError(f"{key}: {value!r} is not a finite number")
    elif base == "int":
        if isinstance(value, bool):
            raise SpecError(f"{key}: expected an integer, got {value!r}")
        if isinstance(value, float) and value == int(value):
            value = int(value)
        if not isinstance(value, int):
            raise SpecError(f"{key}: expected an integer, got {value!r}")
        result = value
    elif base == "float":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise SpecError(f"{key}: expected a number, got {value!r}")
        result = float(value)
    else:
        if not isinstance(value, str):
            value = str(value)
        result = value
    choices = meta["choices"]
    if choices is not None and result not in choices:
        raise SpecError(f"{key}: {result!r} is not one of "
                        f"{', '.join(str(choice) for choice in choices)}")
    if meta["min"] is not None and result < meta["min"]:
        raise SpecError(f"{key}: {result!r} is below {meta['min']}")
    if meta["max"] is not None and result > meta["max"]:
        raise SpecError(f"{key}: {result!r} is above {meta['max']}")
    return result


def _check_key(key):
    if key in DERIVED:
        raise SpecError(f"{key} is derived, it cannot be set")
    if key not in FIELDS:
        near = difflib.get_close_matches(key, keys(), n=3)
        raise SpecError(f"unknown setting {key!r}; nearest: "
                        f"{', '.join(near) or 'none'} (python3 -m "
                        "bench.leansphincs run --list-keys)")


def parse_sets(items):
    """['a.b=1', 'c=x'] -> {'a.b': 1, 'c': 'x'}; values parsed as JSON,
    else kept as strings. A later item for the same key wins."""
    result = {}
    for item in items:
        key, separator, text = item.partition("=")
        if not separator:
            raise SpecError(f"--set {item!r}: expected KEY=VALUE")
        key = key.strip()
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            value = text
        result[key] = value
    return result


# ------------------------------------------------------------- resolution
def resolve(params, deployment="8141", step=None, sets=None):
    """The resolved, validated RunSpec of one run.

    `step` and `sets` are flat {dotted key: value} dicts (timeline step,
    then --set). `params` is a `starksim.v3.params.Params`.
    """
    step = dict(step or {})
    sets = dict(sets or {})
    if "deployment" in step:
        deployment = step.pop("deployment")
    if "deployment" in sets:
        deployment = sets.pop("deployment")
    if deployment not in DEPLOYMENTS:
        raise SpecError(f"deployment {deployment!r} is not one of "
                        f"{', '.join(DEPLOYMENTS)}")
    values = {key: FIELDS[key][0].default for key in FIELDS
              if FIELDS[key][1] is None}
    for key, (inner, group) in FIELDS.items():
        if group is not None:
            values[key] = inner.default
    values["deployment"] = deployment
    for key, (value, _source) in DEPLOYMENT_DEFAULTS[deployment].items():
        values[key] = value
    for key, value in _file_deployment_defaults(params, deployment).items():
        values[key] = _coerce(key, value)
    explicit = {}
    for layer in (step, sets):
        for key, value in layer.items():
            _check_key(key)
            explicit[key] = _coerce(key, value)
    values.update(explicit)
    _check_inert(values, explicit)
    _resolve_candidate(params, values, explicit)
    return _build(values)


def _file_deployment_defaults(params, deployment):
    if params is None or not params.has_section("deployments"):
        return {}
    if deployment not in params.section("deployments"):
        return {}
    entry = params.deployment_entry(deployment)
    result = {}
    for path, key in DEPLOYMENT_FILE_KEYS:
        if not _has_path(entry, path):
            continue
        node = entry
        for part in path:
            node = node[part]
        if isinstance(node, dict) and "value" in node:
            node = node["value"]
        if isinstance(node, dict):
            continue
        result[key] = node
    return result


def _has_path(entry, path):
    node = entry
    for part in path:
        if not isinstance(node, dict) or part not in node:
            return False
        node = node[part]
    return True


def _check_inert(values, explicit):
    deployment = values["deployment"]
    ideal = values["net.mode"] == "ideal"
    for key in explicit:
        meta = FIELDS[key][0].metadata
        if deployment not in meta["acts_in"]:
            raise InertSetting(f"{key} cannot act under deployment "
                               f"{deployment} (acts in "
                               f"{', '.join(meta['acts_in'])})")
        if ideal and meta["realistic_only"]:
            raise InertSetting(f"{key} cannot act under net.mode=ideal")
        mode = meta["demand_mode"]
        if mode is not None and values["demand.mode"] != mode:
            raise InertSetting(f"{key} acts only under demand.mode={mode}")


def _resolve_candidate(params, values, explicit):
    name = values["candidate"]
    sig_bytes = values["sig_bytes"]
    perms = values["perms"]
    if values["deployment"] == "today":
        if name is not None or sig_bytes is not None or perms is not None:
            if "candidate" in explicit or "sig_bytes" in explicit or \
                    "perms" in explicit:
                raise InertSetting("deployment today carries no PQ "
                                   "signature: candidate/sig_bytes/perms "
                                   "cannot act")
        values["candidate_label"] = "none"
        return
    # An explicit custom signature without a name drops the default name.
    if "candidate" not in explicit and ("sig_bytes" in explicit or
                                        "perms" in explicit) and \
            sig_bytes is not None and perms is not None:
        # Both set without a name: a custom signature, unless they are
        # exactly the default candidate's (then it is that candidate, with
        # the same label and spec_hash).
        keep = False
        if name is not None and params is not None:
            entry = params.candidate(name)
            keep = (entry["sig_bytes"], entry["perms"]) == (sig_bytes, perms)
        if keep:
            values["sig_bytes"] = None
            values["perms"] = None
            sig_bytes = None
            perms = None
        else:
            name = None
            values["candidate"] = None
    if name is not None:
        if params is None:
            raise SpecError("resolving a candidate name needs params")
        try:
            entry = params.candidate(name)
        except UnknownCandidate as error:
            raise SpecError(str(error)) from None
        if sig_bytes is None:
            sig_bytes = entry["sig_bytes"]
        if perms is None:
            perms = entry["perms"]
        if sig_bytes == entry["sig_bytes"] and perms == entry["perms"]:
            label = name
        else:
            label = f"{name}@B{sig_bytes}/P{perms}"
    else:
        if sig_bytes is None or perms is None:
            raise SpecError("without a candidate name both sig_bytes and "
                            "perms must be set")
        label = f"custom@B{sig_bytes}/P{perms}"
    values["sig_bytes"] = sig_bytes
    values["perms"] = perms
    values["candidate_label"] = label


def _build(values):
    groups = {}
    for group in GROUPS:
        group_class = [top for top in dataclasses.fields(RunSpec)
                       if top.name == group][0].default_factory
        kwargs = {}
        for inner in dataclasses.fields(group_class):
            kwargs[inner.name] = values[f"{group}.{inner.name}"]
        groups[group] = group_class(**kwargs)
    top_kwargs = {}
    for top in dataclasses.fields(RunSpec):
        if top.name in GROUPS:
            top_kwargs[top.name] = groups[top.name]
        else:
            top_kwargs[top.name] = values[top.name]
    return RunSpec(**top_kwargs)


# --------------------------------------------------------------- outputs
def as_dict(spec):
    """Nested plain dict in declaration order."""
    return dataclasses.asdict(spec)


def flat(spec):
    """{dotted key: value} in declaration order."""
    result = {}
    nested = as_dict(spec)
    for key, (inner, group) in FIELDS.items():
        if group is None:
            result[key] = nested[key]
        else:
            result[key] = nested[group][inner.name]
    return result


def canonical_json(spec):
    return json.dumps(as_dict(spec), sort_keys=True, separators=(",", ":"),
                      allow_nan=False)


def spec_hash(spec, params):
    """sha256 over the resolved spec, the two parameter files' sha256 and
    the other data files' digest (params.data_sha256)."""
    material = {
        "spec": as_dict(spec),
        "network_params_sha256": params.network_sha256,
        "deployments_sha256": params.deployments_sha256,
    }
    data = getattr(params, "data_sha256", "")
    if data:
        # Candidate table, counted rows, prover_model.py (S5 review E2).
        material["data_sha256"] = data
    material = json.dumps(material, sort_keys=True, separators=(",", ":"),
                          allow_nan=False)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def replace(spec, **changes):
    """A copy with top-level or dotted changes, *without* re-validation;
    for internal arms (elasticity) only. User input goes through resolve."""
    values = flat(spec)
    for key, value in changes.items():
        values[key.replace("__", ".")] = value
    return _build(values)

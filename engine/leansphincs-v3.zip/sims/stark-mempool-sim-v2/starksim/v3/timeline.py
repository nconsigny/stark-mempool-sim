"""Timeline driver (arch.md 3.16): H* (8141 full) for its months, then I* on
the chosen branch (8288 full | leanPCS full). Stage S5.

A path file (`data/phase4/timeline_default.json`, schema
`leanSPHINCS/timeline/1`) lists steps; each step is sampled at
`points_per_step` months (first, evenly spaced, last; offsets rounded half
up), every schedule `{"YYYY-MM": value}` is interpolated piecewise linearly
by month index (held flat outside its first and last month), and each point
is one load-mode run of `slots.warmup + measured + drain` slots: months are
never simulated, a point is a 12-slot snapshot (stated in every record).

Step fields -> RunSpec keys (FIELD_KEYS; a leaf is `{"value": ...}` with a
source and a status, or a bare value):

    deployment    deployment (the branch entry's for I*)
    candidate     candidate
    gas_limit     chain.gas_limit          schedule, rounded to an int
    slot_ms       chain.slot_ms
    pq_share      demand.pq_share          schedule
    demand_tps    demand.level_tps         schedule x diurnal factor
    focil         chain.focil
    mix           demand.multisig_share, demand.multisig_k
                  (single_sig_share must be 1 - multisig_share; multisig_n
                  is recorded, not simulated: only k signatures go on chain)
    settings      SETTING_KEYS below (the file's names are not spec keys;
                  build-s0s1.md flagged the map as S5's)

Unknown step fields or settings raise TimelineError (no silent drop).

Records (one JSONL line each, the web tool's shape, inbox 09:05 UTC):
    point        {"record": "point", "timeline": {"step", "branch", "month",
                  "variant", "schedule"}, "seed", "weight_months",
                  "snapshot", "row"}
    elasticity   elasticity.estimate's record plus the same "timeline" key
                 of the base point (`elasticity_at`; inbox 09:50 UTC gap 2)

Schedules (inbox 09:50 UTC gap 1). `variant.pq_share` names the PQ-share
schedule a point actually ran, by value, with the web tool's rule
(web-v3/build.py pq_variants): "default" = the step's schedule, "forced" =
its all-1.0 alternative, "low" = its alternative below the schedule;
"custom" = anything else (e.g. `--set demand.pq_share=0.3`). It is computed
from the values at the step's sampled months, so the label cannot claim a
schedule the run did not use. `pq_share=` (points, run_path, elasticity_at;
CLI `--pq-share`) selects an alternative. `timeline.schedule` carries every
schedule of the point's step as run ({"pq_share", "gas_limit",
"demand_tps", "slot_ms"}: the YYYY-MM dict, or a constant when a `--set`
overrides it, demand_tps before the diurnal factor), so two records are
the same point only if they ran the same schedules.
    step         month-weighted means of SUMMARY_COLUMNS over the step's
                 points (trapezoid weights normalised to the step's months,
                 seeds averaged first), the binding labels by point
    path         month-weighted means over every step of one branch
    branch_diff  per I* month: leanpcs minus 8288 of SUMMARY_COLUMNS (when
                 both branches ran)

Latency means are weighted by month x included PQ tx/s (a mean over
transactions, arch.md 3.16; pq1 = 8141/8288/leanPCS-dependency txs, pcs =
leanPCS pcs routes); a None value is left out of its mean and the
count of points used is reported beside it.
"""

import json
from collections import namedtuple

from starksim.v3 import params as P
from starksim.v3 import spec as spec_module
from starksim.v3 import sweep3

P.register_bindings({
    "demand_diurnal_utc": (P.NET, ("demand", "diurnal_utc"), None),
})

SCHEMA = "leanSPHINCS/timeline/1"
HOURS = 24            # [E] UTC hours of demand.diurnal_utc
MONTHS = 12           # [E] months per year
POINTS_DEFAULT = 3    # [A] arch.md 3.16: first, middle, last month
BRANCHES = ("8288", "leanpcs")
SNAPSHOT_NOTE = ("a point is one load-mode run of warmup + measured + drain "
                 "slots at that month's settings; months are not simulated")

# Step-file settings (deployments_v3.json names) -> RunSpec keys.
SETTING_KEYS = {
    "8141.rule6": "chain.rule6",
    "8141.max_verify_gas": "chain.max_verify_gas",
    "8288.block.dep_cap": "chain.dep_cap",
    "8288.wrapper.mode1_cap_deps": "agg.wrapper_cap_deps",
    "8288.wrapper.cap_deps": "agg.wrapper_cap_deps",
    "builder.prover_cluster_size": "prover.builder_p",
    "leanpcs.sig_route": "agg.sig_route",
    "leanpcs.pcs_claim_share": "demand.pcs_share",
}
# Plain step fields -> RunSpec keys (schedules marked).
FIELD_KEYS = {
    "candidate": ("candidate", False),
    "gas_limit": ("chain.gas_limit", True),
    "slot_ms": ("chain.slot_ms", True),
    "pq_share": ("demand.pq_share", True),
    "demand_tps": ("demand.level_tps", True),
    "focil": ("chain.focil", False),
}
INT_KEYS = ("chain.gas_limit", "chain.slot_ms")
# Top-level fields of a path file (`start` and `diurnal` describe: the
# steps carry their own start, the CLI's --hour picks the diurnal factor).
TOP_FIELDS = ("schema", "written", "by", "doc", "points_per_step", "start",
              "diurnal", "steps", "note")
# Step fields that describe and are not settings.
META_FIELDS = ("id", "fork", "start", "months", "deployment", "branch",
               "settings", "mix", "doc", "note")

SUMMARY_COLUMNS = ("tps_included", "pq_tps", "pcs_tps", "sig_per_s",
                   "ecdsa_bg_tps",
                   "gas_per_s", "block_gas_fill_mean",
                   "payload_reach_t90_p50_ms", "block_reach_t90_p50_ms",
                   "user_fee_pq_p50_gwei", "base_fee_end_gwei",
                   "censored_share")
LATENCY_COLUMNS = ("incl_latency_pq1_p50_s", "incl_latency_pq1_p95_s",
                   "incl_latency_pq1_p99_s", "incl_latency_pcs_p50_s",
                   "incl_latency_pcs_p95_s")

Point = namedtuple("Point", ("step", "branch", "month", "weight_months",
                             "deployment", "sets", "variant", "schedule"),
                   defaults=(None,))
PQ_VARIANTS = ("default", "low", "forced")
SCHEDULE_FIELDS = ("pq_share", "gas_limit", "demand_tps", "slot_ms")


class TimelineError(ValueError):
    """An invalid timeline file or request."""


# ------------------------------------------------------------- months
def month_index(text):
    """'YYYY-MM' -> months since year 0."""
    try:
        year, month = str(text).split("-")
        year, month = int(year), int(month)
    except ValueError:
        raise TimelineError(f"month {text!r}: expected YYYY-MM") from None
    if not 1 <= month <= MONTHS:
        raise TimelineError(f"month {text!r}: month out of range")
    return year * MONTHS + month - 1


def month_text(index):
    return f"{index // MONTHS:04d}-{index % MONTHS + 1:02d}"


def _leaf(value):
    if isinstance(value, dict) and "value" in value:
        return value["value"]
    return value


def interpolate(schedule, month):
    """Piecewise-linear value of a {'YYYY-MM': number} schedule at month
    index `month` (flat outside); a non-dict is a constant."""
    if not isinstance(schedule, dict):
        return schedule
    knots = sorted((month_index(key), value)
                   for key, value in schedule.items())
    if not knots:
        raise TimelineError("empty schedule")
    if month <= knots[0][0]:
        return knots[0][1]
    for (m0, v0), (m1, v1) in zip(knots, knots[1:]):
        if month <= m1:
            if isinstance(v0, bool) or not isinstance(v0, (int, float)) or \
                    isinstance(v1, bool) or not isinstance(v1, (int, float)):
                return v0 if month < m1 else v1
            return v0 + (v1 - v0) * (month - m0) / (m1 - m0)
    return knots[-1][1]


def sample_offsets(months, points):
    """Month offsets of the sample: 0, ..., months - 1, `points` of them
    evenly spaced (rounded half up), duplicates dropped."""
    if months < 1:
        raise TimelineError(f"months {months!r} < 1")
    points = max(1, int(points))
    if points == 1 or months == 1:
        return [0]
    span = months - 1
    result = []
    for i in range(points):
        offset = (2 * span * i + (points - 1)) // (2 * (points - 1))
        if offset not in result:
            result.append(offset)
    return result


def trapezoid_weights(offsets, months):
    """Weights of the sample offsets (sum = months): trapezoid rule over
    [first, last] offset, scaled to the step's months; one point: all."""
    if len(offsets) == 1:
        return [float(months)]
    raw = []
    for i, x in enumerate(offsets):
        left = offsets[i - 1] if i > 0 else x
        right = offsets[i + 1] if i + 1 < len(offsets) else x
        raw.append((right - left) / 2.0)
    total = sum(raw)
    return [months * w / total for w in raw]


# --------------------------------------------------------------- file
def load(path):
    """The timeline as a dict (validated by `steps`)."""
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    if data.get("schema") != SCHEMA:
        raise TimelineError(f"{path}: schema {data.get('schema')!r}, "
                            f"expected {SCHEMA}")
    for key in data:
        if key not in TOP_FIELDS:
            raise TimelineError(f"{path}: unknown top-level field {key!r}")
    for branch in BRANCHES:
        steps(data, branch)
    return data


def check_forks(data, params):
    """Each step's `fork` equals deployments_v3.json's fork of its
    deployment (review E10); raises TimelineError."""
    for branch in BRANCHES:
        for step_id, _b, deployment, _s, _m, entry in steps(data, branch):
            fork = _leaf(entry.get("fork"))
            if fork is None:
                continue
            expected = params.deployment_entry(deployment).get("fork")
            if isinstance(expected, dict):
                expected = expected.get("value")
            if expected is not None and fork != expected:
                raise TimelineError(f"step {step_id}: fork {fork!r} but "
                                    f"{deployment} runs on {expected!r}")


def diurnal_factor(params, hour):
    """Demand multiplier: 'mean' = 1, 'peak' = max/mean, an int h = the
    UTC hour's tx_mean[h] / mean (network_params demand.diurnal_utc [M])."""
    if hour in (None, "mean", "off"):
        return 1.0
    table = params.value("demand_diurnal_utc")
    values = [float(table[str(h)]) for h in range(HOURS)]
    mean = sum(values) / len(values)
    if hour == "peak":
        return max(values) / mean
    hour = int(hour)
    if not 0 <= hour < HOURS:
        raise TimelineError(f"hour {hour}: expected 0-23")
    return values[hour] / mean


def _mix_sets(mix):
    mix = _leaf(mix)
    if mix is None:
        return {}
    allowed = ("single_sig_share", "multisig_share", "multisig_k",
               "multisig_n")
    for key in mix:
        if key not in allowed:
            raise TimelineError(f"mix: unknown field {key!r}")
    share = float(mix.get("multisig_share", 0.0))
    single = mix.get("single_sig_share")
    if single is not None and abs(float(single) + share - 1.0) > 1e-9:  # [A] float tolerance
        raise TimelineError(f"mix: single_sig_share {single} + "
                            f"multisig_share {share} != 1")
    sets = {"demand.multisig_share": share}
    if "multisig_k" in mix:
        sets["demand.multisig_k"] = int(mix["multisig_k"])
    return sets


def _settings_sets(settings, deployment):
    sets = {}
    for name, leaf in (settings or {}).items():
        if name not in SETTING_KEYS:
            raise TimelineError(f"setting {name!r} has no RunSpec key "
                                f"(known: {', '.join(sorted(SETTING_KEYS))})")
        key = SETTING_KEYS[name]
        meta = spec_module.FIELDS[key][0].metadata
        if deployment not in meta["acts_in"]:
            raise TimelineError(f"setting {name!r} ({key}) cannot act in "
                                f"deployment {deployment}")
        sets[key] = _leaf(leaf)
    return sets


def steps(data, branch):
    """[(step id, branch, deployment, start month index, months, entry
    merged with its branch entry)] for one branch (None: '8288' when
    validating)."""
    result = []
    for raw in data.get("steps", []):
        months = int(_leaf(raw["months"]))
        start = month_index(_leaf(raw["start"]))
        entry = dict(raw)
        step_branch = None
        if "branch" in raw:
            chosen = branch or BRANCHES[0]
            if chosen not in raw["branch"]:
                raise TimelineError(f"step {raw.get('id')}: no branch "
                                    f"{chosen!r}")
            sub = raw["branch"][chosen]
            entry = dict(raw)
            entry.pop("branch")
            for key, value in sub.items():
                if key == "settings":
                    merged = dict(entry.get("settings", {}))
                    merged.update(value)
                    entry["settings"] = merged
                else:
                    entry[key] = value
            step_branch = chosen
        deployment = _leaf(entry.get("deployment"))
        if deployment not in spec_module.PQ_DEPLOYMENTS:
            raise TimelineError(f"step {raw.get('id')}: deployment "
                                f"{deployment!r}")
        for key in entry:
            if key not in META_FIELDS and key not in FIELD_KEYS:
                raise TimelineError(f"step {raw.get('id')}: unknown field "
                                    f"{key!r}")
        _settings_sets(entry.get("settings"), deployment)
        _mix_sets(entry.get("mix"))
        result.append((raw.get("id", f"step{len(result)}"), step_branch,
                       deployment, start, months, entry))
    if not result:
        raise TimelineError("timeline has no steps")
    return result


def _point_sets(entry, deployment, month, factor):
    sets = {"demand.mode": "load"}
    for field, (key, schedule) in FIELD_KEYS.items():
        if field not in entry:
            continue
        value = _leaf(entry[field])
        if schedule:
            value = interpolate(value, month)
        if key == "demand.level_tps":
            value = float(value) * factor
        if key in INT_KEYS:
            value = int(value + 0.5)
        sets[key] = value
    sets.update(_mix_sets(entry.get("mix")))
    sets.update(_settings_sets(entry.get("settings"), deployment))
    return sets


def pq_variants(leaf):
    """{name: schedule} of a step's pq_share leaf: "default" = its value;
    "forced" = the alternative whose values are all 1.0; "low" = the other
    alternative lying at or below the schedule at every month it names
    (web-v3/build.py pq_variants; a missing one is absent)."""
    default = _leaf(leaf)
    result = {"default": default}
    alternatives = leaf.get("alternatives", []) if isinstance(leaf, dict) \
        else []
    alternatives = [a for a in alternatives if isinstance(a, dict)]
    forced = [a for a in alternatives
              if all(float(v) == 1.0 for v in a.values())]
    if isinstance(default, dict):
        low = [a for a in alternatives if a not in forced and all(
            float(v) <= float(default.get(m, v)) for m, v in a.items())]
    else:
        low = [a for a in alternatives if a not in forced and all(
            float(v) <= float(default) for v in a.values())]
    if len(forced) == 1:
        result["forced"] = forced[0]
    if len(low) == 1:
        result["low"] = low[0]
    return result


def _pq_label(entry, start, offsets, used):
    """The PQ_VARIANTS name whose values equal `used` (the run's pq_share
    at each sampled month), else "custom"."""
    leaf = entry.get("pq_share")
    if leaf is None:
        return "custom"
    for name, schedule in pq_variants(leaf).items():
        values = [float(interpolate(schedule, start + o)) for o in offsets]
        if all(abs(a - b) <= 1e-12 for a, b in zip(values, used)):  # [A] float tolerance
            return name
    return "custom"


def points(data, branch=None, points_per_step=None, sets=None,
           variant=None, params=None, hour="mean", pq_share=None):
    """Point list of the path (module docstring). `branch` None = both I*
    branches (H* points once, branch None). `sets` ({key: value}) apply to
    every point after the file; `variant` {branch or 'all': {key: value}}
    applies to that branch's I* points only (e.g. sig_route). `pq_share`
    (None = "default") picks a PQ_VARIANTS schedule of every step."""
    if pq_share not in (None,) + PQ_VARIANTS:
        raise TimelineError(f"pq_share {pq_share!r}: one of "
                            f"{', '.join(PQ_VARIANTS)}")
    branches = BRANCHES if branch is None else (branch,)
    for name in branches:
        if name not in BRANCHES:
            raise TimelineError(f"branch {name!r}: one of "
                                f"{', '.join(BRANCHES)}")
    per_step = (points_per_step if points_per_step is not None
                else _leaf(data.get("points_per_step", POINTS_DEFAULT)))
    factor = diurnal_factor(params, hour) if params is not None else 1.0
    result = []
    seen = set()
    for name in branches:
        for step_id, step_branch, deployment, start, months, entry in \
                steps(data, name):
            if step_branch is None and (step_id, None) in seen:
                continue
            seen.add((step_id, step_branch))
            original = entry
            if pq_share not in (None, "default"):
                choices = pq_variants(entry.get("pq_share", {}))
                if pq_share not in choices:
                    raise TimelineError(f"step {step_id}: no {pq_share!r} "
                                        "pq_share alternative")
                entry = dict(entry, pq_share=choices[pq_share])
            offsets = sample_offsets(months, per_step)
            weights = trapezoid_weights(offsets, months)
            step_points = []
            for offset, weight in zip(offsets, weights):
                month = start + offset
                point_sets = _point_sets(entry, deployment, month, factor)
                point_sets.update(sets or {})
                extra = {}
                if variant:
                    extra.update(variant.get("all", {}))
                    if step_branch is not None:
                        extra.update(variant.get(step_branch, {}))
                for key, value in extra.items():
                    meta = spec_module.FIELDS[key][0].metadata
                    if deployment in meta["acts_in"]:
                        point_sets[key] = value
                step_points.append((month, weight, point_sets))
            used = [float(ps.get("demand.pq_share", 0.0))
                    for _m, _w, ps in step_points]
            label = _pq_label(original, start, offsets, used)
            overrides = dict(sets or {})
            if variant:
                # Variant settings that act here override the file too
                # (review C8: a variant gas limit was not in the schedule).
                for scope in ("all", step_branch):
                    for key, value in variant.get(scope, {}).items():
                        meta = spec_module.FIELDS[key][0].metadata
                        if deployment in meta["acts_in"]:
                            overrides[key] = value
            schedule = _schedule(entry, overrides)
            for month, weight, point_sets in step_points:
                tag = _variant(point_sets, deployment)
                tag["pq_share"] = label
                result.append(Point(step_id, step_branch, month_text(month),
                                    weight, deployment, point_sets, tag,
                                    schedule))
    return result


def _schedule(entry, sets):
    """Every schedule of a step as run (module docstring, Schedules)."""
    result = {}
    for field in SCHEDULE_FIELDS:
        key = FIELD_KEYS[field][0]
        if sets and key in sets:
            result[field] = sets[key]
        elif field in entry:
            result[field] = _leaf(entry[field])
        else:
            result[field] = None
    return result


def timeline_key(point):
    """The "timeline" key of a point's records."""
    return {"step": point.step, "branch": point.branch,
            "month": point.month, "variant": point.variant,
            "schedule": point.schedule}


def _variant(sets, deployment):
    return {
        "candidate": sets.get("candidate"),
        "gas_limit": sets.get("chain.gas_limit"),
        "pq_share": "default",
        "sig_route": (sets.get("agg.sig_route", "dependency")
                      if deployment == "leanpcs" else None),
        "dep_cap": (sets.get("chain.dep_cap")
                    if deployment in spec_module.AGG_DEPLOYMENTS else None),
    }


# ----------------------------------------------------------------- run
def resolve_points(pts, params, nodes=None, seeds=(0,)):
    """[(point, seed, RunSpec)] for every point and seed."""
    result = []
    for point in pts:
        for seed in seeds:
            sets = dict(point.sets)
            sets["seed"] = int(seed)
            if nodes is not None:
                sets["nodes"] = int(nodes)
            try:
                spec = spec_module.resolve(params, point.deployment,
                                           sets=sets)
            except spec_module.SpecError as error:
                raise TimelineError(f"{point.step} {point.branch} "
                                    f"{point.month}: {error}") from None
            result.append((point, int(seed), spec))
    return result


def run_path(data, params, branch=None, nodes=None, seeds=(0,),
             points_per_step=None, sets=None, variant=None, jobs=1,
             cache=None, progress=None, hour="mean", pq_share=None):
    """Every record of the path (module docstring), in a fixed order: the
    point records (path order, seeds inner), then step, path and
    branch_diff summaries."""
    check_forks(data, params)
    pts = points(data, branch, points_per_step, sets, variant, params, hour,
                 pq_share)
    jobs_list = resolve_points(pts, params, nodes, seeds)
    rows = sweep3.run_specs([spec for _p, _s, spec in jobs_list], params,
                            jobs=jobs, cache=cache, progress=progress)
    records = []
    for (point, seed, _spec), row in zip(jobs_list, rows):
        records.append({
            "record": "point",
            "timeline": timeline_key(point),
            "seed": seed, "weight_months": point.weight_months,
            "snapshot": SNAPSHOT_NOTE, "row": row})
    records.extend(summaries(records, branch))
    return records


def _seed_mean(rows, column):
    values = [row[column] for row in rows if row.get(column) is not None]
    if not values:
        return None
    return sum(values) / len(values)


def _by_point(point_records):
    """{(step, branch, month): (weight, [rows])} in first-seen order."""
    grouped = {}
    for record in point_records:
        tl = record["timeline"]
        key = (tl["step"], tl["branch"], tl["month"])
        if key not in grouped:
            grouped[key] = (record["weight_months"], [])
        grouped[key][1].append(record["row"])
    return grouped


def weighted_means(entries):
    """entries: [(weight, rows)] -> {column: mean or None, column + '_n':
    points used}; latency columns weighted by weight x pq_tps."""
    means = {}
    for column in SUMMARY_COLUMNS + LATENCY_COLUMNS:
        total = acc = 0.0
        used = 0
        for weight, rows in entries:
            value = _seed_mean(rows, column)
            if value is None:
                continue
            w = weight
            if column in LATENCY_COLUMNS:
                w = weight * (_seed_mean(rows, "pq_tps") or 0.0)
            if w <= 0.0:
                continue
            total += w
            acc += w * value
            used += 1
        means[column] = acc / total if total else None
        means[column + "_n"] = used
    return means


def summaries(point_records, branch=None):
    grouped = _by_point(point_records)
    steps_seen = []
    for (step, step_branch, _month) in grouped:
        if (step, step_branch) not in steps_seen:
            steps_seen.append((step, step_branch))
    out = []
    for step, step_branch in steps_seen:
        entries = [(w, rows) for (s, b, _m), (w, rows) in grouped.items()
                   if s == step and b == step_branch]
        binding = {m: [row["binding"] for row in rows]
                   for (s, b, m), (_w, rows) in grouped.items()
                   if s == step and b == step_branch}
        out.append({"record": "step",
                    "timeline": {"step": step, "branch": step_branch},
                    "months": sum(w for w, _r in entries),
                    "means": weighted_means(entries), "binding": binding})
    branches = BRANCHES if branch is None else (branch,)
    for name in branches:
        entries = [(w, rows) for (s, b, _m), (w, rows) in grouped.items()
                   if b in (None, name)]
        if not any(b == name for (_s, b, _m) in grouped):
            continue
        out.append({"record": "path", "timeline": {"branch": name},
                    "months": sum(w for w, _r in entries),
                    "means": weighted_means(entries)})
    if branch is None:
        months = {}
        for (s, b, m), (_w, rows) in grouped.items():
            if b is not None:
                months.setdefault((s, m), {})[b] = rows
        for (s, m), by_branch in months.items():
            if len(by_branch) < 2:
                continue
            diff = {}
            for column in SUMMARY_COLUMNS + LATENCY_COLUMNS:
                a = _seed_mean(by_branch["leanpcs"], column)
                b = _seed_mean(by_branch["8288"], column)
                diff[column] = None if a is None or b is None else a - b
            out.append({"record": "branch_diff",
                        "timeline": {"step": s, "month": m},
                        "leanpcs_minus_8288": diff})
    return out


def find_point(data, step, month, branch=None, points_per_step=None,
               sets=None, variant=None, params=None, hour="mean",
               pq_share=None):
    """The Point of `step` (and I* `branch`) at `month` ('YYYY-MM'), which
    must be one of the step's sampled months; raises TimelineError."""
    pts = points(data, branch, points_per_step, sets, variant, params, hour,
                 pq_share)
    found = [p for p in pts if p.step == step and p.month == month and
             (p.branch is None or p.branch == branch)]
    if not found:
        months = sorted({(p.step, p.branch, p.month) for p in pts},
                        key=str)
        raise TimelineError(f"no point {step} {branch} {month}; sampled: "
                            f"{months}")
    return found[0]


def elasticity_at(data, params, step, month, branch=None, inputs=(
        "sig_bytes", "perms"), seeds=(0, 1, 2), h=None, resource=None,
        nodes=None, points_per_step=None, sets=None, variant=None, jobs=1,
        cache=None, hour="mean", pq_share=None, metric="pq_tps"):
    """Elasticity records at one timeline point (inbox 09:50 UTC gap 2):
    `elasticity.estimate` on the point's settings (its saturated base
    runs, module docstring of elasticity.py), each record carrying the
    point's "timeline" key."""
    from starksim.v3 import elasticity
    point = find_point(data, step, month, branch, points_per_step, sets,
                       variant, params, hour, pq_share)
    point_sets = dict(point.sets)
    if nodes is not None:
        point_sets["nodes"] = int(nodes)
    records = []
    for name in inputs:
        kwargs = {} if h is None else {"h": h}
        record = elasticity.estimate(point_sets, params, point.deployment,
                                     name, seeds, resource=resource,
                                     metric=metric, jobs=jobs, cache=cache,
                                     **kwargs)
        record["timeline"] = timeline_key(point)
        records.append(record)
    return records

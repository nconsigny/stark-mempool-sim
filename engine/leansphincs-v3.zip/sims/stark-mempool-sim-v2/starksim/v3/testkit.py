"""Builders for tests of v3 modules: a run context with the campaign
topology and links, or a hand-made topology (line, ring, star) with fixed
latency and rates for analytic checks. Not used by model code.
"""

from starksim.v3 import params as params_module
from starksim.v3 import spec as spec_module
from starksim.v3.links import Links
from starksim.v3.state import Context, NodeTable
from starksim.v3.topology import MBIT_TO_BYTES_PER_MS, Topology


def campaign_params():
    return params_module.default_params().fresh()


def lane_weights(spec, params):
    weights = params.value("lane_weights")
    el_weight = spec.net.lane_weight_el
    cl_weight = spec.net.lane_weight_cl
    if el_weight is None:
        el_weight = weights["el"]
    if cl_weight is None:
        cl_weight = weights["cl"]
    return (el_weight, cl_weight)


def context(deployment="8141", sets=None, params=None, links=True):
    """A Context whose topology (and links) are built from the campaign
    files: what the runner (S5) will do, minus the plug-ins."""
    params = params or campaign_params()
    run_spec = spec_module.resolve(params, deployment, sets=sets or {})
    topo = Topology.build(run_spec, params)
    ctx = Context(run_spec, params, topo.n_total)
    topo.install(ctx)
    if links:
        background = None
        if run_spec.net.background:
            background = params.value("background_mbps")
        ctx.links = Links(ctx, topo, lane_weights(run_spec, params),
                          background)
    return ctx


class FixedTopology:
    """A hand-made topology: every edge has the same one-way latency; all
    nodes the same uplink and downlink unless set per node. Same interface
    as Topology for links and gossip (nodes, n_total, latency, ideal)."""

    def __init__(self, n, el_edges=(), cl_edges=(), latency_ms=10.0,  # [A] test default
                 up_mbps=100.0, down_mbps=100.0, ideal=False):  # [A] test default
        self.n = n
        self.n_total = n
        self.builders = []
        self.ideal = ideal
        self.latency_ms = latency_ms
        self.stats = {}
        nodes = NodeTable(n)
        for node in range(n):
            nodes.up_Bpms[node] = up_mbps * MBIT_TO_BYTES_PER_MS
            nodes.down_Bpms[node] = down_mbps * MBIT_TO_BYTES_PER_MS
            nodes.cl_D[node] = 0
            nodes.reachable[node] = True
        self.nodes = nodes
        nodes.el_peers = _adjacency(n, el_edges)
        nodes.cl_mesh = _adjacency(n, cl_edges)

    def latency(self, u, v):
        if self.ideal or u == v:
            return 0.0
        return self.latency_ms

    def install(self, ctx):
        ctx.topo = self
        ctx.nodes = self.nodes


def _adjacency(n, edges):
    peers = [set() for _ in range(n)]
    for u, v in edges:
        peers[u].add(v)
        peers[v].add(u)
    return [tuple(sorted(peer_set)) for peer_set in peers]


def line(n):
    return [(node, node + 1) for node in range(n - 1)]


def ring(n):
    return line(n) + [(n - 1, 0)]


def star(n):
    return [(0, node) for node in range(1, n)]


def fixed_context(topo, deployment="8141", sets=None, lane_weights=(1.0,
                                                                     1.0),
                  background_mbps=None, params=None):
    """A Context over a FixedTopology with Links built on it."""
    params = params or campaign_params()
    merged = {"nodes": max(topo.n, 2)}
    merged.update(sets or {})
    run_spec = spec_module.resolve(params, deployment, sets=merged)
    ctx = Context(run_spec, params, topo.n_total)
    topo.install(ctx)
    ctx.links = Links(ctx, topo, lane_weights, background_mbps)
    return ctx

"""CL gossip: gossipsub v1.2 topics over symmetric meshes, IDONTWANT,
IHAVE/IWANT repair, flood publish, PeerDAS data columns (arch.md 3.5,
STAGES.md S2b).

Topics. `beacon_block`, `execution_payload`, `payload_attestation` and
`inclusion_list` share the mesh `ctx.nodes.cl_mesh` (topology, S1): every
node subscribes to them. Each `data_column_sidecar_{i}` subnet (i < 128) has
its own mesh over its subscribers, built with `topology.build_mesh(members,
targets, ctx.stream("topo", "column_mesh", i))`, targets = the nodes'
`cl_D`.

Peers. Besides its meshes a node has CL peers (`cl.peers`): a configuration
graph on the clients' target peer counts (Lighthouse 200, Lodestar 200,
Prysm 70, Nimbus 160, Teku 100 [R] params topology.cl_mesh.cl_target_peers
and cl_gossip.cl.client; Grandine 100 [A]), capped at n - 1 (a scaled network
keeps the degree, as the EL graph does), plus every edge of the shared
mesh. A node's peers on a topic are its peers subscribed to it, plus, for a
column subnet, its neighbours in that subnet's mesh (the column meshes are
not unioned into `cl.peers`, which would triple the peer count). They receive flood
publishes, fanout publishes, and IHAVE gossip.

Clients. Lighthouse nodes are the ones topology dealt D = lighthouse_D (the
same stream, re-dealt here); the other simulated nodes are dealt Prysm,
Teku, Lodestar, Nimbus, Grandine in equal shares [Mo] (params
cl_gossip.idontwant_min_bytes draw text: "the rest split equally when no
mix is given"); builders are Prysm [A]. The client sets the IDONTWANT
threshold (cl_gossip.idontwant_min_bytes [R]), the heartbeat and D_lazy
(Lighthouse network load 3: 1,000 ms, 3 [R]; others the spec's 700 ms, 6
[E]), the peer target, and flood publishing:

  lighthouse  no  (lighthouse config.rs:520 `.flood_publish(false)`) [R]
  lodestar    no  (lodestar network/options.ts:73 disableFloodPublish) [R]
  teku        only messages <= 16 KiB (teku gossip config :39) [R]
  nimbus      to at most max(heartbeat / (size / 12.5 kB/ms), D_low) peers
              (nim-libp2p gossipsub.nim:1011-1030, bandwidth 100 Mbit/s
              :134) [R]
  prysm       no  (go-libp2p-pubsub master: router field unset,
              gossipsub.go:296-317; prysm pubsub.go:158-172 sets no
              WithFloodPublish) [R]
  grandine    yes (rust-libp2p default flood_publish true, config.rs:546;
              Grandine's own setting not read) [R] library, [Rc] client

Publish (gossipsub.go:1352-1420). The publisher sends the full message on
the CL lane to: every topic peer when it flood-publishes, else its mesh
when subscribed (rust clients top a mesh shorter than mesh_n up from topic
peers, behaviour.rs filter_publish_candidates), else mesh_n fanout peers
(Lighthouse 5, others D = 8) drawn from its topic peers. Publishers
do not send IDONTWANT (nim sendIDontWantOnPublish false; rust
idontwant_on_publish off by default).

Receive. On a node's first copy: (1) IDONTWANT (v1.2) at once, before
validation (gossipsub.go:873-911 Preprocess), when the receiver supports
v1.2 and the message is at least its client's threshold: a control message
to every mesh peer of the topic except the sender that also supports v1.2
(rust clients also to the peers they sent IWANT for it, behaviour.rs
handle_received_message); thresholds compare as go `>=`, rust `>`, nim
`> max(512, ...)`; (2) after the topic's validation delay, forward to the
mesh except the peers that sent IDONTWANT (gossipsub.go:1398-1405) and the
peers that sent us a copy (rust-libp2p, forwarding after validation; go
clients exclude only the first sender, gossipsub.go:1406), then call
`on_first_receipt` and `ctx.hooks.cl_first_receipt`. Later copies are
duplicates (counted: copies and bytes). A peer receiving IDONTWANT never
enqueues the message to that node later, and (switch `idontwant_cancels`,
default on, STAGES.md S2b) drops queued copies to it that have not started
(a started stream finishes).

Transmission. libp2p writes to every peer's connection in parallel, so a
node's copies of one message share its uplink (processor sharing) rather
than going one after another. `send_mode="parallel"` (default) emulates
that on the links' FIFO lane by cutting each copy into chunks of
`chunk_bytes` and interleaving them round-robin over the peers of one
forward; the last chunk delivers. `send_mode="staggered"` sends whole
copies one after another (the prototype's and the S1 bench's model, and
the "staggered sending" proposal). A copy can be cancelled by IDONTWANT
only while its first chunk is still queued.

IHAVE/IWANT (gossipsub.go:938-1060, 2039-2110). A node gossips a message
at the first `mcache_gossip` (3) heartbeats after it forwarded or
published it. At each such heartbeat, per topic, it sends one IHAVE to
max(D_lazy, 0.25 x non-mesh topic peers) of its non-mesh topic peers,
drawn from `ctx.stream("cl", "ihave", node, beat)`. A peer that lacks a
listed message and has no IWANT pending for it (rust-libp2p
pending_iwant_msgs; go asks every advertiser) replies IWANT; the
advertiser sends the full message unless that peer sent IDONTWANT. The
pending mark expires at the asker's next heartbeat (rust-libp2p). Heartbeats are
lazy: a node has a heartbeat event only while its gossip window holds a
message (phase `ctx.fraction("phase", "cl", node)` x heartbeat), which
emits exactly what a periodic heartbeat would. An IHAVE to a peer that
already has every listed message is counted (bytes) without an event.

Data columns (PeerDAS, Fulu). Custody groups map 1:1 to columns and
subnets (NUMBER_OF_COLUMNS = NUMBER_OF_CUSTODY_GROUPS = 128 [E]). A
node's custody group count: supernodes (`nodes.is_supernode`) 128;
validator-hosting nodes a draw from the measured cgc histogram restricted
to [VALIDATOR_CUSTODY_REQUIREMENT, 127] (`custody="hist"`, default; params
topology.custody_group_count_hist [C]) or exactly 8 (`custody=
"requirement"`, the STAGES.md reading); others CUSTODY_REQUIREMENT (4).
A node subscribes to max(SAMPLES_PER_SLOT, cgc) groups (das-core.md
custody sampling: sampling_size; fulu p2p: publish iff subscribed for
custody or sampling) chosen by the smallest `stable_fraction(seed,
"custody", node, j)`. Sidecar bytes = const + per_blob x blobs from
cl_gossip.data_column_sidecar_bytes (Fulu under MEV-boost, Gloas under
ePBS) [E layout, Mo bytes]. `net.columns=background` loads, instead of
messages, the publisher's 128 x fanout copies and each subscriber's
measured relay copies (cl_gossip.measured_duplicates
relay_copies_sent_mean, 3 [R+Mo]) onto CL lanes as fluid bytes, all at
the publish instant and on uplinks only (`links.load` has no receiver, so
downlinks carry none of it).
Not modelled: getBlobs distributed publishing and column reconstruction
(S3 can call `local_receipt` when a node obtains a column from its EL).

Reach. Per message a flat list of first-copy arrival times per node
(-1.0 = never; the publisher's is the publish time). `reach_time` and
`spread` give exact order statistics over any observer subset.
"""

from starksim.v3 import detmath
from starksim.v3 import params as P
from starksim.v3.state import LANE_CL
from starksim.v3.topology import (apportion, build_mesh, configuration_graph,
                                  deal)

TOPIC_BEACON_BLOCK = "beacon_block"
TOPIC_PAYLOAD = "execution_payload"
TOPIC_PAYLOAD_ATTESTATION = "payload_attestation"
TOPIC_INCLUSION_LIST = "inclusion_list"
COLUMN_TOPIC_PREFIX = "data_column_sidecar_"
SHARED_TOPICS = (TOPIC_BEACON_BLOCK, TOPIC_PAYLOAD,
                 TOPIC_PAYLOAD_ATTESTATION, TOPIC_INCLUSION_LIST)

# Event kinds S2b registers (owner prefix "cl."):
EV_HEARTBEAT = "cl.heartbeat"
EV_FORWARD = "cl.forward"      # validation delay over, forward to the mesh
EV_SLOW_START = "cl.slow_start"  # a copy held to its congestion-window floor

# Link message kinds (links.kind_bytes keys).
KIND_MSG = "cl.msg"                # a full copy, mesh / flood / fanout
KIND_IWANT_MSG = "cl.iwant_msg"    # a full copy answering IWANT
KIND_IDONTWANT = "cl.idontwant"
KIND_IHAVE = "cl.ihave"
KIND_IWANT = "cl.iwant"
KIND_COLUMNS_BG = "cl.columns_bg"

CLIENTS = ("lighthouse", "prysm", "teku", "lodestar", "nimbus", "grandine")
LIGHTHOUSE = 0
BUILDER_CLIENT = "prysm"           # [A] builders run go-libp2p rules
OTHER_CLIENTS = CLIENTS[1:]

# Flood publishing per client (module docstring has the sources).
FLOOD_NEVER = 0
FLOOD_ALWAYS = 1  # [A] enum
FLOOD_MAX_BYTES = 2                # [A] enum: flood only messages <= FLOOD_TEKU_MAX
FLOOD_BANDWIDTH = 3                # [A] enum: nimbus: peers limited by a bandwidth estimate
FLOOD_RULE = {"lighthouse": FLOOD_NEVER, "lodestar": FLOOD_NEVER,
              "prysm": FLOOD_NEVER, "teku": FLOOD_MAX_BYTES,
              "nimbus": FLOOD_BANDWIDTH, "grandine": FLOOD_ALWAYS}
FLOOD_TEKU_MAX = 16384             # [R] teku gossip config :39 (1 << 14)
NIMBUS_BANDWIDTH_BPMS = 12500      # [R] nim gossipsub.nim:134 100 Mbit/s = 12,500 B/ms
GRANDINE_TARGET_PEERS = 100        # [A] not read; Teku's upper bound
RUST_CLIENTS = ("lighthouse", "grandine")   # rust-libp2p (Grandine: a fork [Rc])
GO_CLIENTS = ("prysm",)                     # go-libp2p-pubsub
NIM_IDONTWANT_MIN = 512            # [R] nim gossipsub.nim:559 (> max(512, 10 x msg-id length))
GOSSIP_FACTOR = 0.25               # [R] go-libp2p gossipsub.go:61; rust-libp2p config.rs:517

# Validation delay before forwarding, ms.
VALIDATE_MS = {TOPIC_BEACON_BLOCK: 2.0,          # [R] v2 (arch.md 3.5)
               TOPIC_PAYLOAD: 2.0,               # [A] gossip checks only signatures (gloas p2p:823-893), as a block
               TOPIC_PAYLOAD_ATTESTATION: 1.0,   # [A] one BLS signature
               TOPIC_INCLUSION_LIST: 2.0}        # [A] as a block
VALIDATE_COLUMN_MS = 3.0           # [A] KZG cell-proof batch check of one sidecar

# Control message sizes, bytes (protobuf framing + 20 B message ids).
IDONTWANT_BYTES = 40               # [A] STAGES.md S2b
IHAVE_BASE_BYTES = 40              # [A] RPC + topic string
ID_BYTES = 22                      # [A] 20 B message id + 2 B protobuf tag/length
IWANT_BASE_BYTES = 8               # [A] RPC framing

DEFAULT_CHUNK_BYTES = 32768        # [A] processor-sharing granularity (one chunk at 25 Mbit/s = 10 ms)

# Congestion-window floor of a copy (net.cl_slow_start, stage S6). A copy of
# S bytes needs r(S) = min{r : IW x (2^r - 1) >= S} window rounds when the
# connection's window starts at IW (RFC 5681 3.1 slow start: the window
# doubles per RTT); it cannot arrive before t_send + (r - 1) x RTT + one-way
# latency, whatever the link rates. IW = 10 segments of 1,460 B (RFC 6928
# IW10, Linux default since 2.6.39; QUIC's RFC 9002 7.2 initial window is
# 10 x max datagram, the same order). "iw10" assumes every block-sized copy
# starts from IW: Linux restarts the window after an idle RTO
# (net.ipv4.tcp_slow_start_after_idle = 1 by default, RFC 5681 4.1) and
# otherwise decays an application-limited window towards what was used
# (RFC 2861 / RFC 7661); between blocks a gossip connection carries only
# small messages. Copies of at most IW bytes are unaffected.
SLOW_START_IW_BYTES = {"off": 0, "iw10": 14600, "conn": 14600}   # [E] RFC 6928: 10 x 1,460 B

# Per-connection congestion windows (net.cl_slow_start = "conn", stage S6b,
# notes/phase4/calib2.md M1). Each directed CL connection (src, dst) is
# drawn once: with probability net.cl_restart_share (params
# cl_restart_share, 0.57 = (1 - 0.40 QUIC share [C]) x 0.95 P(restart | TCP)
# [R + Mo]) it is a Linux TCP sender whose window is back at IW10 whenever a
# burst starts after more than one RTO without sending (tcp_cwnd_restart /
# RFC 2861 app-limited decay, calib2 1.3: trickle traffic does not keep it
# open); otherwise it keeps a persistent window (QUIC: quinn / quic-go never
# shrink an app-limited window, calib2 1.4; or TCP with BBR / sysctl 0).
# A burst is every copy sent on the connection until it idles for one RTO:
# its copies share the window (a block and the columns sent right after it
# queue behind the same slow-start rounds, calib2 3 (a)); a copy completing
# the burst's first B bytes cannot arrive before burst start + (r - 1) RTT +
# one way, r = min{r : W (2^r - 1) >= B} (slow start from W, no loss).
# At the end of a cwnd-limited burst a persistent window has grown by the
# bytes it carried (slow start adds one MSS per MSS acked, RFC 5681 3.1).
# A persistent window starts at cl_persistent_window_bytes (quinn's initial
# window, calib2 1.4) and persists with its growth: connections warm up over
# the run's first bursts (net.cl_persistent_window overrides it for the
# bracket 14,720 B / p99 block / unbounded, build-s6b.md 3). A copy cancelled
# by IDONTWANT before it started leaves its connection's burst (review fix).
TCP_RTO_MIN_MS = 200.0             # [R] linux include/net/tcp.h TCP_RTO_MIN (calib2 1.3); RTO ~ RTT + rto_min

P.register_bindings({
    "cl_idontwant_min_bytes": (P.NET, ("cl_gossip", "idontwant_min_bytes"),
                               None),
    "cl_idontwant_adoption": (P.NET, ("cl_gossip", "idontwant_adoption"),
                              None),
    "cl_target_peers": (P.NET, ("topology", "cl_mesh", "cl_target_peers"),
                        None),
    "cl_teku_peers_upper": (P.NET, ("cl_gossip", "cl.client",
                                    "teku peers upper"), None),
    "cl_v2_gossipsub": (P.NET, ("cl_gossip", "v2_gossipsub"), None),
    "cl_custody_requirement": (P.NET, ("cl_gossip", "cl.spec",
                                       "CUSTODY_REQUIREMENT"), None),
    "cl_validator_custody_requirement": (
        P.NET, ("cl_gossip", "cl.spec", "VALIDATOR_CUSTODY_REQUIREMENT"),
        None),
    "cl_samples_per_slot": (P.NET, ("cl_gossip", "cl.spec",
                                    "SAMPLES_PER_SLOT"), None),
    "cl_number_of_columns": (P.NET, ("cl_gossip", "cl.spec",
                                     "NUMBER_OF_COLUMNS"), None),
    "cl_custody_hist": (P.NET, ("topology", "custody_group_count_hist"),
                        None),
    "cl_sidecar_bytes": (P.NET, ("cl_gossip", "data_column_sidecar_bytes"),
                         None),
    "cl_measured_duplicates": (P.NET, ("cl_gossip", "measured_duplicates"),
                               None),
    # S6b calibration keys: sourced fallbacks until network_params_v3.json
    # carries a `calibration` section (values = data/phase4/
    # calib2_params.json; tests/v3/test_clgossip checks they agree).
    "cl_restart_share": (P.NET, ("calibration", "cl_restart_share"), (
        0.57,  # [Mo] calib2_params.json cl_restart_share_per_connection
        "data/phase4/calib2_params.json cl_restart_share_per_connection"
        " (range 0.46-0.64) = (1 - cl_quic_connection_share 0.40 [C] Xatu "
        "libp2p_disconnected 2026-11-10, long-lived outbound) x "
        "tcp_restart_given_tcp 0.95 ([R] Linux v6.12 tcp_cwnd_restart, "
        "RFC 2861 decay; [Mo] BBR/sysctl-0 share); notes/phase4/calib2.md "
        "1.2-1.5", "[Mo] product of [C] and [R]+[Mo]")),
    "cl_persistent_window_bytes": (P.NET, ("calibration",
                                           "cl_persistent_window_bytes"), (
        14720,  # [R] quinn-proto 0.11.12 initial window (calib2_params quic_window_after_idle)
        "initial persistent (QUIC) window = quinn-proto 0.11.12 initial "
        "window 14,720 B (Lighthouse, Grandine, Lodestar; quic-go 32 x "
        "1,252 B = 40,064 B for Prysm) [R], data/phase4/calib2_params.json "
        "quic_window_after_idle; the window then grows by slow start and "
        "never shrinks (calib2 1.4). S6b review: replaces an unsourced p99-"
        "block starting window", "[R]")),
})


class _Msg:
    """State of one message (lists indexed by node)."""

    __slots__ = ("msg_id", "topic", "size", "origin", "t_pub", "first",
                 "copies", "senders", "dontwant", "forwarded", "pending",
                 "on_first", "dup_bytes", "asked")

    def __init__(self, msg_id, topic, size, origin, t_pub, n, on_first):
        self.msg_id = msg_id
        self.topic = topic          # topic index
        self.size = size
        self.origin = origin
        self.t_pub = t_pub
        self.first = [-1.0] * n     # first-copy arrival, ms
        self.copies = [0] * n       # copies received
        self.senders = [0] * n      # bitset of peers that sent a copy
        self.dontwant = [0] * n     # bitset of peers that sent IDONTWANT
        self.forwarded = 0          # bitset of nodes that forwarded
        self.pending = {}           # node -> IWANT pending until (ms)
        self.asked = {}             # node -> bitset of peers sent IWANT
        self.on_first = on_first
        self.dup_bytes = 0


class _Copy:
    """One copy in flight (shared by its chunks)."""

    __slots__ = ("msg", "src", "dst", "cancelled", "kind", "floor")

    def __init__(self, msg, src, dst, kind, floor=0.0):
        self.msg = msg
        self.src = src
        self.dst = dst
        self.cancelled = False
        self.kind = kind
        self.floor = floor          # earliest arrival (congestion window)


class _Conn:
    """Congestion-window state of one directed CL connection (conn mode)."""

    __slots__ = ("restart", "window", "burst_t", "burst_bytes", "last_t")

    def __init__(self, restart, window):
        self.restart = restart      # restarts from IW after an idle RTO
        self.window = window        # bytes at the start of the burst
        self.burst_t = -1.0         # start of the current burst (ms)
        self.burst_bytes = 0        # bytes sent in the current burst
        self.last_t = -1.0          # last send (or window-bound arrival)


class ClGossip:
    def __init__(self, ctx, send_mode="parallel", chunk_bytes=None,
                 custody="hist", clients=None, peers=None,
                 idontwant_cancels=True):
        """Registers counters `cl.*` (copies received, duplicate copies and
        bytes, IDONTWANT sent and bytes saved, IHAVE/IWANT) and builds the
        column-subnet subscriptions (custody groups, supernodes = all).

        Keyword arguments (tests and sensitivities): `send_mode`
        "parallel" | "staggered"; `chunk_bytes`; `custody` "hist" |
        "requirement"; `clients` (a client name per node) and `peers` (a
        tuple of peers per node) override the drawn ones; with `peers`
        given, column meshes are not unioned into it."""
        if send_mode not in ("parallel", "staggered"):
            raise ValueError("send_mode must be parallel or staggered")
        if custody not in ("hist", "requirement"):
            raise ValueError("custody must be hist or requirement")
        self.ctx = ctx
        self.engine = ctx.engine
        self.links = ctx.links
        self.topo = ctx.topo
        self.nodes = ctx.nodes
        spec = ctx.spec
        params = ctx.params
        n = ctx.topo.n_total
        self.n = n
        self.send_mode = send_mode
        self.chunk = int(chunk_bytes or DEFAULT_CHUNK_BYTES)
        self.idontwant_on = bool(spec.net.idontwant)
        self.repair_on = bool(spec.net.gossip_repair)
        self.idontwant_cancels = idontwant_cancels
        self.columns_mode = spec.net.columns
        self.slow_start_mode = getattr(spec.net, "cl_slow_start", "off")
        self.slow_start_iw = 0 if spec.net.mode == "ideal" else \
            SLOW_START_IW_BYTES[self.slow_start_mode]
        self.conn_windows = self.slow_start_iw > 0 and \
            self.slow_start_mode == "conn"
        self._conn = {}                 # src * n + dst -> _Conn
        if self.conn_windows:
            share = spec.net.cl_restart_share
            self.restart_share = float(share if share is not None else
                                       params.value("cl_restart_share"))
            override = getattr(spec.net, "cl_persistent_window", None)
            self.persistent_window = (
                int(params.value("cl_persistent_window_bytes"))
                if override is None else
                (_UNBOUNDED_WINDOW if override == 0 else int(override)))
        self.pbs = spec.chain.pbs or _pbs_of(spec.deployment)

        v2 = params.value("cl_v2_gossipsub")
        self.mcache_gossip = int(v2["spec"]["mcache_gossip"])
        lighthouse_rules = v2["clients"]["lighthouse_default_load3"]
        self.d_low = int(params.value("cl_D_low"))
        self.d_default = int(params.value("cl_D"))

        # Clients and their rules.
        self.client = clients if clients is not None else \
            self._deal_clients(params)
        thresholds = params.value("cl_idontwant_min_bytes")
        targets = params.value("cl_target_peers")
        peer_target = {name: int(targets[name]) for name in
                       ("lighthouse", "lodestar", "prysm", "nimbus")}
        peer_target["teku"] = int(params.value("cl_teku_peers_upper"))
        peer_target["grandine"] = GRANDINE_TARGET_PEERS
        heartbeat = float(params.value("cl_heartbeat_ms"))
        d_lazy = int(params.value("cl_D_lazy"))
        self.threshold = [0] * n
        self.rust = [False] * n         # rust-libp2p rules (module docstring)
        self.go = [False] * n           # go-libp2p rules
        self.mesh_n = [self.d_default] * n
        self.flood = [FLOOD_NEVER] * n
        self.heartbeat_ms = [heartbeat] * n
        self.d_lazy = [d_lazy] * n
        for node in range(n):
            name = self.client[node]
            # IDONTWANT when size >= threshold: go `< threshold` skips
            # (gossipsub.go:879); rust sends when len > threshold
            # (behaviour.rs); nim when len > max(512, 10 x id length).
            self.threshold[node] = int(thresholds[name])
            self.rust[node] = name in RUST_CLIENTS
            self.go[node] = name in GO_CLIENTS
            if self.rust[node]:
                self.threshold[node] += 1
            elif name == "nimbus":
                self.threshold[node] = max(self.threshold[node],
                                           NIM_IDONTWANT_MIN) + 1
            self.flood[node] = FLOOD_RULE[name]
            if name == "lighthouse":
                self.heartbeat_ms[node] = float(
                    lighthouse_rules["heartbeat_ms"])
                self.d_lazy[node] = int(lighthouse_rules["D_lazy"])
                self.mesh_n[node] = int(lighthouse_rules["D"])
        adoption = float(params.value("cl_idontwant_adoption"))
        dealt = deal(apportion([1.0 - adoption, adoption], n),
                     ctx.stream("cl", "idontwant_support"))
        self.supports = [label == 1 for label in dealt]

        # Topics: shared ones then 128 column subnets.
        self.n_columns = int(params.value("cl_number_of_columns"))
        self.topic_names = list(SHARED_TOPICS) + [
            COLUMN_TOPIC_PREFIX + str(i) for i in range(self.n_columns)]
        self.topic_index = {name: index for index, name in
                            enumerate(self.topic_names)}
        everyone = (1 << n) - 1
        self.sub_bits = [everyone] * len(SHARED_TOPICS)
        self.mesh = [self.nodes.cl_mesh] * len(SHARED_TOPICS)
        self.validate_ms = [VALIDATE_MS[name] for name in SHARED_TOPICS]
        self._custody(params, custody)
        self._column_meshes()

        # CL peers.
        if peers is not None:
            self.peers = [tuple(p) for p in peers]
        else:
            self.peers = self._peer_graph(peer_target)
        peer_column = self.nodes.add_column("cl.peers", ())
        for node in range(n):
            peer_column[node] = self.peers[node]
        self._topic_peers = {}

        self.msgs = []
        self.by_id = {}
        self.gossip = [[] for _ in range(n)]   # [msg, beats left]
        self.beat_due = [-1.0] * n
        self.started = False

        counters = ctx.counters
        self.c_copies = counters.array("cl.copies_received", n, 0)
        self.c_dup = counters.array("cl.dup_copies", n, 0)
        self.c_dup_bytes = counters.array("cl.dup_bytes", n, 0)
        self.c_idw_sent = counters.array("cl.idontwant_sent", n, 0)
        self.c_idw_saved = counters.array("cl.idontwant_saved_bytes", n, 0)
        self.c_ihave = counters.array("cl.ihave_sent", n, 0)
        self.c_iwant = counters.array("cl.iwant_sent", n, 0)
        self.c_iwant_served = counters.array("cl.iwant_served", n, 0)
        counters.scalar("cl.messages", 0)
        counters.scalar("cl.ihave_events", 0)
        ctx.on(EV_FORWARD, self._forward)
        ctx.on(EV_SLOW_START, self._arrive_now)
        self.c_slow_start_held = counters.array("cl.slow_start_held", n, 0)
        ctx.on(EV_HEARTBEAT, self._heartbeat)

    # -- construction
    def _deal_clients(self, params):
        """Lighthouse = topology's deal (same stream); the rest equal."""
        topo_n = self.topo.n
        share = float(params.value("cl_lighthouse_share"))
        clients = [BUILDER_CLIENT] * self.n
        lighthouse = deal(apportion([1.0 - share, share], topo_n),
                          detmath.stream(self.ctx.seed, "topo", "cl_client"))
        others = [node for node in range(topo_n) if lighthouse[node] != 1]
        rest = deal(apportion([1.0] * len(OTHER_CLIENTS), len(others)),
                    self.ctx.stream("cl", "client_rest"))
        for node in range(topo_n):
            if lighthouse[node] == 1:
                clients[node] = "lighthouse"
        for position, node in enumerate(others):
            clients[node] = OTHER_CLIENTS[rest[position]]
        return clients

    def _custody(self, params, custody):
        n = self.n
        nodes = self.nodes
        n_columns = self.n_columns
        base = int(params.value("cl_custody_requirement"))
        validator_min = int(params.value("cl_validator_custody_requirement"))
        samples = int(params.value("cl_samples_per_slot"))
        hist = params.value("cl_custody_hist")
        values = []
        weights = []
        for key in sorted(hist, key=int):
            count = int(key)
            if validator_min <= count < n_columns:
                values.append(count)
                weights.append(float(hist[key]))
        cgc = self.nodes.add_column("cl.custody", 0)
        groups = self.nodes.add_column("cl.custody_groups", ())
        self.cgc = cgc
        self.sub_count = [0] * n
        column_bits = [0] * n_columns
        total = sum(weights)
        for node in range(n):
            if nodes.is_supernode[node]:
                count = n_columns
            elif nodes.is_validator[node]:
                if custody == "requirement" or not values:
                    count = validator_min
                else:
                    u = self.ctx.fraction("cl", "cgc", node) * total
                    count = values[-1]
                    acc = 0.0
                    for value, weight in zip(values, weights):
                        acc += weight
                        if u < acc:
                            count = value
                            break
            else:
                count = base
            cgc[node] = count
            sampled = max(samples, count)
            self.sub_count[node] = sampled
            if sampled >= n_columns:
                chosen = list(range(n_columns))
            else:
                order = sorted(range(n_columns), key=lambda j: (
                    self.ctx.fraction("custody", node, j), j))
                chosen = sorted(order[:sampled])
            groups[node] = tuple(chosen)
            for j in chosen:
                column_bits[j] |= 1 << node
        self.sub_bits.extend(column_bits)

    def _column_meshes(self):
        nodes = self.nodes
        for i in range(self.n_columns):
            bits_ = self.sub_bits[len(SHARED_TOPICS) + i]
            members = _members(bits_)
            mesh = [()] * self.n
            if len(members) > 1:
                built = build_mesh(members, [nodes.cl_D[m] or self.d_default
                                             for m in members],
                                   self.ctx.stream("topo", "column_mesh", i))
                for node in members:
                    mesh[node] = built[node]
            self.mesh.append(mesh)
            self.validate_ms.append(VALIDATE_COLUMN_MS)

    def _peer_graph(self, peer_target):
        n = self.n
        targets = [min(peer_target[self.client[node]], n - 1)
                   for node in range(n)]
        adjacency = configuration_graph(targets, self.ctx.stream(
            "cl", "peer_graph"))
        for mesh in self.mesh[:len(SHARED_TOPICS)]:
            for node in range(n):
                for peer in mesh[node]:
                    adjacency[node].add(peer)
                    adjacency[peer].add(node)
        return [tuple(sorted(adjacency[node])) for node in range(n)]

    # -- public interface
    def start(self):
        """Heartbeats are lazy (module docstring): a node schedules one
        only while its gossip window holds a message, so starting needs no
        event. Idempotent."""
        self.started = True

    def publish(self, node, topic, msg_id, size, on_first_receipt=None):
        """Publish a message from `node`. `on_first_receipt(node, msg_id,
        src)` runs at every node's first copy (after the topic's validation
        delay); ctx.hooks.cl_first_receipt is called as well. The publisher
        holds the message from now: its first-receipt time is the publish
        time and the callbacks run for it at once with src None."""
        msg = self._new_msg(node, topic, msg_id, size, on_first_receipt)
        t = msg.topic
        if self._subscribed(t, node):
            targets = self.mesh[t][node]
        else:
            targets = ()
        rule = self.flood[node]
        flood = (rule == FLOOD_ALWAYS or rule == FLOOD_BANDWIDTH or
                 (rule == FLOOD_MAX_BYTES and size <= FLOOD_TEKU_MAX))
        if flood:
            topic_peers = self.topic_peers(t, node)
            if rule == FLOOD_BANDWIDTH:
                ms_to_transmit = max(size // NIMBUS_BANDWIDTH_BPMS, 1)
                cap = max(int(self.heartbeat_ms[node]) // ms_to_transmit,
                          self.d_low)
                chosen = list(targets)
                known = set(chosen)
                # nim iterates a HashSet: a random order, not node ids.
                order = list(topic_peers)
                self.ctx.stream("cl", "flood_order", node, t).shuffle(order)
                for peer in order:
                    if len(chosen) >= cap:
                        break
                    if peer not in known:
                        chosen.append(peer)
                        known.add(peer)
                targets = tuple(chosen)
            else:
                targets = topic_peers
        elif len(targets) < self.mesh_n[node] and \
                (not targets or self.rust[node]):
            # Not subscribed: fanout peers (mesh_n of the topic peers).
            # rust-libp2p also tops a short mesh up to mesh_n at publish
            # (behaviour.rs filter_publish_candidates).
            topic_peers = [peer for peer in self.topic_peers(t, node)
                           if peer not in targets]
            rng = self.ctx.stream("cl", "fanout", node, t)
            rng.shuffle(topic_peers)
            extra = self.mesh_n[node] - len(targets)
            targets = tuple(sorted(tuple(targets) + tuple(topic_peers[:extra])))
        msg.forwarded |= 1 << node
        self._send(node, msg, targets, KIND_MSG)
        self._remember(node, msg)
        self._deliver_callbacks(node, msg, None)
        return msg_id

    def local_receipt(self, node, msg_id):
        """`node` obtains an existing message outside gossip (getBlobs,
        reconstruction): it is a first receipt from no peer at `now`,
        validated and forwarded like a gossip copy."""
        msg = self.by_id[msg_id]
        if msg.first[node] >= 0.0:
            return
        self._first(node, msg, None)

    def publish_columns(self, node, slot, blobs, on_first_receipt=None):
        """Publish the slot's 128 column sidecars for `blobs` blobs; returns
        their msg ids. Under net.columns=background, loads CL-lane bytes
        instead and returns []. `on_first_receipt(node, msg_id, src)` runs
        at every node's first copy of each column (S6b: data
        availability for the import step)."""
        if blobs <= 0:
            return []
        size = self.sidecar_bytes(blobs)
        if self.columns_mode == "background":
            self._columns_background(node, size)
            return []
        ids = []
        for i in range(self.n_columns):
            msg_id = (COLUMN_TOPIC_PREFIX, slot, i)
            self.publish(node, COLUMN_TOPIC_PREFIX + str(i), msg_id, size,
                         on_first_receipt)
            ids.append(msg_id)
        return ids

    def sidecar_bytes(self, blobs):
        """Bytes of one DataColumnSidecar carrying `blobs` cells."""
        table = self.ctx.params.value("cl_sidecar_bytes")
        layout = table["gloas" if self.pbs == "epbs" else "fulu"]
        return int(layout["const"]) + int(layout["per_blob"]) * int(blobs)

    def first_receipt(self, msg_id):
        """First-receipt time per node (list, -1.0 = never)."""
        return list(self.by_id[msg_id].first)

    def subscribers(self, topic):
        """Sorted node ids subscribed to `topic`."""
        return _members(self.sub_bits[self.topic_index[topic]])

    def topic_peers(self, t, node):
        """Peers of `node` subscribed to topic index `t` (sorted tuple)."""
        key = t * self.n + node
        cached = self._topic_peers.get(key)
        if cached is None:
            bits_ = self.sub_bits[t]
            subscribed = [peer for peer in self.peers[node]
                          if (bits_ >> peer) & 1]
            if t >= len(SHARED_TOPICS):
                # Column meshes are not unioned into `peers` (a node keeps
                # its peer target); their edges are topic peers.
                subscribed = sorted(set(subscribed) | set(self.mesh[t][node]))
            cached = tuple(subscribed)
            self._topic_peers[key] = cached
        return cached

    def copies(self, msg_id):
        """Copies received per node (the publisher's counts copies sent
        back to it by peers that got the message elsewhere first)."""
        return list(self.by_id[msg_id].copies)

    def reach_time(self, msg_id, q, observers=None):
        """Time by which a share q of `observers` (default: the topic's
        subscribers except the publisher) held the message: the ceil(q x count)-th smallest
        first-receipt time; -1.0 when fewer observers ever got it."""
        times = self._observer_times(msg_id, observers)
        rank = _ceil_rank(q, len(times))
        if rank == 0 or rank > len(times):
            return -1.0
        value = times[rank - 1]
        return value if value < _INF else -1.0

    def spread(self, msg_id, q, observers=None):
        """reach_time(q) minus the first observer's receipt (the Xatu
        `first -> reach q` metric); -1.0 when not reached."""
        times = self._observer_times(msg_id, observers)
        if not times or times[0] >= _INF:
            return -1.0
        reach = self.reach_time(msg_id, q, observers)
        return -1.0 if reach < 0.0 else reach - times[0]

    # -- internals
    def _observer_times(self, msg_id, observers):
        msg = self.by_id[msg_id]
        if observers is None:
            observers = [node for node in _members(self.sub_bits[msg.topic])
                         if node != msg.origin]
        times = []
        for node in observers:
            value = msg.first[node]
            times.append(value if value >= 0.0 else _INF)
        times.sort()
        return times

    def _subscribed(self, t, node):
        return (self.sub_bits[t] >> node) & 1 == 1

    def _new_msg(self, node, topic, msg_id, size, on_first):
        if msg_id in self.by_id:
            raise ValueError(f"message id {msg_id!r} published twice")
        t = self.topic_index[topic]
        msg = _Msg(msg_id, t, int(size), node, self.engine.now, self.n,
                   on_first)
        msg.first[node] = self.engine.now
        self.msgs.append(msg)
        self.by_id[msg_id] = msg
        self.ctx.counters.scalars["cl.messages"] += 1
        return msg

    def _send(self, src, msg, targets, kind, only_src=None):
        """Send full copies of msg from src to targets (in a stable random
        order), skipping peers that sent IDONTWANT or a copy (go-libp2p:
        only the first sender `only_src`, gossipsub.go:1406)."""
        if only_src is None:
            unwanted = msg.dontwant[src] | msg.senders[src]
        else:
            unwanted = msg.dontwant[src] | (1 << only_src)
        dsts = [dst for dst in targets if not (unwanted >> dst) & 1]
        if not dsts:
            return
        if len(dsts) > 1:
            self.ctx.stream("cl", "order", msg.msg_id, src,
                            kind).shuffle(dsts)
        links = self.links
        size = msg.size
        chunk = self.chunk
        floor = self._floor_fn(src, size)
        if self.send_mode == "staggered" or size <= chunk:
            for dst in dsts:
                record = _Copy(msg, src, dst, kind, floor(dst))
                links.send(src, dst, LANE_CL, kind, size, self._arrive,
                           (record, 0))
            return
        records = [_Copy(msg, src, dst, kind, floor(dst)) for dst in dsts]
        n_chunks = (size + chunk - 1) // chunk
        last = n_chunks - 1
        for index in range(n_chunks):
            piece = chunk if index < last else size - chunk * last
            for record in records:
                links.send(src, record.dst, LANE_CL, kind, piece,
                           self._arrive if index == last else None,
                           (record, index))

    def _floor_fn(self, src, size):
        """dst -> earliest arrival of a copy of `size` bytes sent now
        (SLOW_START_IW_BYTES); 0.0 when the window does not bind."""
        iw = self.slow_start_iw
        if self.conn_windows:
            return self._conn_floor_fn(src, size)
        if iw <= 0 or size <= iw:
            return _no_floor
        rounds = 1
        while iw * ((1 << rounds) - 1) < size:
            rounds += 1
        now = self.engine.now
        latency = self.topo.latency
        extra = 2 * (rounds - 1) + 1          # (r - 1) RTTs + one way

        def floor(dst):
            return now + extra * latency(src, dst)
        return floor

    def connection(self, src, dst):
        """The `_Conn` window state of the directed connection src -> dst
        (drawn on first use; conn mode only)."""
        key = src * self.n + dst
        state = self._conn.get(key)
        if state is None:
            restart = self.ctx.fraction("cl", "cwnd", src, dst) < \
                self.restart_share
            state = _Conn(restart, self.slow_start_iw if restart else
                          self.persistent_window)
            self._conn[key] = state
        return state

    def _conn_floor_fn(self, src, size):
        """Per-connection window floor (module comment at
        TCP_RTO_MIN_MS): every copy joins its connection's current burst,
        or starts one after an idle RTO."""
        now = self.engine.now
        latency = self.topo.latency
        iw = self.slow_start_iw

        def floor(dst):
            conn = self.connection(src, dst)
            one_way = latency(src, dst)
            if conn.burst_t < 0.0 or \
                    now - conn.last_t > 2.0 * one_way + TCP_RTO_MIN_MS:
                if conn.burst_t >= 0.0 and conn.burst_bytes > conn.window:
                    conn.window += conn.burst_bytes   # slow-start growth
                if conn.restart:
                    conn.window = iw
                conn.burst_t = now
                conn.burst_bytes = 0
            conn.burst_bytes += size
            window = conn.window
            if conn.burst_bytes <= window:
                conn.last_t = now
                return 0.0
            rounds = 1
            while window * ((1 << rounds) - 1) < conn.burst_bytes:
                rounds += 1
            at = conn.burst_t + (2 * (rounds - 1) + 1) * one_way
            conn.last_t = at if at > now else now
            return at
        return floor

    def _arrive(self, arg):
        record, _index = arg
        if record.cancelled:
            return
        if record.floor > self.engine.now:
            self.c_slow_start_held[record.dst] += 1
            self.engine.schedule_at(record.floor, EV_SLOW_START, record)
            return
        self._arrive_now(record)

    def _arrive_now(self, record):
        if record.cancelled:
            return
        msg = record.msg
        node = record.dst
        src = record.src
        msg.copies[node] += 1
        msg.senders[node] |= 1 << src
        self.c_copies[node] += 1
        if msg.first[node] >= 0.0:
            self.c_dup[node] += 1
            self.c_dup_bytes[node] += msg.size
            msg.dup_bytes += msg.size
            return
        self._first(node, msg, src)

    def _first(self, node, msg, src):
        now = self.engine.now
        msg.first[node] = now
        msg.pending.pop(node, None)
        asked = msg.asked.pop(node, 0)
        if self.idontwant_on and self.supports[node] and \
                msg.size >= self.threshold[node]:
            links = self.links
            sent = 0
            peers = self.mesh[msg.topic][node]
            if asked and self.rust[node]:
                # rust-libp2p also tells the peers it sent IWANT to
                # (behaviour.rs handle_received_message, gossip_promises).
                peers = tuple(peers) + tuple(
                    peer for peer in _members(asked) if peer not in peers)
            for peer in peers:
                if peer == src or not self.supports[peer]:
                    continue
                links.control(node, peer, KIND_IDONTWANT, IDONTWANT_BYTES,
                              self._idontwant, (msg, node, peer))
                sent += 1
            self.c_idw_sent[node] += sent
        self.engine.schedule_at(now + self.validate_ms[msg.topic], EV_FORWARD,
                                (msg, node, src))

    def _forward(self, payload):
        msg, node, src = payload
        msg.forwarded |= 1 << node
        self._send(node, msg, self.mesh[msg.topic][node], KIND_MSG,
                   only_src=src if self.go[node] else None)
        self._remember(node, msg)
        self._deliver_callbacks(node, msg, src)

    def _deliver_callbacks(self, node, msg, src):
        if msg.on_first is not None:
            msg.on_first(node, msg.msg_id, src)
        self.ctx.hooks.cl_first_receipt(node, self.topic_names[msg.topic],
                                        msg.msg_id, src)

    def _idontwant(self, payload):
        msg, sender, node = payload
        msg.dontwant[node] |= 1 << sender
        if not self.idontwant_cancels or not (msg.forwarded >> node) & 1:
            return
        if self.links.backlog(node, LANE_CL) <= 0.0:
            return
        state = {}

        def unwanted(kind, dst, arg):
            if dst != sender or (kind != KIND_MSG and kind != KIND_IWANT_MSG):
                return False
            record, index = arg
            if record.msg is not msg:
                return False
            if index == 0:
                state[0] = record
                return True
            return state.get(0) is record

        saved = self.links.cancel(node, LANE_CL, unwanted)
        if 0 in state:
            state[0].cancelled = True
            if self.conn_windows:
                # The cancelled copy never used the connection's window.
                conn = self._conn.get(node * self.n + sender)
                if conn is not None and conn.burst_bytes >= msg.size:
                    conn.burst_bytes -= msg.size
        self.c_idw_saved[node] += saved

    # -- IHAVE / IWANT
    def _remember(self, node, msg):
        if not self.repair_on:
            return
        self.gossip[node].append([msg, self.mcache_gossip])
        if self.beat_due[node] < 0.0:
            self._schedule_beat(node)

    def _schedule_beat(self, node):
        now = self.engine.now
        period = self.heartbeat_ms[node]
        phase = self.ctx.fraction("phase", "cl", node) * period
        beats = int((now - phase) // period) + 1
        if beats < 0:
            beats = 0
        due = phase + beats * period
        if due <= now:
            due += period
            beats += 1
        self.beat_due[node] = due
        self.engine.schedule_at(due, EV_HEARTBEAT, (node, beats))

    def _next_beat(self, node, now):
        """The node's first heartbeat instant after `now` (rust-libp2p
        clears pending IWANTs at each heartbeat)."""
        period = self.heartbeat_ms[node]
        phase = self.ctx.fraction("phase", "cl", node) * period
        due = phase + max(int((now - phase) // period) + 1, 0) * period
        return due + period if due <= now else due

    def _heartbeat(self, payload):
        node, beat = payload
        self.beat_due[node] = -1.0
        window = self.gossip[node]
        by_topic = {}
        for entry in window:
            msg = entry[0]
            by_topic.setdefault(msg.topic, []).append(msg)
            entry[1] -= 1
        self.gossip[node] = [entry for entry in window if entry[1] > 0]
        for t, msgs in by_topic.items():
            self._emit_gossip(node, beat, t, msgs)
        if self.gossip[node]:
            self._schedule_beat(node)

    def _emit_gossip(self, node, beat, t, msgs):
        mesh = self.mesh[t][node]
        candidates = [peer for peer in self.topic_peers(t, node)
                      if peer not in mesh]
        if not candidates:
            return
        target = max(self.d_lazy[node],
                     int(GOSSIP_FACTOR * len(candidates)))
        if target < len(candidates):
            self.ctx.stream("cl", "ihave", node, beat, t).shuffle(candidates)
            candidates = candidates[:target]
        size = IHAVE_BASE_BYTES + ID_BYTES * len(msgs)
        links = self.links
        now = self.engine.now
        for peer in candidates:
            self.c_ihave[node] += 1
            useful = [msg for msg in msgs if msg.first[peer] < 0.0 and
                      msg.pending.get(peer, -1.0) < now]
            if useful:
                self.ctx.counters.scalars["cl.ihave_events"] += 1
                links.control(node, peer, KIND_IHAVE, size, self._ihave,
                              (node, peer, useful))
            else:
                links.ctrl_bytes_up[node] += size
                links.ctrl_bytes_down[peer] += size
                links.kind_bytes[KIND_IHAVE] = (
                    links.kind_bytes.get(KIND_IHAVE, 0) + size)

    def _ihave(self, payload):
        src, node, msgs = payload
        now = self.engine.now
        wanted = []
        for msg in msgs:
            if msg.first[node] >= 0.0 or msg.pending.get(node, -1.0) >= now:
                continue
            msg.pending[node] = self._next_beat(node, now)
            msg.asked[node] = msg.asked.get(node, 0) | (1 << src)
            wanted.append(msg)
        if not wanted:
            return
        self.c_iwant[node] += 1
        self.links.control(node, src, KIND_IWANT,
                           IWANT_BASE_BYTES + ID_BYTES * len(wanted),
                           self._iwant, (node, src, wanted))

    def _iwant(self, payload):
        asker, node, msgs = payload
        for msg in msgs:
            if (msg.dontwant[node] >> asker) & 1:
                continue
            self.c_iwant_served[node] += 1
            # An IWANT answer ignores `senders` (the asker asked).
            saved = msg.senders[node]
            msg.senders[node] = saved & ~(1 << asker)
            self._send(node, msg, (asker,), KIND_IWANT_MSG)
            msg.senders[node] = saved

    def _columns_background(self, node, size):
        relay = float(self.ctx.params.value("cl_measured_duplicates")[
            "relay_copies_sent_mean"])
        links = self.links
        base = len(SHARED_TOPICS)
        for i in range(self.n_columns):
            t = base + i
            fanout = len(self.mesh[t][node]) or self.d_default
            links.load(node, LANE_CL, KIND_COLUMNS_BG, size * fanout)
            for member in _members(self.sub_bits[t]):
                if member != node:
                    links.load(member, LANE_CL, KIND_COLUMNS_BG,
                               int(size * relay))


_INF = float("inf")
_UNBOUNDED_WINDOW = 1 << 62   # [A] net.cl_persistent_window = 0: no persistent-window limit


def _no_floor(_dst):
    return 0.0


def _members(bitset):
    result = []
    while bitset:
        low = bitset & -bitset
        result.append(low.bit_length() - 1)
        bitset ^= low
    return result


def _ceil_rank(q, count):
    """ceil(q x count) without float surprises at exact products."""
    scaled = q * count
    rank = int(scaled)
    if rank < scaled - 1e-9:  # [A] float tolerance
        rank += 1
    return max(rank, 1) if count else 0


def _pbs_of(deployment):
    from starksim.v3.deploy import PBS_OF
    return PBS_OF[deployment]

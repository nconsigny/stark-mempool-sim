"""Slot clock, PBS, canonical decision, FOCIL, import CPU (arch.md 3.6).
Stage S3a.

Per slot s, t0 = s x slot_ms. Two PBS modes (`deploy.pbs`):

`mevboost` (deployment today, Fulu mainnet):
    t0 + r     the full block (beacon block with the payload) is published
               on `beacon_block` from the builder's node (the relay's
               broadcast; [A]); r is drawn per slot from params
               `slot.proposer_release_ms` (inverse CDF of the first-seen
               bins, uniform inside a bin, minus 50 ms for the first hop:
               the leaf's `draw` text). The builder's view is frozen at
               t0 + r (no build latency [A]).
    t0 + 4 s   attestation deadline (`forks.today.attestation_due_ms`): the
               block is canonical iff at least REORG_THRESHOLD of the
               validator-hosting nodes imported it (receipt + import CPU)
               by then; otherwise the next proposer re-orgs it (orphaned).

`epbs` (8141, 8288, leanpcs; EIP-7732, spec.md T6-T7):
    t0 - m     the slot's builder freezes its payload (the bid commits the
               block hash, T7): m = `prover.bid_margin_ms` (8288/leanPCS
               add their proof time inside `deploy.build`).
    t0 + r'    the proposer publishes the beacon block carrying the bid,
               r' = r x (attestation due under ePBS / today's) [A]: timing
               games keep their position relative to the deadline.
    builder    reveals the payload envelope on `execution_payload` when it
               receives that beacon block, if by PAYLOAD_DUE (50 %); else
               the payload is withheld (missed).
    25 %       attestation deadline: beacon block canonical iff at least
               REORG_THRESHOLD of validator nodes received it.
    75 %       PTC deadline: the payload is canonical iff the block is and
               more than PAYLOAD_TIMELY_THRESHOLD (256) of PTC_SIZE (512)
               seats, drawn with replacement from validator nodes per slot,
               received it by then.

A slot is skipped with probability `slot.missed_slot_share` (an input:
offline proposers). Canonical payloads: `demand.background_included`, then
`demand.on_payload`, then the txs are marked included and
`hooks.payload_canonical` fires; every node unpools the payload's txs when
it holds the payload and the decision is known (`deploy.drop_included`).
Orphaned or missed payloads leave their txs pooled everywhere (counted as
`slot.txs_requeued`), so the next builders re-offer them.

FOCIL (Hegota, spec.md T8, A14; `chain.focil`): 16 IL members per slot
(validator nodes) each build at the end of the IL window (8 s at 12 s) an
inclusion list of at most 8,192 B of txs from their pool, best effective
tip first, and publish it on `inclusion_list`; the builder of slot s+1
takes the txs of every IL it received by INCLUSION_LIST_DUE (75 %) first.
With the fluid ECDSA background, ILs can only carry explicit txs (PQ txs):
an [A] bias toward PQ, at most 16 txs per slot.

Import (S6b, notes/phase4/calib2.md M2): a node imports a payload when it
holds the payload (gossip receipt, after gossip validation) AND the slot's
data is available to it (`net.import_waits_for_columns`, default on; Fulu
fork-choice `is_data_available`): every column it samples (custody or
SAMPLES_PER_SLOT), or any NUMBER_OF_COLUMNS / 2 = 64 columns when it samples
at least 64 (reconstruction, whose compute time is not modelled). Then it
runs `deploy.import_ms` (EL execution, gas-scaled) on its CPU. Without
blobs, or with net.columns=background, data is available at receipt. The
import time per node is the "after-import" event (beacon-API `block`) that
metrics reports beside the gossip receipt. A validator that has not
imported a payload by its next attestation (ePBS: slot s+1 at 25 %;
MEV-boost: the same slot's deadline, so a MEV-boost vote needs the import)
is counted in `slot.imports_late`.

Local building (S6b, calib2 M3; MEV-boost only): with probability
`chain.local_build_share` (params local_build_share 0.088 [C]) a slot is
built by its proposer from its own pool and the block and its columns are
published from the proposer's node and uplink (home or datacentre), not
from a builder/relay node. ePBS deployments keep their builders (no source
for a self-build share under EIP-7732).
"""

from starksim.v3 import params as P
from starksim.v3.clgossip import (TOPIC_BEACON_BLOCK, TOPIC_INCLUSION_LIST,
                                  TOPIC_PAYLOAD)
from starksim.v3.state import KIND_ECDSA, NOT_INCLUDED

P.register_bindings({
    "slot_proposer_release_ms": (P.NET, ("slot", "proposer_release_ms"),
                                 None),
    "slot_missed_share": (P.NET, ("slot", "missed_slot_share"), None),
    "slot_blobs_per_block": (P.NET, ("slot", "blobs_per_block"), None),
    "slot_block_bytes_snappy": (P.NET, ("slot", "block_bytes_snappy"), None),
    "slot_block_bytes_ssz": (P.NET, ("slot", "block_bytes_ssz"), None),
    # S6b: sourced fallback until network_params_v3.json carries it.
    "local_build_share": (P.NET, ("calibration", "local_build_share"), (
        0.088,  # [C] calib2_params.json local_build_share (relayscan 7d)
        "data/phase4/calib2_params.json local_build_share: relayscan "
        "7d overview (data/phase4/sources/relayscan/overview-7d.html, at slot "
        "15636733) 45,778 builder payloads / 50,400 slots = 0.908 MEV-Boost, "
        "minus missed 0.00375 (Xatu); notes/phase4/calib2.md 2", "[C]")),
})

EV_START = "slot.start"
EV_FREEZE = "slot.freeze"
EV_RELEASE = "slot.release"
EV_ATTEST = "slot.attestation_deadline"
EV_PTC = "slot.ptc_deadline"
EV_IL = "slot.il_build"

RECONSTRUCT_FRACTION = 2     # [E] fulu das-core: any NUMBER_OF_COLUMNS // 2 columns recover the blobs
FIRST_HOP_MS = 50.0          # [R] params slot.proposer_release_ms draw: "minus 50 ms for the first hop"
RELEASE_BIN_MS = 250.0       # [R] params slot.proposer_release_ms cdf_250ms_bins width
REORG_THRESHOLD = 0.2        # [Rc] consensus-specs REORG_HEAD_WEIGHT_THRESHOLD 20 %: a block below it is re-orged
BEACON_OVERHEAD_BYTES = 8_000  # [A] compressed beacon block body without the payload (attestations, sync aggregate)
IL_FALLBACK_MS = 7_000       # [E] eip-7805.md:43 "if no block is received by t=7s"
IL_BUILDER_FREEZE_MS = 11_000  # [E] eip-7805.md:58-60 builder freezes its IL view at t=11s
IL_OVERHEAD_BYTES = 100      # [A] signed InclusionList envelope around the tx bytes
IL_SCAN_LIMIT = 256          # [A] performance only: IL member scans its 256 best txs
PQ_COMPRESSION = 1.0         # [A] signature bytes are high-entropy: snappy leaves them as is
BPS = 10_000                 # [E] basis points of a slot (consensus-specs *_BPS)


class SlotState:
    __slots__ = ("slot", "t0", "missed_input", "proposer", "builder",
                 "release_ms", "payload", "block_id", "payload_id",
                 "published_ms", "votes", "voted", "block_canonical",
                 "canonical", "seen", "il_txs", "il_members", "blobs",
                 "seen_set", "il_built", "imported", "column_ids",
                 "base_fee", "block_quorum_ms", "payload_quorum_ms",
                 "local_build", "received", "columns_held", "available",
                 "import_at", "el_ms")

    def __init__(self, slot, t0):
        self.slot = slot
        self.t0 = t0
        self.missed_input = False
        self.proposer = -1
        self.builder = -1
        self.release_ms = 0.0
        self.payload = None
        self.block_id = None
        self.payload_id = None
        self.published_ms = -1.0
        self.votes = 0
        self.voted = set()
        self.block_canonical = None
        self.canonical = None
        self.seen = []
        self.il_txs = []
        self.il_members = None
        self.seen_set = set()
        self.il_built = set()
        self.imported = {}
        self.blobs = 0
        self.column_ids = ()
        self.base_fee = None
        self.block_quorum_ms = None
        self.payload_quorum_ms = None
        self.local_build = False
        self.received = {}          # node -> payload receipt (ms)
        self.columns_held = {}      # node -> columns held so far
        self.available = {}         # node -> data available (ms)
        self.import_at = {}         # node -> import done (ms), every node
        self.el_ms = {}             # node -> EL execution (CPU ms)


class SlotClock:
    def __init__(self, ctx, deploy):
        self.ctx = ctx
        self.deploy = deploy
        spec = ctx.spec
        params = ctx.params
        self.pbs = deploy.pbs
        self.slot_ms = float(spec.chain.slot_ms)
        if spec.deployment == "today":
            fork = params.fork("today")
        else:
            fork = params.fork(params.deployment_entry(spec.deployment)
                               ["fork"])
        self.fork = fork
        scale = self.slot_ms / 12_000.0  # [E] deadlines are bps of the 12 s mainnet slot
        today = params.fork("today")
        today_att = float(today["attestation_due_ms"]["value"]) * scale
        if self.pbs == "epbs":
            self.att_due = _bps(fork["attestation_due_bps"], self.slot_ms)
            self.payload_due = _bps(fork["payload_due_bps"], self.slot_ms)
            self.ptc_due = _bps(fork["ptc_due_bps"], self.slot_ms)
            self.ptc_size = int(fork["ptc_size"]["value"])
            self.ptc_threshold = int(fork["payload_timely_threshold"]
                                     ["value"])
            self.release_scale = self.att_due / today_att
        else:
            self.att_due = today_att
            self.payload_due = self.att_due
            self.ptc_due = None
            self.release_scale = 1.0
        self.margin = float(spec.prover.bid_margin_ms)
        self.wait_columns = bool(spec.net.import_waits_for_columns)
        self.local_share = 0.0
        if self.pbs == "mevboost":
            share = spec.chain.local_build_share
            self.local_share = float(share if share is not None else
                                     params.value("local_build_share"))
        self.focil = None
        if spec.chain.focil and self.pbs == "epbs" and "focil" in fork:
            value = fork["focil"]["value"]
            if isinstance(value, dict):
                self.focil = {
                    "members": int(value["committee_size"]),
                    "max_bytes": int(value["max_bytes_per_il"]),
                    "due": _bps_value(value["il_due_bps"], self.slot_ms),
                    # Members build after processing slot N's payload,
                    # by 7 s at the latest (eip-7805.md:42-43); the
                    # window end (8 s) is when ILs are due on the wire.
                    "build": IL_FALLBACK_MS * scale,
                    "builder_due": IL_BUILDER_FREEZE_MS * scale,
                }
        release = params.value("slot_proposer_release_ms")["cdf_250ms_bins"]
        self.release_bins = [(float(t), float(f)) for t, f in release]
        self.missed_share = float(params.value("slot_missed_share"))
        hist = params.value("slot_blobs_per_block")["hist"]
        self.blob_values = [int(b) for b, _w in hist]
        self.blob_weights = [float(w) for _b, w in hist]
        snappy = params.value("slot_block_bytes_snappy")
        ssz = params.value("slot_block_bytes_ssz")
        self.ecdsa_compression = float(snappy[1]) / float(ssz[1])
        topo = ctx.topo
        nodes = ctx.nodes
        self.validators = [node for node in range(topo.n)
                           if nodes.is_validator[node]]
        self.is_validator = nodes.is_validator
        self.builders = list(topo.builders)
        self.states = {}
        self.records = []
        self._il_content = {}
        counters = ctx.counters
        for name in ("slots_missed_input", "blocks_orphaned",
                     "payloads_missed", "payloads_withheld",
                     "payloads_canonical", "txs_requeued", "imports_late",
                     "il_txs", "il_published"):
            counters.scalar("slot." + name)
        ctx.on(EV_START, self._start)
        ctx.on(EV_FREEZE, self._freeze)
        ctx.on(EV_RELEASE, self._release)
        ctx.on(EV_ATTEST, self._attest)
        ctx.on(EV_PTC, self._ptc)
        ctx.on(EV_IL, self._il_build)
        for name in ("payload_canonical", "payload_missed"):
            if getattr(ctx.hooks, name).__name__ == "fail":
                ctx.hooks.wire(name, _noop)
        if getattr(ctx.hooks, "cl_first_receipt").__name__ == "fail":
            ctx.hooks.wire("cl_first_receipt", _noop)
        ctx.slot = self

    # ------------------------------------------------------------ draws
    def release_ms(self, slot):
        """Proposer release after slot start (ms) for `slot`."""
        u = self.ctx.fraction("slot", "release", slot)
        low_f = 0.0
        value = self.release_bins[-1][0] + RELEASE_BIN_MS
        for t, f in self.release_bins:
            if u < f:
                width = f - low_f
                inside = (u - low_f) / width if width > 0 else 0.0
                value = t + inside * RELEASE_BIN_MS
                break
            low_f = f
        return max(0.0, value - FIRST_HOP_MS) * self.release_scale

    def blobs(self, slot):
        u = self.ctx.fraction("slot", "blobs", slot) * sum(self.blob_weights)
        acc = 0.0
        for value, weight in zip(self.blob_values, self.blob_weights):
            acc += weight
            if u < acc:
                return value
        return self.blob_values[-1]

    def proposer(self, slot):
        pool = self.validators or list(range(self.ctx.topo.n))
        index = int(self.ctx.fraction("slot", "proposer", slot) * len(pool))
        return pool[min(index, len(pool) - 1)]

    def builder(self, slot):
        if not self.builders:
            return self.proposer(slot)
        if self.ctx.spec.chain.builder_choice == "max_fee":
            return max(self.builders, key=lambda b: (self._pool_value(b), -b))
        return self.builders[slot % len(self.builders)]

    def _pool_value(self, builder):
        deploy = self.deploy
        txs = self.ctx.txs
        base = deploy.base_fee()
        gas_left = self.ctx.spec.chain.gas_limit or float("inf")
        value = 0
        for tx in deploy.pool.fee_order(builder, base):
            if txs.gas[tx] <= gas_left:
                gas_left -= txs.gas[tx]
                value += txs.gas[tx] * max(0, min(txs.tip[tx],
                                                  txs.fee_cap[tx] - base))
        return value

    # --------------------------------------------------------- schedule
    def schedule(self, n_slots):
        """Schedule slots 0..n_slots-1."""
        for slot in range(n_slots):
            t0 = slot * self.slot_ms
            state = SlotState(slot, t0)
            self.states[slot] = state
            self.ctx.at(t0, EV_START, slot)
            if self.pbs == "epbs":
                self.ctx.at(max(0.0, self.freeze_ms(slot)), EV_FREEZE, slot)
            if self.focil is not None:
                self.ctx.at(t0 + self.focil["build"], EV_IL, slot)

    def freeze_ms(self, slot):
        """ePBS: when the builder of `slot` calls `deploy.build`. Default
        t0 - bid margin; a plug-in may define `freeze_ms(slot, t0, margin)`
        (8288/leanPCS: earlier, to leave room for the final proof)."""
        t0 = slot * self.slot_ms
        hook = getattr(self.deploy, "freeze_ms", None)
        if callable(hook):
            return float(hook(slot, t0, self.margin))
        return t0 - self.margin

    def undecided_payloads(self, slot, node):
        """[(earlier_slot, payload)] of earlier payloads `node` holds whose
        canonical decision is still pending at `now`, oldest first: a
        builder freezing before the parent's PTC decision builds on that
        parent (review F5). Its PQ txs: `undecided_cover`; its fluid
        background records: `demand.background_offer(..., undecided=)`."""
        result = []
        for earlier in (slot - 2, slot - 1):
            state = self.states.get(earlier)
            if state is not None and state.canonical is None and \
                    state.payload is not None and node in state.seen_set:
                result.append((earlier, state.payload))
        return result

    def undecided_cover(self, slot, node):
        """Bitset of txs in earlier payloads `node` holds whose canonical
        decision is still pending at `now` (`undecided_payloads`)."""
        cover = 0
        for _earlier, payload in self.undecided_payloads(slot, node):
            cover |= payload.cover
        return cover

    def bid_ms(self, slot):
        """ePBS: the payload (and any proof) must be ready by the bid."""
        return max(0.0, slot * self.slot_ms - self.margin)

    def parent_seen_ms(self, node, slot):
        """When `node` first held the payload of slot - 1 (-1.0: never or
        no payload): the opening of an 8288 builder's proof window."""
        state = self.states.get(slot - 1)
        if state is None or state.payload_id is None:
            return -1.0
        return self.ctx.cl.first_receipt(state.payload_id)[node]

    def _start(self, slot):
        state = self.states[slot]
        if self.ctx.fraction("slot", "missed", slot) < self.missed_share:
            state.missed_input = True
            self.ctx.counters.scalars["slot.slots_missed_input"] += 1
            return
        state.proposer = self.proposer(slot)
        state.builder = (state.builder if state.builder >= 0
                         else self.builder(slot))
        state.release_ms = self.release_ms(slot)
        state.blobs = self.blobs(slot)
        self.ctx.at(state.t0 + state.release_ms, EV_RELEASE, slot)
        self.ctx.at(state.t0 + self.att_due, EV_ATTEST, slot)
        if self.pbs == "epbs":
            self.ctx.at(state.t0 + self.ptc_due, EV_PTC, slot)

    def _il_for(self, slot):
        previous = self.states.get(slot - 1)
        return list(previous.il_txs) if previous is not None else []

    def _freeze(self, slot):
        """ePBS: the builder fixes its payload before the bid."""
        state = self.states[slot]
        if state.builder < 0:
            state.builder = self.builder(slot)
        state.payload = self.deploy.build(state.builder, slot,
                                          self.ctx.now(),
                                          il_txs=self._il_for(slot))

    def wire_bytes(self, payload):
        """Snappy-compressed gossip bytes of a payload: ECDSA bytes at the
        measured block ratio (snappy p50 / SSZ p50 [C]), PQ bytes as is."""
        txs = self.ctx.txs
        explicit_ecdsa = 0
        explicit_pq = 0
        for tx in payload.txs:
            if txs.kind[tx] == KIND_ECDSA:
                explicit_ecdsa += txs.bytes_chain[tx]
            else:
                explicit_pq += txs.bytes_chain[tx]
        other = payload.bytes - explicit_ecdsa - explicit_pq
        return int(self.ecdsa_compression * (explicit_ecdsa + other)
                   + PQ_COMPRESSION * explicit_pq)

    def _release(self, slot):
        state = self.states[slot]
        ctx = self.ctx
        cl = ctx.cl
        now = ctx.now()
        if self.pbs == "mevboost":
            if self.local_share > 0.0 and state.proposer >= 0 and \
                    self.ctx.fraction("slot", "local_build", slot) < \
                    self.local_share:
                # Local build (calib2 M3): the proposer builds from its
                # own pool and publishes from its own node.
                state.local_build = True
                state.builder = state.proposer
            state.payload = self.deploy.build(state.builder, slot, now,
                                              il_txs=self._il_for(slot))
            size = BEACON_OVERHEAD_BYTES + self.wire_bytes(state.payload)
            state.published_ms = now
            state.block_id = ("block", slot)
            state.payload_id = state.block_id
            # MEV-boost: the relay broadcasts the signed block (and its
            # columns) from well-connected nodes, and the release draw is
            # the first sighting of that broadcast [C]: publish from the
            # builder's datacentre node, not the proposer's uplink [A]
            # (builder-specs submitBlindedBlockV2: the relay MUST publish
            # the block and blobs [E], calib2 C2-10).
            source = state.builder if state.builder >= 0 else state.proposer
            cl.publish(source, TOPIC_BEACON_BLOCK, state.block_id,
                       size, self._block_receipt)
            state.column_ids = tuple(cl.publish_columns(
                source, slot, state.blobs, self._column_hook()))
            return
        state.block_id = ("block", slot)
        cl.publish(state.proposer, TOPIC_BEACON_BLOCK, state.block_id,
                   BEACON_OVERHEAD_BYTES, self._block_receipt)

    # ---------------------------------------------------------- receipts
    def _block_receipt(self, node, msg_id, src):
        slot = msg_id[1]
        state = self.states[slot]
        now = self.ctx.now()
        if self.pbs == "mevboost":
            self._payload_receipt(node, msg_id, src)
            return
        if self.is_validator[node] and now <= state.t0 + self.att_due:
            if node not in state.voted:
                state.voted.add(node)
                state.votes += 1
        if node == state.builder:
            if now <= state.t0 + self.payload_due and \
                    state.payload is not None and \
                    state.payload.ready_at <= self.bid_ms(slot) + 1e-9:  # [A] float slack
                self._reveal(state)
            else:
                self.ctx.counters.scalars["slot.payloads_withheld"] += 1

    def _reveal(self, state):
        cl = self.ctx.cl
        state.published_ms = self.ctx.now()
        state.payload_id = ("payload", state.slot)
        cl.publish(state.builder, TOPIC_PAYLOAD, state.payload_id,
                   self.wire_bytes(state.payload), self._payload_receipt)
        state.column_ids = tuple(cl.publish_columns(
            state.builder, state.slot, state.blobs, self._column_hook()))

    # ------------------------------------------------- data availability
    def _column_hook(self):
        """Column first-receipt callback, or None when import does not
        wait for columns."""
        return self._column_receipt if self.wait_columns else None

    def columns_needed(self, node):
        """Columns `node` must hold for the slot's data to be available:
        its sampled columns, or half of all when it samples at least half
        (reconstruction)."""
        cl = self.ctx.cl
        sampled = cl.sub_count[node]
        half = cl.n_columns // RECONSTRUCT_FRACTION
        return half if sampled >= half else sampled

    def _column_receipt(self, node, msg_id, src):
        slot = msg_id[1]
        state = self.states.get(slot)
        if state is None or node in state.available:
            return
        held = state.columns_held.get(node, 0) + 1
        state.columns_held[node] = held
        if held >= self.columns_needed(node):
            state.available[node] = self.ctx.now()
            if node in state.received:
                self._start_import(node, state)

    def _data_available(self, node, state):
        if not self.wait_columns or not state.column_ids:
            return True
        return node in state.available

    def _start_import(self, node, state):
        deploy = self.deploy
        duration = deploy.import_ms(node, state.payload)
        state.el_ms[node] = duration
        deploy.cpu.run(node, duration, self._imported, (node, state.slot))

    def _payload_receipt(self, node, msg_id, src):
        slot = msg_id[1]
        state = self.states[slot]
        deploy = self.deploy
        state.received[node] = self.ctx.now()
        if self._data_available(node, state):
            self._start_import(node, state)
        state.seen.append(node)
        state.seen_set.add(node)
        if state.canonical:
            deploy.drop_included(node, state.payload)
        if self.focil is not None and self.pbs == "epbs":
            self._il_maybe_build(node, slot)

    def _imported(self, arg):
        node, slot = arg
        state = self.states[slot]
        now = self.ctx.now()
        state.import_at[node] = now
        if not self.is_validator[node]:
            return
        state.imported[node] = now
        if self.pbs == "mevboost":
            if now <= state.t0 + self.att_due:
                if node not in state.voted:
                    state.voted.add(node)
                    state.votes += 1
            else:
                self.ctx.counters.scalars["slot.imports_late"] += 1
        elif now > state.t0 + self.slot_ms + self.att_due:
            self.ctx.counters.scalars["slot.imports_late"] += 1

    # --------------------------------------------------------- decisions
    def _attest(self, slot):
        state = self.states[slot]
        quorum = REORG_THRESHOLD * max(1, len(self.validators))
        votes = state.votes
        parent = self.states.get(slot - 1)
        if self.ctx.spec.chain.late_import == "orphan_vote" and \
                self.pbs == "epbs" and parent is not None and \
                parent.canonical and parent.payload_id is not None:
            # A validator that has not imported the parent payload by its
            # attestation cannot vote for this block (arch.md 3.6).
            deadline = state.t0 + self.att_due
            imported = parent.imported
            kept = {node for node in state.voted
                    if imported.get(node, deadline + 1.0) <= deadline}
            votes = len(kept)
            state.votes = votes
            state.voted = kept     # the quorum time counts these only
        state.block_canonical = votes >= quorum
        state.block_quorum_ms = self._block_quorum_ms(state, quorum)
        if self.pbs == "mevboost":
            self._decide(state, state.block_canonical, "orphaned")

    def _ptc(self, slot):
        state = self.states[slot]
        if not state.block_canonical:
            self._decide(state, False, "orphaned")
            return
        if state.payload_id is None:
            self._decide(state, False, "missed")
            return
        first = self.ctx.cl.first_receipt(state.payload_id)
        # PTC members vote at 75 % on whether they saw the envelope before
        # PAYLOAD_DUE_BPS (eip-7732.md:502; review F2). Blob availability
        # (the second PTC vote) is not checked (columns may be fluid).
        deadline = state.t0 + self.payload_due
        rng = self.ctx.stream("slot", "ptc", slot)
        pool = self.validators or list(range(self.ctx.topo.n))
        timely = 0
        seen = []
        for _seat in range(self.ptc_size):
            node = pool[min(int(rng.random() * len(pool)), len(pool) - 1)]
            if 0.0 <= first[node] <= deadline:
                timely += 1
            if first[node] >= 0.0:
                seen.append(first[node])
        # PTC quorum time (metrics.SlotRecord): when the seat that makes
        # the threshold strict received the payload (None: never by 75 %).
        need = self.ptc_threshold + 1
        if len(seen) >= need:
            seen.sort()
            state.payload_quorum_ms = seen[need - 1]
        self._decide(state, timely > self.ptc_threshold, "missed")

    def _block_quorum_ms(self, state, quorum):
        """When the attester quorum was reached (abs ms, None: not by the
        deadline): the ceil(quorum)-th validator vote, a vote being the
        beacon block's receipt (ePBS) or the block's import (MEV-boost)."""
        need = int(quorum)
        if need < quorum:
            need += 1
        need = max(need, 1)
        if self.pbs == "mevboost":
            times = [t for node, t in state.imported.items()
                     if node in state.voted]
        else:
            if state.block_id is None:
                return None
            first = self.ctx.cl.first_receipt(state.block_id)
            times = [first[node] for node in sorted(state.voted)
                     if first[node] >= 0.0]
        if len(times) < need:
            return None
        times.sort()
        return times[need - 1]

    def slot_records(self):
        """One metrics.SlotRecord per decided or skipped slot (S4's input),
        in slot order. Slots still undecided at the call are left out."""
        from starksim.v3 import metrics as M
        result = []
        for slot in sorted(self.states):
            state = self.states[slot]
            if state.missed_input:
                result.append(M.SlotRecord(slot, M.STATUS_EMPTY, None))
                continue
            if state.canonical is None:
                continue
            payload = state.payload
            if state.canonical:
                status = M.STATUS_CANONICAL
            elif state.block_canonical is False or self.pbs == "mevboost":
                status = M.STATUS_ORPHANED
            else:
                status = M.STATUS_MISSED
            proof_ms = proof_window = None
            plan = getattr(self.deploy, "proof_plan", None)
            if callable(plan):
                proof_ms, proof_window = plan(slot)
            epbs = self.pbs == "epbs"
            payload_msg = (state.payload_id if epbs and
                           state.payload_id != state.block_id else None)
            result.append(M.SlotRecord(
                slot=slot, status=status, payload=payload,
                block_msg=state.block_id, payload_msg=payload_msg,
                column_msgs=state.column_ids, blobs=state.blobs,
                base_fee_wei=state.base_fee,
                block_quorum_ms=state.block_quorum_ms,
                attest_deadline_ms=state.t0 + self.att_due,
                payload_quorum_ms=state.payload_quorum_ms if epbs else None,
                ptc_deadline_ms=(state.t0 + self.payload_due if epbs
                                 else None),
                proof_ms=proof_ms, proof_window_ms=proof_window,
                requeued=(0 if state.canonical or payload is None
                          else len(payload.txs)),
                import_at=dict(state.import_at),
                el_ms=dict(state.el_ms),
                local_build=state.local_build))
        return result

    def _decide(self, state, canonical, failure):
        ctx = self.ctx
        scalars = ctx.counters.scalars
        payload = state.payload
        state.canonical = canonical
        if ctx.demand is not None:
            state.base_fee = ctx.demand.base_fee()
        record = {"slot": state.slot, "release_ms": state.release_ms,
                  "published_ms": state.published_ms,
                  "local_build": state.local_build,
                  "proposer": state.proposer, "builder": state.builder,
                  "canonical": canonical, "votes": state.votes,
                  "blobs": state.blobs}
        if payload is not None:
            record.update({"txs": len(payload.txs),
                           "gas_used": payload.gas_used,
                           "bytes": payload.bytes,
                           "binding": payload.binding,
                           "bg_count": payload.bg_count,
                           "bg_gas": payload.bg_gas})
        self.records.append(record)
        if not canonical:
            record["failure"] = failure
            scalars["slot.blocks_orphaned" if failure == "orphaned"
                    else "slot.payloads_missed"] += 1
            if payload is not None:
                scalars["slot.txs_requeued"] += len(payload.txs)
                ctx.hooks.payload_missed(state.slot, payload)
            return
        scalars["slot.payloads_canonical"] += 1
        demand = ctx.demand
        if demand is not None:
            demand.background_included(state.slot, payload.bg_gas)
            if ctx.spec.chain.gas_limit:
                # No gas limit: no EIP-1559 target, base fee unchanged
                # (review F3).
                demand.on_payload(payload.gas_used, ctx.spec.chain.gas_limit)
        txs = ctx.txs
        when = state.published_ms
        for tx in payload.txs:
            if txs.included_slot[tx] == NOT_INCLUDED:
                txs.included_slot[tx] = state.slot
                txs.included_at[tx] = when
        ctx.hooks.payload_canonical(state.slot, payload)
        deploy = self.deploy
        for node in state.seen:
            deploy.drop_included(node, payload)

    # ------------------------------------------------------------ FOCIL
    def _il_members(self, slot):
        state = self.states[slot]
        if state.il_members is None:
            rng = self.ctx.stream("slot", "il_members", slot)
            pool = self.validators or list(range(self.ctx.topo.n))
            state.il_members = {
                member: index for index, member in enumerate(
                    rng.sample(pool, min(self.focil["members"], len(pool))))}
        return state.il_members

    def _il_maybe_build(self, node, slot):
        """An IL member builds its IL once it has processed slot N's payload
        (EIP-7805: after confirming the block as head), at the latest at the
        7 s fallback."""
        if self.focil is None:
            return
        members = self._il_members(slot)
        if node in members and node not in self.states[slot].il_built and \
                self.ctx.now() <= self.states[slot].t0 + self.focil["build"]:
            self._il_publish(slot, node, members[node])

    def _il_build(self, slot):
        """The 7 s fallback: members that have not built yet build on their
        local head (eip-7805.md:42-43)."""
        state = self.states[slot]
        for member, index in self._il_members(slot).items():
            if member not in state.il_built:
                self._il_publish(slot, member, index)

    def _il_publish(self, slot, member, index):
        state = self.states[slot]
        state.il_built.add(member)
        ctx = self.ctx
        deploy = self.deploy
        txs = ctx.txs
        base = deploy.base_fee()
        # Txs of slot N's payload are on the member's head once it holds
        # the payload (review F1): never put them in the IL.
        head = state.payload.cover if (state.payload is not None and
                                        member in state.seen_set) else 0
        chosen = []
        room = self.focil["max_bytes"]
        for scanned, tx in enumerate(deploy.pool.fee_order(member, base)):
            if scanned >= IL_SCAN_LIMIT or room <= 0:
                break
            if txs.included_slot[tx] != NOT_INCLUDED or (head >> tx) & 1:
                continue
            if txs.bytes_wire[tx] <= room:
                chosen.append(tx)
                room -= txs.bytes_wire[tx]
        if not chosen:
            return
        ctx.counters.scalars["slot.il_published"] += 1
        size = IL_OVERHEAD_BYTES + sum(txs.bytes_wire[tx] for tx in chosen)
        msg_id = ("il", slot, index)
        self._il_content[msg_id] = tuple(chosen)
        nxt = self.states.get(slot + 1)
        if nxt is not None and nxt.builder < 0:
            nxt.builder = self.builder(slot + 1)
        ctx.cl.publish(member, TOPIC_INCLUSION_LIST, msg_id, size,
                       self._il_receipt)

    def _il_receipt(self, node, msg_id, src):
        slot = msg_id[1]
        nxt = self.states.get(slot + 1)
        if nxt is None or node != nxt.builder:
            return
        # The builder freezes its IL view at 11 s (eip-7805.md:58-60).
        if self.ctx.now() > self.states[slot].t0 + self.focil["builder_due"]:
            return
        state = self.states[slot]
        for tx in self._il_content[msg_id]:
            if tx not in state.il_txs:
                state.il_txs.append(tx)
                self.ctx.counters.scalars["slot.il_txs"] += 1


def _bps(leaf, slot_ms):
    return _bps_value(leaf["value"], slot_ms)


def _bps_value(value, slot_ms):
    return float(value) * slot_ms / BPS


def _noop(*_args):
    return None

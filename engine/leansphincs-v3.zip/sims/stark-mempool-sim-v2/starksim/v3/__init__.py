"""The v3 simulator core (phase 4 of the leanSPHINCS campaign).

A small discrete-event model of the three deployments (8141 full, 8288
full, leanPCS full) on one engine: `starksim.engine.Engine`, a node table,
regional latency, GPS uplink lanes and downlink FIFOs, eth/68 and eth/73
announce/fetch, gossipsub, ePBS slots and rule plug-ins. Design:
notes/phase4/arch.md of the campaign; contract for contributors:
INTERFACES.md and STAGES.md in this directory. The v2 core (starksim/*.py)
is frozen and not imported from here except `engine` and `derive`.
"""

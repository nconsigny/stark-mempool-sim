"""Topology of one v3 run: node table, latency, EL graph, CL mesh (arch.md 3.2).

Inputs are bound names of `params.BINDINGS`; every random choice comes from
a stream keyed by (seed, "topo", purpose), so the topology is a function of
(seed, spec.nodes, the network settings, the params file) and nothing else.

- Shares (regions, uplink classes, EL clients, reachability, validators,
  supernodes, gossipsub client D) are dealt exactly: largest-remainder
  apportionment of N, then a seeded shuffle (v2's `draw_uplinks` method).
  Each share is dealt independently of the others.
- Latency: one way = RTT[r_u][r_v] / 2 + access_u + access_v, times
  1 + jitter * f(u, v), f = stable_fraction(seed, "edge", min, max):
  symmetric and fixed per edge.
- EL graph (devp2p): per-node target degree = client cap if reachable, else
  cap // 3 (geth DialRatio; params topology.el_degree.draw). A node behind
  NAT cannot accept inbound connections, so an edge between two unreachable
  nodes is impossible: unreachable stubs pair only with reachable stubs,
  then the remaining reachable stubs pair among themselves (configuration
  model, self and multi edges dropped). Re-drawn until connected (<= 20
  tries), then components are chained and the row says so.
- CL mesh (gossipsub): one undirected graph with per-node target D (5 for
  Lighthouse, else 8; params topology.cl_mesh.client_weighted_D.draw),
  configuration model plus a repair pass among nodes still short of D.
  Symmetric by construction (REPORT-PHASE2B defect 4). `build_mesh` is
  reused by clgossip (S2b) for the column subnets.
- Builders: `builders` extra nodes appended after the N simulated nodes,
  datacentre, reachable, EL degree = factor x geth cap, in the CL mesh.
"""

import math
from collections import deque

from starksim.v3 import detmath
from starksim.v3.state import NodeTable

MBIT_TO_BYTES_PER_MS = 125.0    # [E] unit: 1 Mbit/s = 10^6 / 8 B/s = 125 B/ms
# Home downlink = 3 x uplink capped at 1,000 Mbit/s; datacentre symmetric.
HOME_DOWNLINK_FACTOR = 3.0      # [R] params bandwidth.downlink_over_uplink_home.draw
HOME_DOWNLINK_CAP_MBPS = 1000.0  # [R] same draw text
NAT_DIAL_RATIO = 3              # [R] params topology.el_degree.draw (geth DialRatio 3)
DATACENTRE_CLASS = "datacentre"  # [R] params bandwidth.uplink_classes[0].name
LIGHTHOUSE = "lighthouse"
EL_CONNECT_TRIES = 20           # [A] arch.md 3.2
HOP_SAMPLE_SOURCES = 16         # [A] BFS sources for the hop statistics
CAP_PARAM = {"geth": "max_peers_geth", "nethermind": "max_peers_nethermind",
             "reth": "max_peers_reth", "erigon": "max_peers_erigon",
             "besu": "max_peers_besu"}
OTHER_CLIENT_CAP_AS = "geth"    # [A] "other" EL clients take geth's cap


def apportion(weights, total):
    """Largest-remainder apportionment of `total` items over `weights`
    (a list of non-negative numbers): counts summing to `total`. Ties in
    the remainder go to the lower index (deterministic)."""
    weight_sum = math.fsum(weights)
    if total == 0:
        return [0] * len(weights)
    if weight_sum <= 0.0:
        raise ValueError("apportion: weights sum to zero")
    quotas = [weight * total / weight_sum for weight in weights]
    counts = [int(math.floor(quota)) for quota in quotas]
    remaining = total - sum(counts)
    order = sorted(range(len(weights)),
                   key=lambda index: (-(quotas[index] - counts[index]),
                                      index))
    for index in order[:remaining]:
        counts[index] += 1
    return counts


def deal(counts, rng):
    """A list of len sum(counts) holding label i counts[i] times, shuffled."""
    labels = []
    for label, count in enumerate(counts):
        labels.extend([label] * count)
    rng.shuffle(labels)
    return labels


def configuration_graph(targets, rng, reachable=None):
    """Undirected simple graph with degrees close to `targets`.

    With `reachable` (list of bools), stubs of unreachable nodes pair only
    with stubs of reachable nodes. Self and multi edges are dropped, so a
    node may end slightly below its target. Returns a list of sets.
    """
    n = len(targets)
    adjacency = [set() for _ in range(n)]
    if reachable is None:
        stubs = []
        for node in range(n):
            stubs.extend([node] * targets[node])
        rng.shuffle(stubs)
        _pair_within(stubs, adjacency)
        return adjacency
    open_stubs = []
    nat_stubs = []
    for node in range(n):
        if reachable[node]:
            open_stubs.extend([node] * targets[node])
        else:
            nat_stubs.extend([node] * targets[node])
    rng.shuffle(open_stubs)
    rng.shuffle(nat_stubs)
    paired = min(len(nat_stubs), len(open_stubs))
    for index in range(paired):
        _link(adjacency, nat_stubs[index], open_stubs[index])
    _pair_within(open_stubs[paired:], adjacency)
    return adjacency


def _pair_within(stubs, adjacency):
    for index in range(0, len(stubs) - 1, 2):
        _link(adjacency, stubs[index], stubs[index + 1])


def _link(adjacency, u, v):
    if u != v and v not in adjacency[u]:
        adjacency[u].add(v)
        adjacency[v].add(u)


def repair(adjacency, targets, rng, reachable=None):
    """Link nodes still short of their target to each other (shuffled
    order; never two unreachable nodes). Returns the edges added."""
    short = [node for node in range(len(adjacency))
             if len(adjacency[node]) < targets[node]]
    rng.shuffle(short)
    added = 0
    for position, u in enumerate(short):
        for v in short[position + 1:]:
            if len(adjacency[u]) >= targets[u]:
                break
            if len(adjacency[v]) >= targets[v] or v in adjacency[u]:
                continue
            if reachable is not None and not reachable[u] and \
                    not reachable[v]:
                continue
            _link(adjacency, u, v)
            added += 1
    # A node short by two or more with nobody short left to pair with:
    # split an edge (a, b) far from it into (u, a) and (u, b), which keeps
    # every other degree.
    for u in short:
        while targets[u] - len(adjacency[u]) >= 2:
            if not _split_edge_for(adjacency, u, reachable):
                break
            added += 1
    return added


def _split_edge_for(adjacency, u, reachable):
    for a in range(len(adjacency)):
        if a == u or a in adjacency[u]:
            continue
        if reachable is not None and not reachable[u] and not reachable[a]:
            continue
        for b in sorted(adjacency[a]):
            if b == u or b in adjacency[u]:
                continue
            if reachable is not None and not reachable[u] and \
                    not reachable[b]:
                continue
            adjacency[a].discard(b)
            adjacency[b].discard(a)
            _link(adjacency, u, a)
            _link(adjacency, u, b)
            return True
    return False


def build_mesh(members, targets, rng):
    """Symmetric gossipsub mesh over `members` (list of node ids) with
    per-member target degree `targets` (same order). Configuration model,
    then a repair pass that links members still short of their target to
    each other (shuffled order). Returns {node: sorted tuple of peers}."""
    count = len(members)
    capped = [min(target, count - 1) for target in targets]
    adjacency = configuration_graph(capped, rng)
    repair(adjacency, capped, rng)
    result = {}
    for index, node in enumerate(members):
        result[node] = tuple(sorted(members[peer]
                                    for peer in adjacency[index]))
    return result


def components(adjacency):
    """Connected components (lists of nodes, each sorted, by smallest node)."""
    n = len(adjacency)
    seen = [False] * n
    result = []
    for start in range(n):
        if seen[start]:
            continue
        seen[start] = True
        queue = deque([start])
        component = []
        while queue:
            node = queue.popleft()
            component.append(node)
            for peer in adjacency[node]:
                if not seen[peer]:
                    seen[peer] = True
                    queue.append(peer)
        component.sort()
        result.append(component)
    return result


def bfs_distances(adjacency, source):
    distances = [-1] * len(adjacency)
    distances[source] = 0
    queue = deque([source])
    while queue:
        node = queue.popleft()
        for peer in adjacency[node]:
            if distances[peer] < 0:
                distances[peer] = distances[node] + 1
                queue.append(peer)
    return distances


class Topology:
    """The built topology. `nodes` is the NodeTable (simulated nodes
    0..n-1, builders n..n_total-1). `latency(u, v)` is the one-way delay in
    ms. `stats` holds what the row reports (degrees, repairs, hops)."""

    def __init__(self):
        self.n = 0
        self.n_total = 0
        self.builders = []
        self.region_names = []
        self.class_names = []
        self.class_mbps = []
        self.rtt = []
        self.jitter = 0.0
        self.seed = 0
        self.ideal = False
        self.nodes = None
        self.stats = {}
        self._latency = {}

    @classmethod
    def build(cls, spec, params, seed=None):
        result = cls()
        result._build(spec, params, spec.seed if seed is None else seed)
        return result

    def install(self, ctx):
        """Make this topology the run's: ctx.topo and ctx.nodes."""
        ctx.topo = self
        ctx.nodes = self.nodes

    # -- latency
    def latency(self, u, v):
        """One-way delay u -> v in ms (symmetric; 0 under net.mode=ideal)."""
        if self.ideal or u == v:
            return 0.0
        if u > v:
            u, v = v, u
        key = u * self.n_total + v
        cached = self._latency.get(key)
        if cached is not None:
            return cached
        nodes = self.nodes
        base = (self.rtt[nodes.region[u]][nodes.region[v]] / 2.0
                + nodes.access_ms[u] + nodes.access_ms[v])
        value = base * (1.0 + self.jitter *
                        detmath.stable_fraction(self.seed, "edge", u, v))
        self._latency[key] = value
        return value

    def base_latency(self, u, v):
        """The latency without the edge jitter (tests)."""
        nodes = self.nodes
        return (self.rtt[nodes.region[u]][nodes.region[v]] / 2.0
                + nodes.access_ms[u] + nodes.access_ms[v])

    # -- construction
    def _build(self, spec, params, seed):
        net = spec.net
        self.seed = seed
        self.ideal = net.mode == "ideal"
        n = spec.nodes
        builders = net.builders
        if builders is None:
            builders = int(params.value("builder_count"))
        self.n = n
        self.n_total = n + builders
        self.builders = list(range(n, n + builders))
        nodes = NodeTable(self.n_total)
        self.nodes = nodes
        self._regions(params, net, seed)
        self._links(params, spec, seed)
        self._roles(params, net, seed)
        self._el_graph(params, seed)
        self._cl_mesh(params, seed)
        self._hop_stats(seed)

    def _stream(self, seed, purpose):
        return detmath.stream(seed, "topo", purpose)

    def _regions(self, params, net, seed):
        nodes = self.nodes
        self.region_names = list(params.value("region_names"))
        weights = params.value("region_weights")
        weight_list = [weights[name] for name in self.region_names]
        rtt_all = params.value("rtt_ms")
        matrix = rtt_all[net.latency_percentile]
        self.rtt = [[float(matrix[a][b]) for b in self.region_names]
                    for a in self.region_names]
        self.jitter = float(params.value("edge_jitter"))
        dealt = deal(apportion(weight_list, self.n),
                     self._stream(seed, "region"))
        for node in range(self.n):
            nodes.region[node] = dealt[node]
        # Builders: the heaviest regions in turn [A] (relays sit in the
        # big hosting regions).
        by_weight = sorted(range(len(weight_list)),
                           key=lambda index: (-weight_list[index], index))
        for position, node in enumerate(self.builders):
            nodes.region[node] = by_weight[position % len(by_weight)]

    def _links(self, params, spec, seed):
        nodes = self.nodes
        net = spec.net
        classes = params.value("uplink_classes")
        self.class_names = [entry["name"] for entry in classes]
        self.class_mbps = [float(entry["uplink_mbps"]) for entry in classes]
        shares = [float(entry["share"]) for entry in classes]
        dealt = deal(apportion(shares, self.n),
                     self._stream(seed, "uplink_class"))
        dc_ratio = float(params.value("downlink_over_uplink_datacentre"))
        access_dc = float(params.value("access_one_way_ms_datacentre"))
        access_home = float(params.value("access_one_way_ms_home"))
        sorted_rates = sorted(set(self.class_mbps))
        for node in range(self.n):
            label = dealt[node]
            rate = self.class_mbps[label]
            if net.within_class == "uniform":
                higher = [r for r in sorted_rates if r > rate]
                if higher:
                    fraction = detmath.stable_fraction(seed, "topo",
                                                       "within", node)
                    rate = rate + fraction * (higher[0] - rate)
            nodes.uplink_class[node] = label
            home = self.class_names[label] != DATACENTRE_CLASS
            nodes.home[node] = home
            if home:
                down = min(rate * HOME_DOWNLINK_FACTOR,
                           max(HOME_DOWNLINK_CAP_MBPS, rate))
                nodes.access_ms[node] = access_home
            else:
                down = rate * dc_ratio
                nodes.access_ms[node] = access_dc
            nodes.up_Bpms[node] = (rate * MBIT_TO_BYTES_PER_MS *
                                   spec.scale.uplink)
            nodes.down_Bpms[node] = (down * MBIT_TO_BYTES_PER_MS *
                                     spec.scale.downlink)
        builder_mbps = float(params.value("builder_uplink_mbps"))
        dc_label = self.class_names.index(DATACENTRE_CLASS)
        for node in self.builders:
            nodes.uplink_class[node] = dc_label
            nodes.home[node] = False
            nodes.access_ms[node] = access_dc
            nodes.up_Bpms[node] = (builder_mbps * MBIT_TO_BYTES_PER_MS *
                                   spec.scale.uplink)
            nodes.down_Bpms[node] = (builder_mbps * dc_ratio *
                                     MBIT_TO_BYTES_PER_MS *
                                     spec.scale.downlink)

    def _roles(self, params, net, seed):
        nodes = self.nodes
        validator_share = net.validator_share
        if validator_share is None:
            validator_share = float(params.value("validator_share"))
        supernode_share = net.supernode_share
        if supernode_share is None:
            supernode_share = float(params.value("supernode_share"))
        for flag, share, purpose in (
                (nodes.is_validator, validator_share, "validator"),
                (nodes.is_supernode, supernode_share, "supernode")):
            dealt = deal(apportion([1.0 - share, share], self.n),
                         self._stream(seed, purpose))
            for node in range(self.n):
                flag[node] = dealt[node] == 1
        for node in self.builders:
            nodes.is_builder[node] = True
            nodes.is_supernode[node] = True

    def _el_graph(self, params, seed):
        nodes = self.nodes
        shares = params.value("el_client_share")
        clients = list(shares)
        weights = [float(shares[name]) for name in clients]
        dealt = deal(apportion(weights, self.n),
                     self._stream(seed, "el_client"))
        caps = {}
        for name in clients:
            cap_name = CAP_PARAM.get(name, CAP_PARAM[OTHER_CLIENT_CAP_AS])
            caps[name] = int(params.value(cap_name))
        reachable_share = float(params.value("reachable_share"))
        reach = deal(apportion([1.0 - reachable_share, reachable_share],
                               self.n), self._stream(seed, "reachable"))
        limit = self.n_total - 1
        targets = [0] * self.n_total
        for node in range(self.n):
            client = clients[dealt[node]]
            nodes.el_client[node] = client
            nodes.el_cap[node] = caps[client]
            nodes.reachable[node] = reach[node] == 1
            if nodes.reachable[node]:
                target = caps[client]
            else:
                target = caps[client] // NAT_DIAL_RATIO
            targets[node] = min(target, limit)
        factor = float(params.value("builder_el_degree_factor"))
        geth_cap = caps.get("geth", int(params.value("max_peers_geth")))
        for node in self.builders:
            nodes.el_client[node] = "geth"
            nodes.el_cap[node] = int(factor * geth_cap)
            nodes.reachable[node] = True
            targets[node] = min(nodes.el_cap[node], limit)
        adjacency = None
        tries = 0
        parts = []
        for attempt in range(EL_CONNECT_TRIES):
            tries = attempt + 1
            rng = detmath.stream(seed, "topo", "el_graph", attempt)
            adjacency = configuration_graph(targets, rng, nodes.reachable)
            repair(adjacency, targets, rng, nodes.reachable)
            parts = components(adjacency)
            if len(parts) == 1:
                break
        repair_edges = 0
        if len(parts) > 1:
            # Join the components through reachable members [A]: a
            # component with a reachable member is chained to the previous
            # such component; one without (possible only with tiny caps)
            # is linked to a reachable node elsewhere. Never NAT-NAT.
            open_anchors = []
            closed_anchors = []
            for part in parts:
                open_members = [node for node in part
                                if nodes.reachable[node]]
                if open_members:
                    open_anchors.append(open_members[0])
                else:
                    closed_anchors.append(part[0])
            for index in range(len(open_anchors) - 1):
                _link(adjacency, open_anchors[index], open_anchors[index + 1])
                repair_edges += 1
            for anchor in closed_anchors:
                if open_anchors:
                    _link(adjacency, anchor, open_anchors[0])
                    repair_edges += 1
        for node in range(self.n_total):
            nodes.el_peers[node] = tuple(sorted(adjacency[node]))
        degrees = [len(adjacency[node]) for node in range(self.n)]
        self.stats["el_tries"] = tries
        self.stats["el_repair_edges"] = repair_edges
        self.stats["el_degree_mean"] = math.fsum(degrees) / self.n
        self.stats["el_degree_target_mean"] = (
            math.fsum(targets[:self.n]) / self.n)
        self.stats["el_edges"] = sum(len(peers) for peers in adjacency) // 2
        self._el_adjacency = adjacency

    def _cl_mesh(self, params, seed):
        nodes = self.nodes
        lighthouse_share = float(params.value("cl_lighthouse_share"))
        d_lighthouse = int(params.value("cl_lighthouse_D"))
        d_default = int(params.value("cl_D"))
        dealt = deal(apportion([1.0 - lighthouse_share, lighthouse_share],
                               self.n), self._stream(seed, "cl_client"))
        targets = []
        for node in range(self.n_total):
            if node >= self.n:
                target = d_default
            elif dealt[node] == 1:
                target = d_lighthouse
            else:
                target = d_default
            nodes.cl_D[node] = target
            targets.append(target)
        members = list(range(self.n_total))
        mesh = None
        for attempt in range(EL_CONNECT_TRIES):
            rng = detmath.stream(seed, "topo", "cl_mesh", attempt)
            mesh = build_mesh(members, targets, rng)
            adjacency = [set(mesh[node]) for node in members]
            if len(components(adjacency)) == 1:
                break
        for node in members:
            nodes.cl_mesh[node] = mesh[node]
        degrees = [len(mesh[node]) for node in members]
        self.stats["cl_degree_mean"] = math.fsum(degrees) / self.n_total
        self.stats["cl_degree_target_mean"] = (math.fsum(targets) /
                                               self.n_total)
        self.stats["cl_short_nodes"] = sum(
            1 for node in members if degrees[node] < min(targets[node],
                                                         self.n_total - 1))

    def _hop_stats(self, seed):
        adjacency = self._el_adjacency
        sources = sorted(set(
            detmath.stable_index(self.n, seed, "topo", "hop_source", index)
            for index in range(min(HOP_SAMPLE_SOURCES, self.n))))
        total = 0
        count = 0
        diameter = 0
        for source in sources:
            distances = bfs_distances(adjacency, source)
            for distance in distances:
                if distance > 0:
                    total += distance
                    count += 1
                    if distance > diameter:
                        diameter = distance
        self.stats["el_mean_hops"] = total / count if count else 0.0
        self.stats["el_diameter_est"] = diameter
        self._el_adjacency = None

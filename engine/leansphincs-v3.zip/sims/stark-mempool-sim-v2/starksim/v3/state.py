"""Shared state of one v3 run: the transaction table, the node table, the
counters, and the run context (engine, event kinds, hooks, random streams).

Tables are struct-of-arrays: one Python list per column, indexed by a dense
integer (`tx` in birth order, `node` in topology order). Sets of
transactions are Python ints used as bitsets (bit `tx`).

FROZEN, APPEND-ONLY (starksim/v3/INTERFACES.md): the column names below, the
kind/route/lane constants and the hook names are fixed. A stage that needs a
new per-tx or per-node column registers it at construction time with
`add_column("<owner>.<name>", default)`; a new counter with
`counters.array(...)`/`counters.scalar(...)`; a new event kind with
`ctx.on("<owner>.<name>", handler)`. Owners are the module names of
arch.md section 3.0 (links, el, mempool, cl, demand, prover, slot, deploy,
metrics). None of that needs an edit of this file.
"""

from starksim.engine import Engine
from starksim.v3 import detmath

# Transaction kinds (arch.md 3.1).
KIND_PQ1 = 0      # PQ single-signature tx (k = spec.k signatures)
KIND_PQK = 1      # PQ k-of-n multisig tx (k = demand.multisig_k)
KIND_PCS = 2      # leanPCS PCS-claim tx
KIND_ECDSA = 3    # ECDSA background tx
KIND_NAMES = ("pq1", "pqk", "pcs", "ecdsa")

ROUTE_PUBLIC = 0
ROUTE_PRIVATE = 1   # direct to builders (8141 txs the public pool refuses)

LANE_EL = 0
LANE_CL = 1
LANE_NAMES = ("el", "cl")

NOT_INCLUDED = -1

OWNERS = ("links", "topo", "el", "mempool", "cl", "demand", "prover",
          "slot", "deploy", "metrics", "runner", "test")


class TxTable:
    """One row per transaction, in birth order. Written by demand (S2c) at
    birth; `included_slot`/`included_at` by slot (S3) on canonical
    inclusion; never deleted (a run is at most ~10^5 txs)."""

    COLUMNS = ("born", "kind", "k", "bytes_wire", "bytes_chain", "gas",
               "deps", "verify_gas", "fee_cap", "tip", "sender",
               "entry_node", "route", "included_slot", "included_at")

    def __init__(self):
        self.born = []          # ms
        self.kind = []          # KIND_*
        self.k = []             # signatures (0 for ECDSA)
        self.bytes_wire = []    # bytes as gossiped (8141 tx, or mode-0 wrapper)
        self.bytes_chain = []   # bytes in the block
        self.gas = []           # gas charged in the block
        self.deps = []          # 8288/leanPCS dependencies (0 for 8141/ECDSA)
        self.verify_gas = []    # 8141 VERIFY-frame execution gas (admission CPU)
        self.fee_cap = []       # wei per gas
        self.tip = []           # wei per gas
        self.sender = []        # sender id
        self.entry_node = []    # node of first submission
        self.route = []         # ROUTE_*
        self.included_slot = []  # NOT_INCLUDED or slot of canonical inclusion
        self.included_at = []    # ms of the canonical payload, or -1.0
        self.extra = {}          # registered columns: name -> (list, default)

    def __len__(self):
        return len(self.born)

    def add(self, born, kind, k, bytes_wire, bytes_chain, gas, deps,
            verify_gas, fee_cap, tip, sender, entry_node,
            route=ROUTE_PUBLIC):
        """Append a transaction; returns its id."""
        tx = len(self.born)
        self.born.append(born)
        self.kind.append(kind)
        self.k.append(k)
        self.bytes_wire.append(bytes_wire)
        self.bytes_chain.append(bytes_chain)
        self.gas.append(gas)
        self.deps.append(deps)
        self.verify_gas.append(verify_gas)
        self.fee_cap.append(fee_cap)
        self.tip.append(tip)
        self.sender.append(sender)
        self.entry_node.append(entry_node)
        self.route.append(route)
        self.included_slot.append(NOT_INCLUDED)
        self.included_at.append(-1.0)
        for column, default in self.extra.values():
            column.append(default)
        return tx

    def add_column(self, name, default):
        """Register a per-tx column `<owner>.<name>`; returns the list."""
        _check_owner(name)
        if name in self.extra:
            raise ValueError(f"tx column {name!r} registered twice")
        column = [default] * len(self.born)
        self.extra[name] = (column, default)
        return column

    def row(self, tx):
        result = {name: getattr(self, name)[tx] for name in self.COLUMNS}
        for name, (column, _default) in self.extra.items():
            result[name] = column[tx]
        return result


class NodeTable:
    """One row per node (simulated nodes first, builders last). Written once
    by topology (S1); the role columns by topology; prover_class by prover
    (S2d) at construction."""

    COLUMNS = ("region", "uplink_class", "home", "up_Bpms", "down_Bpms",
               "access_ms", "el_client", "el_cap", "reachable", "cl_D",
               "is_validator", "is_builder", "is_supernode", "cpu_class",
               "prover_class", "el_peers", "cl_mesh")

    def __init__(self, n):
        self.n = n
        self.region = [0] * n          # index into params region_names
        self.uplink_class = [0] * n    # index into Topology.class_names
        self.home = [False] * n        # home (True) or datacentre access
        self.up_Bpms = [0.0] * n       # uplink, bytes per ms
        self.down_Bpms = [0.0] * n     # downlink, bytes per ms
        self.access_ms = [0.0] * n     # one-way access latency
        self.el_client = [""] * n      # EL client name
        self.el_cap = [0] * n          # EL max peers of that client
        self.reachable = [False] * n   # accepts inbound EL connections
        self.cl_D = [0] * n            # gossipsub target mesh degree
        self.is_validator = [False] * n
        self.is_builder = [False] * n
        self.is_supernode = [False] * n  # full data-column custody
        self.cpu_class = [""] * n      # CPU class name (verification/import)
        self.prover_class = [""] * n   # prover class name, "" = no prover
        self.el_peers = [()] * n       # sorted tuple of EL neighbours
        self.cl_mesh = [()] * n        # sorted tuple, shared non-column mesh
        self.extra = {}

    def add_column(self, name, default):
        _check_owner(name)
        if name in self.extra:
            raise ValueError(f"node column {name!r} registered twice")
        column = [default] * self.n
        self.extra[name] = column
        return column


class Counters:
    """Flat counters, registered by name `<owner>.<metric>`. Arrays are
    indexed by node (or by any dense id the owner documents); metrics (S4)
    reads them by name and aggregates by node class at the end."""

    def __init__(self):
        self.arrays = {}
        self.scalars = {}

    def array(self, name, size, initial=0):
        _check_owner(name)
        if name in self.arrays or name in self.scalars:
            raise ValueError(f"counter {name!r} registered twice")
        values = [initial] * size
        self.arrays[name] = values
        return values

    def scalar(self, name, initial=0):
        """Register a scalar; read and write through `counters.scalars`."""
        _check_owner(name)
        if name in self.arrays or name in self.scalars:
            raise ValueError(f"counter {name!r} registered twice")
        self.scalars[name] = initial

    def add(self, name, amount=1):
        self.scalars[name] += amount

    def snapshot(self):
        """A deep copy of every counter (window boundaries)."""
        return {"arrays": {name: list(values)
                           for name, values in self.arrays.items()},
                "scalars": dict(self.scalars)}


# Hooks: cross-module callbacks the deployment plug-in (S3) wires. The
# producer calls `ctx.hooks.<name>(...)`; the default raises so a missing
# wiring fails loudly. Names and signatures are frozen (INTERFACES.md).
HOOK_NAMES = (
    # demand -> deploy: a tx is born (row already in ctx.txs).
    "tx_born",               # (tx)
    # el gossip -> deploy: an object's body arrived at `node` from `src`;
    # deploy runs admission (CPU via mempool.cpu) and on success calls
    # elgossip.admit(node, rule, obj).
    "el_body_received",      # (node, rule_name, obj, src)
    # cl gossip -> slot: first copy of a message at `node`.
    "cl_first_receipt",      # (node, topic, msg_id, src)
    # slot -> everyone: a payload became canonical (or was missed).
    "payload_canonical",     # (slot, payload)
    "payload_missed",        # (slot, payload)
    # deploy -> el gossip: size in bytes of a gossip object.
    "object_bytes",          # (rule_name, obj) -> int
)


class Hooks:
    def __init__(self):
        for name in HOOK_NAMES:
            setattr(self, name, _unwired(name))

    def wire(self, name, function):
        if name not in HOOK_NAMES:
            raise ValueError(f"unknown hook {name!r}; known: "
                             f"{', '.join(HOOK_NAMES)}")
        setattr(self, name, function)


def _unwired(name):
    def fail(*args):
        raise RuntimeError(f"hook {name!r} called but not wired")
    return fail


class Context:
    """Everything one run shares: spec, params, engine, tables, counters,
    hooks, and the per-module objects (`topo`, `links`, ... set by the
    runner as it builds them; None until then)."""

    def __init__(self, spec, params, n_nodes=0):
        self.spec = spec
        self.params = params
        self.seed = spec.seed
        self.engine = Engine()
        self.txs = TxTable()
        self.nodes = NodeTable(n_nodes)
        self.counters = Counters()
        self.hooks = Hooks()
        self.kinds = {}
        self.topo = None
        self.links = None
        self.el = None
        self.mempool = None
        self.cl = None
        self.demand = None
        self.prover = None
        self.slot = None
        self.deploy = None

    def on(self, kind, handler):
        """Register an event kind `<owner>.<name>`; handler(payload).

        The engine calls handlers as handler(engine, payload); v3 handlers
        take the payload only (they hold ctx), so the adapter drops it.
        """
        _check_owner(kind)
        if kind in self.kinds:
            raise ValueError(f"event kind {kind!r} registered twice")
        self.kinds[kind] = handler
        self.engine.on(kind, _adapter(handler))

    def at(self, t, kind, payload=None):
        return self.engine.schedule_at(t, kind, payload)

    def after(self, delay, kind, payload=None):
        return self.engine.schedule(delay, kind, payload)

    def now(self):
        return self.engine.now

    def stream(self, purpose, *keys):
        """random.Random for (seed, purpose, *keys): see detmath.stream."""
        return detmath.stream(self.seed, purpose, *keys)

    def fraction(self, purpose, *keys):
        """A stable value in [0, 1) for (seed, purpose, *keys)."""
        return detmath.stable_fraction(self.seed, purpose, *keys)


def _adapter(handler):
    def call(_engine, payload):
        handler(payload)
    return call


def _check_owner(name):
    owner = name.split(".", 1)[0]
    if "." not in name or owner not in OWNERS:
        raise ValueError(f"{name!r} must be '<owner>.<name>' with owner in "
                         f"{', '.join(OWNERS)}")


def bits(indices):
    """Bitset of an iterable of non-negative ints."""
    result = 0
    for index in indices:
        result |= 1 << index
    return result


_BYTE_BITS = tuple(tuple(i for i in range(8) if (byte >> i) & 1)  # [E] bits of a byte
                   for byte in range(256))  # [E] byte values
_SPARSE = 8   # [A] perf only: below this popcount the lowest-bit loop is faster


def members(bitset):
    """Indices of the set bits, ascending. Dense sets are read byte by
    byte (O(bytes + members)); sparse ones by peeling the lowest bit
    (O(members x words)), the original loop (S5 perf: 23 % of an 8288 run
    was this function)."""
    if bitset.bit_count() <= _SPARSE:
        result = []
        while bitset:
            low = bitset & -bitset
            result.append(low.bit_length() - 1)
            bitset ^= low
        return result
    data = bitset.to_bytes((bitset.bit_length() + 7) // 8, "little")  # [E] bytes of the int
    result = []
    base = 0
    table = _BYTE_BITS
    for byte in data:
        if byte:
            for i in table[byte]:
                result.append(base + i)
        base += 8  # [E] bits per byte
    return result

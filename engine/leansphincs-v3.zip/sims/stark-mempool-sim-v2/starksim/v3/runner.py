"""Build and run one RunSpec -> one row (arch.md 3.11, 3.13). Stage S5.

Public entry points (also the browser engine's, INTERFACES.md section 6):

    build(spec, params) -> ctx                      the wired world
    execute(spec, params, until_extra_slots=1, prepare=None) -> (row, ctx)
    run(spec, params) -> row                        execute(...)[0]
    row_json(row) -> str                            the canonical row text
    offered_rates(ctx) -> (pq tx/s | None, ECDSA tx/s | None, bounds)

`row` is S4's fixed row (`metrics.ROW_COLUMNS`, 228 columns, validated);
nothing that depends on the wall clock is in it, so one spec and one code
commit give byte-identical `row_json` (tested). Wall times, event counts,
the analytic bounds and the raw slot/deploy counters of the run are in
`ctx.run_info` (a dict; not part of the row).

World order: topology -> links -> deployment plug-in (pool, CPU, EL gossip,
hooks) -> CL gossip -> demand -> slot clock -> metrics.Recorder; then
demand.schedule over the warm-up and measured slots, the slot clock over all
slots (drain included), the aggregation ticks of 8288/leanPCS
(`deploy.start_intervals`), and the engine until one slot after the last.

Saturate mode offers PQ txs at `saturate_factor x` the smallest analytic
bound of the deployment (gas with the ECDSA background's gas, `ecdsa_tps x
mean ECDSA gas`, taken off the gas limit; bytes; the block dependency cap;
the LEANSTARK cap of the pcs routes), unless `demand.offered_pq_tps` fixes
the rate (elasticity/shadow-price arms), and ECDSA at `ecdsa_tps x
saturate_factor` (`demand.saturate_ecdsa=proportional`, build-s2c.md 4).
"""

import functools
import hashlib
import heapq
import json
import os
import time

from starksim.engine import HeapCalendar
from starksim.v3 import metrics
from starksim.v3 import spec as spec_module
from starksim.v3.clgossip import ClGossip
from starksim.v3.demand import Demand
from starksim.v3.deploy import deployment_class
from starksim.v3.links import Links
from starksim.v3.slot import SlotClock
from starksim.v3.state import KIND_PCS, KIND_PQ1, KIND_PQK, Context
from starksim.v3.topology import Topology

# Bounds (PQ tx/s) that cap the saturate offer besides gas.
EXTRA_BOUND_KEYS = ("bytes", "dep_cap", "leanstark_cap")
COMMIT_ENV = "LEANSPHINCS_CODE_COMMIT"
COMMIT_CHARS = 12     # [A] abbreviated commit id in rows
GITDIR = "gitdir:"    # [E] git worktree .git file prefix
REF = "ref:"          # [E] git symbolic HEAD prefix
FINGERPRINT_CHARS = 12  # [A] 48 bits of sha256 name a source version
_COMMIT = []
_FINGERPRINT = []
# Sources outside starksim/v3 that a v3 run executes (S5 review E2).
EXTRA_SOURCES = (("starksim", "engine.py"), ("starksim", "derive.py"),
                 ("starksim", "costs.py"), ("starksim", "network.py"),
                 ("bench", "leansphincs", "models.py"))


def lane_weights(spec, params):
    weights = params.value("lane_weights")
    el_weight = spec.net.lane_weight_el
    cl_weight = spec.net.lane_weight_cl
    return (weights["el"] if el_weight is None else el_weight,
            weights["cl"] if cl_weight is None else cl_weight)


def code_commit():
    """`<git HEAD>+src.<fingerprint>`: the commit of this checkout and the
    sha256 of the sources a run executes (`code_fingerprint`), so a row
    from an uncommitted tree cannot pass for the commit's (S5 review E6).
    The env LEANSPHINCS_CODE_COMMIT replaces the git part (the web engine;
    git HEAD is read from .git files, no subprocess, and is "unknown"
    without them). Cached per process."""
    if _COMMIT:
        return _COMMIT[0]
    head = os.environ.get(COMMIT_ENV) or _git_head() or "unknown"
    value = f"{head}+src.{code_fingerprint()}"
    _COMMIT.append(value)
    return value


def code_fingerprint():
    """sha256 (12 hex) over starksim/v3/*.py and EXTRA_SOURCES, in sorted
    file order, each name and content. Cached per process."""
    if _FINGERPRINT:
        return _FINGERPRINT[0]
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(os.path.dirname(here))
    paths = sorted(os.path.join(here, name) for name in os.listdir(here)
                   if name.endswith(".py"))
    paths += [os.path.join(root, *parts) for parts in EXTRA_SOURCES]
    digest = hashlib.sha256()
    for path in paths:
        if not os.path.isfile(path):
            continue
        digest.update(os.path.relpath(path, root).encode("utf-8"))
        with open(path, "rb") as handle:
            digest.update(handle.read())
    _FINGERPRINT.append(digest.hexdigest()[:FINGERPRINT_CHARS])
    return _FINGERPRINT[0]


def _git_head():
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.dirname(os.path.dirname(here))
        git = os.path.join(root, ".git")
        if os.path.isfile(git):
            with open(git, encoding="utf-8") as handle:
                text = handle.read().strip()
            if not text.startswith(GITDIR):
                return None
            git = os.path.normpath(os.path.join(
                root, text[len(GITDIR):].strip()))
        with open(os.path.join(git, "HEAD"), encoding="utf-8") as handle:
            head = handle.read().strip()
        if not head.startswith(REF):
            return head[:COMMIT_CHARS]
        ref = head[len(REF):].strip()
        common = git
        common_file = os.path.join(git, "commondir")
        if os.path.isfile(common_file):
            with open(common_file, encoding="utf-8") as handle:
                common = os.path.normpath(os.path.join(
                    git, handle.read().strip()))
        for base in (git, common):
            path = os.path.join(base, ref)
            if os.path.isfile(path):
                with open(path, encoding="utf-8") as handle:
                    return handle.read().strip()[:COMMIT_CHARS]
        packed = os.path.join(common, "packed-refs")
        if os.path.isfile(packed):
            with open(packed, encoding="utf-8") as handle:
                for line in handle:
                    parts = line.split()
                    if len(parts) == 2 and parts[1] == ref:
                        return parts[0][:COMMIT_CHARS]
    except OSError:
        return None
    return None


def build(spec, params):
    """A Context with every module of the run built and wired."""
    topo = Topology.build(spec, params)
    ctx = Context(spec, params, topo.n_total)
    topo.install(ctx)
    background = None
    if spec.net.background and spec.net.mode != "ideal":
        background = params.value("background_mbps")
    ctx.links = Links(ctx, topo, lane_weights(spec, params), background)
    deploy = deployment_class(spec.deployment)(ctx)
    ctx.deploy = deploy
    ctx.cl = ClGossip(ctx)
    ctx.demand = Demand(ctx, deploy, burst_r=spec.demand.burst_r)
    SlotClock(ctx, deploy)
    return ctx


def offered_rates(ctx):
    """(offered PQ tx/s or None, ECDSA tx/s or None, bounds) for
    demand.schedule. `bounds` gains `gas_residual` (PQ tx/s left by the
    ECDSA background's gas) and `saturate_min` (the bound the offer
    scales)."""
    spec = ctx.spec
    deploy = ctx.deploy
    demand = ctx.demand
    bounds = dict(deploy.analytic_bounds())
    if spec.demand.mode != "saturate":
        return None, None, bounds
    if spec.deployment == "today":
        return 0.0, None, bounds
    ecdsa = (spec.demand.ecdsa_tps if spec.demand.ecdsa_tps is not None
             else demand.included_tps)
    slot_s = spec.chain.slot_ms / 1000.0
    limits = []
    if "gas" in bounds:
        residual = spec.chain.gas_limit - ecdsa * slot_s * demand.gas_ref
        bounds["gas_residual"] = (max(0.0, residual) / bounds["gas_per_tx"]
                                  / slot_s)
        limits.append(bounds["gas_residual"])
    for key in EXTRA_BOUND_KEYS:
        if bounds.get(key) is not None:
            limits.append(float(bounds[key]))
    if spec.demand.offered_pq_tps is not None:
        return float(spec.demand.offered_pq_tps), ecdsa, bounds
    if not limits:
        raise ValueError("saturate mode needs a gas limit or a byte cap")
    bounds["saturate_min"] = min(limits)
    return spec.demand.saturate_factor * min(limits), ecdsa, bounds


def identity(spec, params):
    """The identity columns `metrics.build_row` takes from the runner."""
    today = spec.deployment == "today"
    return {
        "spec_hash": spec_module.spec_hash(spec, params),
        "code_commit": code_commit(),
        "params_sha256": params.network_sha256,
        "deployments_sha256": params.deployments_sha256,
        "deployment": spec.deployment,
        "candidate": None if today else spec.candidate_label,
        "sig_bytes": None if today else int(spec.sig_bytes),
        "perms": None if today else int(spec.perms),
        "k": int(spec.k),
        "nodes": int(spec.nodes),
        "seed": int(spec.seed),
        "demand_mode": spec.demand.mode,
    }


def run(spec, params, until_extra_slots=1):
    """Run one spec; returns the row (dict, metrics.ROW_COLUMNS)."""
    return execute(spec, params, until_extra_slots)[0]


def execute(spec, params, until_extra_slots=1, prepare=None):
    """Run one spec; returns (row, ctx). `prepare(ctx)` runs after the
    world is built and before anything is scheduled (tests; the web
    engine's progress hook)."""
    started = time.perf_counter()
    code_commit()     # fixed before the run: a later edit or commit is not
    ctx = build(spec, params)   # the code that ran
    if prepare is not None:
        prepare(ctx)
    recorder = metrics.Recorder(ctx)
    built_s = time.perf_counter() - started
    slots = spec.slots
    n_demand = slots.warmup + slots.measured
    n_slots = n_demand + slots.drain
    offered_pq, ecdsa, bounds = offered_rates(ctx)
    ctx.demand.schedule(n_demand, offered_pq, ecdsa,
                        ecdsa_proportional=(spec.demand.saturate_ecdsa
                                            == "proportional"))
    ctx.slot.schedule(n_slots)
    horizon = (n_slots + until_extra_slots) * spec.chain.slot_ms
    intervals = getattr(ctx.deploy, "start_intervals", None)
    if callable(intervals):
        intervals(horizon)
    ctx.cl.start()
    ctx.el.start()
    run_engine(ctx, horizon)
    run_s = time.perf_counter() - started
    records = ctx.slot.slot_records()
    offered = None if spec.deployment == "today" else ctx.demand.pq_tps
    data = metrics.collect(
        ctx, recorder, records, identity(spec, params),
        tx_rule="eth68" if "eth68" in getattr(ctx.el, "rules", {}) else None,
        offered_tps=offered)
    row = metrics.build_row(data)
    wall_s = time.perf_counter() - started
    ctx.run_info = run_info(ctx, offered_pq, bounds, built_s, run_s, wall_s)
    return row, ctx


def run_engine(ctx, until):
    """`ctx.engine.run(until=until)` with the same event order and effects
    (S7, performance): pops the heap calendar directly and calls the v3
    handlers without the engine's adapter. Falls back to `Engine.run`
    when observers or another calendar are in use."""
    engine = ctx.engine
    calendar = engine.calendar
    heap = getattr(calendar, "_heap", None)
    if heap is None or type(calendar) is not HeapCalendar or \
            engine.observers or engine.sealed:
        return engine.run(until=until)
    dispatch = {}
    for kind, handler in engine.handlers.items():
        raw = ctx.kinds.get(kind)
        dispatch[kind] = raw if raw is not None else \
            functools.partial(handler, engine)
    hooks = engine.post_event_hooks
    pop = heapq.heappop
    processed = 0
    engine.stop_reason = "drained"
    try:
        while heap:
            if heap[0][0] > until:
                engine.stop_reason = "until"
                break
            t, _seq, kind, payload = pop(heap)
            engine.now = t
            handler = dispatch.get(kind)
            if handler is None:
                handler = engine.handlers.get(kind)
                if handler is None:
                    raise KeyError(f"no handler registered for event kind "
                                   f"{kind!r}")
                raw = ctx.kinds.get(kind)
                handler = raw if raw is not None else \
                    functools.partial(handler, engine)
                dispatch[kind] = handler
            handler(payload)
            processed += 1
            if hooks:
                engine.events_processed += 1
                if engine.sealed:
                    break
                for hook in hooks:
                    hook(kind)
            elif engine.sealed:
                break
    finally:
        if not hooks:
            engine.events_processed += processed
    if engine.now < until:
        engine.now = until
    return processed


def run_info(ctx, offered_pq, bounds, built_s, run_s, wall_s):
    """Diagnostics of one run that are not row columns: [M] wall times
    (never in the row: rows must be byte-identical), events, the analytic
    bounds, the binding counts of the measured window's canonical payloads
    and the raw slot/deploy counters (whole run)."""
    txs = ctx.txs
    scalars = ctx.counters.scalars
    events = ctx.engine.events_processed
    pq_born = sum(1 for tx in range(len(txs))
                  if txs.kind[tx] in (KIND_PQ1, KIND_PQK, KIND_PCS))
    bindings = {}
    first = ctx.spec.slots.warmup
    last = first + ctx.spec.slots.measured
    for record in ctx.slot.records:
        if record.get("canonical") and first <= record["slot"] < last:
            name = record.get("binding", "none")
            bindings[name] = bindings.get(name, 0) + 1
    return {
        "build_s_measured": round(built_s, 3),   # [A] ms resolution
        "run_s_measured": round(run_s, 3),       # [A] ms resolution
        "wall_s_measured": round(wall_s, 3),     # [A] ms resolution
        "events": events,
        "events_per_s_measured": round(events / max(wall_s, 1e-9)),  # [A] no /0
        "events_per_pq_tx_per_node": (events / pq_born / ctx.topo.n_total
                                      if pq_born else None),
        "offered_pq_tps": offered_pq,
        "bounds_tps": bounds,
        "binding_counts": bindings,
        "slot_counters": {key[len("slot."):]: value
                          for key, value in scalars.items()
                          if key.startswith("slot.")},
        "deploy_counters": {key[len("deploy."):]: value
                            for key, value in scalars.items()
                            if key.startswith("deploy.")},
        "input_status": ctx.params.input_status(),
    }


def row_json(row):
    """The canonical text of a row: what `run` prints and sweeps cache."""
    return json.dumps(row, indent=1, allow_nan=False)

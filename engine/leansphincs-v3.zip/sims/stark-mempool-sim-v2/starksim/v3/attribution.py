"""What binds: the utilisation vector, the binding set, capacity shadow
prices by paired perturbation, and the paired central-difference estimator
behind the elasticities (arch.md 3.13, 3.14, stage S4).

Utilisation vector (every row, `util_<resource>`, each in [0, UTIL_CAP]):

  gas, bytes, dep_cap   sum over canonical window payloads of use / (cap x
                        payloads); NA when the cap is 0/None
  builder_proof         p90 over canonical payloads of planned final-proof
                        time / time available (SlotRecord.proof_ms /
                        proof_window_ms)
  prover_pool           busy time of aggregating (non-builder) provers /
                        (their parallel provers x window), capacity-weighted
  uplink_el_<g>         p90 over nodes of group g of the EL lane's busy
  uplink_cl_<g>         fraction (links.busy_ms_el / _cl, window delta)
  downlink_<g>          p90 over nodes of bytes received / (downlink after
                        background x window)
  cpu_<g>               p90 over nodes of CPU time booked / (cores x window)
  propagation_block     p90 over window slots of (attester quorum time -
                        block publish) / (attestation deadline - publish)
  propagation_payload   same with the PTC quorum and deadline
  tx_delivery           mean over canonical payloads of the share of
                        eligible txs not at the builder at freeze
  mempool               evictions / admissions (all nodes, window)
  demand                PQ included / PQ offered in the window
  (g in RESOURCE_GROUPS; a quorum never reached counts UTIL_CAP)

Binding set. Two methods, and the row says which one decided:

- `shadow_ci` / `shadow_point` (rigorous, `attribute` verb): for each
  capacity knob r, paired runs with common random numbers at c_r x (1 + h)
  and c_r x (1 - h) around the base point give, per seed,
      s_up   = ln(T_up / T_0) / ln(c_up / c_0)
      s_down = ln(T_0 / T_down) / ln(c_0 / c_down)
      s_c    = ln(T_up / T_down) / ln(c_up / c_down)   (central)
  with the achieved ratios (integer knobs are rounded, never assumed).
  r is binding when the t-interval of s_down over seeds lies above 0
  (`shadow_ci`, >= 2 seeds); with one seed only the argmax of s_down with
  s_down > 0 is named (`shadow_point`). No utilisation threshold enters.
  Why s_down: at a kink (T = min(C1, C2) with C1 = C2) relaxing either
  capacity alone gains nothing (s_up = 0 for both), while tightening either
  loses throughput (s_down = 1 for both): one-sided upward prices miss
  co-binding resources. For T concave and homogeneous of degree 1 in the
  capacities the directional derivatives bracket Euler's identity:
  sum_r s_up <= 1 <= sum_r s_down (superadditivity of the directional
  derivative). That bracket holds for derivatives only: finite +-h log
  differences miss it by O(h) even for smooth T (T = C1 + C2: sums 1.024
  and 0.974 at h = 0.1, review F6), so read only gaps well above h as
  co-binding; a sum far from 1 says latency or demand effects matter.
  What the label means: "binding within h": tightening r by h costs
  throughput. A resource with slack below h (T = min(C1, 1.05 C1)) is in
  the set; `strict` lists the knobs whose s_up interval is also above 0
  (relaxing r alone helps). The tests are one-sided t-tests at
  (1 - level) / 2 with Holm's step-down over the knobs (family-wise error
  control, review F9); when no knob passes the label is `unresolved`
  (not "none": with few seeds and noise that does not cancel under CRN
  the test has little power, review F10). Shares s_down / sum s_down are
  reported; a statistically positive but tiny s_down is in the set and
  its share says how little it matters (review F8). A knob whose arm
  collapsed (T <= 0) is listed in `collapsed`, not averaged.
- `util_heuristic` (a reading aid when no perturbation was run): the
  resources with util >= max util - UTIL_TIE and util >= UTIL_FLOOR, the
  two [A] constants of arch.md 3.14; `binding_margin` = max util - the
  largest util outside the set. The vector itself is always in the row.

Estimator. `summarize(values, level)`: mean, sample sd, n and the Student-t
interval mean +- t_{(1+level)/2, n-1} sd / sqrt(n) (none for n = 1). The
Student-t quantile is computed from the regularised incomplete beta
function (Lentz continued fraction), not a table, and is tested against
tabulated values.

Elasticities (the driver that runs specs is S5's elasticity.py; this module
has the estimator): `central_elasticity` per seed
    eps = ln(T(x (1 + h)) / T(x (1 - h))) / ln((1 + h) / (1 - h))
and `fair_and_supply`: the measured elasticity of PQ throughput under
kind-blind fee rationing is eps_fair; eps_supply = eps_fair / s_PQ, s_PQ =
the PQ share of the *binding* resource (PQ_SHARE_COLUMN: gas -> PQ share of
included gas; dep_cap, provers -> 1, ECDSA uses none of them), per seed,
averaged over the two arms. Proof of the identity for one kind-blind
rationed resource of capacity C: included share phi solves phi (N_P a +
N_E e) = C, so d ln(phi N_P)/d ln a = -N_P a / (N_P a + N_E e) = -s_PQ,
while the PQ-only supply C / a has elasticity -1. With a resource ECDSA
does not use, s_PQ = 1 and the two coincide; dividing by the PQ gas share
there would overstate eps_supply. A binding resource without a share
mapping gives eps_supply NA (reason in the result).
"""

import math
from collections import namedtuple

from starksim.v3 import detmath

UTIL_CAP = 10.0      # [A] serialisable stand-in for "never reached"
UTIL_TIE = 0.02      # [A] arch.md 3.14 heuristic: within 2 % of the max
UTIL_FLOOR = 0.9     # [A] arch.md 3.14 heuristic: and at least 0.9
DEMAND_BOUND = 0.97  # [A] arch.md 3.14 heuristic: demand binds at 97 %
_LARGE_DF = 2000     # [A] above it ln B(df/2, 1/2) by its asymptotic series
P90 = 0.9            # [A] arch.md 3.14 "p90 busy fraction"
H_DEFAULT = 0.1      # [A] arch.md 3.13/3.14: +-10 % arms
LEVEL_DEFAULT = 0.95  # [A] two-sided 95 % t-interval
_CF_MAX_ITER = 400   # [A] continued fraction: ample for df <= 10^6
_CF_EPS = 1e-15      # [A] relative convergence of the continued fraction
_CF_TINY = 1e-300    # [A] Lentz's guard against a zero denominator
_BISECT_STEPS = 200  # [A] bisection to float resolution

RESOURCE_GROUPS = ("dc", "home", "builder")
RESOURCES = (("gas", "bytes", "dep_cap", "builder_proof", "prover_pool") +
             tuple(f"uplink_el_{g}" for g in RESOURCE_GROUPS) +
             tuple(f"uplink_cl_{g}" for g in RESOURCE_GROUPS) +
             tuple(f"downlink_{g}" for g in RESOURCE_GROUPS) +
             tuple(f"cpu_{g}" for g in RESOURCE_GROUPS) +
             ("propagation_block", "propagation_payload", "tx_delivery",
              "mempool", "demand"))

# Shadow-price knobs: name -> spec key. Integer keys are rounded.
KNOB_KEYS = {"gas": "chain.gas_limit", "bytes": "chain.byte_cap",
             "dep_cap": "chain.dep_cap", "prover": "scale.prover",
             "uplink": "scale.uplink", "downlink": "scale.downlink",
             "cpu": "scale.cpu"}
INT_KEYS = ("chain.gas_limit", "chain.byte_cap", "chain.dep_cap")

# Binding knob/resource -> PQ share of it (a row column, or a constant).
PQ_SHARE_COLUMN = {"gas": "pq_share_gas", "bytes": "pq_share_bytes",
                   "dep_cap": 1.0, "prover": 1.0, "prover_pool": 1.0,
                   "builder_proof": 1.0}

Label = namedtuple("Label", ("binding", "method", "margin"))
Summary = namedtuple("Summary", ("mean", "sd", "n", "ci_lo", "ci_hi",
                                 "level", "values"))


# ------------------------------------------------------- utilisation
def _cap(value):
    return None if value is None else min(float(value), UTIL_CAP)


def utilisation(data, row):
    """{resource: util or None} for RESOURCES, from metrics.RunData and the
    row's throughput columns (module docstring)."""
    from starksim.v3 import metrics as M
    util = dict.fromkeys(RESOURCES)
    t0, t1 = data.window()
    window_ms = t1 - t0
    first, last = data.warmup, data.warmup + data.measured
    window = [r for r in data.slots if first <= r.slot < last]
    canonical = [r for r in window if r.status == M.STATUS_CANONICAL]
    if canonical:
        n = len(canonical)
        if data.gas_limit:
            util["gas"] = sum(r.payload.gas_used for r in canonical) / (
                n * data.gas_limit)
        if data.byte_cap:
            util["bytes"] = sum(r.payload.bytes for r in canonical) / (
                n * data.byte_cap)
        if data.dep_cap:
            util["dep_cap"] = sum(r.payload.deps for r in canonical) / (
                n * data.dep_cap)
        ratios = [r.proof_ms / r.proof_window_ms for r in canonical
                  if r.proof_ms is not None and r.proof_window_ms]
        if ratios:
            util["builder_proof"] = _cap(M.quantile(ratios, P90))
        gaps = [r.tx_undelivered_share for r in canonical
                if r.tx_undelivered_share is not None]
        if gaps:
            util["tx_delivery"] = math.fsum(gaps) / len(gaps)
    c = data.counters
    pbusy = c.get("prover.busy_ms")
    if pbusy is not None and data.provers is not None:
        agg = [v for v in range(data.n_sim) if data.provers[v] > 0]
        capacity = sum(data.provers[v] for v in agg) * window_ms
        if capacity:
            util["prover_pool"] = _cap(sum(pbusy[v] for v in agg) / capacity)
    for g in RESOURCE_GROUPS:
        members = M.node_group(data.nodes, data.n_sim, "dc" if g == "dc"
                               else g)
        if not members:
            continue
        for lane in ("el", "cl"):
            busy = c.get(f"links.busy_ms_{lane}")
            if busy is not None:
                util[f"uplink_{lane}_{g}"] = _cap(M.quantile(
                    [busy[v] / window_ms for v in members], P90))
        down = M._down_bytes(c)
        if down is not None and data.down_eff_Bpms is not None:
            util[f"downlink_{g}"] = _cap(M.quantile(
                [down[v] / (data.down_eff_Bpms[v] * window_ms)
                 for v in members], P90))
        cpu = c.get("mempool.cpu_busy_ms")
        if cpu is not None and data.cores is not None:
            util[f"cpu_{g}"] = _cap(M.quantile(
                [cpu[v] / (data.cores[v] * window_ms) for v in members],
                P90))
    for name, msg_field, quorum, deadline in (
            ("propagation_block", "block_msg", "block_quorum_ms",
             "attest_deadline_ms"),
            ("propagation_payload", "payload_msg", "payload_quorum_ms",
             "ptc_deadline_ms")):
        ratios = []
        for record in window:
            msg_id = getattr(record, msg_field)
            end = getattr(record, deadline)
            if msg_id is None or end is None:
                continue
            published = data.msgs[msg_id].t_pub
            reached = getattr(record, quorum)
            if end <= published:
                ratios.append(UTIL_CAP)
            elif reached is None:
                ratios.append(UTIL_CAP)
            else:
                ratios.append(_cap((reached - published) /
                                   (end - published)))
        if ratios:
            util[name] = M.quantile(ratios, P90)
    admitted = c.get("mempool.admitted")
    evicted = c.get("mempool.evicted")
    if admitted is not None and evicted is not None and sum(admitted):
        util["mempool"] = _cap(sum(evicted) / sum(admitted))
    if row.get("demand_ratio") is not None:
        util["demand"] = _cap(row["demand_ratio"])
    return util


def binding_from_util(util):
    """The `util_heuristic` label (module docstring); 'none' when nothing
    was measured. Utilisations are compared after min(u, 1): uplink busy
    fractions cannot exceed 1 while offered loads (CPU, provers, downlink)
    can, so every saturated resource ties at 1 (review F17). `demand`
    enters when included >= DEMAND_BOUND x offered (arch.md 3.14)."""
    measured = sorted((min(value, 1.0), name) for name, value in util.items()
                      if value is not None and name != "demand")
    if util.get("demand") is not None:
        measured.append((1.0 if util["demand"] >= DEMAND_BOUND else
                         min(util["demand"], 1.0), "demand"))
        measured.sort()
    if not measured:
        return Label("none", "util_heuristic", None)
    top = measured[-1][0]
    chosen = sorted(name for value, name in measured
                    if value >= top - UTIL_TIE and value >= UTIL_FLOOR)
    rest = [value for value, name in measured if name not in chosen]
    margin = (top - rest[-1]) if rest and chosen else None
    if len(measured) < 2:
        margin = None
    return Label("+".join(chosen) if chosen else "none", "util_heuristic",
                 margin)


# ------------------------------------------------------- statistics
def _betacf(a, b, x):
    """Continued fraction of the incomplete beta (modified Lentz)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    d = _CF_TINY if abs(d) < _CF_TINY else d
    d = 1.0 / d
    h = d
    for m in range(1, _CF_MAX_ITER + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = _CF_TINY if abs(d) < _CF_TINY else d
        c = 1.0 + aa / c
        c = _CF_TINY if abs(c) < _CF_TINY else c
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = _CF_TINY if abs(d) < _CF_TINY else d
        c = 1.0 + aa / c
        c = _CF_TINY if abs(c) < _CF_TINY else c
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < _CF_EPS:
            return h
    raise ArithmeticError("incomplete beta continued fraction did not "
                          "converge")


def _ln_beta_half(df):
    """ln B(df/2, 1/2) for a positive integer df, by B(a + 1, b) =
    B(a, b) a / (a + b) from B(1/2, 1/2) = pi and B(1, 1/2) = 2."""
    if df > _LARGE_DF:
        # ln B(a, 1/2) = ln Gamma(1/2) + ln Gamma(a) - ln Gamma(a + 1/2),
        # ln Gamma(a) - ln Gamma(a + 1/2) = -ln(a)/2 + 1/(8a) - 1/(192 a^3)
        # + O(a^-5) [E] DLMF 5.11.13 (review F5: the loop is O(df)).
        a = df / 2.0
        return (0.5 * detmath.ln(math.pi) - 0.5 * detmath.ln(a) +
                1.0 / (8.0 * a) - 1.0 / (192.0 * a * a * a))  # [E] DLMF 5.11.13
    a = 0.5 if df % 2 else 1.0
    value = detmath.ln(math.pi) if df % 2 else detmath.ln(2.0)
    while 2.0 * a < df:
        value += detmath.ln(a / (a + 0.5))
        a += 1.0
    return value


def t_two_sided_tail(t, df):
    """P(|T| > t) for Student's t with integer df >= 1:
    I_x(df/2, 1/2), x = df / (df + t^2)."""
    if df < 1 or int(df) != df:
        raise ValueError("df must be a positive integer")
    t = abs(float(t))
    if t == 0.0:
        return 1.0
    x = df / (df + t * t)
    if x >= 1.0:
        # t below ~1e-8 sqrt(df): 1 - 2 f(0) t, f(0) = 1 / (sqrt(df)
        # B(df/2, 1/2)) the density at 0 (review F5).
        return 1.0 - 2.0 * t / (math.sqrt(df) *
                                detmath.exp(_ln_beta_half(int(df))))
    a, b = df / 2.0, 0.5
    ln_front = (a * detmath.ln(x) + b * detmath.ln(1.0 - x) -
                _ln_beta_half(int(df)))
    front = detmath.exp(ln_front)
    if x < (a + 1.0) / (a + b + 2.0):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1.0 - x) / b


def t_quantile(level, df):
    """t such that P(|T| <= t) = level (two-sided), df >= 1 integer."""
    if not 0.0 < level < 1.0:
        raise ValueError("level must be in (0, 1)")
    alpha = 1.0 - level
    hi = 1.0
    while t_two_sided_tail(hi, df) > alpha:
        hi *= 2.0
    lo = 0.0
    for _ in range(_BISECT_STEPS):
        mid = 0.5 * (lo + hi)
        if mid in (lo, hi):
            break
        if t_two_sided_tail(mid, df) > alpha:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def summarize(values, level=LEVEL_DEFAULT):
    """Summary(mean, sd, n, ci_lo, ci_hi, level, values) with a Student-t
    interval; sd and the interval are None for n = 1."""
    values = [float(v) for v in values]
    n = len(values)
    if n == 0:
        raise ValueError("no values")
    for value in values:
        if not math.isfinite(value):
            raise ValueError(f"non-finite estimate {value!r}")
    mean = math.fsum(values) / n
    if n == 1:
        return Summary(mean, None, 1, None, None, level, tuple(values))
    sd = math.sqrt(math.fsum((v - mean) * (v - mean) for v in values) /
                   (n - 1))
    half = t_quantile(level, n - 1) * sd / math.sqrt(n)
    return Summary(mean, sd, n, mean - half, mean + half, level,
                   tuple(values))


def log_slope(t_a, t_b, c_a, c_b):
    """ln(t_a / t_b) / ln(c_a / c_b); raises on a non-positive throughput
    (a collapsed arm has no log slope: report it, do not average it)."""
    if t_a <= 0.0 or t_b <= 0.0:
        raise ValueError(f"throughput {t_a!r} / {t_b!r} not positive: no "
                         "log slope")
    if c_a <= 0.0 or c_b <= 0.0 or c_a == c_b:
        raise ValueError(f"capacities {c_a!r}, {c_b!r} give no ratio")
    return detmath.ln(t_a / t_b) / detmath.ln(c_a / c_b)


def scaled(key, base, factor):
    """base x factor, rounded for integer keys; raises when rounding
    leaves the value unchanged."""
    value = base * factor
    if key in INT_KEYS:
        value = int(round(value))
    if value == base:
        raise ValueError(f"{key}: {base!r} x {factor} rounds to itself")
    return value


def _metric(result, metric):
    return float(result if metric is None else result[metric])


# ------------------------------------------------------- shadow prices
ShadowPrice = namedtuple("ShadowPrice", ("knob", "key", "base", "up",
                                         "down", "s_up", "s_down",
                                         "s_central"))
ShadowResult = namedtuple("ShadowResult", ("prices", "sum_up", "sum_down",
                                           "label", "seeds", "h", "strict",
                                           "shares", "collapsed", "pvalues"))


def shadow_prices(run, knobs, seeds, h=H_DEFAULT, metric=None,
                  level=LEVEL_DEFAULT):
    """Capacity shadow prices by paired +-h perturbation runs.

    run(sets, seed) -> throughput (or a row, read at `metric`), where
    `sets` is a {spec key: value} override of the base point and the same
    seed gives common random numbers. knobs: {name: (spec key, base
    value)}; a knob whose base is 0/None (no cap) or whose +-h rounds to
    itself is refused. Returns ShadowResult: one ShadowPrice per knob (each
    s_* a Summary over seeds), the Euler sums of the means, the binding
    Label, `strict` (knobs with s_up also above 0), `shares` (s_down /
    sum s_down), `collapsed` (knobs with an arm at T <= 0, excluded), and
    the Holm-adjusted one-sided p-values of s_down."""
    seeds = list(seeds)
    if not seeds:
        raise ValueError("no seeds")
    base_t = {seed: _metric(run({}, seed), metric) for seed in seeds}
    for seed, value in base_t.items():
        if value <= 0.0:
            raise ValueError(f"base point collapsed (T = {value!r}) at "
                             f"seed {seed}: no shadow prices")
    prices, collapsed = {}, []
    for name in sorted(knobs):
        key, base = knobs[name]
        if not base:
            raise ValueError(f"knob {name}: base {base!r} is not a "
                             "capacity (0/None = no cap)")
        up = scaled(key, base, 1.0 + h)
        down = scaled(key, base, 1.0 - h)
        s_up, s_down, s_c = [], [], []
        for seed in seeds:
            t_up = _metric(run({key: up}, seed), metric)
            t_down = _metric(run({key: down}, seed), metric)
            if t_up <= 0.0 or t_down <= 0.0:
                collapsed.append(name)
                break
            t_0 = base_t[seed]
            s_up.append(log_slope(t_up, t_0, up, base))
            s_down.append(log_slope(t_0, t_down, base, down))
            s_c.append(log_slope(t_up, t_down, up, down))
        else:
            prices[name] = ShadowPrice(name, key, base, up, down,
                                       summarize(s_up, level),
                                       summarize(s_down, level),
                                       summarize(s_c, level))
    sum_up = math.fsum(p.s_up.mean for p in prices.values())
    sum_down = math.fsum(p.s_down.mean for p in prices.values())
    label, strict, pvalues = binding_from_shadow(prices, level)
    positive = math.fsum(max(p.s_down.mean, 0.0) for p in prices.values())
    shares = {name: (max(p.s_down.mean, 0.0) / positive if positive
                     else 0.0) for name, p in prices.items()}
    return ShadowResult(prices, sum_up, sum_down, label, tuple(seeds), h,
                        strict, shares, tuple(collapsed), pvalues)


def _one_sided_p(summary):
    """p-value of H0: mean <= 0 against mean > 0 (one-sided t-test)."""
    if summary.sd == 0.0:
        return 0.0 if summary.mean > 0.0 else 1.0
    t = summary.mean / (summary.sd / math.sqrt(summary.n))
    tail = 0.5 * t_two_sided_tail(t, summary.n - 1)
    return tail if t > 0.0 else 1.0 - tail


def holm(pvalues, alpha):
    """Names rejected by Holm's step-down at family-wise level alpha."""
    ordered = sorted(pvalues.items(), key=lambda item: (item[1], item[0]))
    m = len(ordered)
    rejected = []
    for index, (name, p) in enumerate(ordered):
        if p > alpha / (m - index):
            break
        rejected.append(name)
    return sorted(rejected)


def binding_from_shadow(prices, level=LEVEL_DEFAULT):
    """(Label, strict, pvalues) from ShadowPrice summaries (module
    docstring). >= 2 seeds: `shadow_ci`, Holm over one-sided t-tests of
    s_down at (1 - level) / 2; `strict` likewise on s_up within that set.
    1 seed: `shadow_point`, the argmax of s_down when > 0."""
    if not prices:
        return Label("unresolved", "shadow_point", None), (), {}
    ranked = sorted(prices.values(), key=lambda p: (-p.s_down.mean, p.knob))
    margin = (ranked[0].s_down.mean - ranked[1].s_down.mean
              if len(ranked) > 1 else None)
    if ranked[0].s_down.n >= 2:
        alpha = (1.0 - level) / 2.0
        pvalues = {p.knob: _one_sided_p(p.s_down) for p in ranked}
        chosen = holm(pvalues, alpha)
        strict = tuple(holm({name: _one_sided_p(prices[name].s_up)
                             for name in chosen}, alpha)) if chosen else ()
        return (Label("+".join(chosen) if chosen else "unresolved",
                      "shadow_ci", margin), strict, pvalues)
    top = ranked[0]
    strict = (top.knob,) if top.s_down.mean > 0.0 and \
        top.s_up.mean > 0.0 else ()
    return (Label(top.knob if top.s_down.mean > 0.0 else "unresolved",
                  "shadow_point", margin), strict, {})


# ------------------------------------------------------- elasticities
def central_elasticity(run, key, base, seeds, h=H_DEFAULT, metric=None,
                       level=LEVEL_DEFAULT, share=None):
    """Paired central-difference elasticity of `metric` to spec `key`
    around `base`, over seeds (common random numbers within a seed).

    Returns (Summary of eps, list of per-seed (row_up, row_down)) ; with
    `share` (a row column), also per-seed mean of the arms' share values
    as a third element (for fair_and_supply)."""
    up = scaled(key, base, 1.0 + h)
    down = scaled(key, base, 1.0 - h)
    eps, arms, shares = [], [], []
    for seed in seeds:
        r_up = run({key: up}, seed)
        r_down = run({key: down}, seed)
        eps.append(log_slope(_metric(r_up, metric), _metric(r_down, metric),
                             up, down))
        arms.append((r_up, r_down))
        if share is not None:
            values = (r_up[share], r_down[share])
            shares.append(None if None in values else 0.5 * (values[0] +
                                                              values[1]))
    summary = summarize(eps, level)
    if share is None:
        return summary, arms
    return summary, arms, shares


EpsPair = namedtuple("EpsPair", ("fair", "supply", "s_pq", "resource",
                                 "note"))


def fair_and_supply(eps_fair, s_pq, resource, level=LEVEL_DEFAULT,
                    key="sig_bytes"):
    """eps_fair (per-seed list, measured) and eps_supply = eps_fair / s_PQ
    per seed (s_pq: per-seed list, or None when the binding resource has a
    constant share in PQ_SHARE_COLUMN). Returns EpsPair of Summaries;
    supply is None (with a note) when the resource has no share mapping or
    a share is missing or zero. `key` is the perturbed input: a capacity
    knob is refused (the identity is about a per-tx use, not a capacity,
    review F13). The identity assumes kind-blind proportional rationing of
    the binding resource (demand.py ranks by tip per gas, kind-blind);
    under priority rationing it does not hold (stated in the note)."""
    if key in KNOB_KEYS.values() or key.startswith("scale."):
        raise ValueError(f"{key}: eps_supply applies to a per-tx input "
                         "(sig_bytes, perms), not a capacity knob")
    fair = summarize(eps_fair, level)
    if resource not in PQ_SHARE_COLUMN:
        return EpsPair(fair, None, None, resource,
                       f"no PQ share mapping for binding resource "
                       f"{resource!r}: eps_supply not derived")
    mapped = PQ_SHARE_COLUMN[resource]
    if not isinstance(mapped, str):
        shares = [float(mapped)] * len(eps_fair)
    else:
        shares = list(s_pq or [])
        if len(shares) != len(eps_fair) or any(
                s is None or s <= 0.0 for s in shares):
            return EpsPair(fair, None, None, resource,
                           f"missing or zero {mapped} in an arm")
    supply = summarize([e / s for e, s in zip(eps_fair, shares)], level)
    return EpsPair(fair, supply, summarize(shares, level), resource,
                   "eps_supply = eps_fair / s_PQ per seed; assumes "
                   "kind-blind proportional rationing of the binding "
                   "resource")


def default_knobs(spec):
    """Shadow-price knobs that can act for a resolved RunSpec: caps that
    exist, prover speed for aggregation deployments, link speeds on a
    realistic network, CPU speed."""
    knobs = {}
    if spec.chain.gas_limit:
        knobs["gas"] = (KNOB_KEYS["gas"], spec.chain.gas_limit)
    if spec.chain.byte_cap:
        knobs["bytes"] = (KNOB_KEYS["bytes"], spec.chain.byte_cap)
    agg = spec.deployment in ("8288", "leanpcs")
    if agg and spec.chain.dep_cap:
        knobs["dep_cap"] = (KNOB_KEYS["dep_cap"], spec.chain.dep_cap)
    if agg:
        knobs["prover"] = (KNOB_KEYS["prover"], spec.scale.prover)
    if spec.net.mode == "realistic":
        knobs["uplink"] = (KNOB_KEYS["uplink"], spec.scale.uplink)
        knobs["downlink"] = (KNOB_KEYS["downlink"], spec.scale.downlink)
    knobs["cpu"] = (KNOB_KEYS["cpu"], spec.scale.cpu)
    return knobs

"""Elasticities of included PQ throughput to signature bytes and to
permutations per signature, and capacity shadow prices (arch.md 3.13, 3.14;
PHASE4-NETSIM.md orchestrator decision after S2c). Stage S5; the
estimators are S4's (`attribution.py`).

Design, per input x in {sig_bytes, perms} and base point B (a saturated
run; `demand.mode=saturate` is forced):

1. Base runs, one per seed: the offered PQ rate R0 (saturate_factor x the
   base point's smallest analytic bound) and the base row.
2. Paired arms per seed: x_up = round(x0 (1 + h)), x_down = round(x0 (1 - h))
   (the other input held; sig_bytes/perms set explicitly without a name, so
   the arms are `custom@B<b>/P<p>` and price proving with the modelled
   leanVM rows in both arms, while a named base point may use counted rows:
   `t_base` is informational, eps uses the two arms only; review E9), with
   `demand.offered_pq_tps = R0` so both
   arms see the base point's offered rate (arch.md 3.13), and the same seed:
   common random numbers (arrivals, fees, entries, topology, proposers are
   keyed by identity, not draw order: arch.md 3.13, demand.py). Only sizes,
   gas and costs move.
3. Per seed eps = ln(T_up / T_down) / ln(x_up / x_down) with the *achieved*
   (rounded) inputs; T = `metric` (default `pq_tps`, included PQ tx/s).
   This is eps_fair: under kind-blind fee rationing PQ txs compete with the
   ECDSA background for the binding resource.
4. eps_supply = eps_fair / s_PQ per seed (`attribution.fair_and_supply`),
   s_PQ = the PQ share of the BINDING resource (inbox 08:35 UTC
   correction): the resource's share column of `attribution.
   PQ_SHARE_COLUMN` averaged over the two arms (gas -> pq_share_gas, bytes
   -> pq_share_bytes; review E1), 1 when the dependency cap, the provers or
   the builder deadline bind, NA (with the reason) for a resource without a
   share mapping. The binding resource is, in order: `resource=` if given;
   else the shadow-price label when `attribute` ran on the point (the CLI's
   --attribute; an unresolved or co-binding label gives NA, review E5);
   else the base rows' `binding` label (util heuristic) when all seeds agree
   on one resource and no arm's label differs from it (an arm across a kink
   gives NA, review E8); else NA.
5. Summaries: mean, sd, Student-t interval over seeds (>= 2 seeds; 5 for
   headline cells, arch.md 3.13).

`attribute`: `attribution.shadow_prices` over `attribution.default_knobs`
with every arm at the base offered rate, same seeds (CRN).

All runs go through `sweep3.run_specs` (<= 8 workers, JSONL cache), so the
results do not depend on `jobs`.
"""

from starksim.v3 import attribution as A
from starksim.v3 import spec as spec_module
from starksim.v3 import sweep3

INPUTS = ("sig_bytes", "perms")
METRIC_DEFAULT = "pq_tps"
UTIL_RESOURCE = {"gas": "gas", "bytes": "bytes", "dep_cap": "dep_cap",
                 "builder_proof": "builder_proof",
                 "prover_pool": "prover_pool"}


class ElasticityError(ValueError):
    pass


def _resolve(params, deployment, sets):
    return spec_module.resolve(params, deployment, sets=sets)


def base_sets(sets):
    out = dict(sets or {})
    out["demand.mode"] = "saturate"
    for key in ("demand.level_tps", "demand.pq_share"):
        out.pop(key, None)
    return out


def arm_value(x0, h, sign):
    """round(x0 (1 + sign h)); raises when it equals x0."""
    value = int(x0 * (1.0 + sign * h) + 0.5)
    if value == x0 or value < 1:
        raise ElasticityError(f"{x0} x (1 {'+' if sign > 0 else '-'} {h}) "
                              "rounds to itself or below 1")
    return value


def base_runs(params, deployment, sets, seeds, jobs=1, cache=None):
    """[(seed, spec, row)] of the base point, and the offered rate R0 (the
    same for every seed: the bound is analytic)."""
    specs = []
    for seed in seeds:
        point = dict(sets)
        point["seed"] = int(seed)
        specs.append(_resolve(params, deployment, point))
    rows = sweep3.run_specs(specs, params, jobs=jobs, cache=cache)
    offered = {row["offered_tps"] for row in rows}
    if len(offered) != 1 or None in offered:
        raise ElasticityError(f"base offered rate differs by seed or is "
                              f"missing: {sorted(map(str, offered))}")
    return list(zip(seeds, specs, rows)), offered.pop()


def binding_resource(rows, resource=None):
    """(resource or None, how it was chosen)."""
    if resource is not None:
        return resource, "given"
    labels = sorted({row["binding"] for row in rows})
    if len(labels) == 1 and "+" not in labels[0] and \
            labels[0] in UTIL_RESOURCE:
        return UTIL_RESOURCE[labels[0]], "util_heuristic (all seeds agree)"
    return None, f"base rows' binding labels {labels}: no single resource"


def check_seeds(seeds):
    """Distinct ints (duplicates would shrink the interval: review E7)."""
    seeds = [int(seed) for seed in seeds]
    if not seeds:
        raise ElasticityError("no seeds")
    if len(set(seeds)) != len(seeds):
        raise ElasticityError(f"duplicate seeds {seeds}: each seed is one "
                              "independent replicate")
    return seeds


def estimate(sets, params, deployment, input="sig_bytes", seeds=(0, 1, 2),
             h=A.H_DEFAULT, resource=None, metric=METRIC_DEFAULT, jobs=1,
             cache=None, level=A.LEVEL_DEFAULT, resource_rule=None):
    """The elasticity record of one point (module docstring; INTERFACES.md
    section 6). `resource_rule` names how a given `resource` was chosen
    (e.g. the attribute verb's outcome)."""
    if input not in INPUTS:
        raise ElasticityError(f"input {input!r}: one of {INPUTS}")
    if deployment == "today":
        raise ElasticityError("today carries no PQ signature")
    seeds = check_seeds(seeds)
    sets = base_sets(sets)
    base, offered = base_runs(params, deployment, sets, seeds, jobs, cache)
    spec0 = base[0][1]
    x0 = int(getattr(spec0, input))
    other = "perms" if input == "sig_bytes" else "sig_bytes"
    held = int(getattr(spec0, other))
    up, down = arm_value(x0, h, 1), arm_value(x0, h, -1)
    arm_specs = []
    for seed in seeds:
        for value in (up, down):
            point = dict(sets)
            point.update({"seed": seed, input: value, other: held,
                          "demand.offered_pq_tps": offered})
            arm_specs.append(_resolve(params, deployment, point))
    rows = sweep3.run_specs(arm_specs, params, jobs=jobs, cache=cache)
    chosen, how = binding_resource([b[2] for b in base], resource)
    if resource_rule is not None:
        how = resource_rule
    column = A.PQ_SHARE_COLUMN.get(chosen)
    column = column if isinstance(column, str) else None
    eps, shares, per_seed = [], [], []
    arms_agree = True
    for i, seed in enumerate(seeds):
        r_up, r_down = rows[2 * i], rows[2 * i + 1]
        t_up, t_down = float(r_up[metric]), float(r_down[metric])
        value = A.log_slope(t_up, t_down, float(up), float(down))
        eps.append(value)
        share = None
        if column is not None and r_up[column] is not None and \
                r_down[column] is not None:
            share = 0.5 * (r_up[column] + r_down[column])
        shares.append(share)
        base_label = base[i][2]["binding"]
        if r_up["binding"] != base_label or r_down["binding"] != base_label:
            arms_agree = False
        per_seed.append({"seed": seed, "eps_fair": value,
                         "t_up": t_up, "t_down": t_down,
                         "t_base": float(base[i][2][metric]),
                         "binding_base": base_label,
                         "binding_up": r_up["binding"],
                         "binding_down": r_down["binding"],
                         "share_column": column,
                         "pq_share_arms": share,
                         "spec_hash_up": r_up["spec_hash"],
                         "spec_hash_down": r_down["spec_hash"]})
    if chosen is not None and how.startswith("util_heuristic") and \
            not arms_agree:
        # An arm crossed a kink (its util label differs): the base point's
        # resource does not describe the difference (review E8).
        how = (f"{how}; an arm's binding label differs from the base's: "
               "eps_supply not derived")
        chosen = None
    pair = A.fair_and_supply(eps, shares if column is not None else None,
                             chosen, level, key=input)
    return {
        "record": "elasticity", "input": input, "h": h, "metric": metric,
        "deployment": deployment, "candidate": spec0.candidate_label,
        "x_base": x0, "x_up": up, "x_down": down, "held": {other: held},
        "base_offered_pq_tps": offered, "resource": chosen,
        "resource_rule": how,
        "s_pq": _summary(pair.s_pq), "eps_fair": _summary(pair.fair),
        "eps_supply": _summary(pair.supply), "note": pair.note,
        "per_seed": per_seed, "base_spec_hash": base[0][2]["spec_hash"],
    }


def _summary(summary):
    if summary is None:
        return None
    return {"mean": summary.mean, "sd": summary.sd, "ci_lo": summary.ci_lo,
            "ci_hi": summary.ci_hi, "seeds": summary.n,
            "level": summary.level}


def attribute(sets, params, deployment, seeds=(0, 1, 2), h=A.H_DEFAULT,
              metric=METRIC_DEFAULT, jobs=1, cache=None,
              level=A.LEVEL_DEFAULT, knobs=None):
    """Shadow prices of the point's capacities (attribution.shadow_prices),
    every arm at the base offered rate. Returns a JSON-able dict."""
    seeds = check_seeds(seeds)
    sets = base_sets(sets)
    base, offered = base_runs(params, deployment, sets, seeds, jobs, cache)
    spec0 = base[0][1]
    knobs = knobs or A.default_knobs(spec0)
    specs = {}

    def spec_for(extra, seed):
        point = dict(sets)
        point["seed"] = seed
        if extra:
            point.update(extra)
            point["demand.offered_pq_tps"] = offered
        return _resolve(params, deployment, point)

    wanted = []
    for name in sorted(knobs):
        key, value = knobs[name]
        for factor in (1.0 + h, 1.0 - h):
            arm = A.scaled(key, value, factor)
            for seed in seeds:
                wanted.append(((key, arm, seed), spec_for({key: arm}, seed)))
    rows = sweep3.run_specs([s for _k, s in wanted], params, jobs=jobs,
                            cache=cache)
    for (k, _s), row in zip(wanted, rows):
        specs[k] = row
    base_rows = {seed: row for seed, _spec, row in base}

    def run(extra, seed):
        if not extra:
            return base_rows[seed]
        (key, value), = extra.items()
        return specs[(key, value, seed)]

    result = A.shadow_prices(run, knobs, seeds, h, metric, level)
    return {
        "record": "attribution", "deployment": deployment,
        "candidate": spec0.candidate_label, "metric": metric, "h": h,
        "base_offered_pq_tps": offered, "seeds": list(seeds),
        "binding": result.label.binding, "method": result.label.method,
        "margin": result.label.margin, "strict": list(result.strict),
        "shares": result.shares, "sum_up": result.sum_up,
        "sum_down": result.sum_down, "collapsed": list(result.collapsed),
        "pvalues": result.pvalues,
        "prices": {name: {"key": p.key, "base": p.base, "up": p.up,
                          "down": p.down, "s_up": _summary(p.s_up),
                          "s_down": _summary(p.s_down),
                          "s_central": _summary(p.s_central)}
                   for name, p in result.prices.items()},
        "base_bindings": [row["binding"] for row in base_rows.values()],
    }


def binding_from_attribution(record):
    """The single binding resource of an `attribute` record, or None."""
    label = record["binding"]
    if "+" in label or label == "unresolved":
        return None
    return {"prover": "prover"}.get(label, label)

"""Inputs of the v3 simulator: the two campaign parameter files and the
signature candidates, with provenance.

Files (campaign `data/`, or `$LEANSPHINCS_DATA`):

- `phase4/network_params_v3.json` (parameter researcher): leaves
  `{value, unit, source, read, status, note?, draw?}`.
- `phase4/deployments_v3.json` (spec researcher): `constants` leaves
  `{value, unit, source, status, deployment, note}`; the optional sections
  `tx_shapes`, `forks`, `deployments`, `assumptions` (arch.md section 6.1)
  may be absent while the researchers complete them. `section(name)` raises
  `MissingSection` naming the section and the note that defines it; loading
  never fails for a missing optional section.
- `phase2/candidates_v2.csv` and `phase2/guest_counts.json`: the candidate
  table and the counted leanVM rows.

Model code never indexes the JSON: it asks for a sim name of `BINDINGS`
(`params.value("rtt_p50_ms")`) or a deployments constant
(`params.constant("MAX_VERIFY_GAS")`). Every answer is recorded with its
status so a row can report `input_status`. In strict mode (the default) a
bound leaf without `source` or `status` is an error.

A missing binding with an `[A]` default in `BINDINGS` (arch.md section 6.3,
"missing" rows) returns the default and records status `A`: the run says
which inputs are assumptions.
"""

import csv
import difflib
import hashlib
import io
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))

NETWORK_FILE = os.path.join("phase4", "network_params_v3.json")
DEPLOYMENTS_FILE = os.path.join("phase4", "deployments_v3.json")
CANDIDATES_FILE = os.path.join("phase2", "candidates_v2.csv")
GUEST_COUNTS_FILE = os.path.join("phase2", "guest_counts.json")
PROVER_MODEL_FILE = "prover_model.py"

OPTIONAL_SECTIONS = {
    "tx_shapes": "arch.md section 6.1 (gas and bytes as coefficient objects)",
    "forks": "arch.md section 6.1 (PBS mode and deadlines per fork)",
    "deployments": "arch.md section 6.1 (admission, wrapper, block rules)",
    "assumptions": "arch.md section 6.1 (Q1..Q13 defaults)",
}


class ParamsError(ValueError):
    """A parameter file is malformed, or a bound leaf lacks provenance."""


class MissingSection(ParamsError):
    """An optional section of deployments_v3.json is not written yet."""


class UnknownCandidate(ValueError):
    """A candidate name that is not in the table (REPORT-PHASE2B defect 1)."""


def data_dir():
    """The campaign's data directory: `$LEANSPHINCS_DATA`, else the
    directory two levels above the repository (sims/<worktree>/../../data)."""
    configured = os.environ.get("LEANSPHINCS_DATA")
    if configured:
        return configured
    return os.path.normpath(os.path.join(REPO_ROOT, "..", "..", "data"))


# ---------------------------------------------------------------- bindings
# sim name -> (file, path, default). `file` is "net" or "dep"; `path` is a
# tuple of keys (some keys of network_params_v3.json contain dots, e.g.
# "geth.fetcher", so a path is never a dotted string). `default` is None for
# a required leaf, else (value, source) used with status "A" when the leaf
# is absent. Append-only: S2 engineers add rows at the end of their block.
NET = "net"
DEP = "dep"
BINDINGS = {
    # topology (S1)
    "region_names": (NET, ("regions", "names"), None),
    "region_weights": (NET, ("regions", "weights"), None),
    "rtt_ms": (NET, ("regions", "rtt_ms"), None),
    "access_one_way_ms_datacentre": (
        NET, ("regions", "access_one_way_ms", "datacentre"), None),
    "access_one_way_ms_home": (
        NET, ("regions", "access_one_way_ms", "home"), None),
    "uplink_classes": (NET, ("bandwidth", "uplink_classes"), None),
    "downlink_over_uplink_home": (
        NET, ("bandwidth", "downlink_over_uplink_home"), None),
    "background_mbps": (
        NET, ("bandwidth", "background_load", "recommended_background_mbps"),
        None),
    "el_nodes": (NET, ("topology", "el_nodes", "recommended"), None),
    "el_client_share": (NET, ("topology", "el_client_share_2026-10-03"), None),
    "max_peers_geth": (NET, ("topology", "max_peers", "geth"), None),
    "max_peers_nethermind": (NET, ("topology", "max_peers", "nethermind"),
                             None),
    "max_peers_reth": (NET, ("topology", "max_peers", "reth"), None),
    "max_peers_erigon": (NET, ("topology", "max_peers", "erigon"), None),
    "max_peers_besu": (NET, ("topology", "max_peers", "besu"), None),
    "reachable_share": (NET, ("topology", "reachable_share"), None),
    "el_degree": (NET, ("topology", "el_degree"), None),
    "cl_D": (NET, ("topology", "cl_mesh", "D"), None),
    "cl_D_low": (NET, ("topology", "cl_mesh", "D_low"), None),
    "cl_D_high": (NET, ("topology", "cl_mesh", "D_high"), None),
    "cl_D_lazy": (NET, ("topology", "cl_mesh", "D_lazy"), None),
    "cl_heartbeat_ms": (NET, ("topology", "cl_mesh", "heartbeat_ms"), None),
    "cl_lighthouse_D": (NET, ("topology", "cl_mesh", "lighthouse_D"), None),
    "cl_lighthouse_share": (NET, ("topology", "cl_client_share_lighthouse"),
                            None),
    # arch.md section 6.3 "missing" rows: [A] defaults until the parameter
    # researcher writes them.
    "downlink_over_uplink_datacentre": (
        NET, ("bandwidth", "downlink_over_uplink_datacentre"),
        (1.0, "arch.md 6.3 default: datacentre symmetric (params draw note)")),
    "lane_weights": (
        NET, ("bandwidth", "lane_weights"),
        ({"el": 1.0, "cl": 1.0},
         "arch.md 3.3/6.3 default 1:1 (two processes, many TCP flows each)")),
    "builder_count": (
        NET, ("topology", "builders", "count"),
        (3, "arch.md 3.2 default: 3 builders (relay market concentration)")),
    "builder_el_degree_factor": (
        NET, ("topology", "builders", "el_degree_factor"),
        (3.0, "arch.md 3.2 default: builder EL degree = 3 x geth cap")),
    "builder_uplink_mbps": (
        NET, ("topology", "builders", "uplink_mbps"),
        (10000.0, "arch.md 3.2 default: builders are datacentre servers; "
                  "10 Gbit/s [A]")),
    "validator_share": (
        NET, ("topology", "validator_share"),
        (0.5, "arch.md 6.3 default: half the nodes host validators [A]")),
    "supernode_share": (
        NET, ("cl_gossip", "supernode_share"),
        (0.1, "arch.md 6.3 default: 10 % full-custody nodes [A]")),
    "edge_jitter": (
        NET, ("regions", "edge_jitter"),
        (0.1, "regions.rtt_ms draw: lognormal sigma 0.1; v3 applies it as a "
              "fixed per-edge factor 1 + 0.1 f(u,v) (arch.md 3.2)")),
}


def register_bindings(table):
    """Add a module's own bindings (same row format as BINDINGS).

    Stage modules (elgossip, mempool, clgossip, demand, prover, slot,
    deploy_*) declare their parameters in their own file and register them
    at import, so no stage edits this shared table. A name already bound to
    a different path or default is an error; re-registering the same row is
    a no-op (module reloads).
    """
    for name, row in table.items():
        existing = BINDINGS.get(name)
        if existing is not None and existing != row:
            raise ParamsError(f"binding {name!r} already registered as "
                              f"{existing!r}")
        if row[0] not in (NET, DEP) or not isinstance(row[1], tuple):
            raise ParamsError(f"binding {name!r}: expected (file, path "
                              "tuple, default)")
        BINDINGS[name] = row


def _primary_tag(status):
    """'[R] counts, [Mo] mapping' -> 'R'; 'shares [R], rates [Mo]' -> 'R';
    'E-draft' -> 'E-draft'; 'none' -> 'none'. The first bracketed tag (else
    the leading word) names the evidence class of the value."""
    text = str(status)
    match = re.search(r"\[([A-Za-z][A-Za-z0-9-]*)", text)
    if match:
        return match.group(1)
    match = re.match(r"\s*([A-Za-z][A-Za-z0-9-]*)", text)
    return match.group(1) if match else text


class Leaf:
    """One parameter: value with unit, source and status, and where it came
    from (`origin` = 'file:pointer' or 'default')."""

    __slots__ = ("name", "value", "unit", "source", "status", "draw", "note",
                 "origin")

    def __init__(self, name, value, unit, source, status, draw, note, origin):
        self.name = name
        self.value = value
        self.unit = unit
        self.source = source
        self.status = status
        self.draw = draw
        self.note = note
        self.origin = origin

    def tag(self):
        return _primary_tag(self.status)

    def as_dict(self):
        return {"name": self.name, "value": self.value, "unit": self.unit,
                "source": self.source, "status": self.status,
                "origin": self.origin}


class Params:
    """The loaded inputs. Build with `Params.load()` (files) or
    `Params.from_dicts()` (tests, the browser)."""

    def __init__(self, network, deployments, candidates_csv_text=None,
                 guest_counts=None, network_sha256="", deployments_sha256="",
                 strict=True):
        if not isinstance(network, dict) or not isinstance(deployments, dict):
            raise ParamsError("both parameter documents must be JSON objects")
        if "constants" not in deployments:
            raise ParamsError("deployments_v3.json has no 'constants' table")
        self.network = network
        self.deployments = deployments
        self.network_sha256 = network_sha256
        self.deployments_sha256 = deployments_sha256
        self.strict = strict
        self.used = {}
        self._candidate_rows = _parse_candidates(candidates_csv_text)
        self._guest_counts = guest_counts
        # The other inputs a run reads (candidate table, counted rows, and
        # prover_model.py when loaded from files): part of spec_hash and of
        # the sweep cache key (S5 review E2).
        self.data_sha256 = data_digest(candidates_csv_text, guest_counts)

    # -- construction
    @classmethod
    def load(cls, directory=None, strict=True):
        directory = directory or data_dir()
        network_bytes = _read_bytes(os.path.join(directory, NETWORK_FILE))
        deployments_bytes = _read_bytes(os.path.join(directory,
                                                     DEPLOYMENTS_FILE))
        candidates_path = os.path.join(directory, CANDIDATES_FILE)
        candidates_text = None
        if os.path.exists(candidates_path):
            candidates_text = _read_bytes(candidates_path).decode("utf-8")
        counts_path = os.path.join(directory, GUEST_COUNTS_FILE)
        counts = None
        if os.path.exists(counts_path):
            counts = json.loads(_read_bytes(counts_path).decode("utf-8"))
        result = cls(json.loads(network_bytes.decode("utf-8")),
                     json.loads(deployments_bytes.decode("utf-8")),
                     candidates_text, counts,
                     hashlib.sha256(network_bytes).hexdigest(),
                     hashlib.sha256(deployments_bytes).hexdigest(), strict)
        model_path = os.path.join(directory, PROVER_MODEL_FILE)
        if os.path.exists(model_path):
            result.data_sha256 = data_digest(candidates_text, counts,
                                             _read_bytes(model_path))
        return result

    @classmethod
    def from_dicts(cls, network, deployments, candidates_csv_text=None,
                   guest_counts=None, strict=True):
        network_sha = hashlib.sha256(_canonical(network)).hexdigest()
        deployments_sha = hashlib.sha256(_canonical(deployments)).hexdigest()
        return cls(network, deployments, candidates_csv_text, guest_counts,
                   network_sha, deployments_sha, strict)

    def fresh(self):
        """The same inputs with an empty `used` record: one per run, so a
        row's `input_status` counts only what that run read."""
        result = Params.__new__(Params)
        result.__dict__.update(self.__dict__)
        result.used = {}
        return result

    # -- bound network leaves
    def leaf(self, name):
        """The `Leaf` of a sim name of `BINDINGS` (recorded as used)."""
        if name not in BINDINGS:
            raise ParamsError(f"unknown parameter name {name!r}; add it to "
                              "params.BINDINGS with its JSON path")
        document_key, path, default = BINDINGS[name]
        document = self.network if document_key == NET else self.deployments
        node = _walk(document, path)
        file_name = NETWORK_FILE if document_key == NET else DEPLOYMENTS_FILE
        pointer = "/".join(path)
        if node is None:
            if default is None:
                raise ParamsError(f"{file_name}: required leaf /{pointer} "
                                  f"({name}) is missing")
            # (value, source) is an [A] default; (value, source, status)
            # a sourced fallback written in code (S6b calibration keys,
            # whose provenance is data/phase4/calib2_params.json).
            value, source = default[0], default[1]
            status = default[2] if len(default) > 2 else "A"
            result = Leaf(name, value, None, source, status, None, None,
                          "default")
        else:
            result = self._leaf_from(name, node, f"{file_name}:/{pointer}")
        self.used[name] = result
        return result

    def value(self, name):
        return self.leaf(name).value

    def _leaf_from(self, name, node, origin):
        if not isinstance(node, dict) or "value" not in node:
            # A plain JSON value (e.g. regions.names): provenance is the
            # file's; strict mode accepts it only for lists of names.
            if isinstance(node, list) and all(isinstance(item, str)
                                              for item in node):
                return Leaf(name, node, "names", origin, "R", None, None,
                            origin)
            raise ParamsError(f"{origin} ({name}) is not a "
                              "{value, source, status} leaf")
        source = node.get("source")
        status = node.get("status")
        if self.strict and (not source or not status):
            raise ParamsError(f"{origin} ({name}) lacks "
                              f"{'source' if not source else 'status'} "
                              "(strict mode)")
        return Leaf(name, node["value"], node.get("unit"), source, status,
                    node.get("draw"), node.get("note"), origin)

    # -- deployments constants and sections
    def constant(self, name):
        """A leaf of deployments_v3.json `constants` (recorded as used)."""
        table = self.deployments["constants"]
        if name not in table:
            near = difflib.get_close_matches(name, sorted(table), n=3)
            raise ParamsError(f"deployments_v3.json has no constant {name!r}"
                              f"; nearest: {', '.join(near) or 'none'}")
        result = self._leaf_from(name, table[name],
                                 f"{DEPLOYMENTS_FILE}:/constants/{name}")
        self.used["const:" + name] = result
        return result

    def constant_value(self, name):
        return self.constant(name).value

    def has_section(self, name):
        return name in self.deployments

    def section(self, name):
        """An optional section of deployments_v3.json, or MissingSection."""
        if name not in OPTIONAL_SECTIONS:
            raise ParamsError(f"{name!r} is not a deployments_v3.json "
                              f"section; known: {sorted(OPTIONAL_SECTIONS)}")
        if name not in self.deployments:
            raise MissingSection(
                f"deployments_v3.json has no '{name}' section yet (defined in "
                f"{OPTIONAL_SECTIONS[name]}); the spec researcher is writing "
                "it. Use the [A] fallback of the caller or wait for the file")
        return self.deployments[name]

    def deployment_entry(self, deployment_id):
        """`deployments.<id>` of deployments_v3.json with its `inherits`
        chain merged (the child's keys win, one level of dict merge), or
        MissingSection. Values are raw leaves."""
        return _inherited(self.section("deployments"), deployment_id,
                          "deployments")

    def fork(self, name):
        """`forks.<name>` with its `inherits` chain merged, or
        MissingSection."""
        return _inherited(self.section("forks"), name, "forks")

    def raw_network(self, *path):
        """An unbound network subtree, for diagnostics only (not recorded,
        not for model code: model code binds its names in BINDINGS)."""
        return _walk(self.network, path)

    # -- provenance summary
    def input_status(self):
        """Counts of the primary status tags of every input used so far."""
        counts = {}
        for name in sorted(self.used):
            tag = self.used[name].tag()
            counts[tag] = counts.get(tag, 0) + 1
        return counts

    # -- candidates
    def candidate_names(self):
        result = list(BUILTIN_CANDIDATES)
        for name in self._candidate_rows:
            if name not in result:
                result.append(name)
        return result

    def candidate(self, name):
        """name -> {name, params, sig_bytes, perms, counted}; raises
        UnknownCandidate with the three nearest names."""
        known = BUILTIN_CANDIDATES.get(name) or self._candidate_rows.get(name)
        if known is None:
            near = difflib.get_close_matches(name, self.candidate_names(),
                                             n=3, cutoff=0.0)
            raise UnknownCandidate(
                f"unknown candidate {name!r}; nearest: {', '.join(near)}. "
                "Give --set sig_bytes=..,perms=.. without a name for a "
                "custom signature")
        parameters, sig_bytes, perms = known
        return {"name": name, "params": parameters, "sig_bytes": sig_bytes,
                "perms": perms, "counted": self.counted_rows(parameters)}

    def counted_rows(self, parameters):
        """(shape name, rows per signature) counted by guest_counts.json for
        these parameters, else None (same rule as the v2 registry)."""
        for shape in (self._guest_counts or {}).get("shapes", ()):
            if shape.get("params") != parameters:
                continue
            if "rows_per_sig" not in shape:
                continue
            rows = {}
            for source, target in COUNTED_TABLES:
                rows[target] = float(shape["rows_per_sig"][source])
            rows["MEM"] = float(shape["memory_cells_per_sig"])
            return shape["name"], rows
        return None

    def candidate_file_rows(self):
        return dict(self._candidate_rows)


# PHASE2B.md section 2 as (parameters, signature bytes, verify permutations);
# built in so names resolve without data/phase2. Must agree with
# candidates_v2.csv and bench/leansphincs/registry.py (tests/v3/test_params).
BUILTIN_CANDIDATES = {
    "B0": ("10+8+8|fors|a10|k24|w4|T128", 7740, 515),
    "P99r": ("24|fors|a10|k17|w4|T127|b11", 4420, 289),
    "P99a": ("24|fors|a11|k15|w4|T126|b11", 4308, 283),
    "S24-minB": ("24|fors|a11|k15|w8|T199|b11", 3972, 317),
    "S22-minP-5K": ("22|fors|a12|k13|w4|T124|b11", 4100, 271),
    "S22-minB-5K": ("22|fors|a12|k13|w8|T195|b11", 3764, 307),
    "N2": ("11+8+7|fors+c|a10|k15|w4|T124", 5980, 415),
    "N3r": ("11+8+7|fors|a10|k15|w4|T124", 6156, 426),
}
COUNTED_TABLES = (("XOR", "XOR"), ("MUL", "MUL"), ("SET", "SET"),
                  ("DEREF", "DEREF"), ("JUMP", "JUMP"), ("KECCAK", "K"))


def _parse_candidates(text):
    """candidates_v2.csv -> name -> (params, B, P_F); a row's `name` lists
    aliases separated by '/'. Bytes are column B, permutations column P_F."""
    result = {}
    if not text:
        return result
    for row in csv.DictReader(io.StringIO(text)):
        for alias in row["name"].split("/"):
            alias = alias.strip()
            if alias and alias not in result:
                result[alias] = (row["params"], int(row["B"]),
                                 int(row["P_F"]))
    return result


def _inherited(table, name, section):
    chain = []
    current = name
    while current is not None:
        if current not in table:
            raise ParamsError(f"deployments_v3.json {section} has no "
                              f"{current!r} (inherited by {name!r})")
        if current in chain:
            raise ParamsError(f"{section}: inheritance cycle at {current!r}")
        chain.append(current)
        current = table[current].get("inherits")
    merged = {}
    for entry_name in reversed(chain):
        for key, value in table[entry_name].items():
            if key == "inherits":
                continue
            if isinstance(value, dict) and isinstance(merged.get(key), dict) \
                    and "value" not in value:
                combined = dict(merged[key])
                combined.update(value)
                merged[key] = combined
            else:
                merged[key] = value
    return merged


def _walk(document, path):
    node = document
    for key in path:
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    return node


def _read_bytes(path):
    if not os.path.exists(path):
        raise ParamsError(f"parameter file not found: {path} (set "
                          "$LEANSPHINCS_DATA to the campaign's data/)")
    with open(path, "rb") as handle:
        return handle.read()


def data_digest(candidates_csv_text, guest_counts, prover_model_bytes=b""):
    """sha256 over the candidate CSV text, the canonical guest counts and
    prover_model.py's bytes (each length-prefixed)."""
    digest = hashlib.sha256()
    parts = ((candidates_csv_text or "").encode("utf-8"),
             _canonical(guest_counts) if guest_counts is not None else b"",
             prover_model_bytes or b"")
    for part in parts:
        digest.update(str(len(part)).encode("ascii") + b":")
        digest.update(part)
    return digest.hexdigest()


def _canonical(document):
    return json.dumps(document, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


_DEFAULT = None


def default_params():
    """The campaign files, loaded once per process."""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = Params.load()
    return _DEFAULT

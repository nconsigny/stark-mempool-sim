"""Stage S6 validation of the v3 simulator (arch.md section 5).

    python3 -m bench.leansphincs validate [--limits] [--v2-cells] [--mainnet]
            [--determinism] [--all] [--jobs 4] [--nodes N] [--seeds 0,1]
            [--out DIR] [--rows a.json,b.json] [--site DIR]

Four checks, each a list of result dicts {check, case, expected, got,
tolerance, verdict, note}; `verdict` is pass | fail | info (info: reported,
not compared, with the reason in `note`). The exit code is 1 when any
verdict is fail.

--limits      arch.md 5.1: every deployment, route and dependency cap on an
              ideal network (zero latency, unmetered links, no ECDSA),
              saturated, through the full engine (runner.execute); the
              measured PQ tx/s must equal the analytic bound of the binding
              resource (`deploy.analytic_bounds()`, whole txs per block)
              exactly when gas, bytes or the dependency cap binds; under a
              lone builder prover (no gas limit, no mempool aggregators) every
              canonical block must hold exactly the largest prefix that
              prover.tree_plan fits in that slot's proof window; and the
              EIP-1559 path of demand.eip1559_next equals the EIP's reference
              code on a fixed gas sequence.
--v2-cells    arch.md 5.2: v3 on the v2 cells of data/phase2b
              (scenario_table_*.csv at 582169c) at 40 nodes; compares and
              names each expected difference (V2_CELLS), never forces equality.
--mainnet     arch.md 5.3: `today` (Fulu, MEV-boost, 60 M gas, ECDSA only)
              against every target of data/phase4/validation_targets.json:
              the row's `val.<target>.<key>` column per tolerance key, abs
              [lo, hi] or rel [lo, hi] x observed; an unknown target or key
              fails loudly. Observers: datacentre nodes (the file's
              observer_rule). Rows: run here (--nodes, --seeds) or given
              (--rows: run JSON files, e.g. from `run --out`).
--determinism arch.md 5.4: one spec run in two fresh interpreters with
              different PYTHONHASHSEED gives byte-identical row JSON; with
              --site, web-v3/test/determinism.mjs (browser worker == CLI on
              the site's bundle) is run and its verdict read.

Every number here is [M] (a run of the simulator) or [Mo] (an analytic
bound); neither is a mainnet measurement except the targets file's [C]
values.
"""

import argparse
import csv
import json
import os
import subprocess
import sys
import tempfile

CAMPAIGN = os.environ.get("LEANSPHINCS_CAMPAIGN", "/projects/leanSPHINCS")
TARGETS_V1 = os.path.join(CAMPAIGN, "data", "phase4",
                          "validation_targets.json")
# S6b: v2 = v1 re-scored like with like (data/phase4/
# make_validation_targets_v2.py); v1 stays for traceability (--targets v1).
TARGETS_V2 = os.path.join(CAMPAIGN, "data", "phase4",
                          "validation_targets_v2.json")
TARGETS = TARGETS_V2
TARGET_FILES = {"v1": TARGETS_V1, "v2": TARGETS_V2}
V2_TABLES = (os.path.join(CAMPAIGN, "data", "phase2b",
                          "scenario_table_noagg.csv"),
             os.path.join(CAMPAIGN, "data", "phase2b",
                          "scenario_table_agg.csv"))

EXACT = 1e-9                      # [A] float tolerance of an exact count / 12
SLOT_S = 12.0                     # [E] spec.md T5
IDEAL = {"nodes": 12, "net.mode": "ideal", "demand.ecdsa_tps": 0.0,
         "net.columns": "background", "slots.warmup": 2,
         "slots.measured": 2, "slots.drain": 0}   # [A] as test_deploy_8141.ideal_run

# (case, deployment, sets, expected PQ tx/s or None = min of the bounds,
#  binding expected). Every agg case lifts proving out of the way
# (scale.prover) unless it tests proving: limits are about gas, bytes, caps.
_FAST_PROVER = {"scale.prover": 1000.0}   # [A] proving never binds
BUNDLE_USERS = 226               # [R+C] pcs_bundler bundle of P99r k = 1 (v2 F3 cell, prover.parse_bundle_cap)
POOL_CASES = ("8288 P99r 200 M", "8288 P99r 300 M dep cap 4096")
SERVING_CASE = "leanPCS pcs_client 200 M"
SERVING_SCALE = 100.0            # [A] serving budget never binds
SERVING_NOTE = ("eth/73 serving budget x100: at the spec's 32 MiB/s per "
                "node every node fetching every 309 KB client wrapper caps "
                "pcs_client below its gas bound even on an ideal network "
                "(see the 'default serving budget' row)")
LIMIT_CASES = (
    ("8141 P99r k=1 200 M", "8141", {}, 656 / SLOT_S, "gas"),
    ("8141 B0 k=1 60 M", "8141", {"candidate": "B0",
                                  "chain.gas_limit": 60_000_000},
     116 / SLOT_S, "gas"),
    ("8141 P99r no gas limit, 7934 cap 8,388,608 B", "8141",
     {"chain.gas_limit": 0}, ((8_388_608 - 600) // 4564) / SLOT_S, "bytes"),
    ("8141 P99r k=2 200 M", "8141", {"k": 2}, None, "gas"),
    ("8288 P99r 60 M k=1", "8288", dict(_FAST_PROVER,
                                       **{"chain.gas_limit": 60_000_000}),
     (60_000_000 // 64_781) / SLOT_S, "gas"),
    ("8288 P99r 200 M", "8288", dict(_FAST_PROVER), 3087 / SLOT_S, "gas"),
    ("8288 P99r 200 M dep cap 256", "8288",
     dict(_FAST_PROVER, **{"chain.dep_cap": 256}), 256 / SLOT_S, "deps"),
    ("8288 P99r 300 M dep cap 4096", "8288",
     dict(_FAST_PROVER, **{"chain.dep_cap": 4096,
                           "chain.gas_limit": 300_000_000}),
     4096 / SLOT_S, "deps"),
    ("leanPCS dependency P99r 60 M", "leanpcs",
     dict(_FAST_PROVER, **{"chain.gas_limit": 60_000_000}), None, "gas"),
    ("leanPCS dependency 200 M dep cap 256", "leanpcs",
     dict(_FAST_PROVER, **{"chain.dep_cap": 256}), 256 / SLOT_S, "deps"),
    ("leanPCS pcs_client 200 M", "leanpcs",
     dict(_FAST_PROVER, **{"agg.sig_route": "pcs_client",
                           "slots.warmup": 3}), None, "gas"),
    ("leanPCS pcs_client 200 M dep cap 256", "leanpcs",
     dict(_FAST_PROVER, **{"agg.sig_route": "pcs_client",
                           "chain.dep_cap": 256}), 36 / SLOT_S, "deps"),
    ("leanPCS pcs_bundler 200 M", "leanpcs",
     dict(_FAST_PROVER, **{"agg.sig_route": "pcs_bundler"}), None, "gas"),
    ("leanPCS pcs_bundler 60 M", "leanpcs",
     dict(_FAST_PROVER, **{"agg.sig_route": "pcs_bundler",
                           "chain.gas_limit": 60_000_000,
                           "slots.warmup": 3}), None, "gas"),
)
UNBOUNDED_POOL_SLOTS = 10 ** 9   # [A] no pool capacity limit
POOL_NOTE = ("pool capacity lifted (ctx.mempool.capacity); at the default "
             "6,144 slots the 8288/leanPCS builder cannot hold two 200 M "
             "blocks of P99r deps while the parent is undecided (see the "
             "'default pool' rows)")
LONE_BUILDER = ("8288 lone builder prover, no gas limit", "8288",
                {"chain.gas_limit": 0, "agg.share": 0.0,
                 "chain.focil": False})   # [A] no IL STARK child: raw sigs only


# ------------------------------------------------------------------ util
def _result(check, case, expected, got, tolerance, verdict, note=""):
    return {"check": check, "case": case, "expected": expected, "got": got,
            "tolerance": tolerance, "verdict": verdict, "note": note}


def _params():
    from starksim.v3 import params as params_module
    return params_module.default_params().fresh()


def _resolve(params, deployment, sets):
    from starksim.v3 import spec as spec_module
    return spec_module.resolve(params, deployment, sets=sets)


def _execute(job):
    """Worker: (deployment, sets) -> (row, run_info, slot extras)."""
    deployment, sets, want_slots = job[:3]
    unbounded_pool = len(job) > 3 and job[3]
    budget_scale = job[4] if len(job) > 4 else None
    from starksim.v3 import runner
    params = _params()
    if budget_scale:
        # eth/73 serving budget (spec B13: 32 MiB/s per node, 8 per peer)
        # scaled: it binds pcs_client client wrappers (309 KB each, fetched
        # by every node) even on an ideal network (SERVING_NOTE).
        original = params.constant_value

        def scaled(name, *args, **kwargs):
            value = original(name, *args, **kwargs)
            if name.startswith("eth73_serving_budget"):
                return value * budget_scale
            return value
        params.constant_value = scaled
    spec = _resolve(params, deployment, sets)

    def prepare(ctx):
        # The 6,144-slot pool (geth GlobalSlots + GlobalQueue, mempool.py)
        # is a binding resource of its own above ~250 txs per slot: lifted
        # here so the check isolates gas, bytes and caps (POOL_NOTE).
        if unbounded_pool and getattr(ctx, "mempool", None) is not None:
            ctx.mempool.capacity = UNBOUNDED_POOL_SLOTS
    row, ctx = runner.execute(spec, params, prepare=prepare)
    extra = None
    if want_slots:
        extra = _lone_builder_slots(ctx)
    info = dict(ctx.run_info)
    info.pop("input_status", None)
    return row, info, extra


def _map(jobs, workers):
    workers = max(1, min(int(workers), 8, len(jobs)))   # [E] task brief: <= 8
    if workers == 1:
        return [_execute(job) for job in jobs]
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(max_workers=workers,
                             initializer=_nice) as pool:
        return list(pool.map(_execute, jobs))


def _nice():
    try:
        os.nice(10)   # [E] task brief: sweeps at nice 10
    except (OSError, AttributeError):
        pass


# ---------------------------------------------------------------- limits
def _lone_builder_slots(ctx):
    """Per canonical measured slot: (PQ txs included, largest prefix the
    builder's tree_plan fits in that slot's window, window ms)."""
    from starksim.v3.prover import tree_plan
    from starksim.v3.state import KIND_ECDSA
    spec = ctx.spec
    first, last = spec.slots.warmup, spec.slots.warmup + spec.slots.measured
    out = []
    provers = ctx.prover
    model = provers.model
    for record in ctx.slot.slot_records():
        if record.status != "canonical" or not first <= record.slot < last:
            continue
        payload = record.payload
        pq = [tx for tx in payload.txs
              if ctx.txs.kind[tx] != KIND_ECDSA]
        _proof_ms, window = ctx.deploy.proof_plan(record.slot)
        builder = payload.builder
        hw = ctx.nodes.prover_class[builder] or provers.builder_class
        p = max(1, provers.parallel(builder))
        low, high = 0, 1
        while tree_plan(model, hw, p, high, [], window).fits:
            low, high = high, high * 2
        while high - low > 1:
            mid = (low + high) // 2
            if tree_plan(model, hw, p, mid, [], window).fits:
                low = mid
            else:
                high = mid
        n = len(pq)
        largest = (tree_plan(model, hw, p, n, [], window).fits and
                   not tree_plan(model, hw, p, n + 1, [], window).fits)
        out.append({"slot": record.slot, "included": n, "bound": low,
                    "window_ms": window, "largest": largest})
    return out


def eip1559_reference(base_fee, gas_used, gas_target, denominator):
    """EIP-1559 reference code (eip-1559.md, `validate_block`), restated
    independently of demand.py."""
    if gas_used == gas_target:
        return base_fee
    if gas_used > gas_target:
        delta = max(base_fee * (gas_used - gas_target) // gas_target
                    // denominator, 1)
        return base_fee + delta
    delta = base_fee * (gas_target - gas_used) // gas_target // denominator
    return base_fee - delta


def check_eip1559():
    from starksim.v3.demand import eip1559_next
    target, denominator = 30_000_000, 8          # [E] EIP-1559 / 60 M limit
    sequence = [60_000_000, 60_000_000, 0, 30_000_000, 45_000_000,
                1, 29_999_999, 59_999_999, 0, 0, 17_000_000]  # [A] test path
    a = b = 7                                    # [A] small base fee (delta floor)
    path_a, path_b = [], []
    for _round in range(3):
        for used in sequence:
            a = eip1559_next(a, used, target, denominator)
            b = eip1559_reference(b, used, target, denominator)
            path_a.append(a)
            path_b.append(b)
    a = b = 10 ** 9 * 13                         # [A] 13 gwei
    for used in sequence:
        a = eip1559_next(a, used, target, denominator)
        b = eip1559_reference(b, used, target, denominator)
        path_a.append(a)
        path_b.append(b)
    ok = path_a == path_b
    return _result("limits", "EIP-1559 base fee path (44 blocks)",
                   path_b[-3:], path_a[-3:], "exact",
                   "pass" if ok else "fail")


def check_limits(jobs=4):
    params = _params()
    from starksim.v3 import runner
    work, meta = [], []
    for case, deployment, sets, expected, binding in LIMIT_CASES:
        merged = dict(IDEAL)
        merged.update(sets)
        spec = _resolve(params, deployment, merged)
        ctx = runner.build(spec, params)
        bounds = dict(ctx.deploy.analytic_bounds())
        meta.append((case, expected, binding, bounds,
                     int(spec.chain.gas_limit or 0)))
        work.append((deployment, merged, False, deployment != "8141",
                     SERVING_SCALE if case == SERVING_CASE else None))
    case, deployment, sets = LONE_BUILDER
    merged = dict(IDEAL)
    merged.update(sets)
    work.append((deployment, merged, True, True))
    # The default pool at the two 200 M+ 8288 cells (finding, not a limit).
    pool_cases = [c for c in LIMIT_CASES if c[0] in POOL_CASES]
    for _case, deployment, sets, _e, _b in pool_cases:
        merged = dict(IDEAL)
        merged.update(sets)
        work.append((deployment, merged, False, False))
    serving = [c for c in LIMIT_CASES if c[0] == SERVING_CASE]
    for _case, deployment, sets, _e, _b in serving:
        merged = dict(IDEAL)
        merged.update(sets)
        work.append((deployment, merged, False, True, None))
    outputs = _map(work, jobs)
    results = []
    n_cases = len(meta)
    for (case, expected, binding, bounds, gas_limit), (row, info, _x) in \
            zip(meta, outputs[:n_cases]):
        limit = min(value for name, value in bounds.items()
                    if name in ("gas", "bytes", "dep_cap", "leanstark_cap"))
        if expected is not None and abs(expected - limit) > EXACT:
            results.append(_result(
                "limits", case + " (analytic)", expected, limit, "exact",
                "fail", "deploy.analytic_bounds disagrees with arch.md 5.1"))
        target = limit if expected is None else expected
        got = row["pq_tps"]
        counts = info.get("binding_counts", {})
        tolerance = "exact"
        ok = got is not None and abs(got - target) <= EXACT and \
            set(counts) == {binding}
        if "pcs_bundler" in case:
            # Bundlers also ship partial bundles (review C1: 9 of 16 in one
            # 60 M block), so deploy.limits' full-bundle figure is not an
            # upper bound. Upper bound: whole users at their gas; packing
            # check: the gas left in a block is less than one full bundle.
            per_user = bounds["gas_per_tx"]
            target = (gas_limit // per_user) / SLOT_S
            unused = gas_limit - row["gas_per_s"] * SLOT_S
            tolerance = ("<= whole-user gas bound; unused gas per block < "
                         "one full bundle (226 users)")
            ok = got is not None and got <= target + EXACT and \
                unused < BUNDLE_USERS * per_user and \
                set(counts) == {binding}
        results.append(_result(
            "limits", case, round(target, 6), got, tolerance,
            "pass" if ok else "fail",
            f"binding per measured block {counts}; bounds "
            f"{ {k: round(v, 4) for k, v in bounds.items()} }"
            + ("" if case.startswith("8141") else "; " + POOL_NOTE)
            + ("; " + SERVING_NOTE if case == SERVING_CASE else "")))
    _row, _info, slots = outputs[n_cases]
    bad = [s for s in slots if not s["largest"]]
    results.append(_result(
        "limits", LONE_BUILDER[0],
        [s["bound"] for s in slots], [s["included"] for s in slots],
        "builder's block is a prefix that fits and the next does not",
        "pass" if slots and not bad else "fail",
        "tree_plan on the slot's window "
        f"({[round(s['window_ms']) for s in slots]} ms); `bound` is a "
        "bisection that assumes monotone fits (tree_plan is not exactly "
        "monotone: leaf counts change with n)"))
    for (case, _d, _s, expected, _b), (row, info, _x) in zip(
            pool_cases, outputs[n_cases + 1:n_cases + 1 + len(pool_cases)]):
        results.append(_result(
            "limits", case + " (default 6,144-slot pool)", expected,
            row["pq_tps"], "-", "info",
            f"binding per measured block {info.get('binding_counts')}: the "
            "builder's pool capacity binds below the analytic bound"))
    for (case, _d, _s, _e, _b), (row, info, _x) in zip(
            serving, outputs[n_cases + 1 + len(pool_cases):]):
        results.append(_result(
            "limits", case + " (default eth/73 serving budget)",
            round(info["bounds_tps"]["gas"], 4), row["pq_tps"], "-", "info",
            f"binding per measured block {info.get('binding_counts')} "
            f"('pool' = the builder lacks admitted client wrappers): "
            f"{SERVING_NOTE}"))
    results.append(check_eip1559())
    return results


# -------------------------------------------------------------- v2 cells
def v2_cell(scenario, gas_limit, candidate, k=1, variant=None,
            uplinks="heterogeneous", nodes="40", extra=None):
    """The first v2 row (dict) of data/phase2b scenario tables matching,
    and every column of `extra` ({column: value}), or None."""
    for path in V2_TABLES:
        with open(path, newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                if row["scenario"] != scenario or \
                        row["candidate"] != candidate or \
                        int(float(row["gas_limit"])) != gas_limit or \
                        row["k"] != str(k) or row["uplinks"] != uplinks or \
                        row["nodes"] != nodes:
                    continue
                if variant is not None and \
                        row["variant"] != variant:
                    continue
                if any(row.get(c) != v for c, v in (extra or {}).items()):
                    continue
                return row
    return None


# (cell, v2 selector, v3 deployment, v3 sets, expectation, comparable)
V2_CELLS = (
    ("A P99r 200 M", ("A", 200_000_000, "P99r", 1, "A", "tps_tx",
                      {"mode": "run", "profile": "baseline"}),
     "8141", {"demand.ecdsa_tps": 0.0},
     "gas-bound at 656 txs per block = 54.667 in both (v3 gas 304,426 per "
     "tx = CH1 fit; ECDSA off to match v2's PQ-only block); block reach "
     "differs (ePBS payload, regions, gossipsub) and is reported only", True),
    ("D B0 60 M k=1", ("D", 60_000_000, "B0", 1,
                          "queue=supersede;rate=1/2;agg=all;deps=1", "tps_tx"),
     "8288", {"candidate": "B0", "chain.gas_limit": 60_000_000,
              "demand.ecdsa_tps": 0.0},
     "both price a dependency at 64,781 gas (v2 models_agg.py:275-280, v3 "
     "spec B4): bound 926/12 = 77.17; v2 76.64 (3 seeds); v3 expected in "
     "[76, 77.17] unless the bid window or eth/73 binds", True),
    ("D P99r 200 M", ("D", 200_000_000, "P99r", 1,
                      "queue=supersede;rate=1/2;agg=all;deps=1", "tps_tx"),
     "8288", {"demand.ecdsa_tps": 0.0},
     "v2 prover-bound 236.68 (every node proves, no builder final proof, "
     "node 0 builds); v3 adds the builder's final proof in the bid window, "
     "prover classes and eth/73: report the ratio and the binding label",
     False),
    ("E-dep3000 P99r 60 M", ("E", 60_000_000, "P99r", 1,
                             "queue=supersede;rate=1/2;agg=all;deps=1",
                             "tps_tx"),
     None, None,
     "v2 priced a dependency at 3,000 gas (141.67 tx/s, gas); v3 uses the "
     "spec's 33,000 (B3): not comparable, no v3 key prices deps "
     "separately", False),
    ("F1 draft B0 60 M", ("F1", 60_000_000, "B0", 1,
                          "bundle=1;queue=supersede;rate=1/2;node=eip7870;"
                          "client_proofs=draft", "tps_tx"),
     "leanpcs", {"candidate": "B0", "chain.gas_limit": 60_000_000,
                 "agg.sig_route": "pcs_client", "demand.ecdsa_tps": 0.0},
     "v2 F1 (client proofs, prover-bound 14.21) ~ v3 pcs_client; the "
     "11-11 draft makes leanPCS deps 8288 deps (spec C7): expect a "
     "different binding; reported, not compared", False),
    ("F3 P99r 60 M bundle 226", ("F3", 60_000_000, "P99r", 226,
                                 "bundle=226;queue=supersede;rate=1/2;"
                                 "node=eip7870;bundle=repo;"
                                 "client_proofs=draft", "tps_tx"),
     "leanpcs", {"chain.gas_limit": 60_000_000,
                 "agg.sig_route": "pcs_bundler", "demand.ecdsa_tps": 0.0,
                 "slots.warmup": 3},
     "gas-bound bundles in both, by different gas: v2 4.97 bundles/s x 226 "
     "= 1,123.7 sig/s at 4,449 gas per signature; v3 counts users (k=1) "
     "at 24,576 gas each (deployments_v3 pcs_bundler formula, 11-11 draft: "
     "PCS claims priced as 8288 deps, spec C5/C7/C8): v3 gas bound 60 M / "
     "24,576 / 12 = 203 users/s (bundlers ship partial bundles, so the "
     "full-bundle 188.3 is not a bound); v2's price <= 4,425 gas/sig (60 "
     "bundles per block): 24,577 / 4,425 = 5.55 vs measured 5.61; warm-up 3 "
     "slots so the bundlers' first bundles are in", False),
)
V2_SLOTS = {"slots.warmup": 1, "slots.measured": 2, "slots.drain": 1,
            "net.columns": "background"}   # [A] 40 nodes in < 10 min


def check_v2_cells(nodes=40, seeds=(0,), jobs=4):
    work, meta = [], []
    for cell, selector, deployment, sets, note, comparable in V2_CELLS:
        scenario, gas, candidate, k, prefix, column = selector[:6]
        v2 = v2_cell(scenario, gas, candidate, k, prefix,
                     extra=selector[6] if len(selector) > 6 else None)
        v2_value = float(v2[column]) if v2 else None
        v2_sig = float(v2["tps_sig"]) if v2 else None
        if deployment is None:
            meta.append((cell, v2, v2_value, v2_sig, note, comparable, None))
            continue
        for seed in seeds:
            merged = dict(V2_SLOTS, nodes=nodes, seed=seed)
            merged.update(sets)
            meta.append((cell, v2, v2_value, v2_sig, note, comparable,
                         len(work)))
            work.append((deployment, merged, False))
    outputs = _map(work, jobs) if work else []
    results = []
    for cell, v2, v2_value, v2_sig, note, comparable, index in meta:
        if index is None:
            results.append(_result("v2-cells", cell, v2_value, None, "-",
                                   "info", note))
            continue
        row, info, _x = outputs[index]
        got = {"pq_tps": row["pq_tps"], "sig_per_s": row["sig_per_s"],
               "binding": row["binding"],
               "binding_counts": info.get("binding_counts"),
               "block_reach_t90_p50_ms": row["block_reach_t90_p50_ms"],
               "payload_reach_t90_p50_ms": row["payload_reach_t90_p50_ms"],
               "seed": row["seed"]}
        expected = {"v2_tps_tx": v2_value, "v2_tps_sig": v2_sig,
                    "v2_binding": v2["binding"] if v2 else None,
                    "v2_t90_block_s": v2.get("t90_block_s") if v2 else None}
        if comparable and v2_value is not None and row["pq_tps"] is not None:
            # Gas-bound cells: v3 within [0.99 v2, analytic bound].
            bound = info["bounds_tps"].get("gas")
            ok = row["pq_tps"] >= 0.99 * v2_value - EXACT and \
                (bound is None or row["pq_tps"] <= bound + EXACT)
            results.append(_result("v2-cells", cell, expected, got,
                                   "[0.99 x v2, gas bound]",
                                   "pass" if ok else "fail", note))
        else:
            ratio = (row["pq_tps"] / v2_value if v2_value and row["pq_tps"]
                     is not None else None)
            got["ratio_to_v2"] = ratio
            results.append(_result("v2-cells", cell, expected, got, "-",
                                   "info", note))
    return results


# --------------------------------------------------------------- mainnet
def target_ids(targets):
    from starksim.v3 import metrics
    known = dict(metrics.VALIDATION_KEYS)
    for target, spec in targets.items():
        if target not in known:
            raise KeyError(f"validation target {target!r} has no row "
                           "column map (metrics.VALIDATION_KEYS)")
        for key in _keys(spec):
            if key not in known[target]:
                raise KeyError(f"validation target {target}.{key}: no row "
                               "column")
    return known


def band(spec, key):
    """(lo, hi) of a tolerance key: abs as given, rel x observed[key]."""
    tolerance = spec["tolerance"][key]
    if "abs" in tolerance:
        lo, hi = tolerance["abs"]
        return float(lo), float(hi)
    lo, hi = tolerance["rel"]
    observed = float(spec["observed"][key])
    return float(lo) * observed, float(hi) * observed


# Row column -> target unit, where they differ (review C6). The factor
# multiplies the row value before the band test.
UNIT_FACTOR = {
    # Target unit "Mbit/s each way"; the row column is up + down (+ bg).
    "bandwidth_home_validating_node_mbps.mid": 0.5,
}
# Keys reported, not scored, with the reason (review C6).
NOT_COMPARABLE = {
    "tx_later_sighting_within_1s_share.within_1s":
        "the Xatu share counts later sightings up to hours after the first "
        "(p99 7.3e6 ms, tools/xatu_mempool.out); a 12-slot run cannot see "
        "them. Conditional on d <= 12 s Xatu's within-1 s share is ~0.976 "
        "(same file: conditional p50/p90/p99 18 / 158 / 5,480 ms)",
}


def _keys(spec):
    """Tolerance keys, then `info` keys without a tolerance (v2)."""
    keys = list(spec["tolerance"])
    keys += [key for key in spec.get("info", {}) if key not in keys]
    return keys


def _seed_mean(rows, column, factor=1.0):
    values = [row[column] * factor for row in rows
              if row.get(column) is not None]
    return sum(values) / len(values) if values else None


def compare_mainnet(rows, targets=None, version="v2"):
    """Every tolerance key of every target vs the mean over `rows` of its
    `val.<target>.<key>` column (None values left out; all None -> NA,
    which fails), UNIT_FACTOR applied, NOT_COMPARABLE keys as info; then
    every `checks` entry of a target (`increasing`: the seed means of the
    listed keys strictly increase; NA fails)."""
    if targets is None:
        with open(TARGET_FILES[version], encoding="utf-8") as handle:
            targets = json.load(handle)["targets"]
    target_ids(targets)
    results = []
    for target, spec in targets.items():
        info = spec.get("info", {})
        for key in _keys(spec):
            name = f"{target}.{key}"
            column = f"val.{name}"
            factor = UNIT_FACTOR.get(name, 1.0)
            got = _seed_mean(rows, column, factor)
            if key in spec["tolerance"]:
                lo, hi = band(spec, key)
            else:
                lo = hi = None
            ok = got is not None and lo is not None and lo <= got <= hi
            verdict = "pass" if ok else "fail"
            note = (f"seeds {[row['seed'] for row in rows]}: "
                    f"{[None if row.get(column) is None else round(row[column], 3) for row in rows]}")
            if factor != 1.0:
                note += f"; row value x {factor} (target unit: {spec.get('unit')})"
            if name in NOT_COMPARABLE:
                verdict = "info"
                note += "; not scored: " + NOT_COMPARABLE[name]
            elif key in info:
                verdict = "info"
                note += "; not scored: " + info[key]
            results.append(_result(
                "mainnet", name, spec["observed"].get(key),
                None if got is None else round(got, 4),
                None if lo is None else [round(lo, 4), round(hi, 4)],
                verdict, note))
        for check in spec.get("checks", []):
            for kind, keys in check.items():
                if kind != "increasing":
                    raise KeyError(f"{target}: unknown check {kind!r}")
                values = [_seed_mean(rows, f"val.{target}.{key}")
                          for key in keys]
                ok = None not in values and all(
                    a < b for a, b in zip(values, values[1:]))
                results.append(_result(
                    "mainnet", f"{target}: increasing {keys}",
                    "increasing", [None if v is None else round(v, 1)
                                   for v in values], "strict order",
                    "pass" if ok else "fail"))
    return results


MAINNET_SETS = {"obs.observers": "datacentre", "slots.measured": 24,
                "demand.background": "explicit"}  # [A] 24 slots per seed; [E] arch.md 5.3 ECDSA explicit


def check_mainnet(nodes=200, seeds=(0, 1), jobs=2, rows=None,
                  version="v2", sets=None):
    """`sets`: extra spec settings (e.g. the pre-S6b model:
    PRE_S6B_SETS) for before/after runs."""
    if rows is None:
        work = [("today", dict(MAINNET_SETS, nodes=nodes, seed=seed,
                               **(sets or {})), False)
                for seed in seeds]
        rows = [row for row, _info, _x in _map(work, jobs)]
    return compare_mainnet(rows, version=version), rows


# The model before the S6b calibration (S6's defaults), for before/after.
PRE_S6B_SETS = {"net.cl_slow_start": "off",
                "net.import_waits_for_columns": False,
                "chain.local_build_share": 0.0}


# ----------------------------------------------------------- determinism
DETERMINISM_ARGV = (
    ["--deployment", "8141", "--nodes", "10", "--seed", "1",
     "--set", "slots.warmup=1", "--set", "slots.measured=2",
     "--set", "slots.drain=1"],
    ["--deployment", "8288", "--nodes", "8", "--seed", "0",
     "--set", "slots.warmup=1", "--set", "slots.measured=2",
     "--set", "slots.drain=1"],
    ["--deployment", "leanpcs", "--sig-route", "pcs_client", "--nodes", "8",
     "--set", "slots.warmup=1", "--set", "slots.measured=1",
     "--set", "slots.drain=1"],
    ["--deployment", "today", "--nodes", "12", "--set", "slots.measured=2"],
)


def _cli_row(argv, hashseed, root):
    env = dict(os.environ, PYTHONHASHSEED=str(hashseed))
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "row.json")
        subprocess.run([sys.executable, "-m", "bench.leansphincs", "run",
                        *argv, "--out", out], cwd=root, env=env, check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        with open(out, "rb") as handle:
            return handle.read()


def check_determinism(site=None, out_dir=None):
    root = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))))
    results = []
    for argv in DETERMINISM_ARGV:
        a = _cli_row(argv, 0, root)
        b = _cli_row(argv, 4242, root)    # [A] a second hash seed
        results.append(_result(
            "determinism", "two interpreters, PYTHONHASHSEED 0 vs 4242: "
            + " ".join(argv[:2] + argv[2:4]), len(a), len(b),
            "byte-identical row JSON", "pass" if a == b else "fail"))
    if site:
        script = os.path.join(CAMPAIGN, "web-v3", "test", "determinism.mjs")
        out = os.path.join(out_dir or tempfile.mkdtemp(prefix="s6-det-"),
                           "determinism-browser.json")
        proc = subprocess.run(["node", script, "--site", site, "--out", out],
                              cwd=CAMPAIGN, capture_output=True, text=True)
        try:
            with open(out, encoding="utf-8") as handle:
                summary = json.load(handle)
            ok = summary["failed"] == 0 and summary["equal"] == \
                summary["cases"]
            results.append(_result(
                "determinism", f"browser worker == CLI ({site})",
                summary["cases"], summary["equal"], "every case equal",
                "pass" if ok else "fail",
                f"bundle {summary.get('bundle_sha256', '')[:16]}; "
                f"not built {summary.get('not_built')}; {out}"))
        except (OSError, ValueError, KeyError):
            results.append(_result(
                "determinism", "browser worker == CLI", None, None, "-",
                "fail", (proc.stderr or proc.stdout)[-400:]))
    return results


# ------------------------------------------------------------------- CLI
def table(results):
    lines = []
    for r in results:
        lines.append(f"{r['verdict']:4s}  {r['check']:11s}  {r['case']}: "
                     f"got {json.dumps(r['got'])[:160]} expected "
                     f"{json.dumps(r['expected'])[:120]} tol "
                     f"{json.dumps(r['tolerance'])}")
    return "\n".join(lines)


def main(argv):
    parser = argparse.ArgumentParser(
        prog="python3 -m bench.leansphincs validate", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    for name in ("limits", "v2-cells", "mainnet", "determinism", "all"):
        parser.add_argument(f"--{name}", action="store_true")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--nodes", type=int, help="mainnet nodes (200), "
                        "v2 cells (40)")
    parser.add_argument("--seeds", default=None)
    parser.add_argument("--rows", help="mainnet: comma-separated run JSON "
                        "files instead of running")
    parser.add_argument("--site", help="determinism: a built web-v3 site "
                        "directory for the browser==CLI test")
    parser.add_argument("--out", help="directory for results.json and "
                        "rows")
    parser.add_argument("--targets", choices=("v1", "v2"), default="v2",
                        help="mainnet target file (v2 default; v1 kept for "
                        "traceability)")
    parser.add_argument("--pre-s6b", action="store_true", help="mainnet: "
                        "run the model as before S6b (PRE_S6B_SETS)")
    args = parser.parse_args(argv)
    chosen = [name for name in ("limits", "v2_cells", "mainnet",
                                "determinism")
              if args.all or getattr(args, name)]
    if not chosen:
        print("validate (stage S6): choose --limits, --v2-cells, --mainnet, "
              "--determinism or --all", file=sys.stderr)
        return 2
    seeds = None
    if args.seeds:
        seeds = tuple(int(s) for s in args.seeds.split(","))
    results, extra = [], {}
    if "limits" in chosen:
        results += check_limits(args.jobs)
    if "v2_cells" in chosen:
        results += check_v2_cells(args.nodes or 40, seeds or (0,), args.jobs)
    if "mainnet" in chosen:
        given = None
        if args.rows:
            given = []
            for path in args.rows.split(","):
                with open(path, encoding="utf-8") as handle:
                    given.append(json.load(handle))
        found, rows = check_mainnet(args.nodes or 200, seeds or (0, 1),
                                    min(args.jobs, 2), given, args.targets,
                                    PRE_S6B_SETS if args.pre_s6b else None)
        results += found
        extra["mainnet_rows"] = rows
    if "determinism" in chosen:
        if args.out:
            os.makedirs(args.out, exist_ok=True)
        results += check_determinism(args.site, args.out)
    print(table(results))
    failed = sum(1 for r in results if r["verdict"] == "fail")
    print(f"# {len(results)} checks: "
          f"{sum(1 for r in results if r['verdict'] == 'pass')} pass, "
          f"{failed} fail, "
          f"{sum(1 for r in results if r['verdict'] == 'info')} info")
    if args.out:
        os.makedirs(args.out, exist_ok=True)
        name = "_".join(chosen)
        with open(os.path.join(args.out, f"results_{name}.json"), "w",
                  encoding="utf-8") as handle:
            json.dump({"results": results}, handle, indent=1,
                      allow_nan=False, default=str)
        for i, row in enumerate(extra.get("mainnet_rows", [])):
            with open(os.path.join(args.out, f"mainnet_row_{i}.json"), "w",
                      encoding="utf-8") as handle:
                json.dump(row, handle, indent=1, allow_nan=False)
    return 1 if failed else 0

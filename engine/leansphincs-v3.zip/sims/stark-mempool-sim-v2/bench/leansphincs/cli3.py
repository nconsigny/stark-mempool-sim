"""The v3 command line (arch.md section 2.1). Stage S5.

    python3 -m bench.leansphincs run --deployment {today,8141,8288,leanpcs}
            [--sig-route dependency|pcs_client|pcs_bundler] [--dep-cap none|256|4096]
            [--candidate P99r] [--nodes 1000] [--gas-limit 200e6] [--seed 0]
            [--demand saturate|<tx/s>] [--set key=value ...] [--out row.json]
            [--info] [--spec-only] [--topology] [--list-keys]
    python3 -m bench.leansphincs timeline <path.json> [--branch 8288|leanpcs]
            [--nodes 200] [--seeds 0] [--points-per-step 3] [--hour mean]
            [--sig-route ...] [--dep-cap ...] [--set k=v] [--jobs 8]
            [--cache c.jsonl] [--out records.jsonl]
    python3 -m bench.leansphincs elasticity --deployment 8288 [--input sig_bytes|perms|both]
            [--seeds 0,1,2] [--h 0.1] [--resource gas] [--attribute] [run flags]
    python3 -m bench.leansphincs attribute --deployment 8141 [--seeds 0,1,2] [run flags]
    python3 -m bench.leansphincs validate [--limits|--v2-cells|--mainnet|--determinism|--all]
    python3 -m bench.leansphincs sweep --deployment 8288 --grid key=v1,v2 ...
            [--seeds 0,1] [--jobs 8] [--cache c.jsonl] [--out rows.jsonl]

`run` resolves the RunSpec (defaults <- deployment <- --set), simulates it
(`starksim.v3.runner`) and prints S4's fixed row (228 columns); `--info`
adds the run's diagnostics (wall time [M], events, bounds, counters) on
stderr; `--spec-only` prints the resolved spec with its spec_hash. Every
model setting not on these lines is `--set dotted.key=value` (`--list-keys`
lists them). Sweeps use at most 8 worker processes at nice 10.

The old `--scenario` path (v2 harness) still works, with a deprecation line
(removed in stage S8).
"""

import argparse
import json
import sys
import time

from starksim.v3 import params as params_module
from starksim.v3 import spec as spec_module

VERBS = ("run", "timeline", "elasticity", "attribute", "validate", "sweep")
HIDDEN_VERBS = ("candidates",)    # still works; not listed (S8 decides)


def run_parser(prog="run"):
    result = argparse.ArgumentParser(
        prog=f"python3 -m bench.leansphincs {prog}", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    add_point_flags(result)
    return result


def add_point_flags(result, deployments=spec_module.DEPLOYMENTS):
    result.add_argument("--deployment", choices=deployments,
                        default="8141")
    result.add_argument("--candidate")
    result.add_argument("--gas-limit", type=float)
    result.add_argument("--nodes", type=int)
    result.add_argument("--seed", type=int)
    result.add_argument("--demand",
                        help="saturate (default) or an offered tx/s (load)")
    result.add_argument("--sig-route",
                        choices=("dependency", "pcs_client", "pcs_bundler"),
                        help="leanPCS signature route (agg.sig_route)")
    result.add_argument("--dep-cap",
                        help="block dependency cap: none, 256, 4096 or any "
                             "integer (chain.dep_cap)")
    result.add_argument("--info", action="store_true",
                        help="also print run diagnostics (wall time [M], "
                             "events, bounds, counters) to stderr")
    result.add_argument("--set", action="append", default=[],
                        metavar="KEY=VALUE",
                        help="a RunSpec setting; the value is parsed as "
                             "JSON, else kept as a string")
    result.add_argument("--out", help="also write the JSON here")
    result.add_argument("--topology", action="store_true",
                        help="build the topology and links, print stats")
    result.add_argument("--list-keys", action="store_true",
                        help="list every --set key with its default")
    result.add_argument("--spec-only", action="store_true",
                        help="resolve and print the spec, do not simulate")


def sets_from(args):
    sets = {}
    if args.candidate is not None:
        sets["candidate"] = args.candidate
    if args.gas_limit is not None:
        sets["chain.gas_limit"] = args.gas_limit
    if args.nodes is not None:
        sets["nodes"] = args.nodes
    if args.seed is not None:
        sets["seed"] = args.seed
    if args.demand is not None:
        if args.demand == "saturate":
            sets["demand.mode"] = "saturate"
        else:
            try:
                level = float(args.demand)
            except ValueError:
                raise SystemExit(f"--demand {args.demand!r}: expected "
                                 "'saturate' or a number of tx/s") from None
            sets["demand.mode"] = "load"
            sets["demand.level_tps"] = level
    if getattr(args, "sig_route", None) is not None:
        sets["agg.sig_route"] = args.sig_route
    if getattr(args, "dep_cap", None) is not None:
        sets["chain.dep_cap"] = parse_dep_cap(args.dep_cap)
    sets.update(spec_module.parse_sets(args.set))
    return sets


def parse_dep_cap(text):
    """'none' -> None, else a positive integer."""
    if str(text).lower() in ("none", "null"):
        return None
    try:
        value = int(text)
    except ValueError:
        raise SystemExit(f"--dep-cap {text!r}: expected none or an "
                         "integer") from None
    return value


def topology_report(spec, params):
    from starksim.v3.links import Links
    from starksim.v3.state import Context
    from starksim.v3.topology import Topology
    started = time.perf_counter()
    topo = Topology.build(spec, params)
    built = time.perf_counter() - started
    ctx = Context(spec, params)
    topo.install(ctx)
    from starksim.v3.runner import lane_weights as runner_lane_weights
    lane_weights = runner_lane_weights(spec, params)
    background = params.value("background_mbps") if spec.net.background \
        else None
    Links(ctx, topo, lane_weights, background)
    total = time.perf_counter() - started
    stats = dict(topo.stats)
    stats["nodes_total"] = topo.n_total
    stats["builders"] = len(topo.builders)
    stats["build_s_measured"] = round(built, 4)
    stats["build_with_links_s_measured"] = round(total, 4)
    return stats


def run_main(argv):
    args = run_parser().parse_args(argv)
    if args.list_keys:
        for key in spec_module.keys():
            default = spec_module.FIELDS[key][0].default
            if not isinstance(default, (int, float, str, bool, type(None))):
                default = "(group)"
            print(f"{key} = {json.dumps(default)}  # "
                  f"{spec_module.describe(key)}")
        return 0
    params = params_module.default_params().fresh()
    try:
        spec = spec_module.resolve(params, args.deployment,
                                   sets=sets_from(args))
    except spec_module.SpecError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    if not args.spec_only and not args.topology:
        from starksim.v3 import runner
        row, ctx = runner.execute(spec, params)
        text = runner.row_json(row)
        print(text)
        info = ctx.run_info
        print(f"[M] wall {info['wall_s_measured']} s, events "
              f"{info['events']}, binding per slot "
              f"{info['binding_counts']}", file=sys.stderr)
        if args.info:
            print(json.dumps(info, indent=1, default=str), file=sys.stderr)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as handle:
                handle.write(text + "\n")
        return 0
    output = {
        "stage": "resolved spec only (--spec-only)",
        "spec_hash": spec_module.spec_hash(spec, params),
        "network_params_sha256": params.network_sha256,
        "deployments_sha256": params.deployments_sha256,
        "spec": spec_module.as_dict(spec),
    }
    if args.topology:
        output["topology"] = topology_report(spec, params)
    output["input_status"] = params.input_status()
    text = json.dumps(output, indent=1, allow_nan=False)
    print(text)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    return 0


def candidates_main(argv):
    if argv:
        raise SystemExit("usage: python3 -m bench.leansphincs candidates")
    params = params_module.default_params()
    for name in params.candidate_names():
        entry = params.candidate(name)
        counted = "counted" if entry["counted"] else "modelled"
        print(f"{name:24s} B={entry['sig_bytes']:5d} P={entry['perms']:4d} "
              f"{entry['params']:32s} {counted}")
    return 0


def _seeds(text):
    try:
        seeds = [int(item) for item in str(text).split(",") if item != ""]
    except ValueError:
        raise SystemExit(f"--seeds {text!r}: expected e.g. 0,1,2") from None
    if not seeds or len(set(seeds)) != len(seeds):
        raise SystemExit(f"--seeds {text!r}: distinct integers expected")
    return seeds


def _write_jsonl(records, path):
    lines = [json.dumps(record, separators=(",", ":"), allow_nan=False)
             for record in records]
    if path:
        with open(path, "w", encoding="utf-8") as handle:
            for line in lines:
                handle.write(line + "\n")
    return lines


def _progress(done, total):
    print(f"  {done}/{total} runs", file=sys.stderr, flush=True)


def _renice_self(jobs):
    """Sweep verbs run at nice 10 (task brief); workers renice themselves,
    a single in-process job renices this process."""
    import os
    if jobs == 1:
        try:
            os.nice(10)  # [E] task brief: sweeps at nice 10
        except (OSError, AttributeError):
            pass


def timeline_main(argv):
    from starksim.v3 import timeline
    parser = argparse.ArgumentParser(
        prog="python3 -m bench.leansphincs timeline",
        description=timeline.__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("path")
    parser.add_argument("--branch", choices=timeline.BRANCHES)
    parser.add_argument("--nodes", type=int, default=200)
    parser.add_argument("--seeds", default="0")
    parser.add_argument("--points-per-step", type=int)
    parser.add_argument("--hour", default="mean",
                        help="diurnal demand: mean (factor 1), peak, or a "
                             "UTC hour 0-23")
    parser.add_argument("--sig-route",
                        choices=("dependency", "pcs_client", "pcs_bundler"),
                        help="leanPCS branch points only")
    parser.add_argument("--dep-cap", help="I* points: none|256|4096|n")
    parser.add_argument("--pq-share", choices=timeline.PQ_VARIANTS,
                        help="PQ-share schedule of every step: the file's "
                             "value (default) or an alternative")
    parser.add_argument("--set", action="append", default=[],
                        metavar="KEY=VALUE", help="every point")
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--cache")
    parser.add_argument("--out", help="JSONL of every record")
    args = parser.parse_args(argv)
    params = params_module.default_params().fresh()
    variant = {}
    if args.sig_route:
        variant.setdefault("leanpcs", {})["agg.sig_route"] = args.sig_route
    if args.dep_cap is not None:
        cap = parse_dep_cap(args.dep_cap)
        for branch in timeline.BRANCHES:
            variant.setdefault(branch, {})["chain.dep_cap"] = cap
    _renice_self(args.jobs)
    try:
        data = timeline.load(args.path)
        records = timeline.run_path(
            data, params, branch=args.branch, nodes=args.nodes,
            seeds=_seeds(args.seeds), points_per_step=args.points_per_step,
            sets=spec_module.parse_sets(args.set), variant=variant,
            jobs=args.jobs, cache=args.cache, progress=_progress,
            hour=args.hour, pq_share=args.pq_share)
    except (timeline.TimelineError, spec_module.SpecError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    _write_jsonl(records, args.out)
    print(json.dumps(timeline_report(records), indent=1, allow_nan=False))
    return 0


def timeline_report(records):
    """The printed summary: per point the headline columns, then the step,
    path and branch-difference records."""
    keep = ("tps_included", "pq_tps", "sig_per_s", "incl_latency_pq1_p50_s",
            "payload_reach_t90_p50_ms", "user_fee_pq_p50_gwei", "binding")
    out = []
    for record in records:
        if record["record"] == "point":
            row = record["row"]
            out.append({"point": record["timeline"], "seed": record["seed"],
                        "weight_months": record["weight_months"],
                        **{key: row[key] for key in keep}})
        else:
            out.append(record)
    return out


def _point_parser(prog, doc):
    parser = argparse.ArgumentParser(
        prog=f"python3 -m bench.leansphincs {prog}", description=doc,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    add_point_flags(parser, spec_module.PQ_DEPLOYMENTS)
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--h", type=float, default=0.1)
    parser.add_argument("--metric", default="pq_tps")
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--cache")
    return parser


def elasticity_main(argv):
    from starksim.v3 import elasticity
    parser = _point_parser("elasticity", elasticity.__doc__)
    parser.add_argument("--input", choices=("sig_bytes", "perms", "both"),
                        default="both")
    parser.add_argument("--resource",
                        help="binding resource for eps_supply (default: "
                             "from --attribute or the base rows)")
    parser.add_argument("--attribute", action="store_true",
                        help="run shadow prices first; their binding "
                             "resource sets s_PQ")
    parser.add_argument("--timeline", metavar="PATH",
                        help="take the point's settings from a timeline "
                             "file (with --point); records carry its "
                             "timeline key")
    parser.add_argument("--point", metavar="STEP[:BRANCH]:YYYY-MM",
                        help="e.g. H*:2028-03 or I*:8288:2030-12")
    parser.add_argument("--pq-share", choices=("default", "low", "forced"))
    args = parser.parse_args(argv)
    params = params_module.default_params().fresh()
    if args.timeline:
        return _elasticity_timeline(args, params)
    sets = sets_from(args)
    seeds = _seeds(args.seeds)
    _renice_self(args.jobs)
    records = []
    try:
        resource = args.resource
        rule = None
        if args.attribute and resource is None:
            shadow = elasticity.attribute(sets, params, args.deployment,
                                          seeds, args.h, args.metric,
                                          args.jobs, args.cache)
            records.append(shadow)
            resource = elasticity.binding_from_attribution(shadow)
            rule = f"attribute: {shadow['binding']} ({shadow['method']})"
            if resource is None:
                # Unresolved or co-binding: no single share (review E5).
                resource = "unresolved:" + shadow["binding"]
        inputs = (("sig_bytes", "perms") if args.input == "both"
                  else (args.input,))
        for name in inputs:
            records.append(elasticity.estimate(
                sets, params, args.deployment, name, seeds, args.h,
                resource, args.metric, args.jobs, args.cache,
                resource_rule=rule))
    except (elasticity.ElasticityError, spec_module.SpecError,
            ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    text = json.dumps(records, indent=1, allow_nan=False)
    print(text)
    if args.out:
        _write_jsonl(records, args.out)
    return 0


def _elasticity_timeline(args, params):
    """`elasticity --timeline PATH --point STEP[:BRANCH]:MONTH`: records
    keyed by the timeline point (timeline.elasticity_at); run flags other
    than --nodes/--set/--seeds/--h/--metric/--jobs/--cache are refused."""
    from starksim.v3 import timeline
    if not args.point:
        raise SystemExit("--timeline needs --point STEP[:BRANCH]:YYYY-MM")
    parts = args.point.split(":")
    if len(parts) == 2:
        step, branch, month = parts[0], None, parts[1]
    elif len(parts) == 3:
        step, branch, month = parts
    else:
        raise SystemExit(f"--point {args.point!r}: STEP[:BRANCH]:YYYY-MM")
    for flag in ("candidate", "gas_limit", "demand", "sig_route",
                 "dep_cap", "seed"):
        if getattr(args, flag) is not None:
            raise SystemExit(f"--{flag.replace('_', '-')}: the timeline "
                             "point sets it (use --set to override)")
    inputs = (("sig_bytes", "perms") if args.input == "both"
              else (args.input,))
    _renice_self(args.jobs)
    try:
        data = timeline.load(args.timeline)
        records = timeline.elasticity_at(
            data, params, step, month, branch, inputs, _seeds(args.seeds),
            args.h, args.resource, args.nodes,
            sets=spec_module.parse_sets(args.set), jobs=args.jobs,
            cache=args.cache, pq_share=args.pq_share, metric=args.metric)
    except (timeline.TimelineError, spec_module.SpecError,
            ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    print(json.dumps(records, indent=1, allow_nan=False))
    if args.out:
        _write_jsonl(records, args.out)
    return 0


def attribute_main(argv):
    from starksim.v3 import elasticity
    parser = _point_parser("attribute", elasticity.attribute.__doc__)
    args = parser.parse_args(argv)
    params = params_module.default_params().fresh()
    _renice_self(args.jobs)
    try:
        record = elasticity.attribute(sets_from(args), params,
                                      args.deployment, _seeds(args.seeds),
                                      args.h, args.metric, args.jobs,
                                      args.cache)
    except (spec_module.SpecError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    text = json.dumps(record, indent=1, allow_nan=False)
    print(text)
    if args.out:
        _write_jsonl([record], args.out)
    return 0


def sweep_main(argv):
    from starksim.v3 import sweep3
    parser = run_parser("sweep")
    parser.add_argument("--grid", action="append", default=[],
                        metavar="KEY=V1,V2",
                        help="a RunSpec key and its values (JSON each); "
                             "repeat for a Cartesian product")
    parser.add_argument("--seeds", default="0")
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--cache")
    args = parser.parse_args(argv)
    params = params_module.default_params().fresh()
    base = sets_from(args)
    axes = []
    for item in args.grid:
        key, separator, text = item.partition("=")
        if not separator:
            raise SystemExit(f"--grid {item!r}: expected KEY=V1,V2")
        values = [spec_module.parse_sets([f"{key}={value}"])[key]
                  for value in text.split(",")]
        axes.append((key.strip(), values))
    combos = [{}]
    for key, values in axes:
        combos = [dict(combo, **{key: value}) for combo in combos
                  for value in values]
    specs, labels = [], []
    try:
        for combo in combos:
            for seed in _seeds(args.seeds):
                sets = dict(base)
                sets.update(combo)
                sets["seed"] = seed
                specs.append(spec_module.resolve(params, args.deployment,
                                                 sets=sets))
                labels.append(dict(combo, seed=seed))
    except spec_module.SpecError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    _renice_self(args.jobs)
    rows = sweep3.run_specs(specs, params, jobs=args.jobs, cache=args.cache,
                            progress=_progress)
    records = [{"record": "sweep", "sets": label, "row": row}
               for label, row in zip(labels, rows)]
    for line in _write_jsonl(records, args.out):
        print(line)
    return 0


def validate_main(argv):
    from bench.leansphincs import validate3
    return validate3.main(argv)


def usage():
    return ("usage: python3 -m bench.leansphincs <verb> [options]\n\n"
            "verbs:\n"
            "  run          one RunSpec -> one row (--deployment today|8141|"
            "8288|leanpcs)\n"
            "  timeline     a path file: H* 8141 -> I* 8288 | leanpcs\n"
            "  elasticity   eps_supply / eps_fair to sig bytes and perms\n"
            "  attribute    capacity shadow prices: what binds\n"
            "  validate     analytic limits, v2 cells, mainnet (stage S6)\n"
            "  sweep        a grid of RunSpecs (<= 8 workers, JSONL cache)\n\n"
            "`<verb> --help` for its options.")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(usage())
        return 0
    known = VERBS + HIDDEN_VERBS
    command = argv[0] if argv[0] in known else "run"
    rest = argv[1:] if argv[0] in known else argv
    handler = {"run": run_main, "candidates": candidates_main,
               "timeline": timeline_main, "elasticity": elasticity_main,
               "attribute": attribute_main, "validate": validate_main,
               "sweep": sweep_main}[command]
    return handler(rest)


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Phase 2: cost and admission models of the no-aggregation scenarios E0 (routes a, b, c; under
EIP-7623 and EIP-7976), A, B and C1 (PHASE2.md section 3), as functions of signature bytes B,
verify permutations P and signatures per transaction k.

Campaign /leansphincs. Note: notes/phase2/models-noagg.md. Builds on data/chain_model.py
(phase 1, claims CH1-CH16), re-deriving only what the current EIP-8141 text changes
(refs/eip-8141-online.md, EIPs master 2026-11-10). Stdlib only.

Tags: [E] EIP text, [R] read at a path, [C] count, [M] measured on this box today, [M rec] measured
by someone else and recorded, [Mo] modelled, [Rc] recalled.

Plugin callables (signatures of sims/LEANSPHINCS-FORK.md, "Model plug-in interface"):
    gas_per_tx-shaped   f(sig_bytes, verify_perms, k=1, **kw) -> int      one per scenario/variant,
                        listed in GAS_FNS, e.g. {"fn": "models_noagg:gas_B_flat_64",
                        "path": "/leansphincs/data/phase2"}
    noagg_verify_cost   native_verify_B(perms_per_sig, sigs_per_leaf, **kw) -> NativeVerifyCost
                        (B and C1: every node verifies natively; needs starksim importable, i.e.
                        run from the simulator; falls back to a dict otherwise)
The simulator's noagg mode prices on-chain bytes as tx_bytes + k*sig_bytes; sim_knobs() returns the
`tx_bytes` knob each scenario needs (B adds pk+signer per signature, C1 the 96-B triples).

    python3 -I models_noagg.py            # self-checks (CH1 receipts) + candidate table
    python3 -I models_noagg.py --csv      # also writes noagg_analytic.csv and noagg_analytic_detail.csv
"""
import csv
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))           # data/ for chain_model (phase 1)
import chain_model as cm                            # noqa: E402

# ---------------------------------------------------------------------------------------------
# Constants (phase-1 ones are imported from chain_model with their tags)
# ---------------------------------------------------------------------------------------------
MAX_VERIFY_GAS = cm.MAX_VERIFY_GAS                  # 100,000 [E] eip-8141-online.md:933
MAX_VERIFY_GAS_PROPOSED = cm.MAX_VERIFY_GAS_PROPOSED  # 300,000 [R] refs/ethresearch/26224.md
TXPOOL_MAX_TX_BYTES = cm.TXPOOL_MAX_TX_BYTES        # 128 KiB [R] geth legacypool.go:56
TX_MAX_GAS_LIMIT = cm.TX_MAX_GAS_LIMIT              # 2^24 [E] EIP-7825
MAX_RLP_BLOCK_SIZE = cm.MAX_RLP_BLOCK_SIZE          # 8 MiB [E] EIP-7934
BLOCK_HEADER_BYTES = 600                            # [Mo] as phase 1
SLOT_S = 12.0
GAS_LIMITS = (60_000_000, 100_000_000, 150_000_000, 200_000_000, 300_000_000)
#   PHASE2 §4 plus 200 M: Glamsterdam's expected limit (notes/phase2/inbox.md [scenarios], acdt/100-101)

# EIP-8141 [E] refs/eip-8141-online.md:37-55, 216-218, 490-562
FRAME_TX_INTRINSIC_COST = 12_000
FRAME_TX_PER_FRAME_COST = 475
STANDARD_TOKEN_COST = 4
TOTAL_COST_FLOOR_PER_TOKEN = 16
SIG_GAS = {"ARBITRARY": 100, "SECP256K1": 2_800, "P256": 6_700}
TX_VALUE_COST = 6_000                               # EIP-2780 per value frame [E]
SENDER_FRAME_GAS = cm.SENDER_FRAME_GAS              # 3,000 [M rec] ethrex txs
VERIFY_DATA_BYTES, VERIFY_DATA_ZERO = 36, 32        # VERIFY frame data [M rec, derived] (phase 1)

# EIP-8288 [E] refs/eip-8288-online.md:40-48, 59-80
LEANSPHINCS_VERIFICATION_GAS = 3_000
TRIPLE_BYTES, TRIPLE_ZERO = 96, 31
MAX_SIGS_PER_TX = 16
MAX_LEANSIG_DEPS_PER_WRAPPER = 16
LEANSPHINCS_PK_BYTES = 32                           # root 16 || public parameter 16 [E] eip-8288:63
WRAPPER_FRAMING_BYTES = 16                          # [Mo] RLP of [mode, [tx], deps, witnesses]

# Native verification on this box [M, 2026-11-10 ~15:45 UTC, load 19-21, 32 cores]
# data/phase2/native_timing.out: `openssl speed -seconds 2 -evp sha3-256 -bytes 16384` x3:
# 609.8 / 605.0 / 555.2 MB/s -> median 605.0 MB/s -> 136 B / 605.0e6 B/s = 0.2248 us per Keccak-f.
# (Phase 1 measured 179 ns at load 10-15: the load moves this by ~25 %.)
T_PERM_US = 136 / 605.04e6 * 1e6
T_SIG_OVERHEAD_US = 10.0                            # [Mo] parsing, message hash (phase 1's 0.01 ms)
# python-cryptography 50.0.2 over OpenSSL 3.6.5, best of 5 x 4000 verifies [M] native_timing.py:
T_P256_US = 35.67          # OpenSSL's optimised nistz256: same class as clients' P256VERIFY
T_SECP256K1_US = 200.65    # OpenSSL's GENERIC secp256k1 code; clients use libsecp256k1 (faster,
#                            ~25-50 us for ecrecover [Rc]); kept because the task asks for it.
GAS_PER_US = {"p256": SIG_GAS["P256"] / T_P256_US,              # 187.8 gas/us
              "k1": SIG_GAS["SECP256K1"] / T_SECP256K1_US}      # 13.95 gas/us

# EVM verifier gas per permutation [M rec, fit Mo] (phase 1 CH4): lean single-layer 150, layered 167.
EVM_PER_PERM = cm.EVM_GAS_PER_PERM

# ---------------------------------------------------------------------------------------------
# E0b / E0c overheads around the verifier [M]: anvil 1.5.1 --hardfork prague (EIP-7623 rules),
# data/phase2/e0_overhead/ (run_measure.sh, receipts.py -> receipts.out). Contracts: src/E0.sol
# (PQModule for a Safe, PQDelegate for EIP-7702, a mock verifier returning true), Safe v1.4.1
# (safe-global/safe-smart-account bf943f80) compiled with solc 0.8.24, optimizer 200.
# Overhead = gasUsed - 21,000 - standard calldata - action, where the action is a CALL with value
# to an existing cold EOA, 9,000 + 2,600 - 2,300 (the stipend comes back) = 9,300 [E schedule].
# Steady state (account nonce already nonzero), 64-B signature:   E0b 25,092   E0c 12,266
#                                              2,048-B signature: E0b 25,477   E0c 12,650
# First use (nonce 0 -> 1, SSTORE zero -> nonzero): E0b 42,192, E0c 29,366 (not modelled).
# The fixed part below is the 64-B measurement minus _mem_copy_gas(64) = 15; the B-dependent part
# (_mem_copy_gas) predicts the 2,048-B receipts within +-10 gas (self_checks).
# Safe >= 1.5 adds a module-guard SLOAD (cold 2,100) that v1.4.1 does not have [Rc]: pass
# e0b_overhead=E0B_OVERHEAD_FIXED + 2_100 to model it.
# Neither includes the verifier's own gas (CH4: 150 or 167 per permutation) nor a real key layout:
# the mock reads one 32-B key slot; a leanSPHINCS key (root 16 + public parameter 16) fits one slot.
# ---------------------------------------------------------------------------------------------
E0_ACTION_GAS = 9_000 + 2_600 - 2_300               # the user's action (frame-tx analogue: 3,000 + 6,000)
E0B_OVERHEAD_FIXED = 25_092 - 15                    # [M] Safe v1.4.1 module path, steady state
E0C_OVERHEAD_FIXED = 12_266 - 15                    # [M] EIP-7702 delegate path, steady state
E0B_PER_EXTRA_SIG = 2_100 + 400                     # [Mo] another owner key slot (cold) + loop
E0C_PER_EXTRA_SIG = 2_100 + 400
E0_MEASURED = (  # (route, input bytes, zero bytes, gasUsed) [M] e0_overhead/receipts.out, steady state
    ("E0b", 292, 180, 57_904), ("E0b", 2276, 2228, 65_457),
    ("E0c", 260, 168, 44_710), ("E0c", 2244, 2216, 52_262))


def _mem_copy_gas(nbytes):
    """Gas to copy nbytes of calldata into fresh memory and pass it to the verifier [E schedule]."""
    w = nbytes / 32                                 # continuous (the model's B is continuous)
    return 3 + 6 * w + w * w / 512                  # CALLDATACOPY 3/word + memory 3/word + w^2/512


# ---------------------------------------------------------------------------------------------
# Per-tx structures
# ---------------------------------------------------------------------------------------------

def _evm_per_perm(impl, per_perm):
    return EVM_PER_PERM[impl] if per_perm is None else per_perm


PR12616_GAS_PER_PERM = 25.5   # EIPs PR #12616 (draft, 2026-11-04): 12,600 = 25.5 x 492 rounded up to 100
#   [R via notes/phase2/inbox.md, scenarios agent; not re-read here]


def g_scheme(P, gvar="flat", p_scale=1.0, g_round=False):
    """Enshrined scheme gas G(P): 'pr12616' = ceil(25.5 * P * p_scale / 100) * 100 (EIPs PR #12616,
    priced on the EthLib permutation count: p_scale = 492/515 for B0) [R/Mo], continuous unless
    g_round; 'flat' = EIP-8288's LEANSPHINCS_VERIFICATION_GAS 3,000 [E] (no source for B);
    'prop_p256' / 'prop_k1' = proportional to native verify time P * T_PERM_US, calibrated on
    P256 6,700 gas / 35.67 us or SECP256K1 2,800 gas / 200.65 us [M]."""
    if gvar == "pr12616":
        g = PR12616_GAS_PER_PERM * P * p_scale
        return math.ceil(g / 100) * 100.0 if g_round else g
    if gvar == "flat":
        return float(LEANSPHINCS_VERIFICATION_GAS)
    if gvar in ("prop_p256", "prop_k1"):
        return GAS_PER_US[gvar[5:]] * P * T_PERM_US
    raise ValueError(gvar)


def tx_model(scenario, B, P, k=1, *, pricing="7976", gvar="flat", byte_price=64, impl="lean",
             per_perm=None, ep_overhead=None, verify_only=False, e0b_overhead=None, e0c_overhead=None,
             p_scale=1.0, g_round=False, floor_rule="master"):
    """One transaction carrying k signatures of B bytes / P permutations. Returns a dict:
    gas (gas_used = block charge), standard, floor, path, onchain_bytes (block bytes per tx),
    gossip_bytes (what one hop sends for it), validation_gas (rule-6 count, reading a: signature
    verification cost only), validation_gas_strict (reading b: + signature_data_cost), public_ok,
    admission (which public limit applies), native_verify_us (per tx, B/C1), notes."""
    n = {}
    if scenario == "E0a":                                         # ERC-4337 handleOps (phase 1)
        ov = cm.ENTRYPOINT_OVERHEAD_STEADY[0] if ep_overhead is None else ep_overhead
        g = cm.gas_breakdown(B, P, k, "4337_evm", pricing, impl=impl, per_perm=per_perm,
                             ep_overhead=ov)
        ub = cm.userop_bytes(B, k)
        n.update(gas=g.total, standard=g.standard, floor=g.floor, path=g.binding,
                 onchain_bytes=g.tx_bytes, gossip_bytes=ub + 64,            # userOp in the 4337 p2p
                 validation_gas=None, validation_gas_strict=None,
                 public_ok=ub <= cm.MAX_USEROP_SIZE, admission="ERC-7562 8,192-B userOp",
                 native_verify_us=None)
        return n
    if scenario in ("E0b", "E0c"):                                # ordinary tx, EVM verifier
        pr = cm.PRICING[pricing]
        v = _evm_per_perm(impl, per_perm) * P
        # continuous signature bytes (ABI padding <= 31 zero bytes dropped, as phase 1's 4337 model);
        # the verify-only receipt shape keeps the exact padding so CH1 reproduces to the gas.
        sig = cm._pad32(k * B) if verify_only else k * B
        if verify_only:      # the measured Sepolia "verify tx" shape (phase 1 call_evm), for CH1
            head, zhead, over, act = 4 + 32 * 5, 4 * 32 + 30, 0, 0
        elif scenario == "E0b":
            head = 4 + 32 * 8           # exec(safe, to, value, data, op, sig) + lens/offsets
            zhead = 2 * 12 + 28 + 31 * 2 + 32 + 30 + 31 + 32
            over = ((E0B_OVERHEAD_FIXED if e0b_overhead is None else e0b_overhead)
                    + E0B_PER_EXTRA_SIG * (k - 1) + _mem_copy_gas(k * B))
            act = E0_ACTION_GAS
        else:
            head = 4 + 32 * 6           # execute(to, value, data, sig)
            zhead = 12 + 28 + 31 * 2 + 32 + 30
            over = ((E0C_OVERHEAD_FIXED if e0c_overhead is None else e0c_overhead)
                    + E0C_PER_EXTRA_SIG * (k - 1) + _mem_copy_gas(k * B))
            act = E0_ACTION_GAS
        nb = head + sig
        z = zhead + (sig - k * B) + k * B / 256
        base = pr.tx_base + pr.to_cold
        standard = base + pr.std_token * cm.std_tokens(z, nb - z) + k * v + over + act
        floor = base + pr.floor_per_token * cm.floor_tokens(z, nb - z, pr)
        txb = nb + 110
        n.update(gas=max(standard, floor), standard=standard, floor=floor,
                 path="floor" if floor >= standard else "standard", onchain_bytes=txb,
                 gossip_bytes=txb, validation_gas=None, validation_gas_strict=None,
                 public_ok=txb <= TXPOOL_MAX_TX_BYTES and max(standard, floor) <= TX_MAX_GAS_LIMIT,
                 admission="geth txpool 128 KiB, EIP-7825", native_verify_us=None)
        return n
    if scenario == "A":                                           # EIP-8141, ARBITRARY + EVM verifier
        g = cm.gas_breakdown(B, P, k, "frame_evm", "7976", impl=impl, per_perm=per_perm)
        vg = cm.validation_gas(B, P, k, "frame_evm", impl=impl, per_perm=per_perm)
        strict = vg + STANDARD_TOKEN_COST * 4 * k * B          # + signature_data_cost (empty msg)
        txb = g.tx_bytes + 4 * k                                # + ~4 B RLP per signature entry
        n.update(gas=g.total, standard=g.standard, floor=g.floor, path=g.binding,
                 onchain_bytes=txb, gossip_bytes=txb, validation_gas=vg,
                 validation_gas_strict=strict, public_ok=vg <= MAX_VERIFY_GAS,
                 admission="EIP-8141 rule 6, MAX_VERIFY_GAS 100K", native_verify_us=None)
        return n
    if scenario in ("B", "C1"):
        G = g_scheme(P, gvar, p_scale, g_round)
        floor_sig = byte_price            # gas per signature/witness byte on the floor path
        std_sig = min(16, byte_price)     # 4 tokens x 4 (empty msg: uniform, eip-8141:519-524)
        fixed = FRAME_TX_INTRINSIC_COST + TX_VALUE_COST
        verify_std = cm.std_tokens(VERIFY_DATA_ZERO, VERIFY_DATA_BYTES - VERIFY_DATA_ZERO)
        if scenario == "B":
            nfr = 2                                              # VERIFY + SENDER
            sigb = B                                             # PR #12616 layout [R via inbox]:
            signer = LEANSPHINCS_PK_BYTES                        # the 32-B public key in `signer`, priced
            sig_ver = k * G                                      # signature_verification_cost
            std = (fixed + nfr * FRAME_TX_PER_FRAME_COST + sig_ver
                   + STANDARD_TOKEN_COST * verify_std
                   + k * (STANDARD_TOKEN_COST * 4 * signer + std_sig * sigb))
            exec_ = 2_000 + 2_100 * k + SENDER_FRAME_GAS         # VERIFY: SIGPARAM, owner SLOAD, APPROVE
            standard = std + exec_
            floor = (fixed + nfr * FRAME_TX_PER_FRAME_COST + sig_ver
                     + TOTAL_COST_FLOOR_PER_TOKEN * 4 * (VERIFY_DATA_BYTES + 3 + k * signer)
                     + k * floor_sig * sigb)
            if floor_rule == "pr12559":
                # EIPs PR #12559 (draft) [R via inbox]: floor = 12,000 + 64 x RLP bytes of frames and
                # signature entries; verification cost and value cost leave the floor. RLP sizes [Mo]:
                # VERIFY frame ~51 B, SENDER frame ~41 B, a signature entry B + 32 + ~10.
                floor = FRAME_TX_INTRINSIC_COST + 64 * (92 + k * (sigb + signer + 10))
            txb = 120 + VERIFY_DATA_BYTES + k * (sigb + signer + 6)
            gossip = txb
            vg = 2_000 + 2_100 * k + sig_ver
            strict = vg + k * (STANDARD_TOKEN_COST * 4 * signer + std_sig * sigb)
            ok = vg <= MAX_VERIFY_GAS
            adm = "EIP-8141 rule 6 with G"
        else:                                                    # C1: 8288 dependency frame, no STARK
            nfr = 3                                              # DEP + VERIFY + SENDER
            dep = TRIPLE_BYTES * k
            dep_std = cm.std_tokens(TRIPLE_ZERO * k, (TRIPLE_BYTES - TRIPLE_ZERO) * k)
            std = (fixed + nfr * FRAME_TX_PER_FRAME_COST
                   + STANDARD_TOKEN_COST * (dep_std + verify_std) + k * std_sig * B)
            exec_ = (k * G + cm.AGG_VERIFY_FRAME_GAS + cm.AGG_VERIFY_FRAME_GAS_PER_DEP * k
                     + SENDER_FRAME_GAS)                         # DEP frame limits.execution = k*G
            standard = std + exec_
            floor = (fixed + nfr * FRAME_TX_PER_FRAME_COST
                     + TOTAL_COST_FLOOR_PER_TOKEN * 4 * (dep + VERIFY_DATA_BYTES) + k * floor_sig * B)
            tx_only = 120 + 20 + dep + VERIFY_DATA_BYTES
            txb = tx_only + k * B                                # witnesses carried in the block [Mo]
            gossip = tx_only + dep + k * B + WRAPPER_FRAMING_BYTES   # mode-0 wrapper: tx + deps + witnesses
            vg = cm.AGG_VERIFY_FRAME_GAS + cm.AGG_VERIFY_FRAME_GAS_PER_DEP * k + k * G
            strict = vg + k * std_sig * B
            ok = vg <= MAX_VERIFY_GAS and k <= min(MAX_SIGS_PER_TX, MAX_LEANSIG_DEPS_PER_WRAPPER)
            adm = "rule 6 (VERIFY + dep frame) and 16 deps/wrapper"
        n.update(gas=max(standard, floor), standard=standard, floor=floor,
                 path="floor" if floor >= standard else "standard", onchain_bytes=txb,
                 gossip_bytes=gossip, validation_gas=vg, validation_gas_strict=strict, public_ok=ok,
                 admission=adm, native_verify_us=k * (P * T_PERM_US + T_SIG_OVERHEAD_US), G=G)
        return n
    raise ValueError(scenario)


# ---------------------------------------------------------------------------------------------
# Variants, plugin callables
# ---------------------------------------------------------------------------------------------
VARIANTS = {
    # name: (scenario, fixed kwargs, pricing label)
    "E0a_7623": ("E0a", {"pricing": "7623"}, "7623"),
    "E0a_7976": ("E0a", {"pricing": "7976"}, "7976"),
    "E0b_7623": ("E0b", {"pricing": "7623"}, "7623"),
    "E0b_7976": ("E0b", {"pricing": "7976"}, "7976"),
    "E0c_7623": ("E0c", {"pricing": "7623"}, "7623"),
    "E0c_7976": ("E0c", {"pricing": "7976"}, "7976"),
    "A": ("A", {}, "8141+7976"),
}
for _s in ("B", "C1"):
    for _g in ("pr12616", "flat", "prop_p256", "prop_k1"):
        for _bp in (64, 16):
            VARIANTS[f"{_s}_{_g}_{_bp}"] = (_s, {"gvar": _g, "byte_price": _bp},
                                             f"8141+{'7976' if _bp == 64 else 'sig16'}")
VARIANTS["B_pr12616_64_fl12559"] = ("B", {"gvar": "pr12616", "byte_price": 64, "floor_rule": "pr12559"},
                                    "8141(PR12559 floor)+7976")
# Plugins pass g_round=True (the PR rounds G up to 100 gas); the tables use the continuous G so that
# elasticities are not step artefacts (<= 100 gas, < 0.1 % of a transaction).


def _make_gas_fn(name):
    scen, fixed, _ = VARIANTS[name]

    def fn(sig_bytes, verify_perms, k=1, **kw):
        a = dict(fixed)
        a.setdefault("g_round", True)
        a.update(kw)
        return int(math.ceil(tx_model(scen, sig_bytes, verify_perms, k, **a)["gas"]))
    fn.__name__ = "gas_" + name
    fn.__doc__ = f"gas_per_tx plugin: scenario {scen}, variant {name} ({fixed}) [Mo]."
    return fn


GAS_FNS = {}
for _name in VARIANTS:
    GAS_FNS[_name] = globals()["gas_" + _name] = _make_gas_fn(_name)


def native_verify_B(perms_per_sig, sigs_per_leaf, ns_per_perm=T_PERM_US * 1e3,
                    per_sig_overhead_ms=T_SIG_OVERHEAD_US / 1e3, stark_ms=9.195, per_message_ms=0.0):
    """noagg_verify_cost plugin for B and C1: every node verifies natively (perms x 224.8 ns [M])."""
    per_sig = perms_per_sig * ns_per_perm / 1e6 + per_sig_overhead_ms
    try:
        from starksim.costs import NativeVerifyCost
        return NativeVerifyCost(per_signature=per_sig * sigs_per_leaf, per_stark=stark_ms,
                                per_message=per_message_ms)
    except ImportError:
        return {"per_signature": per_sig * sigs_per_leaf, "per_stark": stark_ms,
                "per_message": per_message_ms}


def sim_knobs(variant, B, P, k=1, base_tx_bytes=None):
    """Knobs for the simulator's noagg mode, which prices on-chain bytes as tx_bytes + k*sig_bytes:
    returns {"tx_bytes": ..., "models": {"gas_per_tx": spec}} for one variant [Mo]."""
    scen, fixed, _ = VARIANTS[variant]
    t = tx_model(scen, B, P, k, **fixed)
    return {"tx_bytes": int(round(t["onchain_bytes"] - k * B)) if base_tx_bytes is None else base_tx_bytes,
            "models": {"gas_per_tx": {"fn": f"models_noagg:gas_{variant}", "path": HERE},
                       **({"noagg_verify_cost": {"fn": "models_noagg:native_verify_B", "path": HERE}}
                          if scen in ("B", "C1") else {})}}


# ---------------------------------------------------------------------------------------------
# TPS, elasticities, admission
# ---------------------------------------------------------------------------------------------

def tps(variant, B, P, k=1, gas_limit=60e6, **kw):
    scen, fixed, _ = VARIANTS[variant]
    a = dict(fixed)
    a.update(kw)
    t = tx_model(scen, B, P, k, **a)
    n_gas = gas_limit / t["gas"]
    n_bytes = (MAX_RLP_BLOCK_SIZE - BLOCK_HEADER_BYTES) / t["onchain_bytes"]
    n = min(n_gas, n_bytes)
    return {"tps_tx": n / SLOT_S, "tps_sig": k * n / SLOT_S, "txs_per_block": n,
            "binding": "gas" if n_gas <= n_bytes else "bytes",
            "block_bytes": n * t["onchain_bytes"] + BLOCK_HEADER_BYTES, "tx": t,
            "verify_cpu_ms_block": (n * t["native_verify_us"] / 1e3
                                    if t.get("native_verify_us") is not None else None)}


def elasticity(variant, B, P, k=1, gas_limit=60e6, rel=1e-4, **kw):
    f = lambda b, p: math.log(tps(variant, b, p, k, gas_limit, **kw)["tps_tx"])
    eB = (f(B * (1 + rel), P) - f(B * (1 - rel), P)) / (math.log(1 + rel) - math.log(1 - rel))
    eP = (f(B, P * (1 + rel)) - f(B, P * (1 - rel))) / (math.log(1 + rel) - math.log(1 - rel))
    return eB, eP


def steps(variant, B, P, k=1, gas_limit=60e6, **kw):
    t0 = tps(variant, B, P, k, gas_limit, **kw)["tps_tx"]
    dB = [tps(variant, B * (1 + s), P, k, gas_limit, **kw)["tps_tx"] / t0 - 1 for s in (.1, .25, .5, 1.)]
    dP = [tps(variant, B, P * (1 + s), k, gas_limit, **kw)["tps_tx"] / t0 - 1 for s in (.1, .25, .5, 1.)]
    return dB, dP


def p_star(variant, B, k=1, **kw):
    """P at which the standard path overtakes the floor; None if it never does below 1e6 (B: G is in
    both paths, so P never switches the path; C1 flat: P does not enter); 0 if the standard path
    already binds at P = 0 (byte price 16)."""
    scen, fixed, _ = VARIANTS[variant]
    a = dict(fixed)
    a.update(kw)
    path = lambda p: tx_model(scen, B, p, k, **a)["path"]
    if path(0) == "standard":
        return 0.0
    lo, hi = 0.0, 1.0
    while path(hi) == "floor":
        lo, hi = hi, hi * 2
        if hi > 1e6:
            return None
    for _ in range(50):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if path(mid) == "floor" else (lo, mid)
    return hi


def k_max_public(variant, B, P, cap=MAX_VERIFY_GAS, strict=False, **kw):
    """Largest k the public mempool admits (rule 6 at `cap` for A/B/C1; ERC-7562 size for E0a;
    128 KiB / 2^24 for E0b/E0c); `strict` counts signature_data_cost in rule 6 (reading b)."""
    scen, fixed, _ = VARIANTS[variant]
    a = dict(fixed)
    a.update(kw)
    k = 0
    while k < 4096:
        t = tx_model(scen, B, P, k + 1, **a)
        if scen in ("A", "B", "C1"):
            vg = t["validation_gas_strict"] if strict else t["validation_gas"]
            ok = vg <= cap
            if scen == "C1":
                ok = ok and k + 1 <= min(MAX_SIGS_PER_TX, MAX_LEANSIG_DEPS_PER_WRAPPER)
            ok = ok and t["gossip_bytes"] <= TXPOOL_MAX_TX_BYTES
        else:
            ok = t["public_ok"]
        if not ok:
            break
        k += 1
    return k


def p_max_public(variant, B, k=1, cap=MAX_VERIFY_GAS, **kw):
    """Largest P whose k-signature tx the public mempool admits (A, B prop, C1 prop); inf if P
    does not enter admission (flat G, E0)."""
    scen, fixed, _ = VARIANTS[variant]
    a = dict(fixed)
    a.update(kw)
    if scen not in ("A", "B", "C1") or a.get("gvar") == "flat":
        return math.inf
    vg = lambda p: tx_model(scen, B, p, k, **a)["validation_gas"]
    if vg(0) > cap:
        return 0.0
    lo, hi = 0.0, 1.0
    while vg(hi) <= cap:
        lo, hi = hi, hi * 2
    for _ in range(50):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if vg(mid) <= cap else (lo, mid)
    return lo


# ---------------------------------------------------------------------------------------------
# Self-checks against phase 1 (claim CH1 receipts and the 4337 calibration)
# ---------------------------------------------------------------------------------------------
CH1_FRAME = (("leanSphincs", 5684, 354, "lean", 385_322), ("leanSphincs-s", 4164, 259, "lean", 288_042),
             ("leanSphincs-f", 4660, 290, "lean", 319_786),
             ("leanSphincs-layered", 7740, 492, "layered", 516_906), ("C13", 3688, 358, "unoptimised", 257_578))
CH1_SEPOLIA = (("leanSphincs", 5684, 354, 390_040), ("leanSphincs-s", 4164, 259, 293_784),
               ("leanSphincs-f", 4660, 290, 324_504), ("C13", 3688, 358, 263_064))


def self_checks():
    out = []
    for name, B, P, impl, rec in CH1_FRAME:      # A: ethrex frame txs [M rec] SPHINCs- docs/deployments.md
        out.append((f"A frame tx {name}", gas_A(B, P, 1, impl=impl), rec))
    for name, B, P, rec in CH1_SEPOLIA:          # E0c/E0b calldata path, verify-only shape, 7976
        out.append((f"E0 verify-only tx {name} (7976)",
                    int(math.ceil(tx_model("E0c", B, P, 1, pricing="7976", verify_only=True)["gas"])), rec))
    # E0a: C13 handleOps 292,727 on Sepolia under 7623, first userOp [M rec]
    out.append(("E0a C13 handleOps first userOp (7623)",
                int(round(tx_model("E0a", 3688, 358, 1, pricing="7623", per_perm=106_672 / 358,
                                   ep_overhead=cm.ENTRYPOINT_OVERHEAD_GAS)["gas"])), 292_727))
    # E0b / E0c measured receipts (anvil prague = EIP-7623): 21,000 + std calldata + O(B) + action
    for route, n, z, rec in E0_MEASURED:
        fixed = E0B_OVERHEAD_FIXED if route == "E0b" else E0C_OVERHEAD_FIXED
        sigb = 64 if n < 1000 else 2048
        model = 21_000 + 4 * z + 16 * (n - z) + fixed + _mem_copy_gas(sigb) + E0_ACTION_GAS
        out.append((f"{route} measured receipt, {sigb}-B mock signature (7623)", int(round(model)), rec))
    # B (PR #12616 layout), floor path, against the scenarios agent's independent formula [Mo]
    # 12,000 + 950 + 6,000 + G + 64 (B + 32 + 39) (notes/phase2/inbox.md): 531,454 and 306,506
    for B, P, scale, rec in ((7740, 515, 492 / 515, 531_454), (4308, 283, 1.0, 306_506)):
        out.append((f"B pr12616 floor, B={B} (cross-check, not a receipt)",
                    gas_B_pr12616_64(B, P, 1, p_scale=scale), rec))
    return out


# ---------------------------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------------------------
P_SCALE_PR12616 = {"B0": 492 / 515}   # PR #12616 prices B0 on EthLib's 492 permutations, not leanVM's 515
CANDIDATES = (("B0", 7740, 515, "layered"), ("P99a", 4308, 283, "lean"), ("N2", 5980, 415, "layered"))
GRID_B = (2000, 3000, 4000, 4308, 5000, 5980, 7000, 7740, 10000)
GRID_P = (150, 200, 283, 350, 415, 515, 750, 1000)
COLS = ["scenario", "variant", "pricing", "gas_limit", "profile", "uplinks", "nodes", "candidate", "B", "P",
        "k", "tps_tx", "tps_sig", "tps_timely", "binding", "eps_B", "eps_P", "dB10", "dB25", "dB50",
        "dB100", "dP10", "dP25", "dP50", "dP100", "block_bytes", "t90_block_s", "bw_node_mbit",
        "dup_share", "wasted_share", "degradation", "status", "source"]
DETAIL = ["scenario", "variant", "pricing", "gas_limit", "candidate", "B", "P", "k", "impl", "gas_tx",
          "path", "standard_gas", "floor_gas", "G_scheme", "onchain_bytes_tx", "gossip_bytes_tx",
          "block_bytes", "eip7934_cap", "txs_per_block", "binding", "public_ok", "admission",
          "validation_gas", "validation_gas_strict", "k_max_public_100K", "k_max_public_300K",
          "k_max_public_strict_100K", "p_max_public_100K", "p_star", "verify_cpu_ms_block"]


def _fmt(x, nd=6):
    if x is None:
        return "NA"
    if isinstance(x, float):
        if math.isinf(x):
            return "inf"
        return f"{x:.{nd}g}"
    return str(x)


def rows():
    pts = [(c, B, P, impl) for c, B, P, impl in CANDIDATES]
    pts += [("grid", B, P, "lean") for B in GRID_B for P in GRID_P]
    for variant, (scen, fixed, plab) in VARIANTS.items():
        for cand, B, P, impl in pts:
            for k in (1, 2, 3):
                kw = {"impl": impl, "p_scale": P_SCALE_PR12616.get(cand, 1.0)}
                kmx = {c: k_max_public(variant, B, P, c, **kw) for c in (MAX_VERIFY_GAS, MAX_VERIFY_GAS_PROPOSED)}
                kms = k_max_public(variant, B, P, MAX_VERIFY_GAS, strict=True, **kw)
                pmax = p_max_public(variant, B, k, **kw)
                ps = p_star(variant, B, k, **kw)
                for G in GAS_LIMITS:
                    d = tps(variant, B, P, k, G, **kw)
                    t = d["tx"]
                    eB, eP = elasticity(variant, B, P, k, G, **kw)
                    dB, dP = steps(variant, B, P, k, G, **kw)
                    binding = d["binding"] + ("" if t["public_ok"] else "+private-only")
                    main = dict(scenario=scen, variant=variant, pricing=plab, gas_limit=G, profile="NA",
                                uplinks="NA", nodes="NA", candidate=cand, B=B, P=P, k=k,
                                tps_tx=d["tps_tx"], tps_sig=d["tps_sig"], tps_timely="NA",
                                binding=binding, eps_B=eB, eps_P=eP, dB10=dB[0], dB25=dB[1], dB50=dB[2],
                                dB100=dB[3], dP10=dP[0], dP25=dP[1], dP50=dP[2], dP100=dP[3],
                                block_bytes=d["block_bytes"], t90_block_s="NA", bw_node_mbit="NA",
                                dup_share="NA", wasted_share="NA", degradation="NA", status="modeled",
                                source=f"data/phase2/models_noagg.py:gas_{variant}")
                    det = dict(scenario=scen, variant=variant, pricing=plab, gas_limit=G, candidate=cand,
                               B=B, P=P, k=k, impl=impl, gas_tx=t["gas"], path=t["path"],
                               standard_gas=t["standard"], floor_gas=t["floor"], G_scheme=t.get("G"),
                               onchain_bytes_tx=t["onchain_bytes"], gossip_bytes_tx=t["gossip_bytes"],
                               block_bytes=d["block_bytes"], eip7934_cap=MAX_RLP_BLOCK_SIZE,
                               txs_per_block=d["txs_per_block"], binding=binding, public_ok=t["public_ok"],
                               admission=t["admission"], validation_gas=t["validation_gas"],
                               validation_gas_strict=t["validation_gas_strict"],
                               k_max_public_100K=kmx[MAX_VERIFY_GAS], k_max_public_300K=kmx[MAX_VERIFY_GAS_PROPOSED],
                               k_max_public_strict_100K=kms, p_max_public_100K=pmax, p_star=ps,
                               verify_cpu_ms_block=d["verify_cpu_ms_block"])
                    yield main, det


def write_csv():
    p1, p2 = os.path.join(HERE, "noagg_analytic.csv"), os.path.join(HERE, "noagg_analytic_detail.csv")
    n = 0
    with open(p1, "w", newline="") as f1, open(p2, "w", newline="") as f2:
        w1, w2 = csv.writer(f1), csv.writer(f2)
        w1.writerow(COLS)
        w2.writerow(DETAIL)
        for m, d in rows():
            w1.writerow([_fmt(m[c]) for c in COLS])
            w2.writerow([_fmt(d[c]) for c in DETAIL])
            n += 1
    return n, p1, p2


def report():
    print(f"T_perm {T_PERM_US*1e3:.1f} ns [M]; gas/us: P256 {GAS_PER_US['p256']:.1f}, k1 {GAS_PER_US['k1']:.2f}")
    print("== self-checks vs phase-1 receipts (CH1) ==")
    bad = 0
    for lab, m, r in self_checks():
        tol = 20 if lab.startswith("E0a") or "measured receipt" in lab else 0
        ok = abs(m - r) <= tol
        bad += not ok
        print(f"  {lab:48s} model {m:>9,}  recorded {r:>9,}  diff {m - r:+,}  {'ok' if ok else 'FAIL'}")
    print(f"  E0b fixed overhead {E0B_OVERHEAD_FIXED:,} [M]; E0c {E0C_OVERHEAD_FIXED:,} [M]; "
          f"4337 steady {cm.ENTRYPOINT_OVERHEAD_STEADY[0]:,.0f} [M replay]")
    print("\n== candidates, k=1, 60M: gas/tx, path, tx/s, eB, eP, onchain B, gossip B, k_max 100K/300K, "
          "P*, Pmax(100K), verify CPU ms/block ==")
    for variant in VARIANTS:
        for c, B, P, impl in CANDIDATES:
            kw = {"impl": impl, "p_scale": P_SCALE_PR12616.get(c, 1.0)}
            d = tps(variant, B, P, 1, 60e6, **kw)
            t = d["tx"]
            eB, eP = elasticity(variant, B, P, 1, 60e6, **kw)
            km = [k_max_public(variant, B, P, cap, **kw) for cap in (MAX_VERIFY_GAS, MAX_VERIFY_GAS_PROPOSED)]
            ps = p_star(variant, B, 1, **kw)
            pm = p_max_public(variant, B, 1, **kw)
            cpu = d["verify_cpu_ms_block"]
            print(f"  {variant:16s} {c:4s} {t['gas']:9,.0f} {t['path']:8s} {d['tps_tx']:6.2f} {eB:+.3f} {eP:+.3f} "
                  f"{t['onchain_bytes']:6,.0f} {t['gossip_bytes']:6,.0f} k {km[0]:2d}/{km[1]:2d} "
                  f"P* {'NA' if ps is None else f'{ps:,.0f}':>6s} Pmax {pm:>7.0f} "
                  f"cpu {'NA' if cpu is None else f'{cpu:.1f}'} {'' if t['public_ok'] else 'NOT-PUBLIC'}")
    return bad


if __name__ == "__main__":
    bad = report()
    if "--csv" in sys.argv:
        n, p1, p2 = write_csv()
        print(f"\nwrote {n} rows to {p1} and {p2}")
    sys.exit(1 if bad else 0)

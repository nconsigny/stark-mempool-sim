#!/usr/bin/env python3
"""Phase 2 cost models of the aggregation scenarios C2, D/E and F (F1, F2, F3) [Mo].

Builds on data/prover_model.py (leanVM 04fba03 prover, calibrated [Mo, cal. R/M]) and
data/analytic_model.py (phase-1 closed forms). Nothing here is measured; every number is [Mo]
unless a constant says [E] (spec text), [R] (read in code or a published file) or [Rc] (recalled).
Notes: /leansphincs/notes/phase2/models-agg.md.

    python3 -I models_agg.py            # self-checks, then writes agg_analytic.csv and prints tables
    python3 -I models_agg.py --check    # self-checks only

Simulator plug-ins (sims/LEANSPHINCS-FORK.md "Model plug-in interface"; the spec's kwargs are bound):

    circuit_cost(perms_per_sig, sigs_per_leaf, *, sig_bytes=None, hw="m4", stack="none", ...)  -> CircuitCost
    verify_cost(perms_per_sig, sigs_per_leaf, *, hw="m4", ...)                                -> NativeVerifyCost
    agg_gas_per_tx(sig_bytes, verify_perms, k, *, dep_gas=33_000, ...)                       -> int gas (D/E/C2)
    pcs_model(sig_bytes, perms_per_sig, k, *, hw="epyc9355p", ...)                            -> dict (F, PCS_KEYS)

Other public functions:

    prove_time_s(n, P, B, c, hw, stack)          one leanVM proof with an optional PR stack
    node_capacity_s(P, B, hw, stack, budget_s)   sig/s one aggregator proves (node loop, c = 1)
    prover_elasticity(P, B, hw, stack)           d ln capacity / d ln P, / d ln B
    gas_bound(G, deps, dep_gas)                  sig/s the chain admits
    c2_builder(n, P, B, hw, ...)                 machines and cores a C2 builder needs
    de_regime(...)                               D/E: min(gas, prover, bandwidth) and which binds
    f_costs(kind, P, B, hw, k)                   F1 / F2 / F3 gas, bytes, prover time, capacity
    always_costs(P, B, hw)                       CPU-s, energy per signature, aggregators, latency
"""

import csv
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))          # /leansphincs/data
import prover_model as pm                            # noqa: E402
import analytic_model as am                          # noqa: E402
import chain_model as cm                             # noqa: E402

SLOT_S = 12.0                                        # [E]
GAS_LIMITS = (60e6, 100e6, 150e6, 200e6, 300e6)      # PHASE2 s4, + 200 M (Glamsterdam, notes/phase2/inbox.md)
CANDIDATES = {"B0": (7740, 515), "P99a": (4308, 283), "N2": (5980, 415)}   # PHASE2 s4 [R]
HW_CLASSES = ("eip7870_full", "eip7870", "box16", "m4", "epyc9355p")
CORES = {"eip7870_full": 4, "eip7870": 8, "box8": 8, "box16": 16, "box16_fit": 16, "m4": 16, "epyc9355p": 32}
# Package power at full load, watts [Rc]: vendor TDP/PPT figures recalled, not measured. Energy
# per signature is therefore a ratio estimate only.
WATTS = {"eip7870_full": 30.0, "eip7870": 65.0, "box8": 80.0, "box16": 120.0, "box16_fit": 120.0,
         "m4": 75.0, "epyc9355p": 280.0}

# --------------------------------------------------------------------------------------------
# 1. leanVM pull requests (refs/leanvm-pulls-2026-11-10.md; bodies in data/phase2/prs_html/,
#    extracted with data/phase2/tools/pr_body.py). Each: what it changes, the claimed gain [R, the
#    PR's own measurement, not ours], the cost level it acts on, status, and the factor this model
#    applies when the PR is in the stack [Mo]. Levels: perm = per Keccak-f permutation (KECCAK
#    rows, keccak_gkr); word = per committed word (bus GKR, commit, constraints, openings);
#    mem = memory commitment (per cell); proof = per proof (fixed); merge = per merged child;
#    bytes = proof bytes only; none = no prover cost change.
# --------------------------------------------------------------------------------------------
PRS = [
    # n, status, protocol change?, level, claim [R], knob, factor
    (730, "open", False, "perm", "keccak_gkr prover -26.5 % (8T) / -21.7 % (16T), Ice Lake AVX-512; proof byte-identical", "aK", 0.783),
    (743, "open", False, "perm", "Keccak GKR tail 2 rounds/pass: Tail 69->38 ms, S500 r1/4 prove -0.9 %", "aK", 0.99),
    (742, "open", False, "perm", "AVX-512 Skip kernel paired chi products: S500 -1.5 %, S480 -3.2 %; overlaps #730 commit 4 (same kernel)", "aK", 1.0),
    (741, "open", False, "perm", "input-opening pack fold by BitFold: Openings 11-15 -> 7 ms, prove within noise", "aK", 1.0),
    (745, "draft", True, "perm", "KECCAK gated output cells count constant 1 (12 count columns removed): S500 r1/4 -2.8 % prove, +2.9 % sigs/s", "kwords", 80.0),
    (744, "open", False, "word", "bus GKR 2 rounds/pass on AVX-512: S500 r1/4 -2.8 % prove, +4.3 % sigs/s", "w", 0.944),
    (716, "open", False, "word", "bus GKR 2 rounds/pass (portable): Bus GKR -17 % at 24T, prove -8 % inside spread (xmss900); same idea as #744", "w", 1.0),
    (740, "open", False, "word", "table sums from the join message (no Bus-tables pass): S500 r1/2 -20 ms (-1.8 %), r1/4 -0.1 %", "w", 0.964),
    (739, "open", False, "proof", "keep the L0 codeword above 1 GiB (opt-in env): S500 r1/4 -3.3 %, +3.5 GiB RSS; rate 1/4 only", "w4", 0.94),
    (718, "open", True, "mem", "announce N_mem, commit only covered cells (<=3 pow2 pieces): xmss900 -15 % committed, -10.8 % prove, proof +8.5 %", "mem_unpadded", 1.0),
    (717, "open", False, "none", "stacking plumbing for #718: nothing changes (proofs and guest identical)", None, 1.0),
    (725, "open", False, "none", "bus count tree in K: time unchanged (S438 0.425 -> 0.43 s EPYC), RSS -5..-14 %", None, 1.0),
    (657, "draft", True, "merge", "affine verifier recursion (DOT, KECCAK_M): 2->1 recursion -22.9 % cycles", "child_cycles", 0.771),
    (663, "open", True, "merge", "1->1 relay hints its list digests instead of rehashing claims (no description); relay nodes only", "relay", 1.0),
    (746, "draft", False, "merge", "aggregate_after: next interval's guest runs before the child proof: node sigs/s +7.1 % (N500), +4.0 % (N480)", "overlap", 1.0),
    (747, "draft", True, "bytes", "Canopy PCS commitment (ePrint 2026/2790), not to merge: proof -11.2 % at rate 1/2 (xmss900), prove unchanged", "proof_bytes", 0.888),
    (737, "open", False, "none", "QROM proof of leanSPHINCS in Lean (formal/ only, 92 files): no crate change", None, 1.0),
    (724, "merged 2026-11-08 (40f877dc)", True, "perm", "KECCAK custom output size: 1000 -> 1400 XMSS/s; already in the 04fba03 calibration", None, 1.0),
    (662, "merged (5e3ade21)", False, "perm", "leanSPHINCS FIPS 205 hash layout: 440 -> 410 sigs/s; already in 04fba03 (P = 515)", None, 1.0),
    (731, "merged 2026-11-09 (80511a47)", False, "none", "Lean certificate tables in N (H26 59 s -> 24 s kernel time): proofs only", None, 1.0),
]
STACKS = {
    "none": (),
    # prover-only PRs (no protocol change), open, non-overlapping knobs
    "prover_only": (730, 743, 744, 740, 739, 746),
    # every open or draft PR that changes cost, if they all land as claimed
    "all": (730, 743, 744, 740, 739, 746, 745, 718, 657, 747),
}
OVERLAP_HIDDEN = 0.943     # #746: 94.3 % of a node's cycles run before the first child hint [R]
OVERLAP_SLOWDOWN = 0.021   # #746: proof k slowed +30.8 ms of ~1.45 s [R]


def _stack_knobs(stack):
    ids = STACKS[stack] if isinstance(stack, str) else tuple(stack)
    k = {"aK": 1.0, "w": 1.0, "w4": 1.0, "kwords": pm.KECCAK_WORDS_PER_ROW, "mem_unpadded": False,
         "child_cycles": 1.0, "overlap": False, "proof_bytes": 1.0}
    for n, _st, _proto, _lvl, _claim, knob, f in PRS:
        if n not in ids or knob is None:
            continue
        if knob in ("aK", "w", "w4", "child_cycles", "proof_bytes"):
            k[knob] *= f
        elif knob == "kwords":
            k[knob] = f
        elif knob in ("mem_unpadded", "overlap"):
            k[knob] = True
    return k


def _three_bits(x):
    """#718: memory committed as up to three aligned power-of-two pieces = x rounded up to a
    number with at most 3 set bits (granularity 2^(t-2) under the top bit t)."""
    if x <= 1:
        return 1
    t = math.floor(math.log2(x))
    g = 1 << max(0, t - 2)
    return math.ceil(x / g) * g


def committed_words_s(rows, smooth=False, knobs=None):
    knobs = knobs or _stack_knobs("none")
    pad = (lambda x: x / math.log(2)) if smooth else pm.p2
    if knobs["mem_unpadded"]:
        mem = rows["MEM"] * (1.0 + 1 / 16) if smooth else _three_bits(rows["MEM"])   # E[3-bit pad] ~ 1/16
    else:
        mem = pad(rows["MEM"])
    w = 4 * max(mem, 1 << pm.MIN_LOG_MEM) + pm.BYTECODE_WORDS
    for t, c in pm.COLS.items():
        w += c * pad(rows[t])
    if rows["K"] > 0:
        w += knobs["kwords"] * pad(rows["K"])
    return w


def _rows_s(n, P, B, c, knobs, child_claims, rate, shape=None):
    rows = pm.proof_rows(n, P, B, c, shape=shape, child_claims=child_claims, rate=rate)
    if c and knobs["child_cycles"] != 1.0:
        r0 = pm.proof_rows(n, P, B, 0, shape=shape, rate=rate)
        for t in ("XOR", "MUL", "SET", "DEREF", "JUMP", "MEM"):
            rows[t] = r0[t] + (rows[t] - r0[t]) * knobs["child_cycles"]
        rows["cycles"] = sum(rows[t] for t in pm.TABLES)
    return rows


def breakdown_s(n, P=None, B=None, c=0, hw="m4", stack="none", *, rate=1, smooth=False,
                child_claims=500, shape=None):
    """prover_model.breakdown with a PR stack applied (stack="none" reproduces it exactly)."""
    knobs = _stack_knobs(stack)
    h = pm.hw_of(hw)
    if isinstance(h, pm.ScaledHW):
        b = breakdown_s(n, P, B, c, "m4", stack, rate=rate, smooth=smooth, child_claims=child_claims, shape=shape)
        tot = b["total_s"]
        ks = b["time"]["keccak_reduction"] / tot if tot else 0.0
        # the Keccak share is taken on the unstacked M4 split, as prover_model does, so that a
        # stacked keccak speed-up is not counted twice through the interpolation
        b0 = pm.breakdown(n, P, B, c, "m4", rate=rate, smooth=smooth, child_claims=child_claims, shape=shape)
        ks = b0["time"]["keccak_reduction"] / b0["total_s"]
        f = min(1.0, max(0.0, (ks - pm._KSHARE_MERGE) / (pm._KSHARE_LEAF - pm._KSHARE_MERGE)))
        s = h.s_merge + (h.s_leaf - h.s_merge) * f
        b["time"] = {k: v * s for k, v in b["time"].items()}
        b["total_s"] = tot * s
        return b
    rows = _rows_s(n, P, B, c, knobs, child_claims, rate, shape)
    W = committed_words_s(rows, smooth, knobs)
    padK = (rows["K"] / math.log(2) if smooth else pm.p2(rows["K"])) if rows["K"] > 0 else 0
    w = h.w2 if rate == 1 else h.w4 * knobs["w4"]
    w *= knobs["w"]
    t = {"fixed": h.f0, "committed_words": w * W, "keccak_reduction": h.aK * knobs["aK"] * padK,
         "execute": h.e_c * rows["cycles"] + h.e_k * rows["K"]}
    mu = math.ceil(math.log2(W))
    return {"rows": rows, "W": W, "mu": mu, "time": t, "total_s": sum(t.values()),
            "feasible": mu <= pm.MAX_MU and c <= pm.MAX_RECURSIONS and n + c * child_claims < pm.MAX_KEYS}


def prove_time_s(n, P=None, B=None, c=0, hw="m4", stack="none", **kw):
    return breakdown_s(n, P, B, c, hw, stack, **kw)["total_s"]


def interval_time_s(n, P, B, hw, stack="none", *, c=1, rate=1, smooth=True, child_claims=500):
    """Seconds of one node-loop interval: a proof of n raw signatures merging its previous
    aggregate. With #746 in the stack the guest run of interval k+1 overlaps proof k: the
    execution share before the first child hint is hidden, and proof k slows by ~2 % [Mo on R]."""
    b = breakdown_s(n, P, B, c, hw, stack, rate=rate, smooth=smooth, child_claims=child_claims)
    T = b["total_s"]
    if _stack_knobs(stack)["overlap"] and c >= 1:
        T = T - OVERLAP_HIDDEN * b["time"]["execute"] + OVERLAP_SLOWDOWN * T
    return T, b


def node_capacity_s(P=None, B=None, hw="m4", stack="none", budget_s=1.0, *, c=1, rate=1,
                    smooth=True, child_claims=500, n_max=8192):
    """Largest n proven per interval (sig/s at a 1 s interval) by one aggregator merging c
    children of child_claims claims, within leanVM's limits (mu <= 28, c <= 16, claims < 2^16)."""
    def ok(n):
        T, b = interval_time_s(n, P, B, hw, stack, c=c, rate=rate, smooth=smooth, child_claims=child_claims)
        return b["feasible"] and T <= budget_s
    if not ok(0):
        return 0
    lo, hi = 0, n_max
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if ok(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


def per_sig_time_s(P=None, B=None, hw="m4", stack="none", rate=1):
    """Marginal smooth seconds per raw signature (no cliffs, no budget)."""
    t1 = prove_time_s(400, P, B, 0, hw, stack, rate=rate, smooth=True)
    t0 = prove_time_s(200, P, B, 0, hw, stack, rate=rate, smooth=True)
    return (t1 - t0) / 200


def _elast(f, x, rel=0.10):
    return (math.log(f(x * (1 + rel))) - math.log(f(x * (1 - rel)))) / (math.log(1 + rel) - math.log(1 - rel))


def prover_elasticity(P=515, B=7740, hw="m4", stack="none", budget_s=1.0, rate=1):
    """d ln(node capacity)/d ln P and /d ln B (smooth), and of the per-signature prover time."""
    capP = lambda p: max(node_capacity_s(p, B, hw, stack, budget_s, rate=rate), 1)
    capB = lambda b: max(node_capacity_s(P, b, hw, stack, budget_s, rate=rate), 1)
    tsP = lambda p: per_sig_time_s(p, B, hw, stack, rate)
    return {"cap": node_capacity_s(P, B, hw, stack, budget_s, rate=rate), "eP": _elast(capP, P),
            "eB": _elast(capB, B), "t_sig_ms": 1e3 * per_sig_time_s(P, B, hw, stack, rate),
            "t_sig_eP": _elast(tsP, P),
            "keccak_share_of_t_sig": _keccak_share(P, B, hw, stack, rate)}


def _keccak_share(P, B, hw, stack, rate):
    """Share of the marginal per-signature time that is proportional to permutations
    (Keccak reduction + KECCAK committed words + native Keccak execution), M4 split [Mo]."""
    knobs = _stack_knobs(stack)
    h = pm.HWS["m4"]
    w = (h.w2 if rate == 1 else h.w4 * knobs["w4"]) * knobs["w"]
    perm = (h.aK * knobs["aK"] + w * knobs["kwords"]) / math.log(2) + h.e_k
    return perm * P / per_sig_time_s(P, B, "m4", stack, rate)


# --------------------------------------------------------------------------------------------
# 2. Gas: EIP-8288 as written (3,000 + 30,000 per dependency [E eip-8288.md:41-42, 80, 384-387:
#    recursive_stark_gas = 30,000 x len(dependency_triples(tx)), "every triple ... duplicates
#    included": per dependency, not per transaction]) and the leanPCS draft (3,000 only, frames at
#    limits.execution = 0 [E refs/leanPCS/eip-draft_leanPCS.md:76 @ 4905424d]).
# --------------------------------------------------------------------------------------------
TX0 = am.S2_GAS0                     # 28,517: frame tx with a dependency frame, 21 k base included [Mo, chain.md]
TRIPLE_CALLDATA_GAS = am.S2_GAS_PER_DEP - 33_000     # 3,264: a 96-byte triple's calldata (7976) [Mo]
PCS_PAYLOAD_CALLDATA_GAS = 64 * 16 + 4   # leanPCS format: 1-byte scheme per frame + 64-byte payload [Mo]
DEP_GAS = {"8288": 33_000, "pcsdraft": 3_000}


DEP_BYTES = {"triple": am.TRIPLE, "pcsfmt": 64}   # EIP-8288 triple; leanPCS draft scheme||msg||pk (+1 B a frame)


def dep_tx_gas(deps=1, dep_gas=33_000, calldata_per_dep=TRIPLE_CALLDATA_GAS, dep_bytes=am.TRIPLE,
               floor_per_byte=64):
    """Gas of one transaction declaring `deps` leanSPHINCS dependencies [Mo]: the phase-1 standard
    form TX0 + deps (dep_gas + calldata) (64,781 at 1 dep and 608,741 at 16 under EIP-8288,
    chain_model.gas_breakdown) against chain_model's EIP-7976 floor (frame intrinsic 12,000 +
    475 a frame + 64 gas a calldata byte: 27,873 at 1 dep), less 64 x 32 a dependency for the
    leanPCS draft's 64-byte payload. The standard side binds in every case here (34,781 at
    3,000 gas and 1 dep; 128,741 at 16)."""
    std = TX0 + deps * (dep_gas + calldata_per_dep)
    floor = cm.gas_breakdown(7740, 515, deps, "agg8288", "7976").floor - floor_per_byte * (am.TRIPLE - dep_bytes) * deps
    return max(std, floor)


def gas_bound(G=60e6, deps=1, dep_gas=33_000, **kw):
    """Signatures per second the chain admits when every tx carries `deps` dependencies."""
    return G / SLOT_S / dep_tx_gas(deps, dep_gas, **kw) * deps


def agg_gas_per_tx(sig_bytes, verify_perms, k, *, dep_gas=33_000, calldata_per_dep=TRIPLE_CALLDATA_GAS,
                   dep_bytes=am.TRIPLE, floor_per_byte=64, **_):
    """Simulator plug-in `agg_gas_per_tx(sig_bytes, verify_perms, k)`: neither B nor P enters.
    dep_gas=3000 is the leanPCS draft's charge; add calldata_per_dep=1024, dep_bytes=64 for its
    64-byte payload format."""
    return int(dep_tx_gas(k, dep_gas, calldata_per_dep, dep_bytes, floor_per_byte))


# --------------------------------------------------------------------------------------------
# 3. Simulator plug-ins for circuit and verify costs, with the PR stack
# --------------------------------------------------------------------------------------------
def circuit_cost(perms_per_sig, sigs_per_leaf, *, sig_bytes=None, hw="m4", stack="none", rate=1,
                 child_claims=500, speedup=1.0):
    """Plug-in `circuit_cost(perms_per_sig, sigs_per_leaf, **kw) -> CircuitCost` (smooth, ms).
    stack="none" equals prover_model.sim_circuit_cost."""
    t_sig = per_sig_time_s(perms_per_sig, sig_bytes, hw, stack, rate)
    t_c = (prove_time_s(0, perms_per_sig, sig_bytes, 3, hw, stack, smooth=True, rate=rate, child_claims=child_claims)
           - prove_time_s(0, perms_per_sig, sig_bytes, 2, hw, stack, smooth=True, rate=rate, child_claims=child_claims))
    t0 = prove_time_s(1, perms_per_sig, sig_bytes, 0, hw, stack, smooth=True, rate=rate) - t_sig
    kw = dict(ms_per_hash=1.0 / speedup, overhead_hashes=1e3 * t0, sphincs_hashes=1e3 * t_sig * sigs_per_leaf,
              leanstark_hashes=1e3 * t_c, recursive_hashes=1e3 * t_c, trace_rows_per_hash=1.0, trace_cap=math.inf)
    try:
        from starksim.costs import CircuitCost
    except ImportError:
        return kw
    return CircuitCost(**kw)


def verify_cost(perms_per_sig, sigs_per_leaf, *, hw="m4", ns_per_perm=179.0, per_sig_overhead_ms=0.01, **_):
    """Plug-in `verify_cost` (same as prover_model.sim_verify_cost)."""
    per_sig = perms_per_sig * ns_per_perm / 1e6 + per_sig_overhead_ms
    kw = dict(per_signature=per_sig * sigs_per_leaf, per_stark=1e3 * pm.verify_time(hw), per_message=0.0)
    try:
        from starksim.costs import NativeVerifyCost
    except ImportError:
        return kw
    return NativeVerifyCost(**kw)


# --------------------------------------------------------------------------------------------
# 4. Costs P always moves, whatever binds TPS
# --------------------------------------------------------------------------------------------
def always_costs(P, B, hw="eip7870", stack="none", demand_sig_s=None, node_rate=100):
    """CPU-seconds and joules per signature (raw proving, marginal), the aggregators a demand
    needs, and the aggregation latency of a node receiving node_rate sig/s (one interval's proof
    of node_rate signatures plus its child, staircase) [Mo; watts Rc]."""
    t = per_sig_time_s(P, B, hw, stack)
    cap = node_capacity_s(P, B, hw, stack)
    lat, _ = interval_time_s(node_rate, P, B, hw, stack, smooth=False)
    out = {"t_sig_ms": 1e3 * t, "cpu_s_per_sig": t * CORES[hw], "joule_per_sig": t * WATTS[hw],
           "node_cap": cap, "latency_s_at_load": lat}
    if demand_sig_s:
        out["aggregators"] = math.ceil(demand_sig_s / cap) if cap else math.inf
    return out


# --------------------------------------------------------------------------------------------
# 5. C2: no mempool recursion; raw signatures gossip; the builder proves the block
# --------------------------------------------------------------------------------------------
LEAF_SWEET = 485          # largest leaf before the 2^22 memory cliff at P = 515 (prover-model s2.2) [Mo]


_LEAF_CACHE = {}


def best_leaf(P, B, hw="epyc9355p", stack="none"):
    """Leaf size with the best signatures per second among the staircase's cliff points (and the
    mu <= 28 maximum): a builder stops each leaf just before a padding cliff [Mo]."""
    key = (P, B, hw, stack)
    if key not in _LEAF_CACHE:
        nmax = pm.max_sigs_per_proof(P, B)
        pts = [n for n, *_ in pm.cliffs(P, B, n_max=nmax) if n >= 64] + [nmax]
        _LEAF_CACHE[key] = max(pts, key=lambda n: n / prove_time_s(n, P, B, 0, hw, stack))
    return _LEAF_CACHE[key]


def c2_builder(n, P, B, hw="epyc9355p", stack="none", *, budget_s=4.0, mode="batch", leaf=None):
    """Machines (and cores) a builder needs to prove n raw signatures for one block [Mo].

    mode="batch": all proving after tx selection, within budget_s: m machines prove leaves in
      parallel (each ceil(n/m) sigs, split in leaves of <= `leaf`), then a merge tree of fan-in
      <= 16, one level per round, the last on one machine.
    mode="stream": proving runs through the 12 s slot as txs arrive (leaves pipelined), only the
      final merge tree waits: machines = n x per-leaf time / (12 s - tree), tree within budget_s."""
    if n <= 0:
        return {"machines": 0, "cores": 0, "time_s": 0.0}
    leaf = leaf or best_leaf(P, B, hw, stack)
    t_leaf_full = prove_time_s(leaf, P, B, 0, hw, stack)

    def tree_time(m_leaves):
        t, level, claims = 0.0, m_leaves, n / max(m_leaves, 1)
        while level > 1:
            fan = min(16, level)
            t += prove_time_s(0, P, B, fan, hw, stack, child_claims=int(min(claims, 65535 // 16)))
            claims *= fan
            level = math.ceil(level / 16)
        return t

    if mode == "stream":
        leaves = math.ceil(n / leaf)
        tt = tree_time(leaves)
        m = math.ceil(leaves * t_leaf_full / max(SLOT_S - tt, 1e-9))
        return {"machines": m, "cores": m * CORES[hw], "time_s": tt, "leaves": leaves,
                "cpu_s": leaves * t_leaf_full, "fits": tt <= budget_s}
    for m in range(1, 4097):
        per = math.ceil(n / m)
        nl = math.ceil(per / leaf)
        t_leaves = (nl - 1) * t_leaf_full + prove_time_s(per - (nl - 1) * leaf, P, B, 0, hw, stack)
        T = t_leaves + tree_time(m * nl)
        if T <= budget_s:
            return {"machines": m, "cores": m * CORES[hw], "time_s": T, "leaves": m * nl,
                    "cpu_s": m * t_leaves, "fits": True}
    return {"machines": math.inf, "cores": math.inf, "time_s": math.inf, "fits": False}


def c2_mempool_bytes_per_sig(B, k=1, deg=None, net="base", tx_bytes=am.S2_TX_OVERHEAD):
    """Bytes one node uploads per signature in C2's raw gossip (announce-fetch: one body per node
    on average, an announcement per peer) plus the block's share (triples only, not signatures)
    [Mo]. B enters one for one: the signature travels to every node, not to calldata."""
    n = am.PROFILES[net]
    d = deg or n.d1
    body = (k * B + tx_bytes + am.TRIPLE * k) / k
    return body + d * n.ann / k + n.D_blk * (tx_bytes + am.TRIPLE * k) / k


def c2_bandwidth_bound(B, k=1, net="base", proof_bytes=None):
    """sig/s a node uplink (S1 budget C1 of the profile) carries in C2 [Mo]."""
    n = am.PROFILES[net]
    proof = proof_bytes or pm.proof_bytes(0, None, None, 2)
    standing = n.D_blk * (proof + am.HEADER_BYTES) / SLOT_S
    return max(0.0, n.C1 - standing) / c2_mempool_bytes_per_sig(B, k, net=net)


# --------------------------------------------------------------------------------------------
# 6. D/E: EIP-8288 full. Regime = min(gas, prover, bandwidth)
# --------------------------------------------------------------------------------------------
def de_prover_bound(P, B, hw="eip7870", n_agg=1, stack="none", dup=1.0, budget_s=1.0):
    """Network raw-proving bound: each signature is proved raw once at its entry aggregator
    (EIP-8288's literal flow: mode-0 to the entry node, mode-1 onward [E eip-8288.md:263,277]),
    so n_agg aggregators carry n_agg x capacity / dup. dup > 1 models repeated proving (phase-1
    sim: 24-47 % of proving repeated, dup 1.3-1.9) [Mo]. Merges are per child, not per signature."""
    return n_agg * node_capacity_s(P, B, hw, stack, budget_s) / dup


def de_bandwidth_bound(B, P, deps=1, net="base"):
    """Phase-1 analytic mempool bound (analytic_model.s2_bounds 'bandwidth'), tx/s x deps; it does
    not depend on P, and on B only through mode-0 first hops (D_raw2 = 0 in the literal flow)."""
    bounds, _ = am.s2_bounds(B, P, am.PROFILES[net], deps)
    for b in bounds:
        if b.name == "bandwidth":
            return b.value * deps
    return math.inf


def de_regime(P, B, G=60e6, deps=1, dep_gas=33_000, hw="eip7870", n_agg=1, net="base", stack="none", dup=1.0):
    g = gas_bound(G, deps, dep_gas)
    p = de_prover_bound(P, B, hw, n_agg, stack, dup)
    w = de_bandwidth_bound(B, P, deps, net) if net else math.inf
    tps = min(g, p, w)
    binding = "gas" if tps == g else "prover" if tps == p else "bandwidth"
    return {"tps_sig": tps, "binding": binding, "gas": g, "prover": p, "bandwidth": w}


def breakeven_gas(P, B, deps=1, dep_gas=33_000, hw="eip7870", n_agg=1, stack="none", dup=1.0):
    """Gas limit above which the raw-proving bound binds before gas (P starts to move TPS),
    ignoring bandwidth: G* = prover bound x slot x tx gas / deps."""
    p = de_prover_bound(P, B, hw, n_agg, stack, dup)
    return p * SLOT_S * dep_tx_gas(deps, dep_gas) / deps


def breakeven_P(B, G=60e6, deps=1, dep_gas=33_000, hw="eip7870", n_agg=1, stack="none", dup=1.0, P_hi=8000):
    """Smallest P at which the prover bound falls to the gas bound (P binds above it)."""
    g = gas_bound(G, deps, dep_gas)
    if de_prover_bound(P_hi, B, hw, n_agg, stack, dup) >= g:
        return math.inf
    lo, hi = 50, P_hi
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if de_prover_bound(mid, B, hw, n_agg, stack, dup) >= g:
            lo = mid
        else:
            hi = mid
    return hi


# --------------------------------------------------------------------------------------------
# 7. F: leanPCS at 4905424d (refs/leanPCS). Measured by its authors [R README.md:84-102,
#    docs/leanvm/univariate/KECCAK.md:55-67, 185-240] on leanXMSS (138.3 Keccak-f a signature):
#    gas 43,819 tx at 128 sigs, 44,593 at 400 (no 21 k base, EIP-7623, MULFIELD 10 gas); 57,883 /
#    58,669 with the frame (193 B = 1 + 6 x 32) and the claims' 11,000 intrinsic (PCS_TX 5,000 +
#    6 x PCS_CLAIM 1,000); calldata 1,005 B; pi1 capacity 2^16 Keccak-f (q_flock 2^11 words a
#    permutation, WHIR 2^28); pi1 M4 0.76 / 1.99 / 4.69 s at 32 / 128 / 400 sigs (4,440 / 17,712 /
#    55,316 perms); h1 (Ryzen 7 PRO 8700GE 8C/16T = our eip7870 proxy) 2.8-3.4 / 7.1-8.4 s at 128 /
#    400; EPYC 9355P pipeline trace->pi1->pi2 0.59 s at 128 (pi1 0.34, pi2 0.195 + 0.051); pi2 M4
#    4.4 + 1.7 s at 128, 3.0 + 0.9 s at 400, 9.8 GB peak (pi1 6.7 GB at 128, 2.3 GB at 32, 14.4 at 400).
# --------------------------------------------------------------------------------------------
F = {
    "tx_gas_128": 57_883, "tx_gas_400": 58_669, "intrinsic": 21_000, "calldata": 1_005, "frame_bytes": 193,
    "claims": 6, "pi1_cap_perms": 1 << 16, "claim_perms_per_sig": 10,        # [Mo] claim framing hashes
    "pi2_peak_gb": 9.8, "pi1_peak_gb_128": 6.7, "pi1_peak_gb_32": 2.3,
}
# pi1 seconds as a function of permutations, per machine [Mo fit on R]: piecewise linear through the
# measured points; below 4,440 perms the 32->128 slope is extrapolated to a floor (0.40 s on M4).
_M4_PTS = ((0, 0.35), (4440, 0.76), (17712, 1.99), (55316, 4.69))   # 0-perm floor extrapolated [Mo]
PI1 = {   # (perms, seconds) anchors, linear between and beyond the last two [Mo fit on R]
    "m4": _M4_PTS,
    # h1 = Ryzen 7 PRO 8700GE: measured 3.1 s (128) and 7.75 s (400) mid-range; below, M4 x 3.1/1.99
    "eip7870": tuple((x, y * 3.1 / 1.99) for x, y in _M4_PTS[:2]) + ((17712, 3.1), (55316, 7.75)),
    # EPYC 9355P: measured 0.34 s at 128 (pi1 with openings); elsewhere M4 x 0.34/1.99
    "epyc9355p": tuple((x, y * 0.34 / 1.99) for x, y in _M4_PTS),
}
# pi2 seconds (verifies pi1; ~independent of k): EPYC 0.246 s [R]; M4 3.9 s at 400 (older pi2v1
# shape, 6.1 s at 128) [R]; eip7870 scaled from the M4 by the pi1 ratio 3.1 / 1.99 [Mo].
PI2 = {"epyc9355p": 0.246, "m4": 3.9, "eip7870": 3.9 * 3.1 / 1.99}
# Phones and laptops [Mo, no measurement exists]: a laptop = M4 Max (the measured Mac); a 16 GB
# laptop the same speed class with the memory flag; a flagship phone = M4 x 4 (6 cores, 2 big;
# memory bandwidth ~1/8 of an M4 Max) [Rc], with an app memory limit of ~4-6 GB [Rc].
PHONE_SLOWDOWN = 4.0
DEVICE_RAM_GB = {"phone": 5.0, "laptop16": 16.0, "m4": 48.0, "eip7870": 64.0, "epyc9355p": 192.0}


def _pi1(perms, hw):
    if hw == "phone":
        return PHONE_SLOWDOWN * _pi1(perms, "m4")
    pts = PI1["m4" if hw == "laptop16" else hw]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if perms <= x1:
            break
    return y0 + (y1 - y0) * (perms - x0) / (x1 - x0)


def _pi2(hw):
    if hw == "phone":
        return PHONE_SLOWDOWN * PI2["m4"]
    return PI2["m4" if hw == "laptop16" else hw]


def _wrap(hw):
    """Mode-1 wrapper: the host folds pi2's 6 openings into one leanVM STARK (PCS claims travel
    only in mode-1 wrappers [E draft:77]); one WHIR opening ~0.56 of a 16-claim child [Mo, PM]."""
    if hw == "phone":
        return PHONE_SLOWDOWN * _wrap("m4")
    hh = {"laptop16": "m4"}.get(hw, hw)
    h = pm.HWS[hh]
    f0 = h.f0 if isinstance(h, pm.HW) else pm.HWS["m4"].f0 * h.s_merge
    return f0 + F["claims"] * pm.S3["opening_child_share"] * pm._t_child(hh, claims=16, mu=26)


def f_bundle_cap(P):
    return F["pi1_cap_perms"] // (P + F["claim_perms_per_sig"])


def f_tx_gas(k, pricing="7976", claim_bytes_per_sig=64, user_op_bytes=0):
    """Gas of one leanPCS-verified tx proving k signatures [Mo on R]: measured 57,883 (k = 128) and
    58,669 (k = 400) without the 21 k base, log-interpolated (+471 gas a doubling of k), plus the
    21 k base, plus k x claim_bytes_per_sig of (pk, msg) binding calldata, re-floored. The measured
    line is EIP-7623 (standard 16/byte, all calldata nonzero); under EIP-7976 the 64-gas floor on
    all calldata can bind once k x 64 B grows [E eip-7976]."""
    slope = (F["tx_gas_400"] - F["tx_gas_128"]) / math.log2(400 / 128)
    base = F["tx_gas_128"] + slope * math.log2(max(k, 1) / 128)
    extra = k * claim_bytes_per_sig + user_op_bytes
    onchain = F["calldata"] + F["frame_bytes"] + extra
    standard = base + 16 * extra
    floor = {"7623": 40, "7976": 64}[pricing] * onchain
    return F["intrinsic"] + max(standard, floor)


def f_costs(kind, P, B, hw="epyc9355p", k=None, pricing="7976", G=60e6, claim_bytes_per_sig=64, user_tx_bytes=200):
    """F1 (the user's host wraps its own signature), F2 (the first hop wraps one raw signature),
    F3 (a bundler proves k signatures; default the full bundle). Returns gas per tx and per
    signature, the gas-bound sig/s at G, wrapper bytes on the first hop and afterwards, prover
    seconds and peak memory on hw, bundle capacity and the bytes B costs (only before the wrap)."""
    cap = f_bundle_cap(P)
    if kind in ("F1", "F2"):
        k = 1
    k = cap if k is None else min(k, cap)
    perms = k * (P + F["claim_perms_per_sig"])
    gas = f_tx_gas(k, pricing, claim_bytes_per_sig)
    t1, t2, tw = _pi1(perms, hw), _pi2(hw), _wrap(hw)
    T = t1 + t2 + tw
    mode1 = pm.proof_bytes(0, None, None, 2, child_claims=16) + F["calldata"] + F["frame_bytes"] + k * user_tx_bytes
    pre_wrap = {"F1": 0, "F2": B + user_tx_bytes, "F3": k * (B + user_tx_bytes)}[kind]
    peak = max(F["pi2_peak_gb"], F["pi1_peak_gb_32"] + (F["pi1_peak_gb_128"] - F["pi1_peak_gb_32"]) * min(perms, 17712) / 17712
               if perms <= 17712 else 6.7 + (14.4 - 6.7) * (perms - 17712) / (55316 - 17712))
    ram = DEVICE_RAM_GB.get(hw, 64.0)
    return {
        "kind": kind, "P": P, "B": B, "k": k, "bundle_cap": cap, "perms": perms,
        "tx_gas": gas, "gas_per_sig": gas / k, "gas_bound_sig_s": G / SLOT_S / gas * k,
        "prove_s": T, "pi1_s": t1, "pi2_s": t2, "wrap_s": tw, "sig_per_s_per_machine": k / T,
        "peak_gb": peak, "fits_ram": peak <= ram,
        "bytes_before_wrap": pre_wrap, "bytes_before_wrap_per_sig": pre_wrap / k,
        "wrapper_bytes_after": mode1, "wrapper_bytes_after_per_sig": mode1 / k,
        "mempool_merge_s": pm._t_child("eip7870", claims=F["claims"], mu=24),
    }


def pcs_model(sig_bytes, perms_per_sig, k, *, hw="epyc9355p", pricing="7976", claim_bytes_per_sig=64, **_):
    """Plug-in `pcs_model(sig_bytes, perms_per_sig, k) -> dict` (PCS_KEYS) for the rewritten
    leanPCS (4905424d): 6 declared claims, PIOP calldata 1,005 B + frame 193 B, mode-1 wrapper
    with one client STARK, mempool work one 6-claim child per tx [Mo on R]."""
    f = f_costs("F3", perms_per_sig, sig_bytes, hw, k, pricing, claim_bytes_per_sig=claim_bytes_per_sig)
    return {
        "claims_per_tx": F["claims"], "header_bytes": 0,
        "opening_bytes": int(f["wrapper_bytes_after"] - F["calldata"] - F["frame_bytes"] - f["k"] * 200),
        "calldata_bytes": F["calldata"] + F["frame_bytes"] + claim_bytes_per_sig * f["k"],
        "prove_ms": 1e3 * pm._t_child("m4", claims=F["claims"], mu=24),
        "verify_ms": 1e3 * pm.verify_time("m4"), "gas": int(math.ceil(f["tx_gas"])),
        "user_prove_ms": 1e3 * f["prove_s"], "bundle_cap": f["bundle_cap"],
    }


# --------------------------------------------------------------------------------------------
# 8. Self-checks
# --------------------------------------------------------------------------------------------
def check():
    out = []
    # (a) stack "none" reproduces prover_model exactly
    for n, P, B, c, hw in ((500, 515, 7740, 0, "m4"), (480, 283, 4308, 1, "eip7870"), (0, 415, 5980, 16, "box16"),
                           (119, 515, 7740, 1, "epyc9355p")):
        a = prove_time_s(n, P, B, c, hw)
        b = pm.prove_time(n, P, B, c, hw)
        assert abs(a - b) < 1e-9, (n, P, c, hw, a, b)
    out.append("stack=none == prover_model.prove_time on 4 shapes: ok")
    assert node_capacity_s(515, 7740, "m4") == pm.node_capacity(515, 7740, "m4", smooth=True)
    out.append(f"node_capacity_s(515, 7740, m4) = {node_capacity_s(515, 7740, 'm4')} == prover_model: ok")
    # (b) README anchor: 500 sigs on M4 1.06 s [R]
    t = prove_time_s(500, 515, 7740, 0, "m4")
    assert abs(t - 1.06) / 1.06 < 0.03, t
    out.append(f"M4 S500 = {t:.3f} s (README 1.06 s, +/-3 %): ok")
    # (c) gas: EIP-8288 phase-1 points 64,781 / 608,741 [Mo chain.md]
    assert dep_tx_gas(1) == 64_781 and dep_tx_gas(16) == 608_741
    out.append("dep_tx_gas(1/16) = 64,781 / 608,741 (phase-1 chain.md): ok")
    # (d) stacks only ever reduce time; the 'all' stack within the sum of claims
    for P in (283, 515, 1000):
        t0, t1, t2 = (prove_time_s(480, P, 7740, 1, "m4", s, smooth=True) for s in ("none", "prover_only", "all"))
        assert t2 <= t1 <= t0, (P, t0, t1, t2)
    out.append("stack times monotone none >= prover_only >= all at P 283/515/1000: ok")
    # (e) #718 memory: three-bit rounding never below the true count, never above 1.25x
    for x in (65537, 100000, 1 << 20, 3_000_001, 7_777_777):
        r = _three_bits(x)
        assert x <= r <= 1.25 * x + 1 and bin(r).count("1") <= 3, (x, r)
    out.append("_three_bits: >= x, <= 1.25 x, <= 3 set bits: ok")
    # (f) leanPCS anchors: measured gas reproduced at k = 128 / 400 (7623, no claim bytes)
    g128 = f_tx_gas(128, "7623", 0) - F["intrinsic"]
    g400 = f_tx_gas(400, "7623", 0) - F["intrinsic"]
    assert abs(g128 - 57_883) < 1 and abs(g400 - 58_669) < 1, (g128, g400)
    out.append("f_tx_gas reproduces leanPCS 57,883 (k 128) and 58,669 (k 400): ok")
    assert abs(_pi1(17712, "m4") - 1.99) < 1e-9 and abs(_pi1(55316, "m4") - 4.69) < 1e-9 and abs(_pi1(4440, "m4") - 0.76) < 1e-9
    assert abs(_pi1(17712, "epyc9355p") - 0.34) < 1e-9 and abs(_pi1(55316, "eip7870") - 7.75) < 1e-9
    out.append("pi1 passes the measured M4 32/128/400, EPYC 128 and h1 400 points: ok")
    assert f_bundle_cap(128) * 138 <= 1 << 16 and f_bundle_cap(515) == 124 and f_bundle_cap(283) == 223
    out.append("bundle cap 2^16/(P+10): 124 at B0, 223 at P99a (phase-1 S3): ok")
    # (g) plug-in shapes
    cc = circuit_cost(515, 16, sig_bytes=7740)
    ref = pm.circuit_cost_kwargs(515, 7740, "m4")
    sph = cc["sphincs_hashes"] if isinstance(cc, dict) else cc.sphincs_hashes
    assert abs(sph - 16 * ref["sphincs_hashes"]) < 1e-6
    d = pcs_model(7740, 515, 124)
    assert set(("claims_per_tx", "header_bytes", "opening_bytes", "calldata_bytes", "prove_ms", "verify_ms", "gas")) <= set(d)
    assert agg_gas_per_tx(7740, 515, 1) == 64_781 and agg_gas_per_tx(7740, 515, 1, dep_gas=3000) == 34_781
    out.append("plug-ins: circuit_cost == prover_model.sim_circuit_cost; pcs_model has PCS_KEYS; agg_gas_per_tx: ok")
    return out


# --------------------------------------------------------------------------------------------
# 9. Tables and the CSV (PHASE2 s4 columns; network columns NA)
# --------------------------------------------------------------------------------------------
COLUMNS = ("scenario, variant, pricing, gas_limit, profile, uplinks, nodes, candidate, B, P, k, tps_tx, "
           "tps_sig, tps_timely, binding, eps_B, eps_P, dB10, dB25, dB50, dB100, dP10, dP25, dP50, dP100, "
           "block_bytes, t90_block_s, bw_node_mbit, dup_share, wasted_share, degradation, status, source").split(", ")
NA = "NA"


def _deltas(f, x):
    base = f(x)
    out = {}
    for pct in (10, 25, 50, 100):
        v = f(x * (1 + pct / 100))
        out[pct] = 100 * (v / base - 1) if base else float("nan")
    e = _elast(lambda y: max(f(y), 1e-12), x)
    return e, out


def _row(scen, variant, pricing, G, cand, B, P, k, tps_sig, binding, fB, fP, block_bytes, source):
    eB, dB = _deltas(fB, B)
    eP, dP = _deltas(fP, P)
    r = dict.fromkeys(COLUMNS, NA)
    r.update(scenario=scen, variant=variant, pricing=pricing, gas_limit=int(G), candidate=cand, B=B, P=P, k=k,
             tps_tx=f"{tps_sig / k:.2f}", tps_sig=f"{tps_sig:.2f}", binding=binding,
             eps_B=f"{eB:.3f}", eps_P=f"{eP:.3f}", block_bytes=block_bytes, status="[Mo]", source=source)
    for p in (10, 25, 50, 100):
        r[f"dB{p}"] = f"{dB[p]:.2f}"
        r[f"dP{p}"] = f"{dP[p]:.2f}"
    return r


def build_rows():
    rows = []
    src = "data/phase2/models_agg.py"
    for cand, (B, P) in CANDIDATES.items():
        for G in GAS_LIMITS:
            # D/E: gas vs prover (n_agg aggregators of class hw); bandwidth NA (network columns)
            for dep_name, dep_gas in DEP_GAS.items():
                for deps in (1, 16):
                    for hw, n_agg in (("eip7870", 1), ("eip7870", 4), ("epyc9355p", 1)):
                        def tps(p, b, _hw=hw, _n=n_agg):
                            return min(gas_bound(G, deps, dep_gas), de_prover_bound(p, b, _hw, _n))
                        t = tps(P, B)
                        binding = "gas" if t == gas_bound(G, deps, dep_gas) else "prover"
                        blk = int(G / dep_tx_gas(deps, dep_gas) * (am.S2_TX_OVERHEAD + am.TRIPLE * deps) + pm.proof_bytes(0, None, None, 2))
                        rows.append(_row("D/E", f"dep{dep_name}_deps{deps}_{hw}x{n_agg}", "7976", G, cand, B, P, deps, t,
                                         binding, lambda b: tps(P, b), lambda p: tps(p, B), blk, src + ":de_regime (no bandwidth)"))
            # C2: gas vs builder (streaming, 4 EPYC) vs raw-gossip bandwidth (base profile, analytic)
            for dep_name, dep_gas in DEP_GAS.items():
                for deps in (1, 16):
                    for machines in (1, 4):
                        def tps_c2(p, b, _m=machines):
                            lf = best_leaf(int(round(p)), int(round(b)))
                            cap = _m / (prove_time_s(lf, p, b, 0, "epyc9355p") / lf)
                            return min(gas_bound(G, deps, dep_gas), cap, c2_bandwidth_bound(b, deps, "base"))
                        t = tps_c2(P, B)
                        cands = {"gas": gas_bound(G, deps, dep_gas), "bandwidth(base, analytic)": c2_bandwidth_bound(B, deps, "base")}
                        binding = min(cands, key=cands.get) if min(cands.values()) <= t + 1e-9 else "prover(builder)"
                        blk = int(G / dep_tx_gas(deps, dep_gas) * (am.S2_TX_OVERHEAD + am.TRIPLE * deps) + pm.proof_bytes(0, None, None, 2))
                        r = _row("C2", f"dep{dep_name}_deps{deps}_builder{machines}xepyc_stream", "7976", G, cand, B, P, deps, t,
                                 binding, lambda b: tps_c2(P, b), lambda p: tps_c2(p, B), blk, src + ":c2_builder/c2_bandwidth_bound")
                        r["profile"] = "base(analytic C1, not simulated)"
                        rows.append(r)
            # F: gas-bound sig/s (bundlers scale out; bundler machines needed reported in notes)
            for kind in ("F1", "F2", "F3"):
                for pricing in ("7623", "7976"):
                    def tps_f(p, b, _kind=kind, _pr=pricing):
                        return f_costs(_kind, int(round(p)), b, "epyc9355p", None, _pr, G)["gas_bound_sig_s"]
                    t = tps_f(P, B)
                    f = f_costs(kind, P, B, "epyc9355p", None, pricing, G)
                    blk = int(G / f["tx_gas"] * (F["calldata"] + F["frame_bytes"] + 64 * f["k"] + 200 * f["k"]) + pm.proof_bytes(0, None, None, 2))
                    rows.append(_row(kind, f"leanPCS_4905424d_k{f['k']}", pricing, G, cand, B, P, f["k"], t, "gas",
                                     lambda b: tps_f(P, b), lambda p: tps_f(p, B), blk, src + ":f_costs"))
    return rows


def write_csv(path=os.path.join(HERE, "agg_analytic.csv")):
    rows = build_rows()
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(rows)
    return path, len(rows)


def tables():
    pr = print
    pr("== 1. PR stack: node capacity (sig/s, 1 s interval, c = 1, smooth) and elasticity to P")
    pr(f"{'hw':13s} {'P':>5s} | {'none':>16s} | {'prover_only':>16s} | {'all':>16s}   (cap, eP, keccak share)")
    for hw in ("m4", "eip7870", "epyc9355p"):
        for P in (283, 415, 515, 1000):
            cells = []
            for s in ("none", "prover_only", "all"):
                e = prover_elasticity(P, 7740 if P == 515 else 4308 if P == 283 else 5980, hw, s)
                cells.append(f"{e['cap']:5d} {e['eP']:+.2f} {e['keccak_share_of_t_sig']:.2f}")
            pr(f"{hw:13s} {P:5d} | " + " | ".join(cells))
    pr("\n   per-signature marginal ms (M4): " + ", ".join(
        f"P{P}: {1e3 * per_sig_time_s(P, 7740, 'm4'):.2f} -> {1e3 * per_sig_time_s(P, 7740, 'm4', 'all'):.2f}" for P in (283, 515, 1000)))
    pr("\n   memory cliff 485 -> 486 at P 515, staircase M4 (s): none "
       f"{prove_time_s(485, 515, 7740, 0, 'm4'):.3f} -> {prove_time_s(486, 515, 7740, 0, 'm4'):.3f}; all "
       f"{prove_time_s(485, 515, 7740, 0, 'm4', 'all'):.3f} -> {prove_time_s(486, 515, 7740, 0, 'm4', 'all'):.3f}")

    pr("\n== 2. Gas-bound sig/s: deps/tx x dep gas x gas limit")
    for dep_name, dg in DEP_GAS.items():
        for deps in (1, 16):
            pr(f"  {dep_name:8s} deps {deps:2d} tx gas {dep_tx_gas(deps, dg):>8,}: " +
               "  ".join(f"{int(G / 1e6)}M {gas_bound(G, deps, dg):7.1f}" for G in GAS_LIMITS))
    for deps in (1, 16):
        kw = dict(calldata_per_dep=1024, dep_bytes=64)
        pr(f"  pcsfmt   deps {deps:2d} tx gas {dep_tx_gas(deps, 3000, **kw):>8,}: " +
           "  ".join(f"{int(G / 1e6)}M {gas_bound(G, deps, 3000, **kw):7.1f}" for G in GAS_LIMITS)
           + "   (3,000 + the draft's 64-byte payload)")

    pr("\n== 3. Per-aggregator capacity sig/s vs P (stack none / all), B = 7,740")
    pr("  hw            " + " ".join(f"{P:>11d}" for P in (150, 200, 283, 350, 415, 515, 750, 1000)))
    for hw in HW_CLASSES:
        pr(f"  {hw:13s} " + " ".join(f"{node_capacity_s(P, 7740, hw):5d}/{node_capacity_s(P, 7740, hw, 'all'):5d}"
                                     for P in (150, 200, 283, 350, 415, 515, 750, 1000)))

    pr("\n== 4. Break-even: P at which ONE aggregator binds before gas (B = 7,740)")
    for dep_name, dg in DEP_GAS.items():
        for deps in (1, 16):
            for G in GAS_LIMITS:
                cells = []
                for hw in ("eip7870_full", "eip7870", "epyc9355p"):
                    bp = breakeven_P(7740, G, deps, dg, hw)
                    n_need = math.ceil(gas_bound(G, deps, dg) / max(node_capacity_s(515, 7740, hw), 1))
                    lab = '>8000' if bp == math.inf else 'always' if bp <= 51 else bp
                    cells.append(f"{hw}:{lab} (B0 needs {n_need})")
                pr(f"  {dep_name:8s} deps {deps:2d} {int(G / 1e6):3d}M: " + "  ".join(cells))
    pr("  break-even gas limit (M gas) for ONE eip7870 aggregator, deps 16: " + ", ".join(
        f"{c}: 8288 {breakeven_gas(P, B, 16, 33000) / 1e6:.0f} / pcsdraft {breakeven_gas(P, B, 16, 3000) / 1e6:.0f}"
        for c, (B, P) in CANDIDATES.items()))

    pr("\n== 5. D/E regime (base profile bandwidth from phase-1 analytic), 1 eip7870 aggregator")
    for dep_name, dg in DEP_GAS.items():
        for deps in (1, 16):
            for G in (60e6, 300e6):
                for net in ("opt", "base"):
                    r = {c: de_regime(P, B, G, deps, dg, "eip7870", 1, net) for c, (B, P) in CANDIDATES.items()}
                    pr(f"  {dep_name:8s} deps {deps:2d} {int(G / 1e6):3d}M {net:4s}: " + "  ".join(
                        f"{c} {v['tps_sig']:.0f} ({v['binding']}; g {v['gas']:.0f} p {v['prover']:.0f} w {v['bandwidth']:.0f})" for c, v in r.items()))

    pr("\n== 6. Costs P always moves (eip7870 aggregator; demand = gas bound 60M, 3k, 16 deps)")
    dem = gas_bound(60e6, 16, 3000)
    for c, (B, P) in CANDIDATES.items():
        for hw in ("eip7870", "epyc9355p"):
            a = always_costs(P, B, hw, demand_sig_s=dem)
            b = always_costs(P, B, hw, "all", demand_sig_s=dem)
            pr(f"  {c:5s} {hw:10s} t_sig {a['t_sig_ms']:.2f} ms ({b['t_sig_ms']:.2f} all) cpu-s/sig {a['cpu_s_per_sig']:.4f} "
               f"J/sig {a['joule_per_sig']:.3f} aggregators {a['aggregators']} ({b['aggregators']} all) "
               f"proof latency at 100 sig/s/node {a['latency_s_at_load']:.2f} s ({b['latency_s_at_load']:.2f} all)")

    pr("\n== 7. C2 builder: machines/cores to prove a full block (dep gas, deps 16)")
    for dep_name, dg in DEP_GAS.items():
        for G in (60e6, 300e6):
            n = int(G / dep_tx_gas(16, dg) * 16)
            for c, (B, P) in CANDIDATES.items():
                cells = []
                for hw in ("eip7870", "epyc9355p"):
                    s = c2_builder(n, P, B, hw, mode="stream")
                    bt = c2_builder(n, P, B, hw, mode="batch", budget_s=4.0)
                    cells.append(f"{hw}: stream {s['machines']}x ({s['cores']} cores) batch4s {bt['machines']}x ({bt['cores']})")
                pr(f"  {dep_name:8s} {int(G / 1e6):3d}M n={n:5d} {c:5s} " + " | ".join(cells))
    pr("  C2 mempool bytes/sig (base, k=1): " + ", ".join(f"{c} {c2_mempool_bytes_per_sig(B):.0f}" for c, (B, P) in CANDIDATES.items())
       + "; bandwidth bound sig/s base/opt: " + ", ".join(f"{c} {c2_bandwidth_bound(B, 1, 'base'):.0f}/{c2_bandwidth_bound(B, 1, 'opt'):.0f}" for c, (B, P) in CANDIDATES.items()))

    pr("\n== 8. F (leanPCS 4905424d)")
    for c, (B, P) in CANDIDATES.items():
        for kind in ("F1", "F2", "F3"):
            for hw in (("phone", "m4", "epyc9355p") if kind == "F1" else ("epyc9355p", "eip7870")):
                f = f_costs(kind, P, B, hw)
                pr(f"  {c:5s} {kind} {hw:10s} k {f['k']:3d} gas/tx {f['tx_gas']:8,.0f} gas/sig {f['gas_per_sig']:8,.0f} "
                   f"60M {f['gas_bound_sig_s']:6.1f} sig/s | prove {f['prove_s']:.2f} s (pi1 {f['pi1_s']:.2f}, pi2 {f['pi2_s']:.2f}, wrap {f['wrap_s']:.2f}) "
                   f"{f['sig_per_s_per_machine']:.1f} sig/s/machine peak {f['peak_gb']:.1f} GB fits {f['fits_ram']} | "
                   f"pre-wrap {f['bytes_before_wrap_per_sig']:.0f} B/sig, mode-1 {f['wrapper_bytes_after'] / 1024:.0f} KiB ({f['wrapper_bytes_after_per_sig']:.0f} B/sig)")
    pr("  F3 bundle cap vs P: " + ", ".join(f"P{P}:{f_bundle_cap(P)}" for P in (150, 200, 283, 350, 415, 515, 750, 1000)))
    pr("  F3 gas/sig vs P (7976 / 7623): " + ", ".join(
        f"P{P}: {f_costs('F3', P, 7740)['gas_per_sig']:.0f}/{f_costs('F3', P, 7740, pricing='7623')['gas_per_sig']:.0f}" for P in (150, 283, 515, 1000)))
    pr("  F3 gas/sig with no per-sig claim bytes (7976): " + ", ".join(
        f"P{P}: {f_costs('F3', P, 7740, claim_bytes_per_sig=0)['gas_per_sig']:.0f}" for P in (150, 283, 515, 1000)))


if __name__ == "__main__":
    for line in check():
        print("check:", line)
    if "--check" not in sys.argv:
        print()
        tables()
        p, n = write_csv()
        print(f"\nwrote {p} ({n} rows)")

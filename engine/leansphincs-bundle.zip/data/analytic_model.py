#!/usr/bin/env python3
"""Closed-form TPS model for leanSPHINCS: S1 NOAGG, S2 AGG8288, S3 PCS-only.  [Mo]

No simulator. Every TPS is min over resource bounds, each of the closed form

    TPS_i = N_i / (a_i + b_i * P + c_i * B)            (k = 1 unless stated)

so its elasticities are analytic:  e_P = -b_i P / den_i,  e_B = -c_i B / den_i.
The elasticity of max TPS is that of the binding bound (the min); near a switch the
finite +10 % arc elasticity is printed too.

Sources of every constant are in the comments; status tags as in BRIEF.md:
[E] spec, [R] read at a path, [C] count from a run, [M] measured on this box,
[Mo] modelled, [Rc] recalled. Inputs taken from the scout notes are cited by claim id
(notes/chain.md CHn, notes/prover-model.md PMn, notes/network.md section).

Usage (stdlib only, < 1 s):
    python3 -I analytic_model.py                 # every table of notes/analytic.md
    python3 -I analytic_model.py --check         # self-tests + cross-checks (needs the scout models
                                                 #  and data/sim/*.csv|json for the [C] comparison)
    python3 -I analytic_model.py --json FILE     # explicit predictions for the simulator sweeps
"""

import json
import math
import sys
from dataclasses import dataclass, field, replace

# ----------------------------------------------------------------------------------------------
# 0. Protocol constants
# ----------------------------------------------------------------------------------------------
SLOT_S = 12.0                     # [E] mainnet slot
GAS_LIMIT = 60_000_000            # [M] BRIEF: 59,999,943 at block 26,383,103
MAX_RLP_BLOCK = 8_388_608         # [E] EIP-7934: 10 MiB - 2 MiB
HEADER_BYTES = 600                # [Rc] block header + envelope (fork default)
T_I = 1.0                         # [E] EIP-8288 AGGREGATION_INTERVAL, s
TRIPLE = 96                       # [E] EIP-8288 dependency triple, bytes
HASH_REF = 32                     # [E] EIP-8288 tx hash reference in a wrapper, bytes
MAX_VERIFY_GAS = 100_000          # [E] EIP-8141 public-mempool validation cap (eip-8141.md:933)
PUSH_THRESHOLD = 4096             # [R] geth eth/handler.go:65 txMaxBroadcastSize
MAX_RECURSIONS = 16               # [R] leanVM rec_aggregation mod.rs:71 (children per proof)
MAX_KEYS = 1 << 16                # [R] leanVM claims per proof (exclusive)
PI1_CAP = 1 << 16                 # [Mo on R] leanPCS pi1 q_flock capacity, Keccak-f per bundle (PM12)

# S1 frame tx under EIP-7976 (Glamsterdam), k signatures, EVM verifier: CH1 reproduced on 9
# receipts (notes/chain.md section 3).
#   floor    = 18,950 + 100 k + 64 (k B + 39)
#   standard = 18,950 + 100 k + 16 k B + 192 + k V(P) + 7,900 + 2,000 (k-1) + 3,000
S1_FLOOR0 = 18_950 + 64 * 39      # + 100 k
S1_STD0 = 18_950 + 192 + 7_900 + 3_000   # + 100 k + 2,000 (k-1)
FLOOR_PER_B = 64                  # [E] EIP-7976
STD_PER_B = 16                    # [E] EIP-7623/7976 nonzero byte
S1_TX_OVERHEAD = 156              # [Mo] frame tx bytes beyond k B: 36 VERIFY data + ~120 RLP (CH11)
GAS_PER_PERM = {"lean": 150.0, "layered": 167.0}   # [M rec] CH4: EVM verify gas per permutation
FRAME_MODULE_GAS = 7_900          # [M rec] chain.md: validation prefix beyond the verifier
EVM_GAS_PER_S = 75e6              # [Mo] fork models.py from ethresearch 26224 (single core)

# S2 EIP-8288 tx (frame + dependency frame + VERIFY + SENDER): chain.md table, k deps:
# 64,781 / 101,045 / 173,573 / 608,741 for k = 1/2/4/16  ->  28,517 + 36,264 k (exact on all four).
S2_GAS0, S2_GAS_PER_DEP = 28_517, 36_264
S2_TX_OVERHEAD = 176              # [Mo] chain.md: S2 tx = 96 k + ~176 B

# S3 leanPCS per-tx (client-aggregated): chain.md CH9, 126,689 gas under 7976, B- and P-free.
S3_GAS = 126_689
S3_CLAIMS = 7                     # [R] leanPCS README @ fc482edd: 7 claims
S3_CALLDATA = 1_004               # [R] same: PIOP calldata
S3_CLAIM_HEADER = 81 + 24 * 22    # [E draft] 81 + 24 n, n = 22 at the current work (fork placeholder)

# ----------------------------------------------------------------------------------------------
# 1. Prover hardware: t_sig(P, B) = s0 + sP P + sB B  per raw signature (ms), linear fit of
#    prover_model.per_sig_time (smooth) over P in [250, 750], B in [3000, 7740]; max residual
#    0.00 % (m4) .. 1.9 % (box16). Fixed per proof f0, merge of one 500-claim child tch, of one
#    7-claim child tch7, native STARK verify tvs: prover_model.prove_time(0, ..., c, smooth=True),
#    _t_child(hw, 7), verify_time(hw).  All [Mo] (PM5, PM7); re-derive with --check.
# ----------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class HW:
    name: str
    s0: float     # ms per signature, P- and B-independent part
    sP: float     # ms per signature per permutation
    sB: float     # ms per signature per signature byte
    f0: float     # ms per proof
    tch: float    # ms per merged 500-claim child
    tch7: float   # ms per merged 7-claim child (S3 client STARK)
    tvs: float    # ms per native verification of one recursive STARK


HWS = {
    "m4":           HW("Apple M4 Max 16T",            0.1849, 4.238e-3, 1.886e-6,  59.1,  68.5,  54.2,  9.40),
    "box16":        HW("this box 16T",                0.1062, 4.194e-3, 1.712e-6,  69.7,  80.8,  64.0, 11.09),
    "eip7870":      HW("EIP-7870 attester 8C/16T",    0.2349, 7.113e-3, 3.014e-6, 110.2, 127.8, 101.2, 17.53),
    "eip7870_full": HW("EIP-7870 full node 4C/8T",    0.3825, 11.022e-3, 4.707e-6, 168.0, 194.8, 154.3, 26.74),
    "epyc9355p":    HW("EPYC 9355P 32C",              0.0580, 1.807e-3, 0.762e-6,  28.2,  32.7,  25.9,  4.49),
    # The simulator fork's default (bench/leansphincs/models.py, calibration sphincs-el-m4):
    # 2.0 ms per signature at 515 permutations, proportional to P, no B term; 60 ms per proof,
    # 63 ms per child; v2's STARK verify 9.195 ms. S3 placeholder child 63 ms + 7 x 0.005 ms.
    "sim":          HW("fork default (sphincs-el-m4)", 0.0,   2.0 / 515, 0.0,       60.0,  63.0,  63.035, 9.195),
}
NATIVE_SIG_VERIFY = (0.01, 179e-6)   # ms: 0.01 + 179 ns per permutation [M] fork models.py


# ----------------------------------------------------------------------------------------------
# 2. Network profiles. Protocol view (opt / base / pess) from data/network_params.json and
#    notes/network.md; simulator views mirror the harness knobs (sims/LEANSPHINCS-FORK.md).
# ----------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Net:
    name: str
    kind: str          # "protocol" or "sim"
    N: int             # nodes (real network for protocol profiles; simulated for sim profiles)
    L: float           # one-way latency, s
    C1: float          # S1 node uplink for the mempool and blocks, B/s (0 = unmetered)
    d1: int            # S1 mempool degree
    C2: float          # S2/S3 node uplink, B/s
    d2: int            # S2/S3 wrapper degree
    Pi: float          # recursive proof bytes on the wire (S2 wrapper, S3 client STARK)
    wait: float        # announce wait per hop, s (client fetch wait)
    ann: float         # bytes of one announcement or request (hash + metadata + overhead)
    D_blk: float       # block copies uploaded per node (duplication on the block topic)
    f_blk: float       # copies serialised ahead of the critical one on a hop (block latency)
    blk_deg: int       # degree of the block-propagation graph
    blk_exec_per_hop: bool   # does every hop execute the block before relaying it (fork: yes)
    D_raw2: float      # raw S2/S3 objects uploaded per node per tx (see note section 3.2)
    alpha: float       # aggregator share
    hw: str            # aggregator hardware
    budget: float      # proving budget per interval, s
    T_d: float         # block deadline, s (3 s of the 4 s attestation window; 4 s in the fork)
    t1: float = S1_TX_OVERHEAD    # S1 non-signature tx bytes
    t2: float = S2_TX_OVERHEAD    # S2 non-triple tx bytes
    gas_model: str = "chain"      # "chain" (notes/chain.md) or "sim" (fork defaults)
    R: float = SLOT_S / 2 + 2 * T_I   # residence of an active tx in the wrappers, s [Mo]


def _cap(mbps, background, goodput=0.95):
    return (mbps - background) * goodput * 125_000.0          # network.md section 4


PROTOCOL = {
    # Block topic = CL gossipsub mesh D = 8 [E]. D_blk (copies uploaded per node) and f_blk (t90 =
    # h90 (L + f size / C)) from the toy mesh data/tools/toy_gossip_dup.out [C on a toy, FIFO
    # uplink, N = 2000]: with IDONTWANT 2.3 copies, f = 3.2 (base); without 5.2 copies, f = 3.5
    # (pess). opt is the idealised lower bound: one copy, the critical-path copy first (1 / 1) [Mo].
    # D_raw2 = 0: EIP-8288's literal flow, users send mode-0 wrappers to their entry node only and
    # nodes forward only mode-1 wrappers (eip-8288.md:263,277) [E].
    "opt":  Net("optimistic", "protocol", 6000, 0.0561, _cap(25, 2), 50, _cap(50, 2), 8, 223_334,
                0.0, 37, 1.0, 1.0, 8, False, 0.0, 0.5, "m4", 1.0, 3.0),
    "base": Net("baseline", "protocol", 8000, 0.0641, _cap(15, 4), 32, _cap(25, 4), 8, 262_144,
                0.350, 37, 2.3, 3.2, 8, False, 0.0, 0.2, "eip7870", 1.0, 3.0),
    "pess": Net("pessimistic", "protocol", 10000, 0.0870, _cap(15, 6), 20, _cap(25, 6), 6, 366_592,
                0.950, 80, 5.2, 3.5, 8, False, 0.0, 0.05, "eip7870", 0.7, 3.0),
}


def sim_net(name, N, d1, d2, mbps1, mbps2, L, Pi, t_extra=200):
    """The fork harness (bench.leansphincs) with these flags; announce_fetch raw relay, block
    notices flooded on the overlay (each node uploads d - 1 copies FIFO), every hop verifies a block
    (S1: EVM execution), late = t90 > 4 s. D_raw2 = (d + 2) / N: a raw leaf is served only until
    folded, about one hop (derivation in the note, section 3.2). gas: fork defaults."""
    return Net(name, "sim", N, L, mbps1 * 125_000.0, d1, mbps2 * 125_000.0, d2, Pi, 0.0, HASH_REF,
               None, None, None, True, (d2 + 2) / N, 1.0, "sim", 1.0, 4.0, t1=t_extra, t2=t_extra,
               gas_model="sim")


SIM = {
    # harness defaults: 40 nodes, degree 6, 25 Mbit/s, 100 ms, proof 223,334 B, tx_bytes 200
    "sim_default": sim_net("fork harness defaults", 40, 6, 6, 25.0, 25.0, 0.100, 223_334),
    "sim_ideal": sim_net("fork, ideal network (uplink 0, latency 0)", 40, 6, 6, 0.0, 0.0, 0.0, 223_334),
    # harness at the network profiles' flags (network.md section 1): nodes 1000, degree per mempool,
    # --uplink-mbps capacity/125, --latency-ms uniform mean, proof_bytes, tx_bytes left at 200
    "sim_opt": sim_net("fork at optimistic flags", 1000, 50, 8, 21.85, 45.6, 0.0561, 223_334),
    "sim_base": sim_net("fork at baseline flags", 1000, 32, 8, 10.45, 19.95, 0.0641, 262_144),
    "sim_pess": sim_net("fork at pessimistic flags", 1000, 20, 6, 8.55, 18.05, 0.0870, 366_592),
}
PROFILES = {**PROTOCOL, **SIM}


def blk_params(net, d):
    """(degree, copies per node, critical-copy position) of block propagation."""
    if net.kind == "sim":
        return d, d - 1, d / 2.0
    return net.blk_deg, net.D_blk, net.f_blk


def hops(N, deg, frac=0.9):
    """Hops for flooding to reach frac of N nodes on a random graph of degree deg [Mo]."""
    return math.log(max(frac * N, 2.0)) / math.log(max(deg - 1, 2))


# ----------------------------------------------------------------------------------------------
# 3. Bounds
# ----------------------------------------------------------------------------------------------
@dataclass
class Bound:
    name: str
    value: float          # tx/s (math.inf if absent)
    eB: float = 0.0
    eP: float = 0.0
    form: str = ""        # the closed form with numbers
    kind: str = "throughput"   # "throughput" or "deadline" (a deadline bound binds via orphaning)


def lin(name, num, a, b, c, P, B, form="", kind="throughput"):
    """TPS = num / (a + b P + c B)."""
    den = a + b * P + c * B
    if num <= 0:
        return Bound(name, 0.0, float("nan"), float("nan"), form + "  [infeasible: numerator <= 0]", kind)
    return Bound(name, num / den, -c * B / den, -b * P / den, form, kind)


def s1_gas(B, P, k, net, impl):
    """On-chain gas bound, S1. Returns the bound and the binding path."""
    if net.gas_model == "sim":
        # fork evm_frame_gas: 21,000 + max(16 kB + k V(P), 64 kB); V(P) = -10,259 + 185.75 P
        v0, g = -10_259.0, 185.75
        std = (21_000 + k * v0, k * g, STD_PER_B * k)
        flo = (21_000, 0.0, FLOOR_PER_B * k)
    else:
        g = GAS_PER_PERM[impl]
        std = (S1_STD0 + 100 * k + 2_000 * (k - 1), k * g, STD_PER_B * k)
        flo = (S1_FLOOR0 + 100 * k, 0.0, FLOOR_PER_B * k)
    gs = std[0] + std[1] * P + std[2] * B
    gf = flo[0] + flo[1] * P + flo[2] * B
    a, b, c = flo if gf >= gs else std
    path = "floor" if gf >= gs else "standard"
    # TPS = (G / S) / gas
    return lin("gas", GAS_LIMIT / SLOT_S, a, b, c, P, B,
               f"{GAS_LIMIT/1e6:.0f}M/{SLOT_S:.0f}s / ({a:,.0f} + {b:.1f}P + {c:.0f}B)  [{path}]"), path


def p_star(B, k, net, impl):
    """P at which the standard path would bind (floor crossover)."""
    if net.gas_model == "sim":
        return (FLOOR_PER_B * k * B - STD_PER_B * k * B - k * -10_259.0) / (k * 185.75)
    g = GAS_PER_PERM[impl]
    a_s = S1_STD0 + 100 * k + 2_000 * (k - 1)
    a_f = S1_FLOOR0 + 100 * k
    return (a_f - a_s + (FLOOR_PER_B - STD_PER_B) * k * B) / (k * g)


def p_max_public(k, impl):
    """EIP-8141 rule 6: k V(P) + 7,900 + 2,000 (k-1) + 100 k <= MAX_VERIFY_GAS."""
    g = GAS_PER_PERM[impl]
    return (MAX_VERIFY_GAS - FRAME_MODULE_GAS - 2_000 * (k - 1) - 100 * k) / (k * g)


def verify_ms_evm(P, net, impl):
    """EVM time of one signature's VERIFY work, ms (V(P) / 75 Mgas/s)."""
    if net.gas_model == "sim":
        return max(0.0, -10_259.0 + 185.75 * P) / EVM_GAS_PER_S * 1e3
    return GAS_PER_PERM[impl] * P / EVM_GAS_PER_S * 1e3


def s1_bounds(B, P, net, k=1, impl="lean"):
    bounds = []
    gb, path = s1_gas(B, P, k, net, impl)
    bounds.append(gb)
    t = net.t1
    tx = k * B + t
    # block byte cap
    bounds.append(lin("bytes", (MAX_RLP_BLOCK - HEADER_BYTES) / SLOT_S, t, 0, k, P, B,
                      f"({MAX_RLP_BLOCK:,} - {HEADER_BYTES})/{SLOT_S:.0f}s / ({t:.0f} + {k}B)"))
    C, d = net.C1, net.d1
    bdeg, D_blk, f_blk = blk_params(net, d)
    # mempool + block average uplink. Body duplication from the gossip rule:
    #   tx > 4096 B: announce-fetch, each node fetches one copy -> 1 upload per node on average;
    #   tx <= 4096 B: geth pushes to ceil(sqrt(peers)) -> ceil(sqrt(d)) copies (protocol only:
    #   the fork's announce_fetch never pushes).
    push = net.kind == "protocol" and tx <= PUSH_THRESHOLD
    D_body = math.ceil(math.sqrt(d)) if push else 1.0
    ann = (d - 1) * net.ann + net.ann        # announcements to the other peers + one request
    if C > 0:
        a = D_body * t + ann + D_blk * t
        c = (D_body + D_blk) * k
        bounds.append(lin("bandwidth", C, a, 0, c, P, B,
                          f"{C:,.0f} B/s / ({D_body:g}+{D_blk:g})({k}B + {t:.0f}) + {ann:.0f})"
                          + ("  [push regime]" if push else "")))
    # block deadline. h hops of (L + f * block / C), plus the execution of n txs, once (protocol:
    # CL relays validate without executing; the attester executes) or per hop (fork).
    #   n_tx = TPS S;  block = TPS S (kB + t)
    tau = k * verify_ms_evm(P, net, impl) / 1e3     # s per tx
    if C > 0:
        h = hops(net.N, bdeg)
        if net.blk_exec_per_hop:
            num = net.T_d / h - net.L
            # den = S (f (kB+t)/C + tau(P))
            if net.gas_model == "sim":
                tv0, tvP = k * -10_259.0 / EVM_GAS_PER_S, k * 185.75 / EVM_GAS_PER_S
            else:
                tv0, tvP = 0.0, k * GAS_PER_PERM[impl] / EVM_GAS_PER_S
            a = SLOT_S * (f_blk * t / C + tv0)
            b = SLOT_S * tvP
            c = SLOT_S * f_blk * k / C
            form = f"(T_d/h - L) / (S (f(kB+t)/C + tau(P))), h={h:.2f}, f={f_blk:g}, per-hop exec"
        else:
            num = net.T_d - h * net.L
            tvP = k * GAS_PER_PERM[impl] / EVM_GAS_PER_S
            a = SLOT_S * h * f_blk * t / C
            b = SLOT_S * tvP
            c = SLOT_S * h * f_blk * k / C
            form = f"(T_d - h L) / (S (h f (kB+t)/C + tau(P))), h={h:.2f}, f={f_blk:g}, T_d={net.T_d:g}s"
        bounds.append(lin("block-deadline", num, a, b, c, P, B, form, kind="deadline"))
    # CPU: every node validates each tx once and executes it once in a block (one core)
    if tau > 0:
        if net.gas_model == "sim":
            eP_cpu = -(185.75 * P) / (-10_259.0 + 185.75 * P)
        else:
            eP_cpu = -1.0
        bounds.append(Bound("cpu", 1.0 / (2 * tau), 0.0, eP_cpu, "1 / (2 k V(P) / 75 Mgas/s)"))
    # public-mempool admission (EIP-8141 rule 6): a cliff in P, not a smooth bound
    pmax = p_max_public(k, impl)
    adm = Bound("admission", math.inf if P <= pmax else 0.0, 0.0, 0.0,
                f"P <= P_max = {pmax:.0f} ({impl}, k={k}); validation {k*GAS_PER_PERM[impl]*P + FRAME_MODULE_GAS + 100*k:,.0f} gas",
                kind="cliff" if net.kind == "protocol" else "info")
    bounds.append(adm)
    extra = {"gas_path": path, "P_star": p_star(B, k, net, impl), "P_max": pmax, "push": push,
             "tx_bytes": tx, "D_body": D_body, "D_blk": D_blk}
    return bounds, extra


def s2_bounds(B, P, net, k=1, n_aggregators=None):
    bounds = []
    if net.gas_model == "sim":
        gas = 21_000 + max(STD_PER_B * TRIPLE * k + 33_000 * k, FLOOR_PER_B * TRIPLE * k)
    else:
        gas = S2_GAS0 + S2_GAS_PER_DEP * k
    bounds.append(Bound("gas", GAS_LIMIT / SLOT_S / gas, 0.0, 0.0, f"{GAS_LIMIT/1e6:.0f}M/{SLOT_S:.0f}s / {gas:,}"))
    t = net.t2 + TRIPLE * k
    Pi = net.Pi
    bounds.append(Bound("bytes", (MAX_RLP_BLOCK - HEADER_BYTES - Pi) / SLOT_S / t, 0.0, 0.0,
                        f"(8 MiB - header - proof)/S / {t:.0f}"))
    hw = HWS[net.hw]
    d = net.d2
    v0, vP = NATIVE_SIG_VERIFY
    # single-node prover: budget - proof fixed - own previous aggregate - verifying d wrappers,
    # over k (t_sig(P, B) + native verify). The fork's ideal network shows this bound (SIM3:
    # identical aggregators all prove every signature).
    num = net.budget * 1e3 - hw.f0 - hw.tch - d * hw.tvs
    a = k * (hw.s0 + v0)
    b = k * (hw.sP + vP)
    c = k * hw.sB
    single = lin("prover", num, a, b, c, P, B,
                 f"({net.budget*1e3:.0f} - {hw.f0} - {hw.tch} - {d}x{hw.tvs}) ms / ({a:.4f} + {b*1e3:.3f}e-3 P + {c*1e6:.3f}e-6 B) ms  [{net.hw}]")
    if net.kind == "protocol":
        single.name, single.kind = "prover-1node", "info"
    bounds.append(single)
    # bandwidth: standing d Pi per interval + block proof, over per-tx bytes
    bdeg, D_blk, f_blk = blk_params(net, d)
    C = net.C2
    if C > 0:
        standing = d * Pi / T_I + D_blk * (Pi + HEADER_BYTES) / SLOT_S
        D_raw = net.D_raw2
        per_tx_0 = ((d - 1) * t                              # first full send to each peer
                    + d * (TRIPLE * k + HASH_REF) * net.R / T_I   # deps + hash in every wrapper
                    + D_blk * t                              # the tx in the block
                    + D_raw * (t + (d + 1) * net.ann))       # raw relay: body + announce/want
        bounds.append(lin("bandwidth", C - standing, per_tx_0, 0.0, D_raw * k, P, B,
                          f"({C:,.0f} - {standing:,.0f}) B/s / ({per_tx_0:,.0f} + {D_raw:.3f} {k}B)"))
    # merge cadence (protocol): own + d peer aggregates per interval must fit the budget
    merge_ms = hw.f0 + (1 + min(d, MAX_RECURSIONS - 1)) * hw.tch + d * hw.tvs
    nagg = n_aggregators if n_aggregators is not None else max(1, round(net.alpha * net.N))
    num_d = net.budget * 1e3 - hw.f0 - 2 * hw.tch - d * hw.tvs
    dist = lin("prover" if net.kind == "protocol" else "prover-distributed", nagg * num_d, a, b, c, P, B,
               f"{nagg} aggregators x (budget - f0 - 2 tch - d tvs)/t_sig  (each sig proven once at its entry node)",
               kind="throughput" if net.kind == "protocol" else "info")
    bounds.append(dist)
    extra = {"merge_ms_all_peers": merge_ms, "merge_fits": merge_ms <= net.budget * 1e3,
             "peers_mergeable": max(0, int((net.budget * 1e3 - hw.f0 - d * hw.tvs) // hw.tch) - 1),
             "max_keys_tps": MAX_KEYS / net.R, "literal_16_deps_tps": 16 / net.R,
             "distributed": dist, "gas": gas}
    return bounds, extra


def s3_bounds(B, P, net, k=1):
    bounds = []
    if net.gas_model == "sim":
        onchain = S3_CALLDATA + S3_CLAIMS * TRIPLE
        gas = 21_000 + max(STD_PER_B * onchain + 27_641 + 5_000 + 7 * 1_000, FLOOR_PER_B * onchain)
    else:
        gas = S3_GAS
    bounds.append(Bound("gas", GAS_LIMIT / SLOT_S / gas, 0.0, 0.0, f"{GAS_LIMIT/1e6:.0f}M/{SLOT_S:.0f}s / {gas:,}"))
    hw = HWS[net.hw]
    d = net.d2
    num = net.budget * 1e3 - hw.f0 - hw.tch - d * hw.tvs
    per_tx = hw.tch7 + hw.tvs        # fold the client STARK as a child, after verifying it natively
    one = Bound("prover", max(0.0, num / per_tx), 0.0, 0.0,
                f"({net.budget*1e3:.0f} - {hw.f0} - {hw.tch} - {d}x{hw.tvs}) / ({hw.tch7} + {hw.tvs}) ms  [{net.hw}]",
                kind="throughput" if net.kind == "sim" else "info")
    if net.kind == "protocol":
        one.name = "prover-1node"
    bounds.append(one)
    # leanVM: <= 16 children per proof: own + >= 1 peer aggregate leaves <= 14 client STARKs per
    # proof per interval at one node (the fork does not model MAX_RECURSIONS)
    bounds.append(Bound("max-recursions-1node", float(MAX_RECURSIONS - 2) / T_I, 0.0, 0.0,
                        "16 children - own - one peer = 14 client STARKs per proof per interval", kind="info"))
    nagg = max(1, round(net.alpha * net.N))
    num_d = net.budget * 1e3 - hw.f0 - 2 * hw.tch - d * hw.tvs
    per_node = min(max(0.0, num_d / per_tx), float(MAX_RECURSIONS - 2))
    bounds.append(Bound("prover" if net.kind == "protocol" else "prover-distributed", nagg * per_node, 0.0, 0.0,
                        f"{nagg} aggregators x min((budget - f0 - 2 tch - d tvs)/(tch7 + tvs), 14)",
                        kind="throughput" if net.kind == "protocol" else "info"))
    C = net.C2
    if C > 0:
        bdeg, D_blk, f_blk = blk_params(net, d)
        t_chain = net.t2 + S3_CALLDATA + S3_CLAIMS * TRIPLE
        # the fork ships claim headers in the mempool body; in the draft only the triples (which
        # carry each claim's hash) are needed by mempool nodes [E draft]
        t_mp = t_chain + (S3_CLAIMS * S3_CLAIM_HEADER if net.kind == "sim" else 0)
        standing = d * net.Pi / T_I + D_blk * (net.Pi + HEADER_BYTES) / SLOT_S
        D_raw = net.D_raw2
        per_tx = ((d - 1) * t_mp + d * (S3_CLAIMS * TRIPLE + HASH_REF) * net.R / T_I + D_blk * t_chain
                  + D_raw * (net.Pi + t_mp + (d + 1) * net.ann))
        bounds.append(Bound("bandwidth", max(0.0, (C - standing) / per_tx), 0.0, 0.0,
                            f"({C:,.0f} - {standing:,.0f}) / {per_tx:,.0f}  (client STARK raw share {D_raw:.3f})"))
    return bounds, {"gas": gas}


def s3_bundle(P, net=None, gas_model="chain"):
    """S3b: one proof-carrying tx per full bundle of n_b = 2^16/(P+10) signatures [Mo, PM12/PM13].
    Gas under 7976 (floor binds): 21,000 + 64 (1,676 + 64 n_b) -> per signature
    4,096 + 128,264 (P+10)/65,536. Bundler (M4) time per signature: (3.0 s + 71.8 us 2^16)/n_b."""
    nb = PI1_CAP / (P + 10)
    g_fix = 21_000 + FLOOR_PER_B * (S3_CALLDATA + S3_CLAIMS * TRIPLE)
    per_sig_gas = FLOOR_PER_B * 64 + g_fix / nb
    sig_s = GAS_LIMIT / SLOT_S / per_sig_gas
    fixed_share = (g_fix / nb) / per_sig_gas
    eP = -fixed_share * P / (P + 10)
    t_bundle = 0.72 + 2.28 + 71.8e-6 * PI1_CAP
    bundler = nb / t_bundle
    return {"n_b": nb, "gas_per_sig": per_sig_gas, "sig_per_s_gas": sig_s, "eP_gas": eP, "eB": 0.0,
            "bundler_sig_per_s_m4": bundler, "eP_bundler": -P / (P + 10)}


def s2r_bounds(B, P, net, k=1):
    """S2 with raw signatures relayed to every node (each node fetches each mode-0 witness once,
    as eth/68 does for a > 4 KiB tx): D_raw = 1."""
    return s2_bounds(B, P, replace(net, D_raw2=1.0), k)


SCEN = {"S1": s1_bounds, "S2": s2_bounds, "S2r": s2r_bounds, "S3": s3_bounds}
SCEN_LIST = ("S1", "S2", "S2r", "S3")


def evaluate(scen, B, P, net, k=1, impl="lean", deadline_binds=True):
    """Max TPS = min over throughput bounds (and deadline bounds if deadline_binds), with the
    binding bound's analytic elasticities and the +10 % arc elasticities of the min."""
    fn = SCEN[scen]
    kw = {"impl": impl} if scen == "S1" else {}
    bounds, extra = fn(B, P, net, k, **kw)

    def pick(bs):
        live = [b for b in bs if b.kind == "throughput" or (b.kind == "deadline" and deadline_binds)]
        return min(live, key=lambda b: b.value)

    best = pick(bounds)
    cliff = [b for b in bounds if b.kind == "cliff" and b.value == 0.0]
    tps = 0.0 if cliff else best.value

    def tps_at(b_, p_):
        bs, _ = fn(b_, p_, net, k, **kw)
        if any(x.kind == "cliff" and x.value == 0.0 for x in bs):
            return 0.0
        return pick(bs).value

    arcB = arcP = float("nan")
    if tps > 0:
        tb, tp = tps_at(B * 1.1, P), tps_at(B, P * 1.1)
        arcB = math.log(tb / tps) / math.log(1.1) if tb > 0 else -math.inf
        arcP = math.log(tp / tps) / math.log(1.1) if tp > 0 else -math.inf
    ranked = sorted([b for b in bounds if b.kind in ("throughput", "deadline")], key=lambda b: b.value)
    return {"tps": tps, "binding": "admission (P > P_max)" if cliff else best.name,
            "eB": best.eB if not cliff else float("nan"), "eP": best.eP if not cliff else float("nan"),
            "arcB": arcB, "arcP": arcP, "bounds": bounds, "ranked": ranked, "extra": extra}


# ----------------------------------------------------------------------------------------------
# 4. Latency predictions (delays, not throughput)
# ----------------------------------------------------------------------------------------------
def latency(scen, B, P, net, tps, k=1, impl="lean"):
    out = {}
    if scen == "S1":
        C, d = net.C1, net.d1
        tx = k * B + net.t1
        if C > 0:
            push = net.kind == "protocol" and tx <= PUSH_THRESHOLD
            hop = (net.L + tx / C) if push else (3 * net.L + net.wait + tx / C)
            out["tx_t50_s"] = hops(net.N, d, 0.5) * hop
            out["tx_t90_s"] = hops(net.N, d, 0.9) * hop
            bdeg, D_blk, f_blk = blk_params(net, d)
            blk = tps * SLOT_S * tx + HEADER_BYTES
            n = tps * SLOT_S
            tau = k * verify_ms_evm(P, net, impl) / 1e3
            h90 = hops(net.N, bdeg, 0.9)
            if net.blk_exec_per_hop:
                out["block_t90_s"] = h90 * (net.L + f_blk * blk / C + n * tau)
            else:
                out["block_t90_s"] = h90 * (net.L + f_blk * blk / C) + n * tau
            out["block_bytes"] = blk
    else:
        C, d = net.C2, net.d2
        hw = HWS[net.hw]
        if C > 0:
            # entry: wait for the tick (T_I/2), prove a small leaf (f0 + tch + n t_sig);
            # each hop: wrapper serialisation to d peers (mean position d/2), latency, STARK verify,
            # wait for the receiver's tick (T_I/2), merge.
            n_new = max(1.0, tps * T_I / max(1.0, net.alpha * net.N))
            t_sig = hw.s0 + hw.sP * P + hw.sB * B if scen == "S2" else hw.tch7
            t_entry = T_I / 2 + (hw.f0 + hw.tch + n_new * t_sig) / 1e3
            hop = (d / 2.0) * net.Pi / C + net.L + hw.tvs / 1e3 + T_I / 2 + (hw.f0 + 2 * hw.tch) / 1e3
            out["evidence_t50_s"] = t_entry + hops(net.N, d, 0.5) * hop
            out["evidence_t90_s"] = t_entry + hops(net.N, d, 0.9) * hop
            out["wrapper_serialisation_s"] = d * net.Pi / C
    return out


# ----------------------------------------------------------------------------------------------
# 5. Tables
# ----------------------------------------------------------------------------------------------
POINTS = [("baseline 7,740 B / 515", 7740, 515, "layered"),
          ("3 KB / 250", 3000, 250, "lean"),
          ("4 KB / 350", 4000, 350, "lean")]


def fmt(x, nd=1):
    if x is None:
        return "-"
    if isinstance(x, float) and math.isnan(x):
        return "n/a"
    if x == math.inf:
        return "inf"
    if x == -math.inf:
        return "cliff"
    if abs(x) >= 1000:
        return f"{x:,.0f}"
    return f"{x:.{nd}f}"


def table_elasticities(profiles, deadline_binds=True):
    lines = []
    hdr = "| profile | point | scen | max TPS | binding | eB | eP | arc +10% B | arc +10% P | next bound (TPS, eB, eP) |"
    lines += [hdr, "|" + "---|" * 10]
    for pk in profiles:
        net = PROFILES[pk]
        for label, B, P, impl in POINTS:
            for sc in SCEN_LIST:
                r = evaluate(sc, B, P, net, impl=impl, deadline_binds=deadline_binds)
                nxt = [b for b in r["ranked"] if b.name != r["binding"]]
                nb = nxt[0] if nxt else None
                nbs = f"{nb.name} {fmt(nb.value)} ({fmt(nb.eB,2)}, {fmt(nb.eP,2)})" if nb else "-"
                lines.append(f"| {pk} | {label} | {sc} | {fmt(r['tps'])} | {r['binding']} | {fmt(r['eB'],3)} | "
                             f"{fmt(r['eP'],3)} | {fmt(r['arcB'],2)} | {fmt(r['arcP'],2)} | {nbs} |")
    return "\n".join(lines)


def table_bounds(pk):
    net = PROFILES[pk]
    lines = [f"### {pk}: {net.name}", "",
             "| point | scen | " + " | ".join(["gas", "bytes", "prover", "bandwidth", "block-deadline", "other"]) + " |",
             "|" + "---|" * 8]
    for label, B, P, impl in POINTS:
        for sc in SCEN_LIST:
            r = evaluate(sc, B, P, net, impl=impl)
            byname = {b.name: b for b in r["bounds"]}
            cells = []
            for nm in ("gas", "bytes", "prover", "bandwidth", "block-deadline"):
                b = byname.get(nm)
                cells.append(fmt(b.value) if b else "-")
            other = []
            for b in r["bounds"]:
                if b.name in ("cpu", "max-recursions-1node", "prover-1node", "prover-distributed"):
                    other.append(f"{b.name} {fmt(b.value)}")
                if b.name == "admission":
                    other.append("admit" if b.value else "REFUSED (P > P_max)")
            lines.append(f"| {label} | {sc} | " + " | ".join(cells) + f" | {', '.join(other)} |")
    return "\n".join(lines)


def table_forms(pk, label_B_P=("baseline", 7740, 515, "layered")):
    net = PROFILES[pk]
    _, B, P, impl = label_B_P
    lines = []
    for sc in SCEN_LIST:
        r = evaluate(sc, B, P, net, impl=impl)
        for b in r["bounds"]:
            lines.append(f"- {sc} {b.name}: {fmt(b.value)} tx/s, eB {fmt(b.eB,3)}, eP {fmt(b.eP,3)}; {b.form}")
    return "\n".join(lines)


def table_latency(profiles):
    lines = ["| profile | point | S1 tx t50/t90 s | S1 block t90 s (at max TPS) | S1 block MB | S2 evidence t50/t90 s | S2 wrapper serialisation s | S3 evidence t90 s |",
             "|" + "---|" * 8]
    for pk in profiles:
        net = PROFILES[pk]
        for label, B, P, impl in POINTS:
            r1 = evaluate("S1", B, P, net, impl=impl, deadline_binds=False)
            l1 = latency("S1", B, P, net, r1["tps"], impl=impl)
            r2 = evaluate("S2", B, P, net)
            l2 = latency("S2", B, P, net, r2["tps"])
            r3 = evaluate("S3", B, P, net)
            l3 = latency("S3", B, P, net, r3["tps"])
            if not l1:
                continue
            lines.append(f"| {pk} | {label} | {fmt(l1['tx_t50_s'],2)} / {fmt(l1['tx_t90_s'],2)} | "
                         f"{fmt(l1['block_t90_s'],2)} | {fmt(l1['block_bytes']/1e6,2)} | "
                         f"{fmt(l2.get('evidence_t50_s'),1)} / {fmt(l2.get('evidence_t90_s'),1)} | "
                         f"{fmt(l2.get('wrapper_serialisation_s'),2)} | {fmt(l3.get('evidence_t90_s'),1)} |")
    return "\n".join(lines)


def table_prover_hw():
    lines = ["| hw | t_sig(P,B) ms | F = f0 + tch ms | single-node TPS P=250/350/515/750 (1 s, d=8) | eP at 515 | eB at 515 | merge own+8 peers ms |",
             "|" + "---|" * 7]
    for hk, hw in HWS.items():
        net = replace(PROTOCOL["base"], hw=hk, budget=1.0)
        tp = [s2_bounds(7740, P, net)[0] for P in (250, 350, 515, 750)]
        vals = [next(b for b in bs if b.name == "prover-1node").value for bs in tp]
        b515 = next(b for b in s2_bounds(7740, 515, net)[0] if b.name == "prover-1node")
        merge = hw.f0 + 9 * hw.tch + 8 * hw.tvs
        lines.append(f"| {hk} | {hw.s0:.3f} + {hw.sP*1e3:.3f}e-3 P + {hw.sB*1e6:.2f}e-6 B | {hw.f0 + hw.tch:.1f} | "
                     + " / ".join(fmt(v, 0) for v in vals) + f" | {b515.eP:.3f} | {b515.eB:.4f} | {merge:.0f} |")
    return "\n".join(lines)


def table_s3b():
    lines = ["| P | n_b | gas/sig (7976) | sig/s on chain @60M | eP (gas) | bundler sig/s (M4, optimistic) | eP (bundler) |",
             "|" + "---|" * 7]
    for P in (250, 350, 515, 750):
        r = s3_bundle(P)
        lines.append(f"| {P} | {r['n_b']:.0f} | {r['gas_per_sig']:,.0f} | {r['sig_per_s_gas']:.0f} | {r['eP_gas']:.3f} | "
                     f"{r['bundler_sig_per_s_m4']:.1f} | {r['eP_bundler']:.3f} |")
    return "\n".join(lines)


def table_levers():
    base = PROTOCOL["base"]
    B, P = 7740, 515
    variants = [
        ("protocol flow (D_raw 0, R 8 s, Pi 256 KiB, D_blk 2.3)", base, "S2"),
        ("raw witness fetched by every node (D_raw 1)", base, "S2r"),
        ("residence R = 12 s (one slot)", replace(base, R=12.0), "S2"),
        ("deps elided from resends (32 B per active tx per peer)", base, "S2-elide"),
        ("rate-1/4 merge proof, 229 KiB [C]", replace(base, Pi=229 * 1024), "S2"),
        ("rate-1/2 merge proof, 288 KiB [C]", replace(base, Pi=288 * 1024), "S2"),
        ("no IDONTWANT on blocks (D_blk 5.2, toy)", replace(base, D_blk=5.2), "S2"),
        ("wrapper degree 6", replace(base, d2=6), "S2"),
        ("attester uplink without background (25 Mbit/s)", replace(base, C2=25 * 0.95 * 125_000), "S2"),
    ]
    lines = ["| variant | S2 bandwidth bound tx/s | eB | standing share of uplink |", "|---|---|---|---|"]
    for label, net, sc in variants:
        if sc == "S2-elide":
            b = next(x for x in s2_bounds(B, P, net)[0] if x.name == "bandwidth")
            d = net.d2
            t = net.t2 + TRIPLE
            saved = d * TRIPLE * net.R / T_I
            per = (net.C2 - d * net.Pi - net.D_blk * (net.Pi + HEADER_BYTES) / SLOT_S) / b.value - saved
            val = (net.C2 - d * net.Pi - net.D_blk * (net.Pi + HEADER_BYTES) / SLOT_S) / per
            lines.append(f"| {label} | {val:.1f} | 0 | {d*net.Pi/net.C2:.2f} |")
            continue
        r = evaluate(sc, B, P, net)
        b = next(x for x in r["bounds"] if x.name == "bandwidth")
        lines.append(f"| {label} | {fmt(b.value)} | {fmt(b.eB,3)} | {net.d2*net.Pi/net.C2:.2f} |")
    return "\n".join(lines)


def thresholds():
    """Crossovers that decide which bound binds [Mo]."""
    out = []
    for pk in ("base", "pess"):
        net = PROTOCOL[pk]
        for label, B, P, impl in POINTS:
            gb, _ = s1_gas(B, P, 1, net, impl)
            n = gb.value * SLOT_S
            blk = n * (B + net.t1) + HEADER_BYTES
            h = hops(net.N, net.blk_deg)
            tau = verify_ms_evm(P, net, impl) / 1e3
            for f in (net.f_blk, 1.0):
                Cs = h * f * blk / (net.T_d - h * net.L - n * tau)
                bg = {"base": 4, "pess": 6}[pk]
                out.append(f"S1 {pk} {label}, f={f:g}: block-deadline = gas bound at relay goodput "
                           f"{Cs/1e6:.2f} MB/s = {Cs*8/1e6/0.95 + bg:.1f} Mbit/s raw uplink (block {blk/1e6:.2f} MB)")
    for pk in ("opt", "base", "pess"):
        net = PROTOCOL[pk]
        bs, ex = s2_bounds(7740, 515, net)
        bw = next(b for b in bs if b.name == "bandwidth")
        gas = next(b for b in bs if b.name == "gas").value
        d = net.d2
        standing = d * net.Pi / T_I + net.D_blk * (net.Pi + HEADER_BYTES) / SLOT_S
        per = (net.C2 - standing) / bw.value if bw.value > 0 else None
        if per is None:
            t = net.t2 + TRIPLE
            per = (d - 1) * t + d * (TRIPLE + HASH_REF) * net.R / T_I + net.D_blk * t
        Css = standing + gas * per
        bg = {"opt": 2, "base": 4, "pess": 6}[pk]
        out.append(f"S2 {pk}: bandwidth = gas bound at uplink goodput {Css/1e6:.2f} MB/s = "
                   f"{Css*8/1e6/0.95 + bg:.1f} Mbit/s raw; standing alone {standing/1e6:.2f} MB/s = "
                   f"{standing*8/1e6/0.95 + bg:.1f} Mbit/s raw (d={d}, Pi={net.Pi/1024:.0f} KiB)")
    # weakest aggregator class: P at which a lone eip7870_full prover equals the S2 gas bound
    hw = HWS["eip7870_full"]
    v0, vP = NATIVE_SIG_VERIFY
    num = 1000 - hw.f0 - hw.tch - 8 * hw.tvs
    gas = GAS_LIMIT / SLOT_S / (S2_GAS0 + S2_GAS_PER_DEP)
    Pc = (num / gas - hw.s0 - v0 - hw.sB * 7740) / (hw.sP + vP)
    out.append(f"S2 lone EIP-7870 full-node-class aggregator (d=8 wrappers verified) proves the gas bound "
               f"({gas:.1f} tx/s) only for P <= {Pc:.0f}")
    return "\n".join("- " + x for x in out)


def sweep_curve(pk, scen, fixed, axis, values, impl="lean"):
    net = PROFILES[pk]
    out = []
    for v in values:
        B, P = (v, fixed) if axis == "B" else (fixed, v)
        r = evaluate(scen, B, P, net, impl=impl)
        out.append((v, r["tps"], r["binding"]))
    return out


# ----------------------------------------------------------------------------------------------
# 6. Predictions for the simulator sweeps (explicit numbers to compare against)
# ----------------------------------------------------------------------------------------------
def sim_prediction(scen, B, P, pk, gas_on=True):
    """Predicted fork capacity (tx/s) with its binding resource. The fork never orphans a late
    block: the S1 deadline bound is reported as 'late blocks expected' and capacity without a gas
    limit is set by the window heuristic (block t90 <= 2/3 slot, section 6 of the note)."""
    net = PROFILES[pk]
    impl = "lean"
    fn = SCEN[scen]
    kw = {"impl": impl} if scen == "S1" else {}
    bounds, extra = fn(B, P, net, 1, **kw)
    live = [b for b in bounds if b.kind == "throughput" and (gas_on or b.name != "gas")
            and b.name not in ("cpu",)]
    if scen == "S1" and net.C1 > 0:
        # window heuristic: block t90 = (2/3) S
        w = replace(net, T_d=SLOT_S * 2 / 3)
        wb = next(b for b in fn(B, P, w, 1, **kw)[0] if b.name == "block-deadline")
        wb = Bound("window(block t90<=8s)", wb.value, wb.eB, wb.eP, wb.form)
        live.append(wb)
    best = min(live, key=lambda b: b.value)
    out = {"scenario": scen, "profile": pk, "sig_bytes": B, "perms": P, "gas_limit": GAS_LIMIT if gas_on else 0,
           "pred_capacity_tps": round(best.value, 2), "binding": best.name,
           "eB": round(best.eB, 3), "eP": round(best.eP, 3)}
    if gas_on and best.name == "gas":
        g = GAS_LIMIT / SLOT_S / best.value
        out["pred_capacity_tps_integer_blocks"] = round((GAS_LIMIT // round(g)) / SLOT_S, 3)
    if scen == "S1":
        dl = next((b for b in bounds if b.name == "block-deadline"), None)
        if dl:
            out["deadline_tps_4s"] = round(dl.value, 2)
            out["late_blocks_expected"] = bool(dl.value < best.value)
        lat = latency("S1", B, P, net, best.value, impl=impl)
        out.update({k_: round(v, 3) for k_, v in lat.items()})
    else:
        lat = latency(scen, B, P, net, best.value)
        out.update({k_: round(v, 3) for k_, v in lat.items()})
        if scen == "S2" and net.C2 > 0:
            # egress prediction at capacity: wrappers = d Pi + tps d (t + 128 R) ; total adds blocks/raw
            d = net.d2
            t = net.t2 + TRIPLE
            out["pred_egress_wrapper_Bps"] = round(d * net.Pi + best.value * ((d - 1) * t + d * 128 * net.R), 0)
            out["pred_standing_share_of_uplink"] = round(d * net.Pi / net.C2, 3)
    return out


def all_predictions():
    preds = []
    for pk in SIM:
        for label, B, P, impl in POINTS:
            for scen in ("S1", "S2", "S3"):
                for gas_on in (True, False):
                    preds.append(sim_prediction(scen, B, P, pk, gas_on))
    return preds


# ----------------------------------------------------------------------------------------------
# 7. Checks
# ----------------------------------------------------------------------------------------------
def _fd_check():
    """Analytic elasticities equal central finite differences of the binding bound."""
    worst = 0.0
    for pk, net in PROFILES.items():
        for _, B, P, impl in POINTS:
            for sc in ("S1", "S2"):
                fn = SCEN[sc]
                kw = {"impl": impl} if sc == "S1" else {}
                bs, _ = fn(B, P, net, 1, **kw)
                for b in bs:
                    if b.kind in ("cliff", "info") or b.value in (0.0, math.inf) or b.name in ("cpu",):
                        continue
                    h = 1e-4

                    def val(BB, PP):
                        return next(x for x in fn(BB, PP, net, 1, **kw)[0] if x.name == b.name).value
                    if b.name == "gas" and sc == "S1":
                        pass
                    eB = (math.log(val(B * (1 + h), P)) - math.log(val(B * (1 - h), P))) / (2 * h)
                    eP = (math.log(val(B, P * (1 + h))) - math.log(val(B, P * (1 - h)))) / (2 * h)
                    worst = max(worst, abs(eB - b.eB), abs(eP - b.eP))
    return worst


def check():
    sys.path.insert(0, "/leansphincs/data")
    print("# --check\n")
    print(f"finite-difference vs analytic elasticities, worst |diff| over all bounds: {_fd_check():.2e}")
    # (a) chain_model cross-check
    try:
        import chain_model as cm
        print("\n## chain_model.py (notes/chain.md)")
        for label, B, P, impl in POINTS:
            g, _ = s1_gas(B, P, 1, PROTOCOL["base"], impl)
            mine = GAS_LIMIT / SLOT_S / g.value
            theirs = cm.gas_per_tx(B, P, 1, impl=impl)
            el = cm.elasticities(B, P, 1, impl=impl)
            print(f"S1 {label}: gas mine {mine:,.0f} vs chain_model {theirs:,}; eB mine {g.eB:.4f} vs {el['B']:.4f}; "
                  f"P_max mine {p_max_public(1, impl):.1f} vs {cm.p_max_public(B, 1, impl=impl):.1f}; "
                  f"P* mine {p_star(B, 1, PROTOCOL['base'], impl):.0f} vs {cm.floor_crossover_P(B, 1, impl=impl):.0f}")
        for k in (1, 2, 4, 16):
            print(f"S2 k={k}: gas mine {S2_GAS0 + S2_GAS_PER_DEP*k:,} vs chain_model {cm.agg_gas_per_tx(7740, 515, k):,}")
        print(f"S3: gas mine {S3_GAS:,} vs chain_model {cm.pcs_model(7740, 515, 1)['gas']:,}")
    except Exception as exc:  # pragma: no cover
        print("chain_model cross-check skipped:", exc)
    # (b) prover_model cross-check: the linear t_sig against per_sig_time, node capacity
    try:
        import prover_model as pm
        print("\n## prover_model.py (notes/prover-model.md)")
        worst = 0.0
        for hk in ("m4", "box16", "eip7870", "eip7870_full", "epyc9355p"):
            hw = HWS[hk]
            for P in (250, 350, 515, 750):
                for B in (3000, 4000, 7740):
                    ref = pm.per_sig_time(P, B, hk) * 1e3
                    mine = hw.s0 + hw.sP * P + hw.sB * B
                    worst = max(worst, abs(mine / ref - 1))
            F1 = pm.prove_time(0, 515, 7740, 1, hk, smooth=True) * 1e3
            cap = pm.node_capacity(515, 7740, hk, 1.0, 1, smooth=True)
            mine_cap = (1000 - hw.f0 - hw.tch) / (hw.s0 + hw.sP * 515 + hw.sB * 7740)
            print(f"{hk}: f0+tch mine {hw.f0 + hw.tch:.1f} vs {F1:.1f} ms; node capacity (no verify share) "
                  f"mine {mine_cap:.0f} vs prover_model {cap}")
        print(f"linear t_sig vs per_sig_time: worst relative error {worst*100:.2f} %")
        e = pm.elasticity(515, 7740, "m4")
        net = replace(PROTOCOL["opt"], d2=0, C2=0.0)
        b = next(x for x in s2_bounds(7740, 515, net)[0] if x.name == "prover-1node")
        print(f"M4 node elasticity at 515: prover_model smooth eP {e['smooth']['eP']:.3f} (integer capacity, "
              f"+-10 %), per-sig time eP {e['per_sig_time_eP']:.3f} eB {e['per_sig_time_eB']:.4f}; "
              f"mine (incl. native verify share, no wrappers) eP {b.eP:.3f} eB {b.eB:.4f}")
    except Exception as exc:  # pragma: no cover
        print("prover_model cross-check skipped:", exc)
    # (c) the existing fork runs [C]: data/sim/baseline-current.csv and baseline-mainnet-*.json
    print("\n## existing fork runs [C] (not the parallel sweeps): prediction vs simulated")
    try:
        import csv
        rows = list(csv.DictReader(open("/leansphincs/data/sim/baseline-current.csv")))
        sc_map = {"noagg": "S1", "agg8288": "S2", "pcs": "S3"}
        for r in rows:
            pk = "sim_default" if float(r["uplink_mbps"]) > 0 else "sim_ideal"
            gas_on = int(r["gas_limit"]) > 0
            p = sim_prediction(sc_map[r["scenario"]], int(r["sig_bytes"]), int(r["perms"]), pk, gas_on)
            sim = float(r["capacity_tps"])
            extra = ""
            if sc_map[r["scenario"]] == "S1" and float(r["uplink_mbps"]) > 0:
                extra = f"; block t90 pred {p['block_t90_s']:.2f} s vs sim {float(r['block_mean_t90_ms'])/1e3:.2f}"
            if sc_map[r["scenario"]] == "S2" and float(r["uplink_mbps"]) > 0:
                extra = (f"; wrapper egress pred {p['pred_egress_wrapper_Bps']/1e6:.2f} MB/s vs sim "
                         f"{float(r['egress_wrapper_Bps_per_node'])/1e6:.2f} at sim's own TPS")
            print(f"{r['scenario']:8s} {pk:11s} gas {'60M' if gas_on else 'none':4s}: pred {p['pred_capacity_tps']:7.1f} "
                  f"({p['binding']}) vs sim capacity {sim:7.1f}  ratio {sim/p['pred_capacity_tps']:.3f}{extra}")
        for f in ("noagg", "agg8288", "pcs"):
            for n in (200, 1000):
                r = json.load(open(f"/leansphincs/data/sim/baseline-mainnet-{f}-n{n}.json"))
                net = replace(SIM["sim_default"], N=n, D_raw2=(6 + 2) / n)
                PROFILES["_tmp"] = net
                p = sim_prediction(sc_map[f], 7740, 515, "_tmp", True)
                msg = f"{f:8s} n={n:4d} run mode 2x load: window TPS {r['tps_included_window']:.2f} vs pred capacity {p['pred_capacity_tps']:.2f}"
                if f == "noagg":
                    msg += f"; block t90 {r['block_mean_t90_ms']/1e3:.2f} s vs pred {p['block_t90_s']:.2f} (late pred: {p['late_blocks_expected']})"
                print(msg)
        PROFILES.pop("_tmp", None)
    except Exception as exc:  # pragma: no cover
        print("sim comparison skipped:", exc)


# ----------------------------------------------------------------------------------------------
def main(argv):
    if "--check" in argv:
        check()
        return
    if "--json" in argv:
        path = argv[argv.index("--json") + 1]
        preds = all_predictions()
        meta = {"model": "data/analytic_model.py", "status": "[Mo]",
                "profiles": {k: {f: getattr(v, f) for f in ("name", "N", "L", "C1", "d1", "C2", "d2", "Pi",
                                                             "D_raw2", "alpha", "hw", "budget", "T_d", "t1", "t2", "R")}
                             for k, v in SIM.items()},
                "assumed_harness_flags": {
                    "sim_default": "defaults (40 nodes, degree 6, 25 Mbit/s, 100 ms, proof 223,334, tx_bytes 200, eip_faithful, announce_fetch, overlay)",
                    "sim_ideal": "--uplink-mbps 0 --latency-ms 0",
                    "sim_opt": "--nodes 1000 --degree 50 (S1) / 8 (S2,S3) --uplink-mbps 21.85 (S1) / 45.6 --latency-ms 56.1 proof_bytes 223334",
                    "sim_base": "--nodes 1000 --degree 32 / 8 --uplink-mbps 10.45 / 19.95 --latency-ms 64.1 proof_bytes 262144",
                    "sim_pess": "--nodes 1000 --degree 20 / 6 --uplink-mbps 8.55 / 18.05 --latency-ms 87 proof_bytes 366592"},
                "predictions": preds}
        with open(path, "w") as fh:
            json.dump(meta, fh, indent=1)
        print(f"wrote {len(preds)} predictions to {path}")
        return
    print("# analytic_model.py tables [Mo]\n")
    print("## A. Max TPS and elasticities, protocol profiles (deadline bound binds)\n")
    print(table_elasticities(list(PROTOCOL)))
    print("\n## A'. Same, block-deadline bound ignored (blocks assumed to propagate)\n")
    print(table_elasticities(list(PROTOCOL), deadline_binds=False))
    print("\n## B. Every bound, protocol profiles\n")
    for pk in PROTOCOL:
        print(table_bounds(pk) + "\n")
    print("## C. Closed forms at the baseline point, base profile\n")
    print(table_forms("base"))
    print("\n## D. Prover bound per hardware (S2, single node, d=8 wrappers verified)\n")
    print(table_prover_hw())
    print("\n## E. S3b proof-carrying bundles (per signature)\n")
    print(table_s3b())
    print("\n## F. Latency predictions\n")
    print(table_latency(list(PROTOCOL) + ["sim_default", "sim_base"]))
    print("\n## G. Simulator profiles: max TPS and elasticities\n")
    print(table_elasticities(list(SIM), deadline_binds=False))
    print("\n## H. Predictions for the fork (capacity mode)\n")
    print("| profile | point | scen | gas | pred TPS | binding | eB | eP | S1 deadline TPS (4 s) | late blocks? |")
    print("|" + "---|" * 10)
    for p in all_predictions():
        lbl = next(l for l, B, P, _ in POINTS if B == p["sig_bytes"] and P == p["perms"])
        print(f"| {p['profile']} | {lbl} | {p['scenario']} | {'60M' if p['gas_limit'] else 'none'} | "
              f"{p['pred_capacity_tps']} | {p['binding']} | {p['eB']} | {p['eP']} | "
              f"{p.get('deadline_tps_4s', '-')} | {p.get('late_blocks_expected', '-')} |")
    print("\n## I. S2 extras (base profile, baseline point)\n")
    _, ex = s2_bounds(7740, 515, PROTOCOL["base"])
    for k_, v in ex.items():
        if k_ != "distributed":
            print(f"- {k_}: {v}")
    print("\n## K. S2 bandwidth levers (base profile, baseline point; protocol flow unless stated)\n")
    print(table_levers())
    print("\n## L. Thresholds\n")
    print(thresholds())
    print("\n## J. Curves, base profile\n")
    for sc in ("S1", "S2"):
        print(f"{sc} TPS vs B at P=350:", [(v, round(t, 1), b) for v, t, b in sweep_curve("base", sc, 350, "B", (2000, 3000, 4000, 5000, 6000, 7740, 9000))])
        print(f"{sc} TPS vs P at B=4000:", [(v, round(t, 1), b) for v, t, b in sweep_curve("base", sc, 4000, "P", (200, 350, 515, 600, 700, 1000))])


if __name__ == "__main__":
    main(sys.argv[1:])

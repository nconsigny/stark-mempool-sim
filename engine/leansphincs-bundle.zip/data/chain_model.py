#!/usr/bin/env python3
"""On-chain cost model for leanSPHINCS: signature bytes B and verify permutations P -> gas, bytes, TPS.

Campaign: /leansphincs (BRIEF.md). Notes: /leansphincs/notes/chain.md.
Stdlib only, so the simulator fork can import it (`from chain_model import gas_per_tx, tps_onchain`).

Status tags (BRIEF.md): [E] EIP text, [R] read at a path, [C] count from a run, [M] measured,
[Mo] modelled, [Rc] recalled. Every constant below carries one.

Public API. gas_per_tx / agg_gas_per_tx / pcs_model follow the model contract of the simulator fork
(sims/stark-mempool-sim-v2, branch leansphincs on c86d905, bench/leansphincs/models.py and
sims/LEANSPHINCS-FORK.md, re-read 2026-11-10 resume): the fork calls gas_per_tx(sig_bytes, perms, k)
and agg_gas_per_tx(sig_bytes, perms, k) positionally and expects pcs_model(...) to return PCS_KEYS.
Select them with {"fn": "chain_model:gas_per_tx", "path": "/leansphincs/data"}.

    gas_per_tx(B, P, k=1, mode="frame_evm", pricing="7976", **opt) -> int     gas_used of one tx
    agg_gas_per_tx(B, P, k=1, **opt) -> int                       S2 (mode "agg8288")
    pcs_model(B, P, k=1, **opt) -> dict                           S3 on-chain shape (PCS_KEYS)
    gas_breakdown(B, P, k=1, mode=..., pricing=..., **opt) -> GasTx   both paths, binding, bytes
    tx_bytes(B, P, k=1, mode="frame_evm", **opt) -> int            on-chain RLP bytes of one tx
    tps_onchain(B, P, k=1, mode="frame_evm", gas_limit=60e6, slot=12.0, pricing="7976",
                fill=1.0, max_block_bytes=None, unit="tx", **opt) -> float
    tps_detail(...same...) -> dict        both bounds, which binds, block bytes, per-tx breakdown
    elasticities(B, P, k=1, mode=..., **same) -> {"B": dlnTPS/dlnB, "P": dlnTPS/dlnP}
    k_max(B, P, mode=..., pricing=...) -> dict   largest k per tx under each per-tx limit
    validation_gas(B, P, k=1, mode=...) -> float  EIP-8141 public-mempool validation work (rule 6)
    p_max_public(B, k=1, mode=..., cap=MAX_VERIFY_GAS) -> float  largest P the public mempool admits
    userop_bytes(B, k=1) -> int                   ERC-4337 packed userOp size (ERC-7562 LIM-010)
    sim_inputs(B, P, k=1, mode=..., **same) -> dict   what the S1 network simulator needs

B: signature bytes. P: Keccak-f[1600] permutations to verify one signature. k: signatures per tx
(k-of-n multisig, all in one tx). Modes:

    S1 NOAGG (signature bytes in the tx):
      "frame_evm"         EIP-8141 frame tx, sig in an ARBITRARY entry, EVM verifier in a VERIFY frame
      "frame_precompile"  same, the verifier is a precompile priced per permutation
      "frame_native"      sig as a protocol-validated EIP-8141 signature scheme priced per permutation
      "4337_evm"          ERC-4337 handleOps (one userOp per bundle tx by default), EVM verifier
      "call_evm"          a plain tx calling the verifier (the measured Sepolia "verify tx" shape)
    S2 AGG8288:  "agg8288"  EIP-8288 dependency frame (96-B triple per signature), no sig on chain
    S3 PCS:      "pcs"      leanPCS draft: per-tx proof remainder + PCS claims as 8288 triples
"""
from dataclasses import dataclass, field, asdict
import math

# ---------------------------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------------------------

# EIP-8141 (Draft; EIPs repo e858e91, 2026-10-24) [E]
FRAME_TX_INTRINSIC_COST = 12_000
FRAME_TX_PER_FRAME_COST = 475
ARBITRARY_SIG_GAS = 100           # signature_gas(ARBITRARY)
TX_VALUE_COST = 6_000             # EIP-2780, charged per value-carrying frame to another account
MAX_FRAMES = 64
# EIP-7825 (Final, Fusaka) [E]
TX_MAX_GAS_LIMIT = 2 ** 24
# EIP-7934 (Final, Fusaka) [E]: RLP execution block cap 10 MiB - 2 MiB margin
MAX_RLP_BLOCK_SIZE = 10_485_760 - 2_097_152
# EIP-8288 (Draft) [E]
LEANSPHINCS_VERIFICATION_GAS = 3_000   # frame limits.execution per leanSPHINCS triple
LEANSTARK_VERIFICATION_GAS = 30_000    # recursive_stark_gas per triple (every triple, intrinsic)
TRIPLE_BYTES = 96                      # 31 zero bytes, scheme byte, data_hash 32, vk 32
TRIPLE_ZERO_BYTES = 31
MAX_SIGS_PER_TX = 16
AGG_STARK_BYTES_EIP = 256 * 1024       # "fixed ~256 kB per AGGREGATION_INTERVAL" [E]
AGG_STARK_BYTES_LEANVM = (321 * 1024, 358 * 1024)  # leanVM 04fba03 rate 1/2, leaves/merges
#   [R] /projects/hashmancer-keccak/docs/studies/leanvm-sphincs-el.md §3.4 (C/M there)
AGG_STARK_NATIVE_VERIFY_S = 0.0058     # [R] hashmancer-keccak/docs/studies/leanvm-integration.md:150
#   (leanXMSS proof 247.6 KiB, native verify 5.8 ms on an M4 Max)
# leanPCS draft (refs/leanPCS @ fc482edd, eip-draft_leanPCS.md) [E-draft]
PCS_TX_GAS = 5_000
PCS_CLAIM_GAS = 1_000
# leanPCS README @ fc482edd [R]: pi2 contract, 128-leanXMSS leaf aggregate, measured by its authors
PCS_PROOF_CALLDATA = 1_004
PCS_CLAIMS = 7
PCS_CONTRACT_EXEC = 27_641
# Mempool tx size: geth legacypool txMaxSize = 4 * 32 KiB [R]
# /projects/leanKohakuDesktop/.tools/ref-lc/go-ethereum @ 2006f08 core/txpool/legacypool/legacypool.go:56
TXPOOL_MAX_TX_BYTES = 128 * 1024
# EIP-8141 public-mempool rule 6 [E] eip-8141.md:933,1026: the validation prefix's limits.execution plus
# the intrinsic cost of validating tx.signatures must not exceed MAX_VERIFY_GAS. A mempool rule, not a
# validity rule: a tx sent straight to a builder is not bound by it.
MAX_VERIFY_GAS = 100_000
# Nethermind's DoS benchmark proposes 300,000, safe only with in-client block-import protection [R]
# refs/ethresearch/26224.md:13,237 (a proposal; the EIP still says 100,000).
MAX_VERIFY_GAS_PROPOSED = 300_000
# ERC-7562 (Review) LIM-010 [E] refs/ercs/erc-7562.md:73,337: a packed, ABI-encoded UserOperation must not
# exceed MAX_USEROP_SIZE bytes in the ERC-4337 public (bundler) mempool.
MAX_USEROP_SIZE = 8_192
# Gas limit [M]: 59,999,943 at mainnet block 26,383,103 (eth_getBlockByNumber, BRIEF.md "Facts checked
# online", 2026-11-10; that block used 26.0 M gas, 184 KB). Earlier [R]: 60 M over blocks
# 26263661-26263860 (scratch-lc/research/ideas.md:361) and EIP-7935's default [E]. The model uses the
# round 60 M; the measured value changes every TPS below by -1e-6 (relative).
GAS_LIMIT_MEASURED = 59_999_943
GAS_LIMIT_NOW = 60_000_000
GAS_LIMITS = (45_000_000, 60_000_000, 100_000_000, 150_000_000)
SLOT_S = 12.0
# EIP-7870 (Living) bandwidth, Mbit/s down/up [E]
BANDWIDTH_7870 = {"full_node": (50, 15), "attester": (50, 25), "local_builder": (100, 50)}
# Propagation windows [E]: pre-ePBS the block must arrive before the attestation deadline (1/3 slot);
# EIP-7732 (Glamsterdam): PAYLOAD_DUE_BPS 5000 -> PAYLOAD_ATTESTATION_DUE_BPS 7500.
DEADLINES_S = {"pre_epbs_attest": SLOT_S / 3, "epbs_payload_to_ptc": SLOT_S * (0.75 - 0.50)}


@dataclass(frozen=True)
class Pricing:
    """Calldata and base-cost rules. Tokens: zero byte 1, nonzero 4 (EIP-7623)."""
    name: str
    std_token: int          # STANDARD_TOKEN_COST
    floor_per_token: int    # TOTAL_COST_FLOOR_PER_TOKEN
    floor_tokens_zero: int  # floor tokens per zero byte: 1 (EIP-7623), 4 (EIP-7976)
    tx_base: int            # legacy/1559 tx base: 21000; EIP-2780 TX_BASE_COST 12000
    to_cold: int            # EIP-2780 COLD_ACCOUNT_ACCESS for tx.to (0 pre-2780: tx.to is warm, in base)
    frame_live: bool        # EIP-8141 requires 7976/2780/8037 (its "requires" line)


PRICING = {
    # Mainnet on 2026-11-10: Fusaka (EIP-7607 Final). [E] eip-7623.md
    "7623": Pricing("Fusaka mainnet (EIP-7623 floor 10/40)", 4, 10, 1, 21_000, 0, False),
    # Glamsterdam (EIP-7773 Scheduled; live on Sepolia 2026-10-06, Hoodi 2026-10-26; mainnet TBD)
    # [E] eip-7976.md, eip-2780.md, eip-8038.md
    "7976": Pricing("Glamsterdam (EIP-7976 floor 64/64, EIP-2780 base)", 4, 16, 4, 12_000, 3_000, True),
}


def std_tokens(zero, nonzero):
    return zero + 4 * nonzero


def floor_tokens(zero, nonzero, pr):
    return pr.floor_tokens_zero * zero + 4 * nonzero


# ---------------------------------------------------------------------------------------------
# Verify-gas models (per signature)
# ---------------------------------------------------------------------------------------------
# EVM verifier gas per permutation, from data/gasfit/fit_verify_gas.out [Mo over R/M rows]:
#   leanSphincs 149.5, -s 150.6, -f 151.9 (single XMSS layer, 16-B tweak, loop-optimised Yul),
#   -layered 166.9, C7 203, C12 196 (64-B seed||ADRS prefix), C13 298 (unoptimised, Lean-pinned).
EVM_GAS_PER_PERM = {"lean": 150.0, "layered": 167.0, "cseries": 200.0, "unoptimised": 298.0}
# Precompile / native scheme price per permutation [Mo, a proposal, no EIP]: the KECCAK256 opcode's
# marginal price for one 136-byte rate block, 6 gas/word * 136/32 = 25.5 -> 26. EIP-7904 measured
# 3 gas/word at 100 Mgas/s (-> 13/perm) as the low case. Base 3,000 = ECRECOVER-like call base.
PC_GAS_PER_PERM = 26
PC_BASE = 3_000
NATIVE_BASE = 0
# EIP-8141 frame module around an EVM verifier [M as recorded]: VERIFY frame - verifier frame over
# the 5 ethrex txs of SPHINCs- docs/deployments.md: 7,857 / 7,905 / 7,893 / 8,261 / 7,628.
FRAME_MODULE_GAS = 7_900
FRAME_MODULE_GAS_PER_EXTRA_SIG = 2_000   # [Mo] another SIGDATACOPY + warm STATICCALL + memory
SENDER_FRAME_GAS = 3_000                 # [M as recorded] SENDER transfer frame, ethrex txs
# Floor bytes outside the signature in the measured frame-tx shape [M as recorded, derived]:
# all 5 ethrex frame txs = 19,050 + 64*(B + 39); 36 of the 39 are VERIFY's data
# (verifyFrameAndApprove(uint256 0): 4 + 32 bytes, 32 of them zero).
FRAME_OTHER_FLOOR_BYTES = 39
VERIFY_DATA_BYTES, VERIFY_DATA_ZERO = 36, 32
# Rough RLP framing of a frame tx outside the frame data and signature bytes [Mo]:
# type 1, chain id/nonce/sender ~30, 2 frames ~2*25, sig entry header ~5, fees ~20, list headers ~10.
FRAME_TX_RLP_OVERHEAD = 120
# EIP-8288 VERIFY frame that checks the dependency against the stored key [Mo]:
# frame walk (FRAMEPARAM), FRAMEDATACOPY, one cold SLOAD per key (2,100), APPROVE.
AGG_VERIFY_FRAME_GAS = 5_900
AGG_VERIFY_FRAME_GAS_PER_DEP = 2_100


def verify_gas(P, model="evm", impl="lean", per_perm=None, base=None):
    """Execution gas to verify one signature of P permutations."""
    if model == "evm":
        return (EVM_GAS_PER_PERM[impl] if per_perm is None else per_perm) * P
    if model == "precompile":
        return (PC_BASE if base is None else base) + (PC_GAS_PER_PERM if per_perm is None else per_perm) * P
    if model == "native":
        return (NATIVE_BASE if base is None else base) + (PC_GAS_PER_PERM if per_perm is None else per_perm) * P
    raise ValueError(model)


# ---------------------------------------------------------------------------------------------
# ERC-4337 handleOps calldata (one userOp, hybrid ECDSA + PQ account, EntryPoint v0.9 layout)
# ---------------------------------------------------------------------------------------------

def _pad32(n):
    return (n + 31) // 32 * 32


def handleops_calldata(B, k=1):
    """(bytes, zero bytes) of handleOps([op], beneficiary) for a SphincsAccount-style userOp whose
    signature is abi.encode(bytes ecdsa65, bytes pq), pq = k*B random bytes. Built byte by byte
    with the layout of /projects/SPHINCs- script/send_userop_c13.py (PackedUserOperation, callData
    execute(dest, 1e13 wei, ""), gas limits 300k/35k, preVerificationGas 100k, fees ~1-2 gwei). [Mo]"""
    import random
    rnd = random.Random(0)
    w = lambda x: int(x).to_bytes(32, "big")
    addr = lambda: b"\0" * 12 + rnd.randbytes(20)
    pq = rnd.randbytes(k * B)
    pq_padded = pq + b"\0" * ((-len(pq)) % 32)
    ecdsa = rnd.randbytes(65) + b"\0" * 31
    hybrid = w(64) + w(64 + 32 + 96) + w(65) + ecdsa + w(len(pq)) + pq_padded
    call = rnd.randbytes(4) + addr() + w(10 ** 13) + w(96) + w(0)
    call_padded = call + b"\0" * ((-len(call)) % 32)
    head_words = 9
    off_init = 32 * head_words
    off_call = off_init + 32
    off_pm = off_call + 32 + len(call_padded)
    off_sig = off_pm + 32
    op = (addr() + w(7) + w(off_init) + w(off_call)
          + (300_000).to_bytes(16, "big") + (35_000).to_bytes(16, "big") + w(100_000)
          + (10 ** 9).to_bytes(16, "big") + (2 * 10 ** 9).to_bytes(16, "big") + w(off_pm) + w(off_sig)
          + w(0) + w(len(call)) + call_padded + w(0) + w(len(hybrid)) + hybrid)
    data = rnd.randbytes(4) + w(64) + addr() + w(1) + w(32) + op
    return len(data), data.count(0)


# Continuous form for the model: overhead bytes at B = 0, plus k*B signature bytes of which 1/256
# are zero on average (ABI padding of the signature, <= 31 bytes, is dropped).
HANDLEOPS_N0, HANDLEOPS_Z0 = handleops_calldata(0)


def handleops_bytes(B, k=1):
    n = HANDLEOPS_N0 + k * B
    return n, HANDLEOPS_Z0 + k * B / 256


def _calibrate_4337():
    """EntryPoint + account + ECDSA execution gas outside the PQ verifier [Mo], from SPHINCs- C13
    handleOps 292,727 gas on Sepolia, June 2026 (EIP-7623 rules; docs/deployments.md), minus the
    C13 verifier frame 106,672 [M, data/gasfit/trace_results.jsonl] and the calldata."""
    n, z = handleops_bytes(3688)
    pr = PRICING["7623"]
    std_cd = pr.std_token * std_tokens(z, n - z)
    e = 292_727 - pr.tx_base - std_cd - 106_672
    floor_total = pr.tx_base + pr.floor_per_token * floor_tokens(z, n - z, pr)
    assert floor_total < 292_727, "calibration assumes the standard path bound under 7623"
    return e


ENTRYPOINT_OVERHEAD_GAS = _calibrate_4337()
# The C13 receipt was the account's FIRST userOp (deposit 0: the account transfers its prefund).
# Replayed on an anvil fork of Sepolia block 10928940 [M, data/verify_chain/fork_4337.out]:
# 292,727 as recorded; 275,627 with the deposit pre-set to the post-first-op leftover; 266,897 with a
# 1-ETH deposit (no prefund transfer). Steady-state overheads, same subtraction:
ENTRYPOINT_OVERHEAD_STEADY = (ENTRYPOINT_OVERHEAD_GAS - (292_727 - 275_627),
                              ENTRYPOINT_OVERHEAD_GAS - (292_727 - 266_897))


# ---------------------------------------------------------------------------------------------
# Per-tx gas
# ---------------------------------------------------------------------------------------------

@dataclass
class GasTx:
    mode: str
    pricing: str
    B: int
    P: float
    k: int
    standard: float          # intrinsic + execution (+ EIP-8288 recursive_stark_gas)
    floor: float             # calldata floor path
    total: float             # max(standard, floor): gas_used and the block-gas charge
    binding: str             # "floor" or "standard"
    calldata_bytes: int      # floor-priced payload bytes (frame data + signature bytes, or calldata)
    tx_bytes: int            # on-chain RLP size estimate
    verify_gas: float        # per-signature verification gas inside the total
    notes: list = field(default_factory=list)

    def as_dict(self):
        return asdict(self)


def gas_breakdown(B, P, k=1, mode="frame_evm", pricing="7976", *, impl="lean", per_perm=None,
               pc_base=None, bundle=1, pcs_claims=PCS_CLAIMS, pcs_proof=PCS_PROOF_CALLDATA,
               pcs_exec=PCS_CONTRACT_EXEC, pcs_pays_stark_gas=False, value_transfer=True,
               ep_overhead=None):
    """Gas of one transaction carrying k signatures of B bytes and P verify permutations each."""
    pr = PRICING[pricing]
    notes = []
    vt = TX_VALUE_COST if value_transfer else 0
    sender = SENDER_FRAME_GAS if value_transfer else 0

    if mode in ("frame_evm", "frame_precompile", "frame_native"):
        if not pr.frame_live:
            notes.append("EIP-8141 is not live under this pricing; frame tx priced hypothetically")
        n_frames = 2                                     # VERIFY + SENDER (the measured shape)
        sig_bytes = k * B
        frame_floor_bytes = FRAME_OTHER_FLOOR_BYTES
        if mode == "frame_native":
            v = verify_gas(P, "native", per_perm=per_perm, base=pc_base)
            sig_ver = k * v                              # in BOTH paths (EIP-8141 signature_verification_cost)
            exec_verify = 2_000 + 500 * (k - 1)          # [Mo] VERIFY frame reads SIGPARAM, APPROVEs
        else:
            v = verify_gas(P, "evm" if mode == "frame_evm" else "precompile", impl=impl,
                           per_perm=per_perm, base=pc_base)
            sig_ver = k * ARBITRARY_SIG_GAS
            exec_verify = k * v + FRAME_MODULE_GAS + FRAME_MODULE_GAS_PER_EXTRA_SIG * (k - 1)
        fixed = FRAME_TX_INTRINSIC_COST + n_frames * FRAME_TX_PER_FRAME_COST + sig_ver + vt
        # Standard: frame data at tokens_in, signature bytes (msg empty) at 4 tokens/byte.
        std_cd = pr.std_token * (std_tokens(VERIFY_DATA_ZERO, VERIFY_DATA_BYTES - VERIFY_DATA_ZERO)
                                 + 4 * sig_bytes)
        standard = fixed + std_cd + exec_verify + sender
        # Floor: EIP-8141 floor_tokens_in = 4/byte for frame data and signature bytes.
        floor = fixed + pr.floor_per_token * 4 * (sig_bytes + frame_floor_bytes)
        cd = sig_bytes + frame_floor_bytes
        txb = sig_bytes + VERIFY_DATA_BYTES + FRAME_TX_RLP_OVERHEAD
    elif mode in ("4337_evm", "call_evm"):
        v = verify_gas(P, "evm", impl=impl, per_perm=per_perm)
        if mode == "4337_evm":
            n, z = handleops_bytes(B, k)
            exec_ = (ENTRYPOINT_OVERHEAD_GAS if ep_overhead is None else ep_overhead) + k * v
            base = pr.tx_base / bundle + pr.to_cold / bundle
            txb = n + 110                                # + 1559 envelope with the bundler's ECDSA [Mo]
        else:
            if k != 1:
                notes.append("call_evm is the single-signature validation shape; k scales bytes and exec")
            n = 4 + 32 * 5 + _pad32(k * B)
            z = 4 * 32 + 30 + (_pad32(k * B) - k * B)    # offset/length/message words mostly zero [Mo]
            exec_ = k * v
            base = pr.tx_base + pr.to_cold
            txb = n + 110
        standard = base + pr.std_token * std_tokens(z, n - z) + exec_
        floor = base + pr.floor_per_token * floor_tokens(z, n - z, pr)
        cd = n
    elif mode == "agg8288":
        if k > MAX_SIGS_PER_TX:
            notes.append(f"k > MAX_SIGS_PER_TX = {MAX_SIGS_PER_TX}: mempool-invalid under EIP-8288")
        n_frames = 3                                     # DEP + VERIFY + SENDER
        v = LEANSPHINCS_VERIFICATION_GAS                 # fixed by the EIP, independent of B and P
        dep_data = TRIPLE_BYTES * k
        dep_zero = TRIPLE_ZERO_BYTES * k                 # data_hash/key random; data_hash may be 0 (sighash)
        fixed = FRAME_TX_INTRINSIC_COST + n_frames * FRAME_TX_PER_FRAME_COST + vt
        std_cd = pr.std_token * (std_tokens(dep_zero, dep_data - dep_zero)
                                 + std_tokens(VERIFY_DATA_ZERO, VERIFY_DATA_BYTES - VERIFY_DATA_ZERO))
        exec_ = (LEANSPHINCS_VERIFICATION_GAS * k + AGG_VERIFY_FRAME_GAS
                 + AGG_VERIFY_FRAME_GAS_PER_DEP * k + sender)
        stark_gas = LEANSTARK_VERIFICATION_GAS * k       # recursive_stark_gas, intrinsic
        standard = fixed + std_cd + stark_gas + exec_
        floor = fixed + pr.floor_per_token * 4 * (dep_data + VERIFY_DATA_BYTES)
        cd = dep_data + VERIFY_DATA_BYTES
        txb = cd + FRAME_TX_RLP_OVERHEAD + 20
        if not pr.frame_live:
            notes.append("EIP-8141/8288 not live under this pricing; priced hypothetically")
    elif mode == "pcs":
        # leanPCS draft: the tx carries the proof remainder as VERIFY-frame data, its claims as
        # 8288 triples (PCS_SCHEME), the contract runs the remainder's verifier and PCS_OPEN.
        n_frames = 3
        v = 0
        dep_data = TRIPLE_BYTES * pcs_claims
        fixed = FRAME_TX_INTRINSIC_COST + n_frames * FRAME_TX_PER_FRAME_COST + vt
        std_cd = pr.std_token * (std_tokens(TRIPLE_ZERO_BYTES * pcs_claims,
                                            (TRIPLE_BYTES - TRIPLE_ZERO_BYTES) * pcs_claims)
                                 + 4 * pcs_proof)
        exec_ = (PCS_TX_GAS + PCS_CLAIM_GAS * pcs_claims + pcs_exec + AGG_VERIFY_FRAME_GAS + sender)
        stark_gas = LEANSTARK_VERIFICATION_GAS * pcs_claims if pcs_pays_stark_gas else 0
        if pcs_pays_stark_gas:
            notes.append("literal EIP-8288 recursive_stark_gas on PCS triples (draft is silent)")
        standard = fixed + std_cd + exec_ + stark_gas
        floor = fixed + pr.floor_per_token * 4 * (dep_data + pcs_proof)
        cd = dep_data + pcs_proof
        txb = cd + FRAME_TX_RLP_OVERHEAD + 20
        notes.append("B and P do not enter: proof size and claims from leanPCS README (128-sig "
                     "leanXMSS aggregate), not a per-tx leanSPHINCS circuit")
    else:
        raise ValueError(mode)

    total = max(standard, floor)
    return GasTx(mode, pricing, B, P, k, standard, floor, total,
                 "floor" if floor >= standard else "standard", cd, int(txb), v, notes)


def gas_per_tx(B, P, k=1, mode="frame_evm", pricing="7976", **opt):
    """gas_used of one tx (an int, the simulator's `gas_per_tx` contract)."""
    return int(math.ceil(gas_breakdown(B, P, k, mode, pricing, **opt).total))


def agg_gas_per_tx(B, P, k=1, pricing="7976", **opt):
    """S2: one EIP-8288 tx declaring k leanSPHINCS dependencies (the simulator's `agg_gas_per_tx`)."""
    opt.pop("mode", None)
    return gas_per_tx(B, P, k, "agg8288", pricing, **opt)


PCS_KEYS = ("claims_per_tx", "header_bytes", "opening_bytes", "calldata_bytes", "prove_ms",
            "verify_ms", "gas")


def pcs_model(B, P, k=1, pricing="7976", *, opening_bytes=223_334, prove_ms=63.035,
              verify_ms=None, n_variables=22, **opt):
    """S3 on-chain shape in the simulator's `pcs_model` contract.

    On-chain keys are this model's: calldata_bytes = the proof remainder the contract verifies
    (1,004 B [R leanPCS README]), claims_per_tx = 7 [R], gas from gas_breakdown(mode="pcs").
    header_bytes is 0 ON CHAIN: the leanPCS draft hashes each claim into its 96-B triple and the
    contract recomputes point and value ("Why claims are hashed" [E-draft]); the 81 + 24 n header
    travels off chain with the opening (returned as claim_header_bytes).
    opening_bytes / prove_ms / verify_ms are prover-side placeholders passed through (defaults are
    the simulator's own placeholders, not this model's numbers)."""
    opt.pop("mode", None)
    g = gas_breakdown(B, P, k, "pcs", pricing, **opt)
    return {"claims_per_tx": opt.get("pcs_claims", PCS_CLAIMS), "header_bytes": 0,
            "claim_header_bytes": 81 + 24 * n_variables, "opening_bytes": opening_bytes,
            "calldata_bytes": opt.get("pcs_proof", PCS_PROOF_CALLDATA), "prove_ms": prove_ms,
            "verify_ms": AGG_STARK_NATIVE_VERIFY_S * 1e3 if verify_ms is None else verify_ms,
            "gas": int(math.ceil(g.total))}


def tx_bytes(B, P, k=1, mode="frame_evm", **opt):
    return gas_breakdown(B, P, k, mode, **opt).tx_bytes


# ---------------------------------------------------------------------------------------------
# Public-mempool admission (EIP-8141 rule 6, ERC-7562 LIM-010)
# ---------------------------------------------------------------------------------------------

def validation_gas(B, P, k=1, mode="frame_evm", *, impl="lean", per_perm=None, pc_base=None, **_):
    """EIP-8141 public-mempool validation work of one tx (rule 6): the VERIFY frame's execution
    (verifier(s) + frame module) plus the intrinsic signature cost. [Mo] on the recorded module gas."""
    if mode in ("frame_evm", "frame_precompile"):
        v = verify_gas(P, "evm" if mode == "frame_evm" else "precompile", impl=impl,
                       per_perm=per_perm, base=pc_base)
        return k * v + FRAME_MODULE_GAS + FRAME_MODULE_GAS_PER_EXTRA_SIG * (k - 1) + k * ARBITRARY_SIG_GAS
    if mode == "frame_native":
        return k * verify_gas(P, "native", per_perm=per_perm, base=pc_base) + 2_000 + 500 * (k - 1)
    if mode == "agg8288":
        return (LEANSPHINCS_VERIFICATION_GAS * k + AGG_VERIFY_FRAME_GAS + AGG_VERIFY_FRAME_GAS_PER_DEP * k)
    return None


def p_max_public(B, k=1, mode="frame_evm", cap=MAX_VERIFY_GAS, **opt):
    """Largest P whose tx the EIP-8141 public mempool admits (validation_gas <= cap), or None."""
    if validation_gas(B, 0, k, mode, **opt) is None or validation_gas(B, 0, k, mode, **opt) > cap:
        return None
    lo, hi = 0.0, 1.0
    while validation_gas(B, hi, k, mode, **opt) <= cap:
        lo, hi = hi, hi * 2
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if validation_gas(B, mid, k, mode, **opt) <= cap else (lo, mid)
    return lo


def userop_bytes(B, k=1, hybrid=True):
    """abi.encode(PackedUserOperation) size for the SphincsAccount layout (callData execute(), 132 B;
    signature abi.encode(bytes ecdsa65, bytes pq) when hybrid). Checked against the decoded C13 userOp
    [C, data/verify_chain/decode_handleops.out]."""
    sig = (224 + _pad32(k * B)) if hybrid else k * B
    return 9 * 32 + 32 + (32 + _pad32(132)) + 32 + (32 + _pad32(sig))


# ---------------------------------------------------------------------------------------------
# TPS
# ---------------------------------------------------------------------------------------------

def block_fixed_bytes(mode, agg_stark_bytes=AGG_STARK_BYTES_EIP):
    """Bytes a block carries regardless of the PQ txs: header (~600 B [Mo]) and, under 8288/PCS,
    the recursive STARK in the header."""
    return 600 + (agg_stark_bytes if mode in ("agg8288", "pcs") else 0)


def tps_detail(B, P, k=1, mode="frame_evm", gas_limit=GAS_LIMIT_NOW, slot=SLOT_S, pricing="7976",
               fill=1.0, max_block_bytes=None, agg_stark_bytes=AGG_STARK_BYTES_EIP, **opt):
    """TPS = min(gas bound, byte bound) / slot. fill = share of the gas limit the PQ txs get
    (1.0 = the limit, a burst; 0.5 = the EIP-1559 target, sustained). max_block_bytes defaults to
    the EIP-7934 cap; pass a propagation budget from the network simulator to replace it."""
    g = gas_breakdown(B, P, k, mode, pricing, **opt)
    n_gas = fill * gas_limit / g.total
    cap = MAX_RLP_BLOCK_SIZE if max_block_bytes is None else max_block_bytes
    n_bytes = max(0.0, cap - block_fixed_bytes(mode, agg_stark_bytes)) / g.tx_bytes
    n = min(n_gas, n_bytes)
    return {
        "gas_tx": g.total, "gas_binding_path": g.binding, "tx_bytes": g.tx_bytes,
        "txs_per_block_gas": n_gas, "txs_per_block_bytes": n_bytes, "txs_per_block": n,
        "bound": "gas" if n_gas <= n_bytes else "bytes",
        "block_bytes": n * g.tx_bytes + block_fixed_bytes(mode, agg_stark_bytes),
        "tps_tx": n / slot, "tps_sig": k * n / slot,
        "gas": g.as_dict(),
    }


def tps_onchain(B, P, k=1, mode="frame_evm", gas_limit=GAS_LIMIT_NOW, slot=SLOT_S, pricing="7976",
                fill=1.0, max_block_bytes=None, unit="tx", **opt):
    d = tps_detail(B, P, k, mode, gas_limit, slot, pricing, fill, max_block_bytes, **opt)
    return d["tps_tx"] if unit == "tx" else d["tps_sig"]


def tps_noagg(B, P, k=1, gas_limit=GAS_LIMIT_NOW, slot=SLOT_S, **opt):
    """The task's TPS_noagg(B, P, k, gas_limit, slot): S1 frame tx with an EVM verifier."""
    return tps_onchain(B, P, k, opt.pop("mode", "frame_evm"), gas_limit, slot, **opt)


def elasticities(B, P, k=1, mode="frame_evm", rel=1e-4, **kw):
    """d ln TPS / d ln B and d ln TPS / d ln P by central differences (continuous txs per block)."""
    f = lambda b, p: math.log(tps_onchain(b, p, k, mode, **kw))
    hB, hP = B * rel, P * rel
    eB = (f(B + hB, P) - f(B - hB, P)) / (math.log(B + hB) - math.log(B - hB))
    eP = (f(B, P + hP) - f(B, P - hP)) / (math.log(P + hP) - math.log(P - hP))
    return {"B": eB, "P": eP}


def floor_crossover_P(B, k=1, mode="frame_evm", pricing="7976", **opt):
    """Smallest P at which execution makes the standard path bind (P stops being free), or None."""
    lo, hi = 1.0, 1.0
    if gas_breakdown(B, hi, k, mode, pricing, **opt).binding == "standard":
        return 0.0
    while gas_breakdown(B, hi, k, mode, pricing, **opt).binding == "floor":
        hi *= 2
        if hi > 1e7:
            return None
    for _ in range(60):
        mid = (lo + hi) / 2
        if gas_breakdown(B, mid, k, mode, pricing, **opt).binding == "floor":
            lo = mid
        else:
            hi = mid
    return hi


def k_max(B, P, mode="frame_evm", pricing="7976", **opt):
    """Largest k per tx under each per-tx limit (and the overall minimum)."""
    out = {}
    k = 1
    while k <= 4096 and gas_breakdown(B, P, k, mode, pricing, **opt).tx_bytes <= TXPOOL_MAX_TX_BYTES:
        k += 1
    out["txpool_128KiB"] = k - 1
    k = 1
    while k <= 4096 and gas_breakdown(B, P, k, mode, pricing, **opt).total <= TX_MAX_GAS_LIMIT:
        k += 1
    out["eip7825_gas_cap"] = k - 1
    if mode in ("agg8288",):
        out["eip8288_MAX_SIGS_PER_TX"] = MAX_SIGS_PER_TX
    # Limits a tx sent straight to a builder still meets: the geth txpool size and EIP-7825.
    out["min_private"] = min(out.values())
    if mode in ("frame_evm", "frame_precompile", "frame_native"):
        for cap, key in ((MAX_VERIFY_GAS, "eip8141_MAX_VERIFY_GAS_100K"),
                         (MAX_VERIFY_GAS_PROPOSED, "eip8141_MAX_VERIFY_GAS_300K")):
            k = 0
            while k < 4096 and validation_gas(B, P, k + 1, mode, **opt) <= cap:
                k += 1
            out[key] = k
    if mode == "4337_evm":
        k = 0
        while k < 4096 and userop_bytes(B, k + 1) <= MAX_USEROP_SIZE:
            k += 1
        out["erc7562_MAX_USEROP_SIZE"] = k
    # Public mempool: the private limits plus the mempool rule at today's value (100K, 8,192 B).
    out["min"] = min(v for key, v in out.items() if key not in ("min_private",)
                     and not key.endswith("_300K"))
    return out


def sim_inputs(B, P, k=1, mode="frame_evm", gas_limit=GAS_LIMIT_NOW, slot=SLOT_S, pricing="7976",
               fill=1.0, **opt):
    """What the S1 network simulator needs per (B, P, k): tx and block sizes, capacity, limits,
    deadlines, and the one-copy serialisation time of a full block at the EIP-7870 uplinks (a
    per-hop lower bound, not a propagation time)."""
    d = tps_detail(B, P, k, mode, gas_limit, slot, pricing, fill, **opt)
    bb = d["block_bytes"]
    return {
        "tx_bytes": d["tx_bytes"], "gas_tx": d["gas_tx"], "txs_per_block": d["txs_per_block"],
        "block_bytes": bb, "bound": d["bound"], "tps_tx": d["tps_tx"], "tps_sig": d["tps_sig"],
        "k_max": k_max(B, P, mode, pricing, **opt),
        "validation_gas": validation_gas(B, P, k, mode, **opt),
        "public_mempool_ok": (validation_gas(B, P, k, mode, **opt) or 0) <= MAX_VERIFY_GAS
                             if mode != "4337_evm" else userop_bytes(B, k) <= MAX_USEROP_SIZE,
        "userop_bytes": userop_bytes(B, k) if mode == "4337_evm" else None,
        "deadlines_s": DEADLINES_S,
        "one_copy_send_s": {role: bb * 8 / (up * 1e6) for role, (down, up) in BANDWIDTH_7870.items()},
        "max_rlp_block_size": MAX_RLP_BLOCK_SIZE,
    }


# ---------------------------------------------------------------------------------------------
# Self-checks against recorded on-chain receipts and local traces
# ---------------------------------------------------------------------------------------------

def _checks():
    """Reproduce recorded gas exactly (returns list of (label, model, recorded))."""
    out = []
    # ethrex chain 8141 frame txs [M as recorded in /projects/SPHINCs- docs/deployments.md]
    for name, B, P, rec in (("leanSphincs", 5684, 354, 385_322), ("leanSphincs-s", 4164, 259, 288_042),
                            ("leanSphincs-f", 4660, 290, 319_786), ("leanSphincs-layered", 7740, 492, 516_906),
                            ("C13", 3688, 358, 257_578)):
        out.append(("frame " + name, gas_breakdown(B, P, 1, "frame_evm", "7976").total, rec))
    # Sepolia verify txs, Glamsterdam rules [M as recorded, same doc]
    for name, B, P, rec in (("leanSphincs", 5684, 354, 390_040), ("leanSphincs-s", 4164, 259, 293_784),
                            ("leanSphincs-f", 4660, 290, 324_504), ("C13", 3688, 358, 263_064)):
        out.append(("sepolia verify " + name, gas_breakdown(B, P, 1, "call_evm", "7976").total, rec))
    return out


def _table():
    pts = [("leanVM b6167fe4 (=04fba03) / EIP-8288 leanSPHINCS (EVM P=492)", 7740, 492),
           ("Tom's leanSphincs h26 k24 a10", 5684, 354),
           ("sphincs.art selected h24 k25 a10", 5828, 355),
           ("leanSphincs-s", 4164, 259),
           ("3 KB", 3000, 355), ("4 KB", 4000, 355), ("6 KB", 6000, 355), ("8 KB", 8000, 355)]
    print("== self-checks (model vs recorded gas) ==")
    for lab, m, r in _checks():
        print(f"  {lab:34s} model {m:>9,.0f}  recorded {r:>9,}  diff {m - r:+,.0f}")
    print(f"  4337 EntryPoint+account+ECDSA overhead (calibrated, [Mo]): {ENTRYPOINT_OVERHEAD_GAS:,.0f}")
    for pricing in ("7976", "7623"):
        for mode in ("frame_evm", "frame_precompile", "frame_native", "4337_evm", "agg8288", "pcs"):
            if pricing == "7623" and mode not in ("4337_evm",):
                continue
            print(f"\n== S1/S2/S3 mode={mode} pricing={pricing} k=1, gas limit 60M, slot 12 s, fill 1.0 ==")
            print(f"  {'point':58s} {'B':>5s} {'P':>4s} {'gas/tx':>8s} {'path':>8s} {'tx B':>6s} "
                  f"{'TPS@45M':>7s} {'@60M':>6s} {'@100M':>6s} {'@150M':>6s} {'eB':>6s} {'eP':>6s} {'P*':>6s}")
            for lab, B, P in pts:
                g = gas_breakdown(B, P, 1, mode, pricing)
                t = [tps_onchain(B, P, 1, mode, G, pricing=pricing) for G in GAS_LIMITS]
                e = elasticities(B, P, 1, mode, pricing=pricing)
                pc = floor_crossover_P(B, 1, mode, pricing, impl="layered" if B == 7740 else "lean")
                pcs = "-" if pc is None else f"{pc:,.0f}"
                print(f"  {lab:58s} {B:5d} {P:4d} {g.total:8,.0f} {g.binding:>8s} {g.tx_bytes:6d} "
                      f"{t[0]:7.1f} {t[1]:6.1f} {t[2]:6.1f} {t[3]:6.1f} {e['B']:6.3f} {e['P']:6.3f} {pcs:>6s}")
    print("\n== multisig k (frame_evm, 7976, 60M): tx/s and sig/s ==")
    for lab, B, P in pts[:4]:
        row = []
        for k in (1, 2, 3, 5, 8, 16):
            d = tps_detail(B, P, k, "frame_evm", 60e6)
            row.append(f"k={k}: {d['tps_tx']:.2f}/{d['tps_sig']:.1f}")
        print(f"  {lab[:40]:40s} " + "  ".join(row))
        print(f"  {'':40s} k_max {k_max(B, P, 'frame_evm', '7976', impl='layered' if B == 7740 else 'lean')}")
    print("\n== public-mempool admission (EIP-8141 rule 6; ERC-7562 LIM-010), k=1 ==")
    for lab, B, P in pts:
        impl = "layered" if B == 7740 else "lean"
        vg = validation_gas(B, P, 1, "frame_evm", impl=impl)
        pm1, pm3 = (p_max_public(B, 1, "frame_evm", cap, impl=impl) for cap in (MAX_VERIFY_GAS, MAX_VERIFY_GAS_PROPOSED))
        pc = floor_crossover_P(B, 1, "frame_evm", "7976", impl=impl)
        ub = userop_bytes(B)
        print(f"  {lab[:58]:58s} validation {vg:7,.0f} ({100*vg/MAX_VERIFY_GAS:3.0f}% of 100K) P_max {pm1:5.0f} (100K) "
              f"{pm3:5.0f} (300K) vs P* {pc:5.0f}; P headroom {100*(pm1/P-1):+4.0f}%; 4337 userOp {ub:,} B "
              f"{'fits' if ub <= MAX_USEROP_SIZE else 'EXCEEDS'} 8,192")
    print(f"  4337 steady-state EntryPoint overhead [M fork replay]: {ENTRYPOINT_OVERHEAD_STEADY[0]:,.0f} / "
          f"{ENTRYPOINT_OVERHEAD_STEADY[1]:,.0f} (vs first-op {ENTRYPOINT_OVERHEAD_GAS:,.0f})")
    for B, P in ((5684, 354), (4164, 259), (4660, 290), (7740, 492)):
        row = []
        for ov in (ENTRYPOINT_OVERHEAD_GAS,) + ENTRYPOINT_OVERHEAD_STEADY:
            e = elasticities(B, P, 1, "4337_evm", pricing="7623", ep_overhead=ov)
            row.append(f"ov {ov/1e3:5.1f}K: {tps_onchain(B, P, 1, '4337_evm', pricing='7623', ep_overhead=ov):5.1f} tx/s "
                       f"eB {e['B']:+.2f} eP {e['P']:+.2f}")
        print(f"  4337@7623 B={B} P={P}: " + " | ".join(row))
    print("\n== sim inputs, frame_evm, 7976, 60M, k=1 ==")
    for lab, B, P in pts[:4]:
        s = sim_inputs(B, P)
        print(f"  {lab[:40]:40s} tx {s['tx_bytes']} B, {s['txs_per_block']:.1f} tx/block, block "
              f"{s['block_bytes']/1e6:.3f} MB, one-copy send s {', '.join(f'{r}={v:.2f}' for r, v in s['one_copy_send_s'].items())}")


if __name__ == "__main__":
    _table()

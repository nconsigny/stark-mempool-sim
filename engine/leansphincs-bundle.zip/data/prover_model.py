#!/usr/bin/env python3
"""Prover cost model for leanSPHINCS under EIP-8288 (S2) and a leanPCS-only world (S3).

Everything here is a MODEL [Mo] calibrated on deterministic VM row counts [C] and on published or
earlier measured timings [R]/[M]. Notes and provenance: /leansphincs/notes/prover-model.md.

    python3 -I prover_model.py            # prints every table the notes quote

Public API (seconds and bytes; the simulator wants milliseconds, so multiply by 1e3):

    prove_time(n, P=None, B=None, c=0, hw="m4", **kw) -> seconds   one leanVM proof: n raw sigs + c children
    proof_bytes(n, P=None, B=None, c=0, **kw)       -> bytes     that proof's size
    breakdown(n, P, B, c, hw, **kw)                 -> dict      rows, padding, committed words, time split
    node_capacity(P, B, hw, budget_s, c, **kw)      -> int       largest n proven within the budget
    elasticity(P, B, hw, ...)                       -> dict      d ln(node TPS) / d ln P and / d ln B
    verify_time(hw, kind)                           -> seconds   native verification of one aggregate
    wrapper_bytes(k, B, mode, ...)                  -> bytes     EIP-8288 mempool wrapper size
    gas_per_dep(...)                                -> gas       EIP-8288 gas a leanSPHINCS dependency pays
    s3_bundle(n_b, P, B, hw)                        -> dict      leanPCS (S3) costs per proof-carrying tx
    circuit_cost(P, B, hw, ...)                     -> starksim.costs.CircuitCost (or its kwargs)
    size_model_kwargs(P, B, ...)                    -> kwargs for starksim.network.SizeModel

P (permutations per verification) and B (signature bytes) select a signature. Either pass a SigShape
(exact counts for a SPHINCS-family parameter set) or P and B alone; P/B alone scale the 04fba03
leanSPHINCS composition ("shape-preserving", see `rows_from_PB`).
"""

import math
from dataclasses import dataclass, field

# --------------------------------------------------------------------------------------------
# 0. Constants read in leanVM 04fba03 [R] and EIP-8288 [E]
# --------------------------------------------------------------------------------------------
LEANVM_COMMIT = "04fba039b00a11d63367369dc229538eb98cf307"
MAX_RECURSIONS = 16          # rec_aggregation/src/aggregation/mod.rs:71 [R]
MAX_KEYS = 1 << 16           # exclusive cap on claim slots per proof, mod.rs:80 [R]
MAX_MU = 28                  # pcs.rs:51: committed witness <= 2^28 words [R]
MIN_LOG_MEM = 16             # smallest memory seen (agg-s1, agg-s2: MEMORY 2^16) [C]
BYTECODE_WORDS = 1 << 19     # BYTECODE 2^18.902 padded, one committed count column [C][R layout.rs]
COLS = {"XOR": 15, "MUL": 15, "SET": 8, "DEREF": 15, "JUMP": 14}   # tables.rs N per table [R]
KECCAK_WORDS_PER_ROW = 92    # 64 q_keccak slots (SLOT_LOG 6) + 28 committed KECCAK columns; fits
                             # TOTAL_COMMITTED of 17 runs to 0.03 % [C fit]
TABLES = ("XOR", "MUL", "SET", "DEREF", "JUMP", "K")

AGGREGATION_INTERVAL_S = 1.0          # EIP-8288 [E]
MAX_SIGS_PER_TX = 16                  # [E]
MAX_LEANSIG_DEPS_PER_WRAPPER = 16     # [E] "both modes"
LEANSPHINCS_VERIFICATION_GAS = 3000   # [E]
LEANSTARK_VERIFICATION_GAS = 30000    # [E] also charged per triple as recursive_stark_gas [E]
TRIPLE_BYTES = 96                     # [E]


def p2(x):
    """Next power of two (tables, memory and Keccak batches are padded to 2^tau)."""
    if x <= 1:
        return 1
    return 1 << math.ceil(math.log2(x) - 1e-12)


def perm(nbytes):
    """Keccak-256 permutations to absorb nbytes (136-byte rate): primitives::hash::permutations."""
    return nbytes // 136 + 1


# --------------------------------------------------------------------------------------------
# 1. Signature shape -> permutations P, bytes B, and VM rows per verification
# --------------------------------------------------------------------------------------------
# Per-instance opcode mix of each piece of the guest's verify_sig_lean_sphincs + sp_wots, from a
# DBG_PROF per-pc profile of `aggregate --sphincs 16` at 04fba03, attributed by the KECCAK order
# of the straight-line code (data/runs/prof-n16-split.txt, data/tools/sections.py) [C].
MIX = {
    "hmsg_call":  {"K": 1, "DEREF": 2.0, "SET": 7.0, "MUL": 1.5, "XOR": 0.5},
    "digest_bit": {"MUL": 618 / 272, "SET": 60 / 272, "XOR": 354 / 272, "DEREF": 18 / 272, "JUMP": 1 / 272},
    "fors_leaf":  {"K": 1, "MUL": 2.0, "XOR": 2.0},
    "fors_node":  {"K": 1, "XOR": 795 / 240, "MUL": 479 / 240, "SET": 773 / 240},
    "tk_perm":    {"K": 1, "XOR": 5.75, "SET": 0.25},
    "wots_enc":   {"K": 1, "DEREF": 12.0, "MUL": 40 / 3, "XOR": 6.0, "SET": 11 / 3},
    "chain_step": {"K": 1, "XOR": 1.0, "SET": 0.4},
    "pk_cell":    {"XOR": 1.0},          # one XOR per message cell after the first block
    "pk_perm":    {"K": 1},
    "digit_group": {"XOR": 1.24, "SET": 4.69, "DEREF": 68 / 22, "MUL": 2.415, "JUMP": 43.2 / 22},
    "path_node":  {"K": 1, "SET": 3.5, "DEREF": 21 / 26, "JUMP": 3 / 26, "XOR": 76 / 26, "MUL": 50 / 26},
}
# Per-signature rows fitted over N = 32..500 at 04fba03 (worst residual 0.9 %) [C]
LEAF_PER_SIG = {"XOR": 1769.22, "MUL": 1418.02, "SET": 1341.93, "DEREF": 294.22, "JUMP": 136.37,
                "K": 515.62, "MEM": 8603.87, "cycles": 5475.41}
LEAF_BASE = {"XOR": 138.6, "MUL": 212.6, "SET": 17123.6, "DEREF": 869.9, "JUMP": 58.8, "K": 0.0,
             "MEM": 18875.2, "cycles": 18442.2}
# Merge node: per child (16-claim leanSPHINCS children, child mu 23, rate 1/2) and base [C],
# fitted over 2->1, 4->1, 8->1, 16->1 (worst residual 0.04 %).
CHILD_PER = {"XOR": 66792.93, "MUL": 86997.53, "SET": 12045.04, "DEREF": 36072.52, "JUMP": 16510.47,
             "K": 5839.35, "MEM": 342523.3, "cycles": 224242.86}
MERGE_BASE = {"XOR": 483.8, "MUL": 262.4, "SET": 17125.1, "DEREF": 988.4, "JUMP": 169.5, "K": 22.5,
              "MEM": 19522.3, "cycles": 19109.0}
# Child cost against child size [C + Mo]: 2->1 over 16/32/64/125/250-signature children gives
# 224.2K/236.6K/233.7K/242.4K/252.7K cycles a child (children of mu 23/24/24/25/26) [C].
# Model: +7.5K cycles per extra mu of the child, +25.4 cycles and +0.94 KECCAK per extra claim
# (two claim-list walks of 12.7 cycles + 0.47 permutation, leanvm-recursion.md s1.1 [M]).
CHILD_CYC_PER_MU, CHILD_K_PER_MU = 7500.0, 540.0
CHILD_CYC_PER_CLAIM, CHILD_K_PER_CLAIM = 25.4, 0.94
# Memory cells per signature: the hinted signature (B/16 cells) plus a share proportional to
# cycles, calibrated so the 04fba03 shape gives 8,603.87 [Mo].
MEM_PER_CYCLE = (8603.87 - 7740 / 16) / 5475.41


def _add(acc, mix, count):
    for t, v in mix.items():
        acc[t] = acc.get(t, 0.0) + v * count


@dataclass(frozen=True)
class SigShape:
    """A SPHINCS-family verification as leanVM's guest runs it (FIPS 205 layout over Keccak-256,
    n = 16, WOTS+C with a target sum, FORS, a hypertree of len(heights) layers).

    target_sum=None means plain WOTS (average v(2^w-1)/2 steps, no grinding) with its checksum
    chains already counted in v. digit_group is how many digits one dispatch walks (3 at w=2 in
    04fba03; DIGIT_GROUP placeholder)."""
    k: int = 24
    a: int = 10
    heights: tuple = (8, 8, 10)
    w: int = 2
    v: int = 64
    target_sum: object = 128
    n: int = 16
    counter_bytes: int = 4
    digit_group: object = None
    name: str = "leanSPHINCS 04fba03"

    @property
    def h(self):
        return sum(self.heights)

    @property
    def d(self):
        return len(self.heights)

    def digest_bytes(self):
        # FIPS 205 Alg. 19 as in mod.rs: md, tree index, leaf index
        return (math.ceil(self.k * self.a / 8) + math.ceil((self.h - self.heights[0]) / 8)
                + math.ceil(self.heights[0] / 8))

    def chain_steps_per_layer(self):
        top = self.v * ((1 << self.w) - 1)
        return top - self.target_sum if self.target_sum is not None else top / 2

    def counts(self):
        """Hash calls by kind and permutations per verification."""
        prefix = 3 * self.n  # PK.seed + 32-byte ADRS
        calls = math.ceil(self.digest_bytes() / 32)
        c = {
            "hmsg_call": calls * perm(3 * self.n + 32 + 4),
            "fors_leaf": self.k * perm(prefix + self.n),
            "fors_node": self.k * self.a * perm(prefix + 2 * self.n),
            "tk_perm": perm(prefix + self.k * self.n),
            "wots_enc": self.d * perm(prefix + self.n + self.counter_bytes),
            "chain_step": self.d * self.chain_steps_per_layer(),
            "pk_perm": self.d * perm(prefix + self.v * self.n),
            "path_node": self.h * perm(prefix + 2 * self.n),
        }
        return c

    def perms(self):
        return sum(self.counts().values())

    def sig_bytes(self):
        return (self.n + self.k * (self.a + 1) * self.n
                + sum(self.counter_bytes + self.v * self.n + hh * self.n for hh in self.heights))

    def rows(self):
        """VM rows per verification by table, plus memory cells and cycles [Mo, exact at 04fba03]."""
        c = self.counts()
        acc = {}
        for kind in ("hmsg_call", "fors_leaf", "fors_node", "tk_perm", "wots_enc", "chain_step",
                     "pk_perm", "path_node"):
            _add(acc, MIX[kind], c[kind])
        _add(acc, MIX["digest_bit"], 8 * self.digest_bytes())
        cells = (3 + self.v) - 8.5          # T_l message cells past the first block, per layer
        _add(acc, MIX["pk_cell"], self.d * max(cells, 0))
        g = self.digit_group or max(1, 6 // self.w)
        _add(acc, MIX["digit_group"], self.d * math.ceil(self.v / g))
        _add(acc, _MISC, 1)                 # claim list walk, loop and coverage per signature
        acc["cycles"] = sum(acc[t] for t in TABLES)
        acc["MEM"] = MEM_PER_CYCLE * acc["cycles"] + self.sig_bytes() / 16
        return acc


def _misc():
    """Per-signature residual (claims, coverage, loop) so the 04fba03 shape reproduces the fit."""
    base = SigShape()
    acc = {}
    c = base.counts()
    for kind in c:
        _add(acc, MIX[kind], c[kind])
    _add(acc, MIX["digest_bit"], 8 * base.digest_bytes())
    _add(acc, MIX["pk_cell"], base.d * ((3 + base.v) - 8.5))
    _add(acc, MIX["digit_group"], base.d * math.ceil(base.v / 3))
    return {t: LEAF_PER_SIG[t] - acc.get(t, 0.0) for t in TABLES}


_MISC = _misc()
CURRENT = SigShape()
assert CURRENT.perms() == 515 and CURRENT.sig_bytes() == 7740
assert abs(CURRENT.rows()["cycles"] - LEAF_PER_SIG["cycles"]) < 1.0


def rows_from_PB(P, B, mode="shape"):
    """Rows per signature for a signature known only by P and B.

    mode="shape" (default): the 04fba03 composition scaled: every per-hash piece and every
      per-layer piece scales with P/515, the per-signature pieces (H_msg, digest bits, claim)
      stay. mode="fixed-layers": per-layer pieces (encoding, digit dispatch, pk absorb) stay too
      (fewer chains/FORS nodes, same three layers). The two bracket the composition effect."""
    r = (P + 0.62) / LEAF_PER_SIG["K"]   # 0.62: the claim walk's permutation share
    c = CURRENT.counts()
    fixed, per_layer, per_hash = {}, {}, {}
    _add(fixed, MIX["hmsg_call"], c["hmsg_call"])
    _add(fixed, MIX["digest_bit"], 8 * CURRENT.digest_bytes())
    _add(fixed, _MISC, 1)
    _add(per_layer, MIX["wots_enc"], c["wots_enc"])
    _add(per_layer, MIX["digit_group"], 3 * 22)
    _add(per_layer, MIX["pk_cell"], 3 * 58.5)
    for kind in ("fors_leaf", "fors_node", "tk_perm", "chain_step", "pk_perm", "path_node"):
        _add(per_hash, MIX[kind], c[kind])
    acc = {}
    _add(acc, fixed, 1)
    _add(acc, per_hash, r)
    _add(acc, per_layer, r if mode == "shape" else 1.0)
    # keep K exactly P + claim share (per-layer encodings are hashes too)
    acc["K"] = P + 0.62
    acc["cycles"] = sum(acc[t] for t in TABLES)
    acc["MEM"] = MEM_PER_CYCLE * acc["cycles"] + B / 16
    return acc


def sig_rows(P=None, B=None, shape=None, mode="shape"):
    if shape is not None:
        return shape.rows(), shape.perms(), shape.sig_bytes()
    P = CURRENT.perms() if P is None else P
    B = CURRENT.sig_bytes() if B is None else B
    if P == CURRENT.perms() and B == CURRENT.sig_bytes():
        return CURRENT.rows(), P, B
    return rows_from_PB(P, B, mode), P, B


# --------------------------------------------------------------------------------------------
# 2. Proof rows, committed words, padding cliffs
# --------------------------------------------------------------------------------------------
# Children proven at rate 1/4 have fewer WHIR queries: 2->1 over 16-signature children at rate 1/4
# costs 166.2K cycles and 4,232 KECCAK rows a child against 224.2K and 5,839 at rate 1/2 [C].
CHILD_RATE4_CYC, CHILD_RATE4_K = 166182 / 224243, 4232 / 5839


def child_rows(claims, mu, rate=1):
    f = (CHILD_PER["cycles"] + CHILD_CYC_PER_MU * max(0, mu - 23)
         + CHILD_CYC_PER_CLAIM * max(0, claims - 16)) / CHILD_PER["cycles"]
    r = {t: CHILD_PER[t] * f for t in ("XOR", "MUL", "SET", "DEREF", "JUMP", "MEM")}
    r["K"] = CHILD_PER["K"] + CHILD_K_PER_MU * max(0, mu - 23) + CHILD_K_PER_CLAIM * max(0, claims - 16)
    if rate >= 2:
        for t in ("XOR", "MUL", "SET", "DEREF", "JUMP", "MEM"):
            r[t] *= CHILD_RATE4_CYC
        r["K"] *= CHILD_RATE4_K
    r["cycles"] = sum(r[t] for t in TABLES)
    return r


def committed_words(rows, smooth=False):
    """TOTAL_COMMITTED of leanVM 04fba03: 4 memory columns at 2^log_mem, the bytecode count
    column, each table's columns at 2^tau, and 92 words per padded KECCAK row. smooth=True
    replaces every padding by its expected factor over a uniform log2 position (1/ln 2 = 1.443)."""
    pad = (lambda x: x / math.log(2)) if smooth else p2
    w = 4 * max(pad(rows["MEM"]), 1 << MIN_LOG_MEM) + BYTECODE_WORDS
    for t, c in COLS.items():
        w += c * pad(rows[t])
    if rows["K"] > 0:
        w += KECCAK_WORDS_PER_ROW * pad(rows["K"])
    return w


def proof_rows(n, P=None, B=None, c=0, *, shape=None, mode="shape", child_claims=500, child_mu=None, rate=1):
    srows, P, B = sig_rows(P, B, shape, mode)
    base = MERGE_BASE if c > 0 else LEAF_BASE
    rows = {t: base[t] + n * srows[t] for t in TABLES + ("MEM",)}
    if c:
        if child_mu is None:   # a child of that many claims, at most a 2^28-word proof
            child_mu = min(MAX_MU, leaf_mu(min(child_claims, 1185), P, B, shape=shape, mode=mode))
        cr = child_rows(child_claims, child_mu, rate)
        for t in TABLES + ("MEM",):
            rows[t] += c * cr[t]
    rows["cycles"] = sum(rows[t] for t in TABLES)
    return rows


def leaf_mu(n, P=None, B=None, *, shape=None, mode="shape"):
    """mu of a proof over n raw signatures, standing in for a child aggregate of n claims."""
    return math.ceil(math.log2(committed_words(proof_rows(n, P, B, 0, shape=shape, mode=mode))))


# --------------------------------------------------------------------------------------------
# 3. Hardware: T = f0 + w(rate) * W + aK * pad(K) + e_c * cycles + e_k * K
# --------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class HW:
    name: str
    f0: float      # s, per-proof fixed
    w2: float      # s per committed word at rate 1/2
    w4: float      # s per committed word at rate 1/4
    aK: float      # s per padded KECCAK row (keccak_gkr reduction)
    e_c: float     # s per VM cycle (execution)
    e_k: float     # s per executed permutation (execution, native Keccak)
    status: str = "[Mo]"
    note: str = ""


_EC, _EK = 8.9e-9, 330e-9   # Execute fit, leanvm-sphincs-el.md s2.4 (box, two traced runs) [Mo]

HWS = {
    # Least squares on M4 Max timings of 04fba03's README (sphincs500 r1 1.06 s, blobs16 0.699,
    # 2->1 0.159, fib 0.289) plus xmss1400 r2 0.949 for w4; predicts benchmarks.json's 16->1
    # (0.905 s) at +0.2 % out of sample; residuals within +-3.2 % (data/tools/fit_time.py).
    "m4": HW("Apple M4 Max, 16 threads", 53.6e-3, 5.230e-9, 7.590e-9, 1.42e-6, _EC, _EK, "[Mo, cal. R]",
             "leanVM README figure machine; +-3 % on 6 published runs"),
    # This box (Ryzen 9 9955HX3D, 16 cores pinned), alternative: exact fit to its three idle-gated
    # runs (xmss1400 r2 0.915 s, 2->1 0.183, 16->1 1.069), aK = its measured 351 ms at 2^18.
    # It prices sphincs500 at 1.21 s, the top of the band; "box16" below (1.10 s) is the default.
    "box16_fit": HW("this box, 16 threads pinned (3-point fit)", 50.7e-3, 6.763e-9, 7.411e-9, 1.34e-6,
                    _EC, _EK, "[Mo, cal. M]", "3 points, 3 parameters: upper end of the box band"),
}


@dataclass(frozen=True)
class ScaledHW:
    """A machine known only by two whole-proof timings (leanVM doc/site/benchmarks.json, commit
    40f877dc2): an xmss-1400 aggregate (Keccak reduction 39 % of the M4's time) and a 16->1
    recursion (21 %). Its time is the M4 model's times a factor interpolated on the job's Keccak
    share between the two ratios (exact on both calibration jobs) [Mo]."""
    name: str
    s_leaf: float
    s_merge: float
    status: str = "[Mo, cal. R]"
    note: str = ""


_M4_XMSS, _M4_REC16 = 0.949, 0.906          # M4 model on the two calibration jobs (s)
HWS["eip7870"] = ScaledHW("EIP-7870 attester/builder class (Hetzner AX42 proxy, 8C/16T)",
                          1.569 / _M4_XMSS, 1.690 / _M4_REC16,
                          note="AX42 Ryzen 7 PRO 8700GE full threads; 7870: 8c/16t ~25k PassMark MT")
HWS["eip7870_full"] = ScaledHW("EIP-7870 full-node class (AX42 at 4 threads, optimistic)",
                               2.437 / _M4_XMSS, 2.577 / _M4_REC16,
                               note="7870 full node 4c/8t ~3k PassMark MT: likely several x slower")
HWS["epyc9355p"] = ScaledHW("AMD EPYC 9355P 32C/64T (builder-class server)", 0.398 / _M4_XMSS, 0.433 / _M4_REC16)
_KSHARE_LEAF, _KSHARE_MERGE = 0.392, 0.205
# This box at 16 threads pinned: the same interpolation on its idle-gated runs of
# hashmancer-keccak docs/tracks/leanvm-profile.md (xmss1400 r2 0.915 s, 16->1 1.069 s) [Mo, cal. M].
HWS["box16"] = ScaledHW("this box (Ryzen 9 9955HX3D), 16 threads pinned", 0.915 / _M4_XMSS, 1.069 / _M4_REC16,
                        "[Mo, cal. M]", "band: box16_fit is the upper end (sphincs500 1.21 s)")
# 8 threads on this box: factor 1.40 on the whole proof (1.45 on the parallel ~90 %, 1.0 on
# execution) from Amdahl fits of benchmarks.json's EPYC 9355P (Zen 5, 4T->8T) and EX63 (8T->20T);
# band 1.25-1.65 [Mo]. Checked 2026-11-10 against idle-gated ABBA runs of the 04fba03 prover on this
# box (hashmancer-keccak docs/studies/leanvm-port2/abba/results-G5.md): sphincs500 rate 1/4,
# 8T 1770.5 ms / 16T 1282.7 ms = 1.38 [M]. Kept at 1.40 (within 1.5 %); see
# data/verify-prover-model/check_box_measured.out.
_B8 = 1.40
HWS["box8"] = ScaledHW("this box, 8 threads", HWS["box16"].s_leaf * _B8, HWS["box16"].s_merge * _B8, "[Mo]",
                       "box16 x 1.40 (band 1.25-1.65); measured 8T/16T = 1.38 [M, ABBA G5]")


def hw_of(hw):
    return hw if isinstance(hw, HW) else HWS[hw]


# --------------------------------------------------------------------------------------------
# 4. prove_time, proof_bytes, verify_time
# --------------------------------------------------------------------------------------------
def breakdown(n, P=None, B=None, c=0, hw="m4", *, shape=None, mode="shape", rate=1,
              child_claims=500, child_mu=None, smooth=False):
    h = hw_of(hw)
    if isinstance(h, ScaledHW):
        b = breakdown(n, P, B, c, "m4", shape=shape, mode=mode, rate=rate, child_claims=child_claims,
                      child_mu=child_mu, smooth=smooth)
        tot = b["total_s"]
        ks = b["time"]["keccak_reduction"] / tot if tot else 0.0
        f = min(1.0, max(0.0, (ks - _KSHARE_MERGE) / (_KSHARE_LEAF - _KSHARE_MERGE)))
        s = h.s_merge + (h.s_leaf - h.s_merge) * f
        b["time"] = {k: v * s for k, v in b["time"].items()}
        b["total_s"] = tot * s
        b["hw_scale"] = s
        return b
    rows = proof_rows(n, P, B, c, shape=shape, mode=mode, child_claims=child_claims, child_mu=child_mu, rate=rate)
    W = committed_words(rows, smooth)
    padK = (rows["K"] / math.log(2) if smooth else p2(rows["K"])) if rows["K"] > 0 else 0
    w = h.w2 if rate == 1 else h.w4 if rate == 2 else h.w4 * (h.w4 / h.w2) ** (rate - 2)
    t = {"fixed": h.f0, "committed_words": w * W, "keccak_reduction": h.aK * padK,
         "execute": h.e_c * rows["cycles"] + h.e_k * rows["K"]}
    mu = math.ceil(math.log2(W))
    claims = n + c * child_claims
    return {
        "rows": rows, "W": W, "mu": mu, "padded_K": padK, "time": t, "total_s": sum(t.values()),
        "feasible": mu <= MAX_MU and c <= MAX_RECURSIONS and claims < MAX_KEYS,
        "limits": {"mu<=28": mu <= MAX_MU, "c<=16": c <= MAX_RECURSIONS, "claims<2^16": claims < MAX_KEYS},
    }


def prove_time(n, P=None, B=None, c=0, hw="m4", **kw):
    """Seconds for one leanVM proof of n raw leanSPHINCS signatures (P permutations, B bytes each)
    and c merged children (default 500 claims each). Staircase unless smooth=True. [Mo]"""
    return breakdown(n, P, B, c, hw, **kw)["total_s"]


# proof bytes: least squares on 16 rate-1/2 and 4 rate-1/4 proofs (+-10 %) [Mo fit on C]
_PROOF_FIT = {1: (-129.0, 17.87), 2: (-84.0, 12.80)}


def proof_bytes(n, P=None, B=None, c=0, *, rate=1, **kw):
    rows = proof_rows(n, P, B, c, rate=rate, **{k: v for k, v in kw.items() if k in ("shape", "mode", "child_claims", "child_mu")})
    a, b = _PROOF_FIT[min(rate, 2)]
    floor = 250.0 if rate == 1 else 190.0   # smallest proofs seen: 242-264 KiB (r 1/2), 194 (r 1/4) [C]
    return int(1024 * max(floor, a + b * math.log2(committed_words(rows))))


def verify_time(hw="m4", kind="merge"):
    """Native verification of one aggregate: README M4 6.3-7.0 ms (leaves), 9.4 ms (2->1);
    box 6-10 ms [R/C]. Scaled by the hardware's committed-word cost relative to the M4 [Mo]."""
    base = 7.0e-3 if kind == "leaf" else 9.4e-3
    h = hw_of(hw)
    if isinstance(h, ScaledHW):
        return base * h.s_merge
    return base * h.w2 / HWS["m4"].w2


# --------------------------------------------------------------------------------------------
# 5. Node throughput under EIP-8288 and elasticities
# --------------------------------------------------------------------------------------------
def node_capacity(P=None, B=None, hw="m4", budget_s=AGGREGATION_INTERVAL_S, c=1, *, child_claims=500,
                  smooth=False, rate=1, shape=None, mode="shape", n_max=4096):
    """Largest n with prove_time(n, ..., c) <= budget_s and the proof within leanVM's limits."""
    def ok(n):
        b = breakdown(n, P, B, c, hw, shape=shape, mode=mode, rate=rate, child_claims=child_claims, smooth=smooth)
        return b["feasible"] and b["total_s"] <= budget_s
    if not ok(0):
        return 0
    lo, hi = 0, n_max
    # the staircase is monotone in n (more rows never shrink a padding), so bisection is exact
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if ok(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


def per_sig_time(P=None, B=None, hw="m4", *, shape=None, mode="shape", rate=1):
    """Marginal smoothed seconds per raw signature (no cliffs): the d T / d n of the smooth model."""
    t1 = prove_time(400, P, B, 0, hw, shape=shape, mode=mode, rate=rate, smooth=True)
    t0 = prove_time(200, P, B, 0, hw, shape=shape, mode=mode, rate=rate, smooth=True)
    return (t1 - t0) / 200


def elasticity(P=None, B=None, hw="m4", budget_s=1.0, c=1, child_claims=500, rate=1, mode="shape",
               rel=0.10):
    """d ln(TPS)/d ln P and d ln(TPS)/d ln B for one node (central differences of +-rel).
    'smooth' uses the expected-padding model; 'cliff' the staircase capacity."""
    P = CURRENT.perms() if P is None else P
    B = CURRENT.sig_bytes() if B is None else B
    out = {}
    for label, smooth in (("smooth", True), ("cliff", False)):
        def tps(p, b):
            return node_capacity(p, b, hw, budget_s, c, child_claims=child_claims, smooth=smooth,
                                 rate=rate, mode=mode) / AGGREGATION_INTERVAL_S
        base = tps(P, B)
        eP = (math.log(tps(P * (1 + rel), B)) - math.log(tps(P * (1 - rel), B))) / (math.log(1 + rel) - math.log(1 - rel))
        eB = (math.log(tps(P, B * (1 + rel))) - math.log(tps(P, B * (1 - rel)))) / (math.log(1 + rel) - math.log(1 - rel))
        out[label] = {"tps": base, "eP": eP, "eB": eB}
    # per-signature prover cost elasticity (no budget, no cliffs)
    def ts(p, b):
        return per_sig_time(p, b, hw, mode=mode, rate=rate)
    out["per_sig_time_eP"] = (math.log(ts(P * (1 + rel), B)) - math.log(ts(P * (1 - rel), B))) / (math.log(1 + rel) - math.log(1 - rel))
    out["per_sig_time_eB"] = (math.log(ts(P, B * (1 + rel))) - math.log(ts(P, B * (1 - rel)))) / (math.log(1 + rel) - math.log(1 - rel))
    return out


# --------------------------------------------------------------------------------------------
# 6. EIP-8288 wire and gas
# --------------------------------------------------------------------------------------------
def wrapper_bytes(k, B=None, mode=1, *, tx_bytes=300, new_txs=None, proof=None, rlp_per_item=3):
    """Bytes of one EIP-8288 wrapper [transactions, mode, content] carrying k leanSPHINCS deps.

    tx_bytes: a frame tx without its dependency frame (default 300 B [Mo]); every tx also carries
    its 96-byte triple in its dependency frame. Already-sent txs travel as 32-byte hashes
    (new_txs = how many go in full, default all). mode 0: deps + k raw signatures (k <= 16 [E]);
    mode 1: deps + one recursive STARK (proof bytes, default proof_bytes(k, ...))."""
    B = CURRENT.sig_bytes() if B is None else B
    new_txs = k if new_txs is None else new_txs
    txs = new_txs * (tx_bytes + TRIPLE_BYTES + rlp_per_item) + (k - new_txs) * (32 + rlp_per_item)
    deps = k * (TRIPLE_BYTES + rlp_per_item)
    if mode == 0:
        return txs + deps + k * (B + rlp_per_item) + 8
    proof = proof_bytes(k, None, B) if proof is None else proof
    return txs + deps + proof + 8


def gas_per_dep(zero_data_hash=False, floor="7623"):
    """Gas one leanSPHINCS triple adds to its transaction [E]: the frame's limits.execution
    (LEANSPHINCS_VERIFICATION_GAS) + recursive_stark_gas (LEANSTARK_VERIFICATION_GAS per triple,
    'duplicates included') + its 96 calldata bytes (31 zero scheme bytes; data_hash zero when it
    stands for the tx's own sig hash). The floor never binds: execution dwarfs it."""
    zeros = 31 + (32 if zero_data_hash else 0)
    nonzero = TRIPLE_BYTES - zeros
    tokens = zeros + 4 * nonzero
    return LEANSPHINCS_VERIFICATION_GAS + LEANSTARK_VERIFICATION_GAS + 4 * tokens


# --------------------------------------------------------------------------------------------
# 7. S3: leanPCS (refs/leanPCS @ fc482edd) for hash-based signatures
# --------------------------------------------------------------------------------------------
# Measured by leanPCS's authors [R README/AGENTS/KECCAK.md], 128 leanXMSS signatures as one proof
# (17,712 Keccak-f): contract calldata 1,004 B, 42,997 tx gas (EIP-7623, claim price 0, no 21k
# base), 64,256 under EIP-7976; 7 claims in 6 PCS_OPEN calls; trace->pi1->pi2 0.59 s on EPYC
# 9355P (64T); M4: pi1 ~1.99 s at 128 sigs, 4.69 s at 400 (55,316 perms); pi2 1.58 + 0.70 s.
# pi1 capacity: C1 reaches 2^28 words at ~2^16 permutations. Opening proofs (PCS_OPEN v3):
# 354, 344, 276 KB for pi1's three.
S3 = {
    "calldata": 1004, "gas_7623": 42997, "gas_7976": 64256, "claims": 7, "openings": 6,
    "pcs_tx_gas": 5000, "pcs_claim_gas": 1000, "pi1_max_perms": 1 << 16,
    "pi1_m4_fixed_s": 0.72, "pi1_m4_per_perm_s": 71.8e-6, "pi2_m4_s": 1.58 + 0.70,
    "epyc_over_m4": 0.59 / (1.87 + 1.58 + 0.70),
    "opening_proof_bytes": (354e3 + 344e3 + 276e3) / 3,
    # One WHIR opening inside the aggregation guest [Mo]: the WHIR part of a child (open_stacked,
    # queries, paths, dispatch, terminal: 106.5K + 8.3K + 11.5K cycles at mu 26, rate 1/4 leaves,
    # leanvm-recursion.md s1.1 [M]) ~ 126K cycles = 0.56 of a 224K-cycle child.
    "opening_child_share": 126e3 / 224.2e3,
}


def _t_child(hw, claims=16, mu=None, rate=1):
    """Marginal staircase-free seconds to merge one child (smooth model, between 2 and 3 children)."""
    return (prove_time(0, None, None, 3, hw, child_claims=claims, child_mu=mu, smooth=True, rate=rate)
            - prove_time(0, None, None, 2, hw, child_claims=claims, child_mu=mu, smooth=True, rate=rate))


def s3_tx_gas(*, claims=7, calldata=1004, piop_exec_gas=27641, recursive_share=False, extra_calldata=0,
              standard_per_byte=16, floor_per_byte=40, intrinsic=21000):
    """Gas of one S3 proof-carrying tx: pi2's verifier (27,641 execution [R]), PCS_TX_GAS once,
    PCS_CLAIM_GAS per claim [E leanPCS draft], its calldata and the claims' 96-byte triples (all
    bytes priced nonzero), under the EIP-7623 (40/byte floor, default) or EIP-7976 (64) rule.
    recursive_share: EIP-8288's recursive_stark_gas, 30,000 per triple, read literally for PCS
    triples too (the leanPCS draft does not exempt them) [E, ambiguous]."""
    onchain = calldata + claims * TRIPLE_BYTES + extra_calldata
    execution = piop_exec_gas + S3["pcs_tx_gas"] + claims * S3["pcs_claim_gas"]
    if recursive_share:
        execution += claims * LEANSTARK_VERIFICATION_GAS
    return intrinsic + max(standard_per_byte * onchain + execution, floor_per_byte * onchain)


def s3_bundle(n_b, P=None, B=None, hw="m4", *, client_aggregates=True, recursive_share=False,
              floor_per_byte=40, claim_bytes_per_sig=64):
    """Costs of one S3 proof-carrying transaction verifying n_b leanSPHINCS signatures [Mo].

    The prover (wallet host, relayer or bundler) proves the n_b verifications with leanPCS's pi1
    (univariate PIOP over leanVM's Keccak VM, Flock for Keccak-f) and pi2 (recursion); the
    contract runs pi2's verifier in the EVM with MULFIELD and hands 7 claims to PCS_OPEN in 6
    calls; the tx declares 7 PCS_SCHEME triples. client_aggregates=True (the leanPCS draft's
    rationale): the prover also folds its 6 openings into one leanVM STARK, which the mempool
    merges as one child. False: the mempool verifies the 6 WHIR openings itself.
    claim_bytes_per_sig: the bundle proof's public (pk, msg) pairs the contract must bind to the
    user operations it authorizes: 64 B per signature in calldata (0 if msg is recomputed from
    calldata the tx carries anyway and pk read from storage) [Mo].
    Calibrated on leanPCS's measured 128-leanXMSS line (S3 dict) [R]; everything else [Mo]."""
    srows, P, B = sig_rows(P, B)
    perms = n_b * (P + 10)                       # + claim/framing hashes per signature [Mo]
    pi1 = S3["pi1_m4_fixed_s"] + S3["pi1_m4_per_perm_s"] * perms
    t_open = S3["opening_child_share"] * _t_child(hw, claims=16, mu=26)
    t_open_m4 = S3["opening_child_share"] * _t_child("m4", claims=16, mu=26)
    client_agg_m4 = (HWS["m4"].f0 + S3["openings"] * t_open_m4) if client_aggregates else 0.0
    user_m4 = pi1 + S3["pi2_m4_s"] + client_agg_m4
    if client_aggregates:
        mempool = _t_child(hw, claims=S3["claims"], mu=24)
        wire = S3["calldata"] + S3["claims"] * TRIPLE_BYTES + proof_bytes(0, P, B, 2, child_claims=16)
    else:
        mempool = S3["openings"] * t_open
        wire = (S3["calldata"] + S3["claims"] * (TRIPLE_BYTES + 81 + 24 * 28)
                + S3["openings"] * S3["opening_proof_bytes"])
    gas = s3_tx_gas(recursive_share=recursive_share, floor_per_byte=floor_per_byte,
                    extra_calldata=claim_bytes_per_sig * n_b)
    return {
        "fits_pi1": perms <= S3["pi1_max_perms"], "perms": perms,
        "user_prover_m4_s": user_m4, "user_prover_epyc_s": user_m4 * S3["epyc_over_m4"],
        "tx_calldata_bytes": S3["calldata"] + S3["claims"] * TRIPLE_BYTES + claim_bytes_per_sig * n_b,
        "tx_gas": gas, "tx_gas_per_sig": gas / n_b,
        "wrapper_bytes": wire, "wire_bytes_per_sig": wire / n_b,
        "mempool_s_per_tx": mempool, "mempool_s_per_sig": mempool / n_b,
        "s2_mempool_s_per_sig": per_sig_time(P, B, hw),
    }


# --------------------------------------------------------------------------------------------
# 8. Simulator adapters (stark-mempool-sim v2 starksim.costs / starksim.network)
# --------------------------------------------------------------------------------------------
def circuit_cost_kwargs(P=None, B=None, hw="m4", *, child_claims=500, rate=1, mode="shape"):
    """Linear (smooth, no cliffs) prover in the simulator's CircuitCost units: ms_per_hash = 1 and
    every weight in milliseconds. duration(sigs, 0, rec) = overhead + sigs*t_sig + rec*t_child."""
    t_sig = per_sig_time(P, B, hw, mode=mode, rate=rate)
    t_c = (prove_time(0, P, B, 3, hw, child_claims=child_claims, smooth=True, rate=rate, mode=mode)
           - prove_time(0, P, B, 2, hw, child_claims=child_claims, smooth=True, rate=rate, mode=mode))
    t0 = prove_time(1, P, B, 0, hw, smooth=True, rate=rate, mode=mode) - t_sig
    return {"ms_per_hash": 1.0, "overhead_hashes": 1e3 * t0, "sphincs_hashes": 1e3 * t_sig,
            "leanstark_hashes": 1e3 * t_c, "recursive_hashes": 1e3 * t_c,
            "trace_rows_per_hash": 1.0, "trace_cap": math.inf}


def prove_ms_callable(P=None, B=None, hw="m4", *, c=1, child_claims=500, rate=1, shape=None, mode="shape"):
    """A CostTable(prove_recursive=...) callable of a dependency count: the staircase prover time
    (ms) of one node proof over `size` new raw signatures plus c children (basis "deps")."""
    def f(size):
        return 1e3 * prove_time(int(size), P, B, c, hw, child_claims=child_claims, rate=rate, shape=shape, mode=mode)
    return f


def cliffs(P=None, B=None, *, shape=None, mode="shape", n_max=2000, min_jump=0.03):
    """n after which the committed words of a leaf jump by more than min_jump, with the tables
    whose padding doubles at n+1: the batch sizes to stop at."""
    out = []
    prev = proof_rows(1, P, B, 0, shape=shape, mode=mode)
    prevW = committed_words(prev)
    for n in range(2, n_max + 1):
        r = proof_rows(n, P, B, 0, shape=shape, mode=mode)
        W = committed_words(r)
        if W > prevW * (1 + min_jump):
            which = [t for t in TABLES + ("MEM",) if p2(r[t]) > p2(prev[t])]
            out.append((n - 1, W / prevW - 1, which, math.ceil(math.log2(W))))
        prev, prevW = r, W
    return out


def max_sigs_per_proof(P=None, B=None, *, shape=None, mode="shape"):
    """Largest n whose leaf proof keeps mu <= MAX_MU = 28."""
    lo, hi = 1, 20000
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if math.ceil(math.log2(committed_words(proof_rows(mid, P, B, 0, shape=shape, mode=mode)))) <= MAX_MU:
            lo = mid
        else:
            hi = mid - 1
    return lo


def circuit_cost(P=None, B=None, hw="m4", **kw):
    try:
        from starksim.costs import CircuitCost
    except ImportError:
        return circuit_cost_kwargs(P, B, hw, **kw)
    return CircuitCost(**circuit_cost_kwargs(P, B, hw, **kw))


def sim_circuit_cost(perms_per_sig, sigs_per_leaf, *, sig_bytes=None, hw="m4", child_claims=500, rate=1,
                     mode="shape", speedup=1.0):
    """The fork's `circuit_cost(perms_per_sig, sigs_per_leaf, **kw) -> CircuitCost` contract
    (sims/stark-mempool-sim-v2 branch leansphincs, bench/leansphincs/models.py): one leaf of
    sigs_per_leaf signatures, one nested proof, and the per-proof overhead, in milliseconds
    (ms_per_hash = 1/speedup). Smooth (expected padding); use prove_ms_callable for cliffs."""
    from starksim.costs import CircuitCost
    k = circuit_cost_kwargs(perms_per_sig, sig_bytes, hw, child_claims=child_claims, rate=rate, mode=mode)
    return CircuitCost(ms_per_hash=1.0 / speedup, overhead_hashes=k["overhead_hashes"],
                       sphincs_hashes=k["sphincs_hashes"] * sigs_per_leaf,
                       leanstark_hashes=k["leanstark_hashes"], recursive_hashes=k["recursive_hashes"],
                       trace_rows_per_hash=1.0, trace_cap=math.inf)


def sim_verify_cost(perms_per_sig, sigs_per_leaf, *, hw="m4", ns_per_perm=179.0, per_sig_overhead_ms=0.01,
                    per_message_ms=0.0):
    """The fork's `verify_cost` contract: native signature check at ns_per_perm (179 ns, OpenSSL
    Keccak-f on this box [M by the fork's author]) and one STARK-class verification at
    verify_time(hw) (README M4 6.3-9.4 ms [R], scaled) [Mo]."""
    from starksim.costs import NativeVerifyCost
    per_sig = perms_per_sig * ns_per_perm / 1e6 + per_sig_overhead_ms
    return NativeVerifyCost(per_signature=per_sig * sigs_per_leaf, per_stark=1e3 * verify_time(hw),
                            per_message=per_message_ms)


def sim_pcs_model(sig_bytes, perms_per_sig, k, *, hw="m4", client_aggregates=True, recursive_share_gas=None,
                  floor_per_byte=64, claim_bytes_per_sig=64, **_):
    """The fork's `pcs_model(sig_bytes, perms_per_sig, k) -> dict` contract (PCS_KEYS), k the
    signatures one S3 transaction proves. header_bytes is 0 ON CHAIN: the leanPCS draft hashes each
    claim into its 96-byte triple and the contract recomputes point and value [E]; the claims ride
    inside the client STARK's witness. recursive_share_gas: None = 0 (exempt), else per triple."""
    s = s3_bundle(k, perms_per_sig, sig_bytes, hw, client_aggregates=client_aggregates,
                  claim_bytes_per_sig=claim_bytes_per_sig)
    gas = s3_tx_gas(recursive_share=bool(recursive_share_gas), floor_per_byte=floor_per_byte,
                    extra_calldata=claim_bytes_per_sig * k)
    return {
        "claims_per_tx": S3["claims"],
        "header_bytes": 0,
        "opening_bytes": int(s["wrapper_bytes"] - s["tx_calldata_bytes"]),
        "calldata_bytes": S3["calldata"] + claim_bytes_per_sig * k,
        "prove_ms": 1e3 * s["mempool_s_per_tx"],
        "verify_ms": 1e3 * verify_time(hw),
        "gas": int(gas),
        "user_prove_ms_m4": 1e3 * s["user_prover_m4_s"],
        "fits_pi1": s["fits_pi1"],
        "claim_bytes_offchain": 81 + 24 * 28,
    }


def size_model_kwargs(P=None, B=None, *, rate=1, typical_claims=500):
    B = CURRENT.sig_bytes() if B is None else B
    return {"sig_witness": B, "recursive_proof": proof_bytes(0, P, B, 2, rate=rate, child_claims=typical_claims)}


# --------------------------------------------------------------------------------------------
# 9. Tables for the notes
# --------------------------------------------------------------------------------------------
def _tables():
    pr = print
    pr(f"leanVM {LEANVM_COMMIT[:7]} leanSPHINCS: P={CURRENT.perms()} B={CURRENT.sig_bytes()}")
    r = CURRENT.rows()
    pr("per-signature rows: " + ", ".join(f"{t} {r[t]:.0f}" for t in TABLES) +
       f", MEM {r['MEM']:.0f}, cycles {r['cycles']:.0f} ({r['cycles'] / CURRENT.perms():.2f}/perm)")
    pr("\n[A] model vs measured timings")
    for hw, n, meas in (("m4", 500, 1.06),):
        pr(f"  {hw} sphincs {n}: model {prove_time(n, hw=hw):.3f} s, README {meas} s")
    pr("\n[B] prove_time (s) for n raw sigs, c children of 500 claims, rate 1/2, staircase")
    hws = ("box8", "box16", "box16_fit", "m4", "eip7870", "eip7870_full", "epyc9355p")
    pr("  n    c  " + "  ".join(f"{h:>12s}" for h in hws) + "   mu  proof KiB")
    for n, c in ((16, 0), (119, 0), (120, 0), (239, 0), (240, 0), (480, 0), (500, 0), (1000, 0),
                 (0, 2), (0, 16), (200, 1), (400, 1), (200, 3)):
        b = breakdown(n, c=c)
        pr(f"  {n:4d} {c:2d}  " + "  ".join(f"{prove_time(n, c=c, hw=h):12.3f}" for h in hws)
           + f"   {b['mu']:2d}  {proof_bytes(n, c=c) / 1024:6.1f}" + ("" if b["feasible"] else "  INFEASIBLE"))
    pr("\n[B2] per-proof fixed and per-child merge costs (s, staircase)")
    for hw in hws:
        f1 = prove_time(1, c=0, hw=hw)
        ch = (prove_time(0, c=16, hw=hw) - prove_time(0, c=2, hw=hw)) / 14
        ch16 = (prove_time(0, c=16, hw=hw, child_claims=16) - prove_time(0, c=2, hw=hw, child_claims=16)) / 14
        pr(f"  {hw:12s} one-signature proof {f1:.3f}; marginal child (500 claims) {ch:.3f}; (16 claims) {ch16:.3f}; verify {1e3 * verify_time(hw):.1f} ms")
    pr("\n[B3] padding cliffs of the leaf (largest n before a >3 % jump in committed words), P = 515")
    for n, j, which, mu in cliffs():
        pr(f"  n={n:5d}: +{100 * j:.0f} % words at n+1 ({', '.join(which)}), mu then {mu}")
    pr(f"  max sigs per proof (mu <= 28): {max_sigs_per_proof()}; at P=250: {max_sigs_per_proof(250, 3800)}")
    pr("\n[C] decomposition at n = 480, c = 1 (M4, staircase / smooth), share of time")
    for smooth in (False, True):
        b = breakdown(480, c=1, smooth=smooth)
        tot = b["total_s"]
        pr(f"  smooth={smooth}: total {tot:.3f} s; " + ", ".join(f"{k} {v / tot:.0%}" for k, v in b["time"].items()))
    pr("\n[D] per-signature marginal (smooth) seconds, and its split into P-, cycle- and B-driven parts (M4)")
    h = HWS["m4"]
    for P in (250, 350, 515, 750):
        rows = rows_from_PB(P, CURRENT.sig_bytes()) if P != 515 else CURRENT.rows()
        f = 1 / math.log(2)
        kpart = h.aK * f * rows["K"] + h.w2 * f * KECCAK_WORDS_PER_ROW * rows["K"] + h.e_k * rows["K"]
        cpart = h.w2 * f * sum(COLS[t] * rows[t] for t in COLS) + h.e_c * rows["cycles"]
        mpart = h.w2 * f * 4 * MEM_PER_CYCLE * rows["cycles"]
        bpart = h.w2 * f * 4 * CURRENT.sig_bytes() / 16
        tot = kpart + cpart + mpart + bpart
        pr(f"  P={P:4d}: {1e3 * tot:.3f} ms/sig  Keccak-proportional {kpart / tot:.0%}, ALU tables {cpart / tot:.0%},"
           f" memory {mpart / tot:.0%}, signature hints (B) {bpart / tot:.1%}; cycles/sig {rows['cycles']:.0f}")
    pr("\n[E] node capacity (sigs per 1 s interval) and elasticities, c = 1 own aggregate of 500 claims")
    for hw in ("box8", "box16", "m4", "eip7870", "eip7870_full"):
        for P in (250, 350, 500, 515, 750):
            for budget in (1.0, 0.7):
                e = elasticity(P, None, hw, budget_s=budget, c=1)
                pr(f"  {hw:8s} P={P:4d} budget {budget:.1f}s: TPS smooth {e['smooth']['tps']:5.0f} "
                   f"eP {e['smooth']['eP']:+.2f} eB {e['smooth']['eB']:+.3f} | cliff TPS {e['cliff']['tps']:5.0f} "
                   f"eP {e['cliff']['eP']:+.2f} eB {e['cliff']['eB']:+.3f} | per-sig time eP {e['per_sig_time_eP']:+.2f} eB {e['per_sig_time_eB']:+.3f}")
    pr("\n[F] composition bracket: per-signature time elasticity to P, shape vs fixed-layers (M4)")
    for P in (250, 350, 500, 750):
        a = elasticity(P, None, "m4", mode="shape")["per_sig_time_eP"]
        b = elasticity(P, None, "m4", mode="fixed-layers")["per_sig_time_eP"]
        pr(f"  P={P}: shape {a:+.2f}, fixed-layers {b:+.2f}")
    pr("\n[G] explicit shapes")
    for s in (CURRENT,
              SigShape(k=14, a=14, name="FORS k14 a14 (study s4.3)"),
              SigShape(k=11, a=14, heights=(8, 8, 8), name="q_s 2^24: d3 (8,8,8), FORS 11x14"),
              SigShape(k=11, a=14, heights=(10, 10), name="q_s 2^20: d2 (10,10), FORS 11x14")):
        r = s.rows()
        pr(f"  {s.name:36s} P {s.perms():4d} B {s.sig_bytes():5d} cycles {r['cycles']:6.0f} "
           f"M4 per-sig {1e3 * per_sig_time(shape=s):.3f} ms; capacity M4 c=1 1s {node_capacity(shape=s, hw='m4', c=1)}")
    pr("\n[H] EIP-8288 wrapper bytes with k signatures (new txs, tx 300 B), mode 0 vs mode 1")
    for k in (1, 4, 16, 45, 64, 128, 500):
        m0 = wrapper_bytes(k, mode=0) if k <= MAX_LEANSIG_DEPS_PER_WRAPPER else None
        pr(f"  k={k:4d}: mode0 {m0 if m0 else '(>16: invalid)'}  mode1 {wrapper_bytes(k, mode=1)}")
    pr(f"  gas per leanSPHINCS dep: {gas_per_dep()} (data_hash nonzero), {gas_per_dep(True)} (zero data_hash)")
    pr("\n[I] rate 1/4 vs 1/2 (M4): n = 480, c = 1")
    for rate in (1, 2):
        pr(f"  rate 1/{2 ** rate}: {prove_time(480, c=1, rate=rate):.3f} s, proof {proof_bytes(480, c=1, rate=rate) / 1024:.0f} KiB")
    pr("\n[J] S3 leanPCS bundle costs (M4 mempool), P = 515; gas EIP-7623 / EIP-7976 floor, exempt / literal 8288 share")
    for nb in (1, 16, 64, 124):
        for ca in (True, False):
            s = s3_bundle(nb, client_aggregates=ca)
            g = [s3_tx_gas(recursive_share=r, floor_per_byte=f, extra_calldata=64 * nb) for f in (40, 64) for r in (False, True)]
            pr(f"  n_b={nb:4d} client_agg={ca!s:5s} fits {s['fits_pi1']} user M4 {s['user_prover_m4_s']:.2f} s EPYC {s['user_prover_epyc_s']:.2f} s; "
               f"tx {s['tx_calldata_bytes']} B; gas {g[0]}/{g[1]} (7623) {g[2]}/{g[3]} (7976); wrapper {s['wrapper_bytes'] / 1024:.0f} KiB; "
               f"mempool {1e3 * s['mempool_s_per_tx']:.0f} ms/tx = {1e3 * s['mempool_s_per_sig']:.2f} ms/sig (S2 {1e3 * s['s2_mempool_s_per_sig']:.2f})")
    pr("\n[J2] S3 at full pi1 bundles (n_b = 2^16 / (P + 10)) vs P, M4, client aggregation")
    for P in (250, 350, 515, 750):
        nb = (1 << 16) // (P + 10)
        s = s3_bundle(nb, P, None)
        pr(f"  P={P}: n_b {nb}, gas/sig {s['tx_gas_per_sig']:.0f}, mempool {1e3 * s['mempool_s_per_sig']:.2f} ms/sig (S2 {1e3 * s['s2_mempool_s_per_sig']:.2f}), "
           f"user M4 {s['user_prover_m4_s']:.1f} s ({1e3 * s['user_prover_m4_s'] / nb:.0f} ms/sig), wire {s['wire_bytes_per_sig']:.0f} B/sig")
    pr("\n[K] simulator adapter, CircuitCost kwargs (ms)")
    for hw in ("box16", "m4", "eip7870"):
        k = circuit_cost_kwargs(None, None, hw)
        pr(f"  {hw}: overhead {k['overhead_hashes']:.1f} ms, per sig {k['sphincs_hashes']:.3f} ms, per child {k['recursive_hashes']:.1f} ms")
    pr(f"  SizeModel: {size_model_kwargs()}")
    pr("\n[L] hardware profiles")
    for k, h in HWS.items():
        if isinstance(h, ScaledHW):
            pr(f"  {k:12s} M4 model x {h.s_leaf:.3f} (Keccak-heavy job) .. x {h.s_merge:.3f} (merge job)  {h.status} {h.note}")
            continue
        pr(f"  {k:12s} f0 {1e3 * h.f0:6.1f} ms  w2 {1e9 * h.w2:.3f} ns  w4 {1e9 * h.w4:.3f} ns  aK {1e6 * h.aK:.2f} us  "
           f"e_c {1e9 * h.e_c:.1f} ns  e_k {1e9 * h.e_k:.0f} ns  {h.status} {h.note}")


if __name__ == "__main__":
    _tables()

"""The page's entry points into bench.leansphincs (web/ENGINE.md).

This module is packed into the site's archive as `web/lsweb.py` and runs
inside Pyodide, in the worker. It also runs natively (build.py calls it to
write site/data/scenarios.json), so every function here is plain Python.

A run goes through the command line's own functions: the configuration is
turned into the argument list of `python3 -m bench.leansphincs run`, parsed
by the harness's parser, resolved by `knobs_from` and evaluated by
`evaluate`, and the row is serialised as `main` serialises it. Nothing of
the simulator is reimplemented here.

The bundle mirrors the campaign's layout below its root, so the harness's
own relative lookups (data/phase2, data/network_params.json) resolve inside
it; `LEANSPHINCS_MODELS` is set as well.
"""

import copy
import json
import math
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIM_DIR = os.path.join(ROOT, "sims", "stark-mempool-sim-v2")
MODELS_DIR = os.path.join(ROOT, "data", "phase2")
# The network parameter files. "v2" is the file every phase-2b table was run
# with; "v1" is the harness's built-in default (data/network_params.json).
NETWORKS = {
    "v2": os.path.join(ROOT, "data", "phase2b", "network_params_v2.json"),
    "v1": os.path.join(ROOT, "data", "network_params.json"),
}
DEFAULT_NETWORK = "v2"
# The same files in the campaign checkout, for the command a user can paste.
NETWORK_SOURCES = {"v2": "data/phase2b/network_params_v2.json",
                   "v1": "data/network_params.json"}

# Settings of `run` and `evaluate_model` -> the flag of the command line.
# Every flag of `python3 -m bench.leansphincs run` that takes one value.
FLAGS = {
    "scenario": "--scenario", "candidate": "--candidate",
    "sig_bytes": "--sig-bytes", "perms": "--perms", "k": "--k",
    "gas_limit": "--gas-limit", "byte_limit": "--byte-limit",
    "profile": "--profile", "uplinks": "--uplinks", "nodes": "--nodes",
    "measured_slots": "--measured-slots", "warmup_slots": "--warmup-slots",
    "drain_slots": "--drain-slots", "seed": "--seed", "mode": "--mode",
    "tps": "--tps", "load_factor": "--load-factor",
    "load_basis": "--load-basis", "batch": "--batch", "degree": "--degree",
    "uplink_mbps": "--uplink-mbps", "latency_ms": "--latency-ms",
    "client_proofs": "--client-proofs", "block_fanout": "--block-fanout",
    "cpu_discipline": "--cpu-discipline", "wrapper_queue": "--wrapper-queue",
    "block_relay": "--block-relay", "egress_priority": "--egress-priority",
    "relay_policy": "--relay-policy", "compat": "--compat",
}
# The order the flags are written in (the result does not depend on it).
FLAG_ORDER = tuple(FLAGS)
# Keys of a configuration that are not flags.
OTHER_KEYS = ("network", "override_limits", "time_limit_s")
# Progress and the time limit are checked every so many simulator events.
PROGRESS_EVENTS = 2000
PROGRESS_SECONDS = 0.25

ELASTICITY_STEPS = (10, 25, 50, 100)
# The campaign's sweeps moved bytes and permutations over these ranges
# (sims/LEANSPHINCS-FORK.md, "Named scenarios").
SWEEP_RANGE = {"sig_bytes": (2000, 10000), "perms": (150, 1000)}
GAS_LIMITS = (60_000_000, 200_000_000, 300_000_000)

_progress = None
_state = {"ready": False}


def setup():
    """Put the simulator on the import path, once."""
    if _state["ready"]:
        return
    if SIM_DIR not in sys.path:
        sys.path.insert(0, SIM_DIR)
    os.environ["LEANSPHINCS_MODELS"] = MODELS_DIR
    _state["ready"] = True


def set_progress(callback):
    """`callback(text)` receives one JSON object per progress event."""
    global _progress
    _progress = callback


def _report(**event):
    if _progress is not None:
        _progress(json.dumps(event))


def _load_json(*parts):
    path = os.path.join(ROOT, *parts)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def manifest():
    """What the archive holds: commit, file hashes (written by build.py)."""
    return _load_json("web", "manifest.json") or {}


def limits():
    """The run limits of web/limits.json (copied into the archive)."""
    return _load_json("web", "limits.json") or {}


def info():
    setup()
    found = manifest()
    return {
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "root": ROOT,
        "simulator_commit": found.get("simulator", {}).get("commit"),
        "simulator_branch": found.get("simulator", {}).get("branch"),
        "pyodide": found.get("pyodide", {}).get("version"),
        "networks": dict(NETWORKS),
        "default_network": DEFAULT_NETWORK,
    }


# -- the scenario list --------------------------------------------------------

def _profiles(network):
    with open(NETWORKS[network], encoding="utf-8") as handle:
        return list(json.load(handle)["profiles"])


def _limits_for(entry, knobs, found):
    """The limits of one configuration: its class's, then its own."""
    result = dict(found.get("by_class", {}).get(entry["class"], {}))
    result.update(found.get("by_id", {}).get(entry["id"], {}))
    result.update(found.get("by_configuration", {}).get(
        entry["configuration"], {}))
    return result


def scenarios():
    """One record per configuration, with the settings it accepts.

    The records are the registry's (`python3 -m bench.leansphincs scenarios
    --json`) with `settings` (name -> type, default, allowed values or
    range), `limits` (what a browser run is held to) and `explore_only`.
    """
    setup()
    from bench.leansphincs import registry
    from bench.leansphincs.scenario import DEFAULTS
    found = limits()
    names = list(registry.PHASE2B_CANDIDATES)
    more = [name for name in registry.candidate_names() if name not in names]
    profiles = _profiles(DEFAULT_NETWORK)
    result = []
    for entry in registry.entries():
        knobs = dict(DEFAULTS)
        knobs.update(registry.configuration(entry["configuration"]))
        cap = _limits_for(entry, knobs, found)
        fixed_uplinks = (knobs.get("set") or {}).get("uplinks")
        settings = {
            "candidate": {"type": "choice", "default": knobs["candidate"],
                          "values": names, "more_values": len(more)},
            "sig_bytes": {"type": "int", "default": knobs["sig_bytes"],
                          "min": 1, "swept": list(SWEEP_RANGE["sig_bytes"]),
                          "follows": "candidate"},
            "perms": {"type": "int", "default": knobs["perms"], "min": 1,
                      "swept": list(SWEEP_RANGE["perms"]),
                      "follows": "candidate"},
            "k": {"type": "int", "default": knobs["k"], "min": 1},
            "gas_limit": {"type": "int", "default": knobs["gas_limit"],
                          "min": 0, "values": list(GAS_LIMITS)},
            "profile": {"type": "choice", "default": knobs["profile"],
                        "values": profiles},
            "uplinks": {"type": "choice", "default": knobs["uplinks"],
                        "values": ["uniform", "heterogeneous"]},
            "nodes": {"type": "int", "default": knobs["nodes"],
                      "min": cap.get("min_nodes", 12),
                      "max": cap.get("max_nodes", knobs["nodes"])},
            "measured_slots": {"type": "int",
                               "default": knobs["measured_slots"], "min": 1,
                               "max": cap.get("max_measured_slots",
                                              knobs["measured_slots"])},
            "seed": {"type": "int", "default": knobs["seed"], "min": 0},
            "mode": {"type": "choice", "default": knobs["mode"],
                     "values": ["run", "capacity"]},
            "network": {"type": "choice", "default": DEFAULT_NETWORK,
                        "values": list(NETWORKS)},
        }
        if cap.get("max_gas_limit"):
            # Above it a browser run is too long (web/limits.json).
            settings["gas_limit"]["max"] = cap["max_gas_limit"]
            settings["gas_limit"]["values"] = [
                value for value in GAS_LIMITS if value <= cap["max_gas_limit"]]
        if entry["id"] == "F3":
            settings["k"]["follows"] = "perms: 65536 // (perms + 10)"
        if entry["class"] == "pcs":
            settings["client_proofs"] = {
                "type": "choice", "default": knobs["client_proofs"],
                "values": ["merge", "draft", "relay"]}
        if fixed_uplinks:
            # The configuration lists one uplink per node: the node count
            # and the uplinks are part of it.
            settings["nodes"].update(min=len(fixed_uplinks),
                                     max=len(fixed_uplinks),
                                     values=[len(fixed_uplinks)])
            settings["uplinks"].update(values=[knobs["uplinks"]])
        record = dict(entry)
        record["settings"] = settings
        record["limits"] = cap
        record["explore_only"] = bool(cap.get("explore_only", False))
        record["browser_defaults"] = cap.get("browser_defaults", {})
        result.append(record)
    return {"scenarios": result, "ids": list(registry.IDS),
            "default_configuration": dict(registry.DEFAULT_CONFIGURATION),
            "budget_s": found.get("budget_s"),
            "time_limit_s": found.get("time_limit_s"),
            "table_nodes": found.get("table_nodes"),
            "limits_basis": found.get("basis")}


def candidates(all_names=False):
    """The eight candidates of PHASE2B.md section 2, as the registry has
    them; with `all_names`, every alias of candidates_v2.csv as well."""
    setup()
    from bench.leansphincs import registry
    names = list(registry.PHASE2B_CANDIDATES)
    if all_names:
        names = registry.candidate_names()
    result = []
    for name in names:
        spec = registry.candidate(name)
        counted = spec["counted"]
        result.append({
            "name": name, "params": spec["params"],
            "sig_bytes": spec["sig_bytes"], "perms": spec["perms"],
            "impl": spec["impl"], "p_scale": spec.get("p_scale"),
            "prover_rows": "counted" if counted else "modelled",
            "counted_shape": counted[0] if counted else None,
            "counted_rows": counted[1] if counted else None,
            "headline": name in registry.PHASE2B_CANDIDATES,
        })
    return {"candidates": result,
            "more_names": len(registry.candidate_names()) - len(names)}


# -- one run ------------------------------------------------------------------

def _flag_value(value):
    if isinstance(value, bool):
        raise ValueError("a setting takes a number or a string")
    if isinstance(value, float) and value == int(value) and math.isfinite(
            value):
        # JSON numbers arrive as floats from some callers; an integer flag
        # must read as one.
        return str(int(value))
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True)
    return str(value)


def argv_for(config, network_paths=None):
    """The arguments of `python3 -m bench.leansphincs run` for a
    configuration. Unknown keys are refused, null values are skipped."""
    unknown = [key for key in config
               if key not in FLAGS and key not in OTHER_KEYS]
    if unknown:
        raise ValueError(f"unknown setting {', '.join(sorted(unknown))}; "
                         f"known: {', '.join(FLAG_ORDER + OTHER_KEYS)}")
    if not config.get("scenario"):
        raise ValueError("a configuration needs `scenario`")
    argv = []
    for key in FLAG_ORDER:
        value = config.get(key)
        if value is None or value == "":
            continue
        argv.extend([FLAGS[key], _flag_value(value)])
    network = config.get("network") or DEFAULT_NETWORK
    if network not in NETWORKS:
        raise ValueError(f"network must be one of {', '.join(NETWORKS)}")
    paths = network_paths or NETWORKS
    if network != "v1":
        argv.extend(["--network-params", paths[network]])
    return argv


def command_for(config):
    """The command line that reproduces a configuration in the campaign
    checkout (from sims/stark-mempool-sim-v2)."""
    paths = {name: "../../" + source
             for name, source in NETWORK_SOURCES.items()}
    words = []
    for word in argv_for(config, paths):
        safe = all(ch.isalnum() or ch in "-_./=@+:" for ch in word)
        words.append(word if safe else "'" + word.replace("'", "'\\''") + "'")
    return "python3 -m bench.leansphincs run " + " ".join(words)


def knobs_for(config):
    """The resolved knobs, through the command line's parser."""
    setup()
    from bench.leansphincs.__main__ import knobs_from, parser
    argv = argv_for(config)
    try:
        args = parser().parse_args(argv)
    except SystemExit as error:
        raise ValueError(f"the command line refused {argv}") from error
    return argv, knobs_from(args)


def check_limits(config):
    """Why a browser run of this configuration is refused, as a list."""
    setup()
    from bench.leansphincs import registry
    if not config.get("scenario"):
        raise ValueError("a configuration needs `scenario`")
    name = registry.configuration_name(config["scenario"])
    for record in scenarios()["scenarios"]:
        if record["configuration"] == name:
            break
    else:
        return []
    reasons = []
    cap = record["limits"]
    if record["explore_only"]:
        reasons.append(f"{name} is explore-only in the browser: "
                       f"{cap.get('reason', 'too slow')}")
    for key in ("nodes", "measured_slots"):
        value = config.get(key)
        if value is None:
            value = record["settings"][key]["default"]
        bound = record["settings"][key]
        if value > bound["max"]:
            reasons.append(f"{key} {value} is above the browser limit "
                           f"{bound['max']} for {name}")
        if value < bound["min"]:
            reasons.append(f"{key} {value} is below {bound['min']}")
    gas = config.get("gas_limit")
    top = record["settings"]["gas_limit"].get("max")
    if gas is not None and top and (gas <= 0 or gas > top):
        reasons.append(f"gas_limit {gas} is above the browser limit {top} "
                       f"for {name}")
    return reasons


def run(config):
    """One run. Returns the row the command line prints (both forms).

    `row` is what `python3 -m bench.leansphincs run <argv>` prints,
    `phase2_row` what it prints with `--phase2-row`; `row_text` and
    `phase2_text` are the exact lines. Progress events go to the callback
    of `set_progress`.
    """
    setup()
    from bench.common import _json_value
    from bench.leansphincs import scenario as scenario_module
    from bench.leansphincs.schema import phase2_row
    from starksim.netsim import NetworkSim
    config = dict(config)
    override = bool(config.pop("override_limits", False))
    time_limit = config.pop("time_limit_s", None)
    if time_limit is None and not override:
        time_limit = limits().get("time_limit_s")
    time_limit = float(time_limit or 0)
    if not override:
        reasons = check_limits(config)
        if reasons:
            raise ValueError("; ".join(reasons)
                             + " (pass override_limits to run it anyway)")
    started = time.perf_counter()
    argv, knobs = knobs_for(config)
    probes = knobs["capacity_max_runs"] if knobs["mode"] == "capacity" else 1
    slot = knobs["slot_ms"]
    horizon = (knobs["birth_slots"] + knobs["drain_slots"]) * slot
    state = {"probe": 0, "rate": None, "watched": None, "reported": started}
    original_run = scenario_module.run
    original_sim_run = NetworkSim.run

    def run_with_progress(run_knobs, *args, **kwargs):
        state["probe"] += 1
        state["rate"] = run_knobs.get("tps")
        _report(event="probe", probe=state["probe"], max_probes=probes,
                offered_tps=state["rate"], mode=knobs["mode"])
        return original_run(run_knobs, *args, **kwargs)

    def watch(sim):
        """A post-event hook on one simulation's engine: every
        PROGRESS_EVENTS events it looks at the wall clock, reports the
        simulated time at most every PROGRESS_SECONDS, and stops a run that
        is over its time limit. It reads the engine and changes nothing."""
        engine = sim.engine
        counter = [0]

        def hook(_kind):
            counter[0] += 1
            if counter[0] % PROGRESS_EVENTS:
                return
            now = time.perf_counter()
            if time_limit and now - started > time_limit:
                raise TimeoutError(
                    f"stopped after {now - started:.0f} s: over the time "
                    f"limit of {time_limit:g} s (probe {state['probe']}, "
                    f"simulated {engine.now / 1000.0:.1f} of "
                    f"{horizon / 1000.0:.0f} s). Fewer nodes or slots, or "
                    "mode 'run', make it shorter")
            if now - state["reported"] >= PROGRESS_SECONDS:
                state["reported"] = now
                _report(event="tick", probe=state["probe"],
                        max_probes=probes, sim_ms=engine.now,
                        horizon_ms=horizon, elapsed_s=now - started)

        engine.after_event(hook)

    def sim_run_with_progress(self, until=None):
        if state["watched"] is not self:
            state["watched"] = self
            watch(self)
        processed = original_sim_run(self, until=until)
        _report(event="segment", probe=state["probe"], max_probes=probes,
                sim_ms=until, horizon_ms=horizon, events=processed)
        if until is not None and until >= horizon:
            # The simulation's last segment: let it go.
            state["watched"] = None
        return processed

    scenario_module.run = run_with_progress
    NetworkSim.run = sim_run_with_progress
    try:
        row = scenario_module.evaluate(knobs)
    finally:
        scenario_module.run = original_run
        NetworkSim.run = original_sim_run
        state["watched"] = None
    row["knobs"] = knobs
    tidy = phase2_row(row)
    row_text = json.dumps(_json_value(row), sort_keys=True, allow_nan=False)
    phase2_text = json.dumps(_json_value(tidy), sort_keys=False,
                             allow_nan=False)
    return {
        "row": json.loads(row_text),
        "phase2_row": json.loads(phase2_text),
        "row_text": row_text,
        "phase2_text": phase2_text,
        "argv": argv,
        "command": command_for(config),
        "timing": {"python_s": time.perf_counter() - started,
                   "runtime_s": row.get("runtime_s"),
                   "probes": state["probe"]},
    }


# -- the model alone ----------------------------------------------------------

def _modelled(knobs):
    """The knobs with the prover's rows modelled instead of counted.

    At a candidate whose parameter set was counted on leanVM runs the
    registry hands the circuit model those rows; any other point is the
    model's composition. An elasticity must compare like with like, so its
    points are all priced by the composition."""
    circuit = knobs["models"].get("circuit_cost") or {}
    if "counted_rows" not in (circuit.get("kwargs") or {}):
        return knobs
    knobs = copy.deepcopy(knobs)
    del knobs["models"]["circuit_cost"]["kwargs"]["counted_rows"]
    knobs["prover_cost"] = "modelled [Mo]"
    return knobs


def _bounds(config, modelled=False):
    """The analytic bounds of one point, as a capacity search computes them
    before its first run (`scenario.find_capacity`)."""
    from bench.leansphincs import scenario as scenario_module
    _argv, knobs = knobs_for(config)
    if modelled:
        knobs = _modelled(knobs)
    _sim, plan = scenario_module.build(dict(knobs, tps=1.0, batch=1))
    shape = plan["shape"]
    circuit = plan["circuit"]
    point = {
        "sig_bytes": knobs["sig_bytes"], "perms": knobs["perms"],
        "k": knobs["k"], "candidate": knobs["candidate"],
        "gas_limit": knobs["gas_limit"], "byte_limit": knobs["byte_limit"],
        "tx_gas": shape.gas, "tx_onchain_bytes": shape.onchain_bytes,
        "tx_wire_bytes": shape.wire_bytes,
        "txs_per_block_gas": (knobs["gas_limit"] // shape.gas
                              if knobs["gas_limit"] > 0 else None),
        "prover_cost": knobs.get("prover_cost"),
        "prove_ms_per_tx": None,
    }
    if circuit is not None:
        point["prove_ms_per_tx"] = (circuit.sphincs_hashes
                                    * circuit.ms_per_hash)
    point.update(plan["bounds"])
    return knobs, point


def _tps(point, basis):
    return point[basis + "_bound_tps"]


def evaluate_model(config):
    """The analytic model at one point, without a simulation [Mo].

    Gas and bytes of one transaction, the bound of each resource in
    transactions per second and which binds (`ideal_*`: gas, bytes and
    prover; `analytic_*` adds the rough bandwidth estimate), all from
    `bench.leansphincs.scenario.analytic_bounds` on the scenario's own
    model modules. Elasticities are of `ideal_bound_tps`:

    - `eps_B`, `eps_P`: the log-log slope between the point 10 % below and
      10 % above (bytes and permutations rounded to integers);
    - `dB10` ... `dB100`, `dP10` ... `dP100`: the change of the bound in
      percent when bytes or permutations grow by that many percent.

    The campaign's tables compute the same columns from simulated grids
    (`schema.fill_elasticities`); these are the model's, evaluated at the
    exact points instead of interpolated. Every point of an elasticity is
    priced by the modelled prover rows, also where the headline bound uses
    a candidate's counted rows (`elasticity_basis`, `elasticity_base_tps`).
    """
    setup()
    started = time.perf_counter()
    config = dict(config)
    config.pop("override_limits", None)
    config.pop("time_limit_s", None)
    knobs, point = _bounds(config)
    result = dict(point)
    # The elasticities' own base: the same point with modelled prover rows.
    counted = _modelled(knobs) is not knobs
    base = _tps(_bounds(config, modelled=True)[1], "ideal") if counted \
        else _tps(point, "ideal")
    result["elasticity_base_tps"] = base
    result["elasticity_basis"] = (
        "modelled prover rows at every point [Mo]; the headline bound "
        "prices this candidate's counted rows [C]" if counted
        else "the model at every point [Mo]")
    result["scenario"] = knobs["scenario_id"] or knobs["scenario"]
    result["class"] = knobs["scenario"]
    result["pricing"] = knobs["pricing"]
    result["variant"] = knobs["variant"]
    headline = _tps(point, "ideal")
    result["tps_sig_bound"] = headline * knobs["k"] if headline > 0 else -1.0
    result["status"] = "[Mo]"

    def moved(axis, factor):
        value = max(1, int(round(knobs[axis] * factor)))
        other = dict(config)
        other["sig_bytes"] = knobs["sig_bytes"]
        other["perms"] = knobs["perms"]
        other[axis] = value
        return value, _tps(_bounds(other, modelled=True)[1], "ideal")

    steps = {}
    for axis, name in (("sig_bytes", "B"), ("perms", "P")):
        low, low_tps = moved(axis, 1 / 1.1)
        high, high_tps = moved(axis, 1.1)
        slope = None
        if low_tps > 0 and high_tps > 0 and high != low:
            slope = math.log(high_tps / low_tps) / math.log(high / low)
        result["eps_" + name] = slope
        result["eps_" + name + "_points"] = [[low, low_tps],
                                             [high, high_tps]]
        for step in ELASTICITY_STEPS:
            value, there = moved(axis, 1 + step / 100.0)
            change = None
            if base > 0 and there >= 0:
                change = 100.0 * (there / base - 1.0)
            result[f"d{name}{step}"] = change
            steps[f"{name}+{step}%"] = {axis: value,
                                        "ideal_bound_tps": there}
    result["steps"] = steps
    result["gas_breakdown"] = gas_breakdown(config, point)
    result["command"] = command_for(config)
    result["timing"] = {"python_s": time.perf_counter() - started}
    return result


# -- gas of one transaction, split ----------------------------------------------

GAS_PARTS = ("fixed", "calldata", "verification", "overhead")
GAS_STATUS = {
    "E0a": {
        "total": "[Mo] EIP-7623 or EIP-7976 calldata rules [E] on the measured parts below",
        "fixed": "[E] transaction base (21,000; 12,000 + 3,000 cold account under EIP-2780)",
        "calldata": "[E] price per token; [Mo] the handleOps calldata layout (EntryPoint v0.9, one userOp)",
        "verification": "[Mo] fitted gas per permutation of recorded verifiers (150 single layer, 167 layered)",
        "overhead": "[M replay] EntryPoint and account overhead, calibrated on a Sepolia handleOps receipt, steady state",
    },
    "E0b": {
        "total": "[Mo] EIP-7623 or EIP-7976 calldata rules [E] on the measured parts below",
        "fixed": "[E] transaction base (21,000; 12,000 + 3,000 cold account under EIP-2780)",
        "calldata": "[E] price per token; [Mo] the module call's calldata layout",
        "verification": "[Mo] fitted gas per permutation of recorded verifiers (150 single layer, 167 layered)",
        "overhead": "[M] Safe v1.4.1 module path on anvil with a mock verifier (25,077), the copy of the signature to memory [E] and the action, 1 wei to a cold account (9,300) [E]",
    },
    "E0c": {
        "total": "[Mo] EIP-7623 or EIP-7976 calldata rules [E] on the measured parts below",
        "fixed": "[E] transaction base (21,000; 12,000 + 3,000 cold account under EIP-2780)",
        "calldata": "[E] price per token; [Mo] the delegate call's calldata layout",
        "verification": "[Mo] fitted gas per permutation of recorded verifiers (150 single layer, 167 layered)",
        "overhead": "[M] EIP-7702 delegate path on anvil with a mock verifier (12,251), the copy of the signature to memory [E] and the action, 1 wei to a cold account (9,300) [E]",
    },
    "A": {
        "total": "[Mo] EIP-8141 with EIP-7976 [E]; reproduces five recorded frame transactions to the gas",
        "fixed": "[E] frame transaction 12,000, 475 per frame, 100 per signature entry, 6,000 for the value transfer",
        "calldata": "[E] 4 gas per token on the standard path, 16 on the floor; every signature byte is 4 tokens",
        "verification": "[Mo] fitted gas per permutation of recorded verifiers (150 single layer, 167 layered)",
        "overhead": "[M as recorded] frame module 7,900 and SENDER frame 3,000, from frame transactions on the ethrex testnet; 2,000 per extra signature [Mo]",
    },
    "B": {
        "total": "[Mo] EIP-8141 with an enshrined scheme, as EIPs PR #12616 lays it out (a draft)",
        "fixed": "[E] frame transaction 12,000, 475 per frame, 6,000 for the value transfer",
        "calldata": "[E/Mo] the signature and the 32-byte key at the configuration's byte price",
        "verification": "[R/Mo] the scheme's gas: PR #12616 (25.5 per permutation, rounded up to 100), EIP-8288's flat 3,000, or proportional to native verify time",
        "overhead": "[Mo] VERIFY frame (2,000 + 2,100 per key) and SENDER frame 3,000 [M as recorded]",
    },
    "C1": {
        "total": "[Mo] an EIP-8288 dependency frame with raw signatures in the block; this price is the campaign's own assumption",
        "fixed": "[E] frame transaction 12,000, 475 per frame, 6,000 for the value transfer",
        "calldata": "[E/Mo] the 96-byte triple and the signature (witness) at the configuration's byte price",
        "verification": "[E/Mo] the scheme's gas per signature (flat 3,000 in EIP-8288, or the variant's)",
        "overhead": "[Mo] VERIFY frame 5,900 + 2,100 per dependency, SENDER frame 3,000",
    },
    "agg8288": {
        "total": "[Mo] models_agg.dep_tx_gas: a frame transaction with dependency frames",
        "fixed": "[Mo] 28,517: the frame transaction with one dependency frame, before the dependencies' own charges",
        "calldata": "[Mo] 3,264 per dependency: the 96-byte triple (message hash, key, scheme) at EIP-7976 prices",
        "verification": "[E] per dependency: 3,000 leanSPHINCS verification plus 30,000 recursive STARK gas in EIP-8288 (33,000); 3,000 in the leanPCS draft",
        "overhead": "none in this model",
    },
    "pcs": {
        "total": "[Mo on R] models_agg.f_tx_gas: the leanPCS repository's transaction gas at 128 and 400 signatures, interpolated, re-floored under EIP-7976",
        "fixed": "[E] transaction base 21,000",
        "calldata": "[Mo on R] proof calldata 1,005 B, frame 193 B and 64 B of claim (key, message) per signature; 64 gas per byte when the floor binds, 16 for the claims on the standard path",
        "verification": "[R] the proof-checking transaction of the leanPCS repository without its base (57,883 at 128 signatures, 58,669 at 400): execution and its own proof calldata, not split by the source",
        "overhead": "none in this model",
    },
}


def _model_modules():
    setup()
    if MODELS_DIR not in sys.path:
        sys.path.insert(0, MODELS_DIR)
    import models_agg
    import models_noagg
    return models_noagg, models_agg


def _noagg_paths(mn, variant, sig_bytes, perms, k, kwargs):
    """(model result, standard-path parts, floor-path parts) of one
    no-aggregation transaction. Every figure is the model module's: its
    `tx_model` result, its constants, or a difference of two of its calls."""
    cm = mn.cm
    scen, fixed_kw, _label = mn.VARIANTS[variant]
    args = dict(fixed_kw)
    args.setdefault("g_round", True)
    args.update(kwargs)
    model = mn.tx_model(scen, sig_bytes, perms, k, **args)
    kb = k * sig_bytes
    if scen in ("E0a", "E0b", "E0c"):
        price = cm.PRICING[args["pricing"]]
        fixed = price.tx_base + price.to_cold
        # The calldata's standard tokens: EIP-7623's floor counts exactly
        # them, so the model's own floor under 7623 gives the token count.
        old = cm.PRICING["7623"]
        tokens = (mn.tx_model(scen, sig_bytes, perms, k,
                              **dict(args, pricing="7623"))["floor"]
                  - old.tx_base - old.to_cold) / old.floor_per_token
        verification = k * cm.verify_gas(perms, "evm",
                                         impl=args.get("impl", "lean"),
                                         per_perm=args.get("per_perm"))
        standard = {"fixed": fixed, "calldata": price.std_token * tokens,
                    "verification": verification}
        floor = {"fixed": fixed, "calldata": model["floor"] - fixed,
                 "verification": 0.0}
        sig_price = {"standard": 4 * price.std_token,
                     "floor": 4 * price.floor_per_token}
    elif scen == "A":
        price = cm.PRICING["7976"]
        fixed = (cm.FRAME_TX_INTRINSIC_COST + 2 * cm.FRAME_TX_PER_FRAME_COST
                 + k * cm.ARBITRARY_SIG_GAS + cm.TX_VALUE_COST)
        frame = cm.std_tokens(cm.VERIFY_DATA_ZERO,
                              cm.VERIFY_DATA_BYTES - cm.VERIFY_DATA_ZERO)
        verification = k * cm.verify_gas(perms, "evm",
                                         impl=args.get("impl", "lean"),
                                         per_perm=args.get("per_perm"))
        standard = {"fixed": fixed,
                    "calldata": price.std_token * (frame + 4 * kb),
                    "verification": verification}
        floor = {"fixed": fixed, "calldata": model["floor"] - fixed,
                 "verification": 0.0}
        sig_price = {"standard": 4 * price.std_token,
                     "floor": 4 * price.floor_per_token}
    else:
        byte_price = args["byte_price"]
        std_sig = min(16, byte_price)
        frames = 2 if scen == "B" else 3
        fixed = (mn.FRAME_TX_INTRINSIC_COST + mn.TX_VALUE_COST
                 + frames * mn.FRAME_TX_PER_FRAME_COST)
        frame = cm.std_tokens(mn.VERIFY_DATA_ZERO,
                              mn.VERIFY_DATA_BYTES - mn.VERIFY_DATA_ZERO)
        verification = k * model["G"]
        if scen == "B":
            calldata = (mn.STANDARD_TOKEN_COST * frame
                        + k * (mn.STANDARD_TOKEN_COST * 4
                               * mn.LEANSPHINCS_PK_BYTES)
                        + std_sig * kb)
            if args.get("floor_rule") == "pr12559":
                # PR #12559: verification and value cost leave the floor.
                floor = {"fixed": mn.FRAME_TX_INTRINSIC_COST,
                         "calldata": (model["floor"]
                                      - mn.FRAME_TX_INTRINSIC_COST),
                         "verification": 0.0}
            else:
                floor = {"fixed": fixed, "verification": verification,
                         "calldata": model["floor"] - fixed - verification}
        else:
            triples = cm.std_tokens(
                mn.TRIPLE_ZERO * k, (mn.TRIPLE_BYTES - mn.TRIPLE_ZERO) * k)
            calldata = (mn.STANDARD_TOKEN_COST * (triples + frame)
                        + std_sig * kb)
            floor = {"fixed": fixed, "calldata": model["floor"] - fixed,
                     "verification": 0.0}
        standard = {"fixed": fixed, "calldata": calldata,
                    "verification": verification}
        sig_price = {"standard": std_sig, "floor": byte_price}
    standard["overhead"] = model["standard"] - sum(standard.values())
    floor["overhead"] = model["floor"] - sum(floor.values())
    return scen, model, standard, floor, sig_price


def _whole_parts(parts, total):
    """The parts as whole gas that sum to the transaction's gas: each part
    rounded, the rounding (under 2 gas) taken by the largest one."""
    whole = {name: int(round(parts[name])) for name in GAS_PARTS}
    largest = max(GAS_PARTS, key=lambda name: whole[name])
    whole[largest] += total - sum(whole.values())
    return whole


def gas_breakdown(config, point=None):
    """The gas of one transaction of a configuration, split [Mo].

    `total` is the gas the harness charges for the transaction (the
    `tx_gas` of `evaluate_model`); `parts` splits it into fixed cost,
    calldata, verification and overhead on the path that binds (the
    transaction pays the larger of the standard path and the calldata
    floor), in whole gas that sums to `total`. `standard` and `floor` hold
    both paths. Where the signature never reaches the chain (EIP-8288
    dependencies, leanPCS claims) `signature_on_chain` is false and the
    parts describe what is paid instead.
    """
    mn, ma = _model_modules()
    if point is None:
        knobs, point = _bounds(config)
    else:
        _argv, knobs = knobs_for(config)
    cls = knobs["scenario"]
    sig_bytes, perms, k = knobs["sig_bytes"], knobs["perms"], knobs["k"]
    total = int(point["tx_gas"])
    result = {
        "scenario": knobs["scenario_id"] or cls, "class": cls,
        "pricing": knobs["pricing"], "variant": knobs["variant"],
        "candidate": knobs["candidate"], "sig_bytes": sig_bytes,
        "perms": perms, "k": k, "total": total,
        "onchain_bytes": point["tx_onchain_bytes"],
    }
    if cls == "noagg":
        spec = knobs["models"]["gas_per_tx"]
        variant = spec["fn"].split(":gas_", 1)[1]
        scen, model, standard, floor, sig_price = _noagg_paths(
            mn, variant, sig_bytes, perms, k, spec.get("kwargs") or {})
        key = scen
        paths = {"standard": (model["standard"], standard),
                 "floor": (model["floor"], floor)}
        binds = model["path"]
        result.update(
            signature_on_chain=True, model="models_noagg:gas_" + variant,
            signature_byte_price=sig_price[binds],
            signature_calldata=k * sig_bytes * sig_price[binds],
            verification_executed=standard["verification"],
            scheme_gas=model.get("G"),
            evm_verifier=(spec.get("kwargs") or {}).get("impl")
            if scen in ("E0a", "E0b", "E0c", "A") else None)
    elif cls == "agg8288":
        spec = knobs["models"]["agg_gas_per_tx"]
        kwargs = dict(spec.get("kwargs") or {})
        dep_gas = kwargs.get("dep_gas", 33_000)
        per_dep = kwargs.get("calldata_per_dep", ma.TRIPLE_CALLDATA_GAS)
        dep_bytes = kwargs.get("dep_bytes", ma.am.TRIPLE)
        floor_total = (
            ma.cm.gas_breakdown(7740, 515, k, "agg8288", "7976").floor
            - kwargs.get("floor_per_byte", 64) * (ma.am.TRIPLE - dep_bytes)
            * k)
        standard = {"fixed": ma.TX0, "calldata": k * per_dep,
                    "verification": k * dep_gas, "overhead": 0.0}
        fixed = (ma.cm.FRAME_TX_INTRINSIC_COST
                 + 3 * ma.cm.FRAME_TX_PER_FRAME_COST + ma.cm.TX_VALUE_COST)
        floor = {"fixed": fixed, "calldata": floor_total - fixed,
                 "verification": 0.0, "overhead": 0.0}
        standard_total = sum(standard.values())
        key = "agg8288"
        paths = {"standard": (standard_total, standard),
                 "floor": (floor_total, floor)}
        binds = "floor" if floor_total > standard_total else "standard"
        result.update(
            signature_on_chain=False, model="models_agg:agg_gas_per_tx",
            signature_byte_price=0, signature_calldata=0,
            verification_executed=standard["verification"],
            dependencies=k, gas_per_dependency_charge=dep_gas,
            calldata_gas_per_dependency=per_dep,
            dependency_bytes=dep_bytes)
    elif cls == "pcs":
        kwargs = dict(knobs["models"]["pcs_model"].get("kwargs") or {})
        pricing = kwargs.get("pricing", "7976")
        claim = kwargs.get("claim_bytes_per_sig", 64)
        bundle = min(k, ma.f_bundle_cap(perms))
        extra = bundle * claim
        onchain = ma.F["calldata"] + ma.F["frame_bytes"] + extra
        # The standard side of f_tx_gas: the repository's transaction gas
        # at 128 and 400 signatures, interpolated on log2 of the bundle.
        slope = ((ma.F["tx_gas_400"] - ma.F["tx_gas_128"])
                 / math.log2(400 / 128))
        measured = ma.F["tx_gas_128"] + slope * math.log2(
            max(bundle, 1) / 128)
        per_byte = {"7623": 40, "7976": 64}[pricing]
        standard = {"fixed": ma.F["intrinsic"], "calldata": 16 * extra,
                    "verification": measured, "overhead": 0.0}
        floor = {"fixed": ma.F["intrinsic"], "calldata": per_byte * onchain,
                 "verification": 0.0, "overhead": 0.0}
        key = "pcs"
        paths = {"standard": (sum(standard.values()), standard),
                 "floor": (sum(floor.values()), floor)}
        binds = "floor" if paths["floor"][0] > paths["standard"][0] \
            else "standard"
        result.update(
            signature_on_chain=False, model="models_agg:f_tx_gas",
            signature_byte_price=0, signature_calldata=0,
            verification_executed=measured, signatures_proved=bundle,
            claim_bytes_per_signature=claim,
            proof_calldata_bytes=ma.F["calldata"] + ma.F["frame_bytes"])
    else:
        raise ValueError(f"no gas model for class {cls!r}")
    path_total, parts = paths[binds]
    if abs(math.ceil(path_total - 1e-9) - total) > 1:
        raise ValueError(
            f"gas breakdown of {result['scenario']} {knobs['candidate']} "
            f"k={k}: the split's {binds} path gives {path_total:.1f}, the "
            f"harness charges {total}")
    for name, (_total, values) in paths.items():
        if min(values.values()) < -0.5:
            raise ValueError(f"negative part in the {name} path: {values}")
    whole = _whole_parts(parts, total)
    signatures = result.get("signatures_proved", k)
    result.update(
        binds=binds, parts=whole,
        calldata_share=whole["calldata"] / total,
        standard={"total": paths["standard"][0], **paths["standard"][1]},
        floor={"total": paths["floor"][0], **paths["floor"][1]},
        signatures=signatures, gas_per_signature=total / signatures,
        status=GAS_STATUS[key], status_key=key)
    return result


def gas_table(configs):
    """`gas_breakdown` of each configuration, in one call (the build)."""
    return {"rows": [gas_breakdown(config) for config in configs]}


def aggregation_compare(candidate="P99r", gas_limit=60_000_000, deps=16):
    """The like-for-like figures of notes/phase3/aggregation-check.md [Mo],
    from the model modules: gas per signature and the gas-bound signatures
    per second at `gas_limit` for the price what-ifs of EIP-8288 at `deps`
    dependencies per transaction, for a user-side bundle whose signatures
    each pay a frame transaction's overhead, and the bundler's proving rate
    (which no simulated node is charged for)."""
    _mn, ma = _model_modules()
    f3 = gas_breakdown({"scenario": "F3", "candidate": candidate})
    perms, sig_bytes, bundle = f3["perms"], f3["sig_bytes"], f3["signatures"]
    full, light = ma.DEP_GAS["8288"], ma.DEP_GAS["pcsdraft"]

    def case(tx_gas, signatures, what):
        return {"what": what, "tx_gas": tx_gas, "signatures": signatures,
                "gas_per_signature": round(tx_gas / signatures, 3),
                "sig_per_s": gas_limit / ma.SLOT_S / tx_gas * signatures}

    bundler = ma.f_costs("F3", perms, sig_bytes, "epyc9355p", bundle)
    return {
        "candidate": candidate, "gas_limit": gas_limit, "deps": deps,
        "max_deps_per_tx": 16,
        "status": "[Mo] data/phase2/models_agg.py: dep_tx_gas, TX0, "
                  "TRIPLE_CALLDATA_GAS, f_costs, node_capacity_s",
        "source": "notes/phase3/aggregation-check.md",
        "tx_overhead": ma.TX0,
        "per_dependency": {"charge": full, "calldata": ma.TRIPLE_CALLDATA_GAS,
                           "charge_light": light},
        "cases": {
            "once_per_tx": case(
                ma.dep_tx_gas(deps, light) + (full - light), deps,
                f"{light} gas per dependency and {full - light} of recursive "
                f"STARK gas once per transaction, {deps} dependencies"),
            "per_dep_light": case(
                ma.dep_tx_gas(deps, light), deps,
                f"{light} gas per dependency, {deps} dependencies"),
            "limit_8288": case(
                full + ma.TRIPLE_CALLDATA_GAS, 1,
                "EIP-8288 as written, the limit for any number of "
                "dependencies: the charge and the triple's calldata"),
            "f3_with_tx_overhead": case(
                f3["gas_per_signature"] + ma.TX0, 1,
                "a bundled signature that also pays a frame transaction's "
                "overhead (TX0)"),
        },
        "bundler": {
            "machine": "epyc9355p", "cores": ma.CORES["epyc9355p"],
            "bundle": bundler["k"], "prove_s": bundler["prove_s"],
            "sig_per_s_per_machine": bundler["sig_per_s_per_machine"],
            "mempool_merge_ms": 1e3 * bundler["mempool_merge_s"],
            "leaf_prover_sig_per_s": ma.node_capacity_s(
                perms, sig_bytes, "epyc9355p"),
        },
    }


# -- dispatch -----------------------------------------------------------------

METHODS = {
    "info": lambda args: info(),
    "scenarios": lambda args: scenarios(),
    "candidates": lambda args: candidates(bool(args.get("all"))),
    "run": lambda args: run(args.get("config", args)),
    "evaluate_model": lambda args: evaluate_model(args.get("config", args)),
    "check_limits": lambda args: {"reasons": check_limits(
        args.get("config", args))},
    "gas_breakdown": lambda args: gas_breakdown(args.get("config", args)),
    "gas_table": lambda args: gas_table(args.get("configs", [])),
    "aggregation_compare": lambda args: aggregation_compare(**args),
}


def call(method, text="{}"):
    """One API call: JSON text in, JSON text out."""
    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}; "
                         f"known: {', '.join(METHODS)}")
    return json.dumps(METHODS[method](json.loads(text or "{}")),
                      allow_nan=False)


if __name__ == "__main__":
    print(call(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "{}"))

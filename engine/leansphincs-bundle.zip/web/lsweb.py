"""The page's entry points into bench.leansphincs (web/ENGINE.md).

This module is packed into the site's archive as `web/lsweb.py` and runs
inside Pyodide, in the worker. It also runs natively (build.py calls it to
write site/data/scenarios.json), so every function here is plain Python.

A run goes through the command line's own functions: the configuration is
turned into the argument list of `python3 -m bench.leansphincs run`, parsed
by the harness's parser, resolved by `knobs_from` and evaluated by
`evaluate`, and the row is serialised as `main` serialises it. Nothing of
the simulator is reimplemented here.

The bundle mirrors the campaign's layout below its root, so the harness's
own relative lookups (data/phase2, data/network_params.json) resolve inside
it; `LEANSPHINCS_MODELS` is set as well.
"""

import copy
import json
import math
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIM_DIR = os.path.join(ROOT, "sims", "stark-mempool-sim-v2")
MODELS_DIR = os.path.join(ROOT, "data", "phase2")
# The network parameter files. "v2" is the file every phase-2b table was run
# with; "v1" is the harness's built-in default (data/network_params.json).
NETWORKS = {
    "v2": os.path.join(ROOT, "data", "phase2b", "network_params_v2.json"),
    "v1": os.path.join(ROOT, "data", "network_params.json"),
}
DEFAULT_NETWORK = "v2"
# The same files in the campaign checkout, for the command a user can paste.
NETWORK_SOURCES = {"v2": "data/phase2b/network_params_v2.json",
                   "v1": "data/network_params.json"}

# Settings of `run` and `evaluate_model` -> the flag of the command line.
# Every flag of `python3 -m bench.leansphincs run` that takes one value.
FLAGS = {
    "scenario": "--scenario", "candidate": "--candidate",
    "sig_bytes": "--sig-bytes", "perms": "--perms", "k": "--k",
    "gas_limit": "--gas-limit", "byte_limit": "--byte-limit",
    "profile": "--profile", "uplinks": "--uplinks", "nodes": "--nodes",
    "measured_slots": "--measured-slots", "warmup_slots": "--warmup-slots",
    "drain_slots": "--drain-slots", "seed": "--seed", "mode": "--mode",
    "tps": "--tps", "load_factor": "--load-factor",
    "load_basis": "--load-basis", "batch": "--batch", "degree": "--degree",
    "uplink_mbps": "--uplink-mbps", "latency_ms": "--latency-ms",
    "client_proofs": "--client-proofs", "block_fanout": "--block-fanout",
    "cpu_discipline": "--cpu-discipline", "wrapper_queue": "--wrapper-queue",
    "block_relay": "--block-relay", "egress_priority": "--egress-priority",
    "relay_policy": "--relay-policy", "compat": "--compat",
}
# The order the flags are written in (the result does not depend on it).
FLAG_ORDER = tuple(FLAGS)
# Keys of a configuration that are not flags.
OTHER_KEYS = ("network", "override_limits", "time_limit_s")
# Progress and the time limit are checked every so many simulator events.
PROGRESS_EVENTS = 2000
PROGRESS_SECONDS = 0.25

ELASTICITY_STEPS = (10, 25, 50, 100)
# The campaign's sweeps moved bytes and permutations over these ranges
# (sims/LEANSPHINCS-FORK.md, "Named scenarios").
SWEEP_RANGE = {"sig_bytes": (2000, 10000), "perms": (150, 1000)}
GAS_LIMITS = (60_000_000, 200_000_000, 300_000_000)

_progress = None
_state = {"ready": False}


def setup():
    """Put the simulator on the import path, once."""
    if _state["ready"]:
        return
    if SIM_DIR not in sys.path:
        sys.path.insert(0, SIM_DIR)
    os.environ["LEANSPHINCS_MODELS"] = MODELS_DIR
    _state["ready"] = True


def set_progress(callback):
    """`callback(text)` receives one JSON object per progress event."""
    global _progress
    _progress = callback


def _report(**event):
    if _progress is not None:
        _progress(json.dumps(event))


def _load_json(*parts):
    path = os.path.join(ROOT, *parts)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def manifest():
    """What the archive holds: commit, file hashes (written by build.py)."""
    return _load_json("web", "manifest.json") or {}


def limits():
    """The run limits of web/limits.json (copied into the archive)."""
    return _load_json("web", "limits.json") or {}


def info():
    setup()
    found = manifest()
    return {
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "root": ROOT,
        "simulator_commit": found.get("simulator", {}).get("commit"),
        "simulator_branch": found.get("simulator", {}).get("branch"),
        "pyodide": found.get("pyodide", {}).get("version"),
        "networks": dict(NETWORKS),
        "default_network": DEFAULT_NETWORK,
    }


# -- the scenario list --------------------------------------------------------

def _profiles(network):
    with open(NETWORKS[network], encoding="utf-8") as handle:
        return list(json.load(handle)["profiles"])


def _limits_for(entry, knobs, found):
    """The limits of one configuration: its class's, then its own."""
    result = dict(found.get("by_class", {}).get(entry["class"], {}))
    result.update(found.get("by_id", {}).get(entry["id"], {}))
    result.update(found.get("by_configuration", {}).get(
        entry["configuration"], {}))
    return result


def scenarios():
    """One record per configuration, with the settings it accepts.

    The records are the registry's (`python3 -m bench.leansphincs scenarios
    --json`) with `settings` (name -> type, default, allowed values or
    range), `limits` (what a browser run is held to) and `explore_only`.
    """
    setup()
    from bench.leansphincs import registry
    from bench.leansphincs.scenario import DEFAULTS
    found = limits()
    names = list(registry.PHASE2B_CANDIDATES)
    more = [name for name in registry.candidate_names() if name not in names]
    profiles = _profiles(DEFAULT_NETWORK)
    result = []
    for entry in registry.entries():
        knobs = dict(DEFAULTS)
        knobs.update(registry.configuration(entry["configuration"]))
        cap = _limits_for(entry, knobs, found)
        fixed_uplinks = (knobs.get("set") or {}).get("uplinks")
        settings = {
            "candidate": {"type": "choice", "default": knobs["candidate"],
                          "values": names, "more_values": len(more)},
            "sig_bytes": {"type": "int", "default": knobs["sig_bytes"],
                          "min": 1, "swept": list(SWEEP_RANGE["sig_bytes"]),
                          "follows": "candidate"},
            "perms": {"type": "int", "default": knobs["perms"], "min": 1,
                      "swept": list(SWEEP_RANGE["perms"]),
                      "follows": "candidate"},
            "k": {"type": "int", "default": knobs["k"], "min": 1},
            "gas_limit": {"type": "int", "default": knobs["gas_limit"],
                          "min": 0, "values": list(GAS_LIMITS)},
            "profile": {"type": "choice", "default": knobs["profile"],
                        "values": profiles},
            "uplinks": {"type": "choice", "default": knobs["uplinks"],
                        "values": ["uniform", "heterogeneous"]},
            "nodes": {"type": "int", "default": knobs["nodes"],
                      "min": cap.get("min_nodes", 12),
                      "max": cap.get("max_nodes", knobs["nodes"])},
            "measured_slots": {"type": "int",
                               "default": knobs["measured_slots"], "min": 1,
                               "max": cap.get("max_measured_slots",
                                              knobs["measured_slots"])},
            "seed": {"type": "int", "default": knobs["seed"], "min": 0},
            "mode": {"type": "choice", "default": knobs["mode"],
                     "values": ["run", "capacity"]},
            "network": {"type": "choice", "default": DEFAULT_NETWORK,
                        "values": list(NETWORKS)},
        }
        if cap.get("max_gas_limit"):
            # Above it a browser run is too long (web/limits.json).
            settings["gas_limit"]["max"] = cap["max_gas_limit"]
            settings["gas_limit"]["values"] = [
                value for value in GAS_LIMITS if value <= cap["max_gas_limit"]]
        if entry["id"] == "F3":
            settings["k"]["follows"] = "perms: 65536 // (perms + 10)"
        if entry["class"] == "pcs":
            settings["client_proofs"] = {
                "type": "choice", "default": knobs["client_proofs"],
                "values": ["merge", "draft", "relay"]}
        if fixed_uplinks:
            # The configuration lists one uplink per node: the node count
            # and the uplinks are part of it.
            settings["nodes"].update(min=len(fixed_uplinks),
                                     max=len(fixed_uplinks),
                                     values=[len(fixed_uplinks)])
            settings["uplinks"].update(values=[knobs["uplinks"]])
        record = dict(entry)
        record["settings"] = settings
        record["limits"] = cap
        record["explore_only"] = bool(cap.get("explore_only", False))
        record["browser_defaults"] = cap.get("browser_defaults", {})
        result.append(record)
    return {"scenarios": result, "ids": list(registry.IDS),
            "default_configuration": dict(registry.DEFAULT_CONFIGURATION),
            "budget_s": found.get("budget_s"),
            "time_limit_s": found.get("time_limit_s"),
            "table_nodes": found.get("table_nodes"),
            "limits_basis": found.get("basis")}


def candidates(all_names=False):
    """The eight candidates of PHASE2B.md section 2, as the registry has
    them; with `all_names`, every alias of candidates_v2.csv as well."""
    setup()
    from bench.leansphincs import registry
    names = list(registry.PHASE2B_CANDIDATES)
    if all_names:
        names = registry.candidate_names()
    result = []
    for name in names:
        spec = registry.candidate(name)
        counted = spec["counted"]
        result.append({
            "name": name, "params": spec["params"],
            "sig_bytes": spec["sig_bytes"], "perms": spec["perms"],
            "impl": spec["impl"], "p_scale": spec.get("p_scale"),
            "prover_rows": "counted" if counted else "modelled",
            "counted_shape": counted[0] if counted else None,
            "counted_rows": counted[1] if counted else None,
            "headline": name in registry.PHASE2B_CANDIDATES,
        })
    return {"candidates": result,
            "more_names": len(registry.candidate_names()) - len(names)}


# -- one run ------------------------------------------------------------------

def _flag_value(value):
    if isinstance(value, bool):
        raise ValueError("a setting takes a number or a string")
    if isinstance(value, float) and value == int(value) and math.isfinite(
            value):
        # JSON numbers arrive as floats from some callers; an integer flag
        # must read as one.
        return str(int(value))
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True)
    return str(value)


def argv_for(config, network_paths=None):
    """The arguments of `python3 -m bench.leansphincs run` for a
    configuration. Unknown keys are refused, null values are skipped."""
    unknown = [key for key in config
               if key not in FLAGS and key not in OTHER_KEYS]
    if unknown:
        raise ValueError(f"unknown setting {', '.join(sorted(unknown))}; "
                         f"known: {', '.join(FLAG_ORDER + OTHER_KEYS)}")
    if not config.get("scenario"):
        raise ValueError("a configuration needs `scenario`")
    argv = []
    for key in FLAG_ORDER:
        value = config.get(key)
        if value is None or value == "":
            continue
        argv.extend([FLAGS[key], _flag_value(value)])
    network = config.get("network") or DEFAULT_NETWORK
    if network not in NETWORKS:
        raise ValueError(f"network must be one of {', '.join(NETWORKS)}")
    paths = network_paths or NETWORKS
    if network != "v1":
        argv.extend(["--network-params", paths[network]])
    return argv


def command_for(config):
    """The command line that reproduces a configuration in the campaign
    checkout (from sims/stark-mempool-sim-v2)."""
    paths = {name: "../../" + source
             for name, source in NETWORK_SOURCES.items()}
    words = []
    for word in argv_for(config, paths):
        safe = all(ch.isalnum() or ch in "-_./=@+:" for ch in word)
        words.append(word if safe else "'" + word.replace("'", "'\\''") + "'")
    return "python3 -m bench.leansphincs run " + " ".join(words)


def knobs_for(config):
    """The resolved knobs, through the command line's parser."""
    setup()
    from bench.leansphincs.__main__ import knobs_from, parser
    argv = argv_for(config)
    try:
        args = parser().parse_args(argv)
    except SystemExit as error:
        raise ValueError(f"the command line refused {argv}") from error
    return argv, knobs_from(args)


def check_limits(config):
    """Why a browser run of this configuration is refused, as a list."""
    setup()
    from bench.leansphincs import registry
    if not config.get("scenario"):
        raise ValueError("a configuration needs `scenario`")
    name = registry.configuration_name(config["scenario"])
    for record in scenarios()["scenarios"]:
        if record["configuration"] == name:
            break
    else:
        return []
    reasons = []
    cap = record["limits"]
    if record["explore_only"]:
        reasons.append(f"{name} is explore-only in the browser: "
                       f"{cap.get('reason', 'too slow')}")
    for key in ("nodes", "measured_slots"):
        value = config.get(key)
        if value is None:
            value = record["settings"][key]["default"]
        bound = record["settings"][key]
        if value > bound["max"]:
            reasons.append(f"{key} {value} is above the browser limit "
                           f"{bound['max']} for {name}")
        if value < bound["min"]:
            reasons.append(f"{key} {value} is below {bound['min']}")
    gas = config.get("gas_limit")
    top = record["settings"]["gas_limit"].get("max")
    if gas is not None and top and (gas <= 0 or gas > top):
        reasons.append(f"gas_limit {gas} is above the browser limit {top} "
                       f"for {name}")
    return reasons


def run(config):
    """One run. Returns the row the command line prints (both forms).

    `row` is what `python3 -m bench.leansphincs run <argv>` prints,
    `phase2_row` what it prints with `--phase2-row`; `row_text` and
    `phase2_text` are the exact lines. Progress events go to the callback
    of `set_progress`.
    """
    setup()
    from bench.common import _json_value
    from bench.leansphincs import scenario as scenario_module
    from bench.leansphincs.schema import phase2_row
    from starksim.netsim import NetworkSim
    config = dict(config)
    override = bool(config.pop("override_limits", False))
    time_limit = config.pop("time_limit_s", None)
    if time_limit is None and not override:
        time_limit = limits().get("time_limit_s")
    time_limit = float(time_limit or 0)
    if not override:
        reasons = check_limits(config)
        if reasons:
            raise ValueError("; ".join(reasons)
                             + " (pass override_limits to run it anyway)")
    started = time.perf_counter()
    argv, knobs = knobs_for(config)
    probes = knobs["capacity_max_runs"] if knobs["mode"] == "capacity" else 1
    slot = knobs["slot_ms"]
    horizon = (knobs["birth_slots"] + knobs["drain_slots"]) * slot
    state = {"probe": 0, "rate": None, "watched": None, "reported": started}
    original_run = scenario_module.run
    original_sim_run = NetworkSim.run

    def run_with_progress(run_knobs, *args, **kwargs):
        state["probe"] += 1
        state["rate"] = run_knobs.get("tps")
        _report(event="probe", probe=state["probe"], max_probes=probes,
                offered_tps=state["rate"], mode=knobs["mode"])
        return original_run(run_knobs, *args, **kwargs)

    def watch(sim):
        """A post-event hook on one simulation's engine: every
        PROGRESS_EVENTS events it looks at the wall clock, reports the
        simulated time at most every PROGRESS_SECONDS, and stops a run that
        is over its time limit. It reads the engine and changes nothing."""
        engine = sim.engine
        counter = [0]

        def hook(_kind):
            counter[0] += 1
            if counter[0] % PROGRESS_EVENTS:
                return
            now = time.perf_counter()
            if time_limit and now - started > time_limit:
                raise TimeoutError(
                    f"stopped after {now - started:.0f} s: over the time "
                    f"limit of {time_limit:g} s (probe {state['probe']}, "
                    f"simulated {engine.now / 1000.0:.1f} of "
                    f"{horizon / 1000.0:.0f} s). Fewer nodes or slots, or "
                    "mode 'run', make it shorter")
            if now - state["reported"] >= PROGRESS_SECONDS:
                state["reported"] = now
                _report(event="tick", probe=state["probe"],
                        max_probes=probes, sim_ms=engine.now,
                        horizon_ms=horizon, elapsed_s=now - started)

        engine.after_event(hook)

    def sim_run_with_progress(self, until=None):
        if state["watched"] is not self:
            state["watched"] = self
            watch(self)
        processed = original_sim_run(self, until=until)
        _report(event="segment", probe=state["probe"], max_probes=probes,
                sim_ms=until, horizon_ms=horizon, events=processed)
        if until is not None and until >= horizon:
            # The simulation's last segment: let it go.
            state["watched"] = None
        return processed

    scenario_module.run = run_with_progress
    NetworkSim.run = sim_run_with_progress
    try:
        row = scenario_module.evaluate(knobs)
    finally:
        scenario_module.run = original_run
        NetworkSim.run = original_sim_run
        state["watched"] = None
    row["knobs"] = knobs
    tidy = phase2_row(row)
    row_text = json.dumps(_json_value(row), sort_keys=True, allow_nan=False)
    phase2_text = json.dumps(_json_value(tidy), sort_keys=False,
                             allow_nan=False)
    return {
        "row": json.loads(row_text),
        "phase2_row": json.loads(phase2_text),
        "row_text": row_text,
        "phase2_text": phase2_text,
        "argv": argv,
        "command": command_for(config),
        "timing": {"python_s": time.perf_counter() - started,
                   "runtime_s": row.get("runtime_s"),
                   "probes": state["probe"]},
    }


# -- the model alone ----------------------------------------------------------

def _modelled(knobs):
    """The knobs with the prover's rows modelled instead of counted.

    At a candidate whose parameter set was counted on leanVM runs the
    registry hands the circuit model those rows; any other point is the
    model's composition. An elasticity must compare like with like, so its
    points are all priced by the composition."""
    circuit = knobs["models"].get("circuit_cost") or {}
    if "counted_rows" not in (circuit.get("kwargs") or {}):
        return knobs
    knobs = copy.deepcopy(knobs)
    del knobs["models"]["circuit_cost"]["kwargs"]["counted_rows"]
    knobs["prover_cost"] = "modelled [Mo]"
    return knobs


def _bounds(config, modelled=False):
    """The analytic bounds of one point, as a capacity search computes them
    before its first run (`scenario.find_capacity`)."""
    from bench.leansphincs import scenario as scenario_module
    _argv, knobs = knobs_for(config)
    if modelled:
        knobs = _modelled(knobs)
    _sim, plan = scenario_module.build(dict(knobs, tps=1.0, batch=1))
    shape = plan["shape"]
    circuit = plan["circuit"]
    point = {
        "sig_bytes": knobs["sig_bytes"], "perms": knobs["perms"],
        "k": knobs["k"], "candidate": knobs["candidate"],
        "gas_limit": knobs["gas_limit"], "byte_limit": knobs["byte_limit"],
        "tx_gas": shape.gas, "tx_onchain_bytes": shape.onchain_bytes,
        "tx_wire_bytes": shape.wire_bytes,
        "txs_per_block_gas": (knobs["gas_limit"] // shape.gas
                              if knobs["gas_limit"] > 0 else None),
        "prover_cost": knobs.get("prover_cost"),
        "prove_ms_per_tx": None,
    }
    if circuit is not None:
        point["prove_ms_per_tx"] = (circuit.sphincs_hashes
                                    * circuit.ms_per_hash)
    point.update(plan["bounds"])
    return knobs, point


def _tps(point, basis):
    return point[basis + "_bound_tps"]


def evaluate_model(config):
    """The analytic model at one point, without a simulation [Mo].

    Gas and bytes of one transaction, the bound of each resource in
    transactions per second and which binds (`ideal_*`: gas, bytes and
    prover; `analytic_*` adds the rough bandwidth estimate), all from
    `bench.leansphincs.scenario.analytic_bounds` on the scenario's own
    model modules. Elasticities are of `ideal_bound_tps`:

    - `eps_B`, `eps_P`: the log-log slope between the point 10 % below and
      10 % above (bytes and permutations rounded to integers);
    - `dB10` ... `dB100`, `dP10` ... `dP100`: the change of the bound in
      percent when bytes or permutations grow by that many percent.

    The campaign's tables compute the same columns from simulated grids
    (`schema.fill_elasticities`); these are the model's, evaluated at the
    exact points instead of interpolated. Every point of an elasticity is
    priced by the modelled prover rows, also where the headline bound uses
    a candidate's counted rows (`elasticity_basis`, `elasticity_base_tps`).
    """
    setup()
    started = time.perf_counter()
    config = dict(config)
    config.pop("override_limits", None)
    config.pop("time_limit_s", None)
    knobs, point = _bounds(config)
    result = dict(point)
    # The elasticities' own base: the same point with modelled prover rows.
    counted = _modelled(knobs) is not knobs
    base = _tps(_bounds(config, modelled=True)[1], "ideal") if counted \
        else _tps(point, "ideal")
    result["elasticity_base_tps"] = base
    result["elasticity_basis"] = (
        "modelled prover rows at every point [Mo]; the headline bound "
        "prices this candidate's counted rows [C]" if counted
        else "the model at every point [Mo]")
    result["scenario"] = knobs["scenario_id"] or knobs["scenario"]
    result["class"] = knobs["scenario"]
    result["pricing"] = knobs["pricing"]
    result["variant"] = knobs["variant"]
    headline = _tps(point, "ideal")
    result["tps_sig_bound"] = headline * knobs["k"] if headline > 0 else -1.0
    result["status"] = "[Mo]"

    def moved(axis, factor):
        value = max(1, int(round(knobs[axis] * factor)))
        other = dict(config)
        other["sig_bytes"] = knobs["sig_bytes"]
        other["perms"] = knobs["perms"]
        other[axis] = value
        return value, _tps(_bounds(other, modelled=True)[1], "ideal")

    steps = {}
    for axis, name in (("sig_bytes", "B"), ("perms", "P")):
        low, low_tps = moved(axis, 1 / 1.1)
        high, high_tps = moved(axis, 1.1)
        slope = None
        if low_tps > 0 and high_tps > 0 and high != low:
            slope = math.log(high_tps / low_tps) / math.log(high / low)
        result["eps_" + name] = slope
        result["eps_" + name + "_points"] = [[low, low_tps],
                                             [high, high_tps]]
        for step in ELASTICITY_STEPS:
            value, there = moved(axis, 1 + step / 100.0)
            change = None
            if base > 0 and there >= 0:
                change = 100.0 * (there / base - 1.0)
            result[f"d{name}{step}"] = change
            steps[f"{name}+{step}%"] = {axis: value,
                                        "ideal_bound_tps": there}
    result["steps"] = steps
    result["command"] = command_for(config)
    result["timing"] = {"python_s": time.perf_counter() - started}
    return result


# -- dispatch -----------------------------------------------------------------

METHODS = {
    "info": lambda args: info(),
    "scenarios": lambda args: scenarios(),
    "candidates": lambda args: candidates(bool(args.get("all"))),
    "run": lambda args: run(args.get("config", args)),
    "evaluate_model": lambda args: evaluate_model(args.get("config", args)),
    "check_limits": lambda args: {"reasons": check_limits(
        args.get("config", args))},
}


def call(method, text="{}"):
    """One API call: JSON text in, JSON text out."""
    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}; "
                         f"known: {', '.join(METHODS)}")
    return json.dumps(METHODS[method](json.loads(text or "{}")),
                      allow_nan=False)


if __name__ == "__main__":
    print(call(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "{}"))

"""Limit checks: the simulator against arithmetic where arithmetic is exact.

    python3 -m bench.leansphincs.validate

With infinite bandwidth and zero latency the network adds nothing, so a
saturated run must land on the analytic bound of the resource that binds:

- S1 under the gas limit, and under a byte cap with the gas limit lifted:
  whole transactions per block, one block per slot;
- S2 and S3 with one prover (a single node, or one builder that alone
  aggregates): whole leaves per one-second interval within the proving
  budget, after the 60 ms fixed cost. The interval right after a block finds
  the prover's previous aggregate settled and skips its 63 ms merge, so the
  rate lies between the floors with and without the merge ("floors").

The rows after the lone-prover checks are the network's own effects at the
same point: receive verification with no budget headroom, and every node
aggregating. Every run is one seed at the current leanSPHINCS point
(7,740 B, 515 permutations, k = 1) unless a row says otherwise, on a small
network (12 nodes of degree 4, three birth slots, the first one warm-up,
one drain slot), the fixture tests/test_leansphincs.py asserts the same
relations on. The output is kept in the campaign's data/sim/validation.txt.
"""

import math
import sys

from bench.leansphincs.scenario import find_capacity, resolve_knobs, run

SMALL = {"nodes": 12, "degree": 4, "birth_slots": 3, "warmup_slots": 1,
         "drain_slots": 1}
IDEAL = dict(SMALL, uplink_mbps=0, latency_ms=0.0)
FREE_VERIFY = {"verify_cost": {"fn": "bench.leansphincs.models:native_verify",
                               "kwargs": {"ns_per_perm": 0,
                                          "per_sig_overhead_ms": 0,
                                          "stark_ms": 0}}}
ONE_BUILDER = {"aggregator_share": 0.1, "proposer_role": "aggregator",
               "relay_forwarding": "none"}
LONE = dict(IDEAL, nodes=1, degree=0, gas_limit=0, load_factor=1.5)
TEN = dict(IDEAL, nodes=10, degree=4, gas_limit=0, load_factor=1.5)

S1 = (
    ("60 M gas, 7,740 B (gas bound)", "gas_bound_tps",
     dict(IDEAL, scenario="noagg", batch=1, load_factor=2.0), False),
    ("60 M gas, 2-of-n multisig of 4,164 B (gas bound)", "gas_bound_tps",
     dict(IDEAL, scenario="noagg", batch=1, load_factor=2.0, k=2,
          sig_bytes=4164), False),
    ("no gas limit, 1 MB byte cap (byte bound)", "byte_bound_tps",
     dict(IDEAL, scenario="noagg", batch=1, load_factor=2.0, gas_limit=0,
          byte_limit=1_000_000), False),
    ("capacity search, 60 M gas", "gas_bound_tps",
     dict(IDEAL, scenario="noagg", batch=1, mode="capacity"), True),
)
S2 = (
    ("lone prover, 400 perms (prover bound)",
     dict(LONE, scenario="agg8288", perms=400, batch=8), 1000.0),
    ("lone prover, 515 perms (prover bound)",
     dict(LONE, scenario="agg8288", batch=8), 1000.0),
    ("lone prover, 800 perms (prover bound)",
     dict(LONE, scenario="agg8288", perms=800, batch=8), 1000.0),
    ("10 nodes, one builder, free verification",
     dict(TEN, scenario="agg8288", batch=8, set=ONE_BUILDER,
          models=FREE_VERIFY), 1000.0),
    ("10 nodes, one builder, verification, 900 ms budget",
     dict(TEN, scenario="agg8288", batch=8,
          set=dict(ONE_BUILDER, proving_budget=900.0)), 900.0),
    ("10 nodes, one builder, verification, 1000 ms budget",
     dict(TEN, scenario="agg8288", batch=8, set=ONE_BUILDER), None),
    ("10 nodes, all aggregate, 1000 ms budget",
     dict(TEN, scenario="agg8288", batch=8), None),
    ("10 nodes, all aggregate, 900 ms budget",
     dict(TEN, scenario="agg8288", batch=8,
          set={"proving_budget": 900.0}), None),
)
S3 = (
    ("placeholder shape (prover bound)",
     dict(LONE, scenario="pcs", batch=1), 1000.0),
)


def floors(row, budget):
    per_leaf = row["prove_ms_per_tx"] * row["batch"]
    batch = row["batch"]
    merged = math.floor((budget - 60.0 - row["prove_ms_per_child"])
                        / per_leaf) * batch
    unmerged = math.floor((budget - 60.0) / per_leaf) * batch
    return merged, unmerged


def line(label, measured, bound, note=""):
    print(f"  {label:<55} sim {measured:>9.2f}  bound {bound:>9.2f}  "
          f"ratio {measured / bound:.4f}  {note}".rstrip())


def prover_rows(rows):
    for label, layer, budget in rows:
        row = run(resolve_knobs(layer))
        note = []
        if budget is not None:
            low, high = floors(row, budget)
            note.append(f"floors [{low}, {high}]")
        if row["leaf_folds_per_included"] >= 0:
            note.append(f"folds/tx {row['leaf_folds_per_included']:.3f}")
            note.append(f"repeat service {row['repeat_service_share']:.2f}")
        line(label, row["tps_included_window"], row["prover_bound_tps"],
             ", ".join(note))


def main():
    print("S1 noagg, ideal network, 2x overload:")
    for label, bound_key, layer, capacity in S1:
        knobs = resolve_knobs(layer)
        row = find_capacity(knobs) if capacity else run(knobs)
        note = f"tx gas {row['tx_gas']}"
        if capacity:
            note = f"{row['capacity_runs']} runs"
        line(label, row["tps_included_window"], row[bound_key], note)
    print("S2 agg8288, ideal network, no gas limit, 1.5x overload, batch 8:")
    prover_rows(S2)
    print("S3 pcs, ideal network, no gas limit, lone prover, batch 1:")
    prover_rows(S3)
    return 0


if __name__ == "__main__":
    sys.exit(main())

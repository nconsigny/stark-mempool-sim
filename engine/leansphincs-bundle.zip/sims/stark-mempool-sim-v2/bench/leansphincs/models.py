"""Default cost, gas and network models for the leanSPHINCS campaign.

Every model is a plain callable selected by a spec, so another agent swaps a
model without editing the core: in a config JSON,

    {"models": {"gas_per_tx": {"fn": "data.my_gas:gas", "kwargs": {...}}}}

`fn` is `module.path:function`, imported with `importlib`; `kwargs` are passed
through. A module outside the repository is found through `PYTHONPATH` or a
`"path"` entry in the spec (a directory prepended to `sys.path`). The
signatures below are the contract; each default names its sources with the
campaign's status tags ([E] spec, [R] read in code, [C] count from a run,
[M] measured on this box, [Mo] modelled, [Rc] recalled).

Signatures (every model also accepts its own keyword arguments):

- `circuit_cost(perms_per_sig, sigs_per_leaf, **kw) -> CircuitCost`
  In-circuit proving price for EIP-8288 aggregation. A leaf is the unit the
  simulator moves: `sigs_per_leaf = k * batch` signatures. Like the two
  verification models, it also receives `sig_bytes=` (the point's signature
  bytes) when its signature names a `sig_bytes` parameter that its spec's
  kwargs leave unset (`CONTEXT_KNOBS`).
- `verify_cost(perms_per_sig, sigs_per_leaf, **kw) -> NativeVerifyCost`
  Receive verification under S2/S3: `per_signature` is the price of one
  *leaf*'s signatures, `per_stark` one STARK-class object.
- `noagg_verify_cost(perms_per_sig, sigs_per_leaf, **kw) -> NativeVerifyCost`
  The same under S1, where a node checks a transaction by simulating its
  VERIFY frame in the EVM (and imports a block by executing it).
- `gas_per_tx(sig_bytes, verify_perms, k, **kw) -> int`
  Gas of one no-aggregation transaction carrying `k` signatures (S1).
- `agg_gas_per_tx(sig_bytes, verify_perms, k, **kw) -> int`
  Gas of one EIP-8288 transaction declaring `k` leanSPHINCS dependencies (S2).
- `pcs_model(sig_bytes, perms_per_sig, k, **kw) -> dict`
  The S3 transaction's shape; keys in `PCS_KEYS`.
- `overlay(nodes, degree, latency_ms, seed, **kw) -> starksim.network.Overlay`
  The topology and link latencies.
"""

import importlib
import inspect
import json
import math
import random
import sys

from starksim.costs import (CircuitCost, LimitedCircuitCost,
                            NativeVerifyCost)
from starksim.network import Overlay

# -- the current leanSPHINCS point --------------------------------------------

# leanVM upstream HEAD b6167fe4's leanSPHINCS (= EthLib leanSphincs-layered:
# d = 3, heights 10+8+8, FORS k = 24 a = 10, WOTS+C w = 2 v = 64 T = 128,
# n = 16): `SIG_SIZE == 7740` and `VERIFY_PERMUTATIONS == 515` are
# compile-time asserts [R, refs/leanVM-upstream/crates/signatures/src/
# lean_sphincs/mod.rs:120-121]; unchanged since 04fba03, where the study
# below counted them.
CURRENT_PERMS = 515
CURRENT_SIG_BYTES = 7740

# -- in-circuit proving --------------------------------------------------------

# Guest cost per permutation: 5,475 cycles per signature over 515
# permutations [C] (study §2.3). The study's point is that the non-Keccak
# tables grow with the permutations too, so cycles are modelled as
# proportional to permutations.
CYCLES_PER_PERM = 5475 / 515
MEMORY_CELLS_PER_PERM = 8604 / 515      # [C], recorded, not priced

# Calibrations: milliseconds attached to cycles, and the fixed costs.
#   sphincs-el-m4: T_leaf(N) = F + b N with F = 60 ms, b = 2.0 ms per
#     signature at N = 500 [Mo, study §3.1], which reproduces the README's
#     500 signatures in 1.06 s on an M4 [R]; a merged child costs 63 ms
#     [M, 16T, leanXMSS children, study §3.1].
#   c7a-leaves: 421 leaf signatures per second on a 32-vCPU AWS c7a.8xlarge
#     [R, refs/ethresearch/26208.md §3], so 2.375 ms per signature; fixed
#     and child costs as sphincs-el-m4 (not measured there).
#   leanvm-990b935: v2's prices (bench/mainnet.py): 303 ms for a 2-to-1
#     fold of 271,156-cycle children anchors cycles to ms; no fixed cost.
#     The 515-permutation cycle count is 04fba03's, since 990b935's 1,820
#     cycles per signature predate that guest.
CALIBRATIONS = {
    "sphincs-el-m4": {"ms_per_sig_at_current": 2.0, "child_ms": 63.0,
                      "overhead_ms": 60.0},
    "c7a-leaves": {"ms_per_sig_at_current": 1000.0 / 421, "child_ms": 63.0,
                   "overhead_ms": 60.0},
    "leanvm-990b935": {"ms_per_cycle": 303.0 / (2 * 271_156),
                       "child_cycles": 271_156, "overhead_ms": 0.0},
}


def leanvm_circuit(perms_per_sig, sigs_per_leaf,
                   calibration="sphincs-el-m4", cycles_per_perm=CYCLES_PER_PERM,
                   fixed_cycles_per_sig=0.0, speedup=1.0):
    """A `CircuitCost` in VM cycles whose signature term is linear in perms.

    One leaf (`sigs_per_leaf` signatures) costs
    `sigs_per_leaf * (cycles_per_perm * perms_per_sig + fixed_cycles_per_sig)`
    cycles; a nested proof and the fixed per-proof cost come from the
    calibration. `speedup` divides every millisecond figure, the hardware
    axis (2 is a machine twice as fast). No trace ceiling is modelled
    (`trace_cap=inf`), as in v2's mainnet bench; leanVM's 16-child and 2^16
    claim-slot limits are not modelled either.

    The model is linear where the prover is a staircase: tables pad to powers
    of two, so real proving time steps at cliffs (study §2.3, +-10%).
    """
    if perms_per_sig <= 0 or sigs_per_leaf <= 0:
        raise ValueError("perms_per_sig and sigs_per_leaf must be positive")
    settings = CALIBRATIONS[calibration]
    if "ms_per_cycle" in settings:
        ms_per_cycle = settings["ms_per_cycle"]
        child_cycles = settings["child_cycles"]
    else:
        current_cycles = cycles_per_perm * CURRENT_PERMS + fixed_cycles_per_sig
        ms_per_cycle = settings["ms_per_sig_at_current"] / current_cycles
        child_cycles = settings["child_ms"] / ms_per_cycle
    ms_per_cycle /= speedup
    per_sig = cycles_per_perm * perms_per_sig + fixed_cycles_per_sig
    return CircuitCost(
        ms_per_hash=ms_per_cycle,
        overhead_hashes=settings["overhead_ms"] / (ms_per_cycle * speedup),
        sphincs_hashes=per_sig * sigs_per_leaf,
        leanstark_hashes=child_cycles,
        recursive_hashes=child_cycles,
        trace_rows_per_hash=1.0, trace_cap=math.inf)


# leanVM's recursion limits [R, data/prover_model.py:35-37, reading
# rec_aggregation/src/aggregation/mod.rs:71 and :80 at 04fba03]: at most 16
# children per merge, and claim slots strictly below 2^16.
LEANVM_MAX_CHILDREN = 16
LEANVM_MAX_CLAIMS = (1 << 16) - 1
RATES = {"1/2": 1, "1/4": 2, 0.5: 1, 0.25: 2}


def _prover_model(path):
    """data/prover_model.py of the campaign, imported from `path`."""
    import os
    if path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.normpath(os.path.join(here, "..", "..", "..", "..",
                                             "data"))
    if path not in sys.path:
        sys.path.insert(0, path)
    return importlib.import_module("prover_model")


class CountedShape:
    """One signature's counted prover rows, as `prover_model`'s `shape`.

    `rows` holds the tables XOR, MUL, SET, DEREF, JUMP and K (KECCAK rows)
    and MEM (memory cells), per signature, as data/phase2/guest_counts.json
    counted them on real proof runs [C]. The model then prices those rows
    instead of composing a signature from its permutations and bytes.
    """

    TABLES = ("XOR", "MUL", "SET", "DEREF", "JUMP", "K")

    def __init__(self, rows, perms, sig_bytes):
        missing = [name for name in self.TABLES + ("MEM",) if name not in rows]
        if missing:
            raise ValueError(f"counted_rows has no {missing}")
        self._rows = {name: float(rows[name])
                      for name in self.TABLES + ("MEM",)}
        self._rows["cycles"] = sum(self._rows[name] for name in self.TABLES)
        self._perms = perms
        self._sig_bytes = sig_bytes

    def rows(self):
        return dict(self._rows)

    def perms(self):
        return self._perms

    def sig_bytes(self):
        return self._sig_bytes


KECCAK_ROWS = ("actual", "padded")


def prove_breakdown(model, signatures, perms, sig_bytes, children, hw,
                    keccak_rows="actual", **kwargs):
    """`prover_model.breakdown` with the Keccak reduction on actual rows.

    The model charges the keccak_gkr reduction `aK` per KECCAK row padded to
    a power of two (or rows / ln 2 when smooth). A paired measurement across
    the 2^18 cliff refuted that: the reduction's span does not move with the
    padding (notes/verify-prover-model.md V8, notes/phase2/
    verify-models-agg.md AG2). `keccak_rows="actual"` charges `aK` on the
    rows the proof has, the verifier's variant
    (data/verify-prover-model/v_keccak_fix.py), and leaves the rest of the
    model alone, the 92 committed words per padded row included.
    `"padded"` is the model as written, which phase 2 ran. [Mo] either way.
    """
    if keccak_rows not in KECCAK_ROWS:
        raise ValueError(f"keccak_rows must be one of {', '.join(KECCAK_ROWS)}")
    if keccak_rows == "padded":
        return model.breakdown(signatures, perms, sig_bytes, children, hw,
                               **kwargs)
    machine = model.hw_of(hw)
    if isinstance(machine, model.ScaledHW):
        # A machine known by two whole-proof timings scales the M4's time by
        # a factor interpolated on the proof's Keccak share (the model's own
        # rule), here on the corrected share.
        result = prove_breakdown(model, signatures, perms, sig_bytes,
                                 children, "m4", keccak_rows, **kwargs)
        total = result["total_s"]
        share = result["time"]["keccak_reduction"] / total if total else 0.0
        weight = min(1.0, max(0.0, (share - model._KSHARE_MERGE)
                              / (model._KSHARE_LEAF - model._KSHARE_MERGE)))
        scale = (machine.s_merge
                 + (machine.s_leaf - machine.s_merge) * weight)
        result["time"] = {name: value * scale
                          for name, value in result["time"].items()}
        result["total_s"] = total * scale
        result["hw_scale"] = scale
        return result
    result = model.breakdown(signatures, perms, sig_bytes, children, hw,
                             **kwargs)
    result["time"] = dict(result["time"],
                          keccak_reduction=machine.aK * result["rows"]["K"])
    result["total_s"] = sum(result["time"].values())
    return result


def leanvm_limited(perms_per_sig, sigs_per_leaf, sig_bytes=None, rate="1/2",
                   cliffs=True, max_children=LEANVM_MAX_CHILDREN,
                   max_claims=LEANVM_MAX_CLAIMS, proof_size=True,
                   child_claims=500, hw="m4", speedup=1.0,
                   prover_model_path=None, keccak_rows="actual",
                   counted_rows=None):
    """leanVM as `data/prover_model.py` models it, limits and cliffs included.

    A `LimitedCircuitCost` whose pieces can each be switched off:

    - `max_children` (16) and `max_claims` (2^16 - 1): leanVM's recursion
      limits; `None` removes one. A simulated leaf uses `sigs_per_leaf`
      claim slots.
    - `cliffs=True`: a proof's time is `prover_model.prove_time`, the
      staircase in which every table pads to a power of two, at the proof's
      own composition (new signatures and merged children, each child priced
      at `child_claims` claims). `False` keeps the smooth linear price.
    - `proof_size=True`: a proof's bytes are `prover_model.proof_bytes` at
      this `rate` for a merge of two children that together hold the proof's
      claims. `False` leaves the `proof_bytes` knob in force.
    - `rate`: "1/2" or "1/4", the code rate of the recursion proofs. It
      moves both the time and the size.
    - `keccak_rows="actual"`: the Keccak reduction is charged on the rows a
      proof has, not on rows padded to a power of two, which a measurement
      refuted (`prove_breakdown`). `"padded"` is phase 2's price, about a
      tenth dearer per signature.
    - `counted_rows`: one signature's rows by table, counted on real proof
      runs (`CountedShape`; the registry passes a candidate's row of
      data/phase2/guest_counts.json). `None` composes the signature from
      `perms_per_sig` and `sig_bytes`, the model's own reading.

    The linear fields are the smooth model at the same point (identical to
    `prover_model.sim_circuit_cost` for padded rows and no counted rows):
    they identify the run and split a proof's service time between inputs.
    Everything here is [Mo]: the model's fit, not a measurement, also when
    the rows it prices were counted.
    """
    if rate not in RATES:
        raise ValueError("rate must be '1/2' or '1/4'")
    if keccak_rows not in KECCAK_ROWS:
        raise ValueError(f"keccak_rows must be one of {', '.join(KECCAK_ROWS)}")
    log_rate = RATES[rate]
    model = _prover_model(prover_model_path)
    size = CURRENT_SIG_BYTES if sig_bytes is None else sig_bytes
    shape = None
    if counted_rows is not None:
        shape = CountedShape(counted_rows, perms_per_sig, size)

    def seconds(signatures, children, smooth=False):
        return prove_breakdown(
            model, signatures, perms_per_sig, size, children, hw, keccak_rows,
            shape=shape, child_claims=child_claims, rate=log_rate,
            smooth=smooth)["total_s"]

    if shape is None and keccak_rows == "padded":
        linear = model.sim_circuit_cost(perms_per_sig, sigs_per_leaf,
                                        sig_bytes=size, hw=hw,
                                        child_claims=child_claims,
                                        rate=log_rate, speedup=speedup)
    else:
        # prover_model.circuit_cost_kwargs, on the corrected breakdown.
        per_sig = (seconds(400, 0, True) - seconds(200, 0, True)) / 200
        per_child = seconds(0, 3, True) - seconds(0, 2, True)
        fixed = seconds(1, 0, True) - per_sig
        linear = CircuitCost(
            ms_per_hash=1.0 / speedup, overhead_hashes=1e3 * fixed,
            sphincs_hashes=1e3 * per_sig * sigs_per_leaf,
            leanstark_hashes=1e3 * per_child,
            recursive_hashes=1e3 * per_child,
            trace_rows_per_hash=1.0, trace_cap=math.inf)
    price = None
    if cliffs:
        times = {}

        def price(signatures, leanstarks, recursive):
            key = (signatures, leanstarks + recursive)
            value = times.get(key)
            if value is None:
                value = 1e3 * seconds(
                    int(round(signatures * sigs_per_leaf)),
                    int(leanstarks + recursive)) / speedup
                times[key] = value
            return value
        rows = "counted" if shape is not None else "modelled"
        price.label = (f"prover_model.prove_time(rate={rate},hw={hw},"
                       f"keccak={keccak_rows},rows={rows})")
    sizes_of = None
    if proof_size:
        sizes = {}

        def sizes_of(claims):
            value = sizes.get(claims)
            if value is None:
                value = model.proof_bytes(
                    0, perms_per_sig, size, 2, rate=log_rate,
                    child_claims=max(16, int(claims) // 2))
                sizes[claims] = value
            return value
        sizes_of.label = f"prover_model.proof_bytes(rate={rate})"
    return LimitedCircuitCost(
        ms_per_hash=linear.ms_per_hash,
        overhead_hashes=linear.overhead_hashes,
        sphincs_hashes=linear.sphincs_hashes,
        leanstark_hashes=linear.leanstark_hashes,
        recursive_hashes=linear.recursive_hashes,
        trace_rows_per_hash=1.0, trace_cap=math.inf,
        max_children=max_children, max_claims=max_claims,
        claims_per_leaf=sigs_per_leaf, price=price, proof_size=sizes_of)


# -- native verification -------------------------------------------------------

# Keccak-f[1600] through OpenSSL 3.6.5 on this box: 179 ns per permutation in
# bulk hashing [M, 2026-11-10, load ~10-15]; a Rust verifier is the same
# order. v2 prices a STARK-class native verification at 9.195 ms, leanVM
# 990b935's measured 2-to-1 proof verification [R, bench/mainnet.py].
NS_PER_PERM = 179.0
STARK_VERIFY_MS = 9.195


# EVM execution of VERIFY-frame work per core, from Nethermind's EIP-8141
# DoS benchmark [R, refs/ethresearch/26224.md §4]: 30 M gas/s of keccak-wide
# failing validation adds 11.1 ms (High) and 13.2 ms (Mid) to a 27-30 ms
# block, a CPU share f = delay / (T + delay) of 0.29-0.31, so a full core
# runs about 100 M gas/s; on Low, 15 M gas/s adds 18.1 ms to 42 ms, about
# 50 M gas/s. 75 M gas/s is the middle [Mo].
EVM_GAS_PER_SECOND = 75e6

# EIP-8141's cap on unpaid validation, `MAX_VERIFY_GAS` [R, 26224.md §1;
# the EIP text]. Reported against, not enforced.
MAX_VERIFY_GAS = 100_000


def evm_verify(perms_per_sig, sigs_per_leaf, gas_per_second=EVM_GAS_PER_SECOND,
               stark_ms=STARK_VERIFY_MS, per_message_ms=0.0, **gas_kwargs):
    """S1 receive verification: the VERIFY frame run in the EVM.

    One signature costs `evm_verify_gas(perms_per_sig)` gas at
    `gas_per_second`: 82 K gas, about 1.1 ms, at the current 515
    permutations, an order above native Keccak. `gas_kwargs` reach the gas
    fit.
    """
    gas = evm_verify_gas(perms_per_sig, **gas_kwargs)
    per_sig = gas / gas_per_second * 1000.0
    return NativeVerifyCost(per_signature=per_sig * sigs_per_leaf,
                            per_stark=stark_ms, per_message=per_message_ms)


def native_verify(perms_per_sig, sigs_per_leaf, ns_per_perm=NS_PER_PERM,
                  per_sig_overhead_ms=0.01, stark_ms=STARK_VERIFY_MS,
                  per_message_ms=0.0):
    """Receive verification: a leaf's signatures cost perms x ns each."""
    per_sig = perms_per_sig * ns_per_perm / 1e6 + per_sig_overhead_ms
    return NativeVerifyCost(per_signature=per_sig * sigs_per_leaf,
                            per_stark=stark_ms, per_message=per_message_ms)


# -- gas -----------------------------------------------------------------------

# EIP-7976 [E]: standard calldata 4/16 gas per byte, floor 64 gas per byte;
# EIP-7623's floor was 10/40. Intrinsic 21,000. A random signature has
# almost no zero bytes, so every byte is priced as nonzero.
INTRINSIC_GAS = 21_000
STANDARD_GAS_PER_BYTE = 16
FLOOR_GAS_PER_BYTE = 64

# Plain-EVM leanSPHINCS verification gas against permutations: the
# P-only least-squares fit over leanSphincs / -s / -f / -layered,
# gas = -10259 + 185.75 P, rms 1,515 [Mo, /projects/leanSPHINCS/data/gasfit/
# fit_verify_gas.out, from measured Foundry gas in /projects/SPHINCs-].
VERIFY_GAS_BASE = -10_259
VERIFY_GAS_PER_PERM = 185.75


def evm_verify_gas(verify_perms, verify_gas_base=VERIFY_GAS_BASE,
                   verify_gas_per_perm=VERIFY_GAS_PER_PERM):
    """Execution gas of one plain-EVM leanSPHINCS verification (the fit)."""
    return max(0.0, verify_gas_base + verify_gas_per_perm * verify_perms)


def evm_frame_gas(sig_bytes, verify_perms, k, extra_calldata_bytes=0,
                  verify_gas_base=VERIFY_GAS_BASE,
                  verify_gas_per_perm=VERIFY_GAS_PER_PERM,
                  exec_overhead_gas=0, intrinsic_gas=INTRINSIC_GAS,
                  standard_per_byte=STANDARD_GAS_PER_BYTE,
                  floor_per_byte=FLOOR_GAS_PER_BYTE):
    """S1: a frame transaction verifying `k` signatures in EVM code.

    gas = intrinsic + max(standard calldata + execution, floor calldata),
    the EIP-7623/7976 rule. With the default 64-gas floor, a leanSPHINCS
    transaction pays the floor: 21,000 + 64 x 5,684 = 384,776 against the
    385 K measured for one leanSphincs frame transaction [R, SPHINCs-
    README], so verify permutations do not move the gas at all until the
    execution exceeds the floor.
    """
    calldata = k * sig_bytes + extra_calldata_bytes
    verify = evm_verify_gas(verify_perms, verify_gas_base, verify_gas_per_perm)
    execution = k * verify + exec_overhead_gas
    standard = standard_per_byte * calldata + execution
    floor = floor_per_byte * calldata
    return int(math.ceil(intrinsic_gas + max(standard, floor)))


def precompile_gas(sig_bytes, verify_perms, k, gas_per_perm=60,
                   base_gas=3000, extra_calldata_bytes=0,
                   intrinsic_gas=INTRINSIC_GAS,
                   standard_per_byte=STANDARD_GAS_PER_BYTE,
                   floor_per_byte=FLOOR_GAS_PER_BYTE):
    """S1 with a verification precompile priced per permutation.

    The default 60 gas per permutation is a placeholder [Mo]: the KECCAK256
    opcode charges 30 + 6 per word, 48-60 gas for one 64-80-byte node hash
    [E, yellow paper]. The calldata rule is the same as `evm_frame_gas`.
    """
    calldata = k * sig_bytes + extra_calldata_bytes
    execution = k * (base_gas + gas_per_perm * verify_perms)
    standard = standard_per_byte * calldata + execution
    floor = floor_per_byte * calldata
    return int(math.ceil(intrinsic_gas + max(standard, floor)))


# EIP-8288 [E]: a leanSPHINCS dependency is a 96-byte triple whose frame
# charges LEANSPHINCS_VERIFICATION_GAS = 3,000, and the transaction also pays
# recursive_stark_gas = LEANSTARK_VERIFICATION_GAS (30,000) per triple.
TRIPLE_BYTES = 96
LEANSPHINCS_VERIFICATION_GAS = 3_000
LEANSTARK_VERIFICATION_GAS = 30_000


def eip8288_gas(sig_bytes, verify_perms, k, extra_calldata_bytes=0,
                per_dep_gas=LEANSPHINCS_VERIFICATION_GAS,
                recursive_share_gas=LEANSTARK_VERIFICATION_GAS,
                triple_bytes=TRIPLE_BYTES, intrinsic_gas=INTRINSIC_GAS,
                standard_per_byte=STANDARD_GAS_PER_BYTE,
                floor_per_byte=FLOOR_GAS_PER_BYTE):
    """S2: gas of a transaction with `k` leanSPHINCS dependencies.

    The signature is not in calldata, so neither `sig_bytes` nor
    `verify_perms` enters the default: EIP-8288 prices a dependency at a
    fixed 3,000 + 30,000 gas. The arguments are there for a model that
    reprices with them, which the EIP's own "Gas costs" section anticipates.
    """
    calldata = k * triple_bytes + extra_calldata_bytes
    execution = k * (per_dep_gas + recursive_share_gas)
    standard = standard_per_byte * calldata + execution
    floor = floor_per_byte * calldata
    return int(math.ceil(intrinsic_gas + max(standard, floor)))


# -- S3, leanPCS ---------------------------------------------------------------

# Required keys of a pcs_model result; "headers_onchain" (default False) is
# optional.
PCS_KEYS = ("claims_per_tx", "header_bytes", "opening_bytes",
            "calldata_bytes", "prove_ms", "verify_ms", "gas")


def leanpcs_placeholder(sig_bytes, perms_per_sig, k, claims_per_tx=7,
                        variables_at_current=22, calldata_bytes=1004,
                        opening_bytes=223_334, prove_ms_per_tx=63.0,
                        prove_ms_per_claim=0.005, verify_ms=STARK_VERIFY_MS,
                        headers_onchain=False,
                        piop_exec_gas=27_641, pcs_tx_gas=5000,
                        pcs_claim_gas=1000, recursive_share_gas=0,
                        triple_bytes=TRIPLE_BYTES, intrinsic_gas=INTRINSIC_GAS,
                        standard_per_byte=STANDARD_GAS_PER_BYTE,
                        floor_per_byte=FLOOR_GAS_PER_BYTE):
    """S3 placeholder until data/prover_model.py: every number is flagged.

    The user proves its `k` leanSPHINCS verifications client side; the PIOP
    verifier runs on chain over `calldata_bytes` (1,004 B for the leanVM line
    [R, refs/leanPCS/README.md]) and hands `claims_per_tx` claims (7 there
    [R]) to PCS_OPEN. A claim's header is `81 + 24 n` bytes [E, leanPCS EIP
    draft]; n grows by one per doubling of the proven work, from
    `variables_at_current` at k = 1 and 515 permutations [Mo placeholder].
    Headers always travel in the mempool transaction. On chain the EIP draft
    carries only each claim's 96-byte dependency triple, the contract
    recomputing the claim from its calldata [E]; the README's first sketch
    instead puts every header in the block, which `headers_onchain=True`
    selects. The openings travel only in the mempool, aggregated client side
    into one STARK per transaction (leanPCS EIP draft [E]) of `opening_bytes`
    (placeholder: 990b935's recursive proof, 223,334 B [R, v2]). A mempool
    circuit verifies that STARK at `prove_ms_per_tx` (placeholder: the study's
    63 ms per merged child [M]) plus `prove_ms_per_claim` per claim (a claim
    walk, 2.5-5 us [Mo, study §3.1]). Gas: intrinsic + max(standard calldata
    + PIOP execution [R, 27,641] + PCS_TX_GAS + PCS_CLAIM_GAS per claim [E],
    floor). The draft says PCS_CLAIM_GAS "pays for each claim's share of the
    aggregation"; read literally, EIP-8288 would also charge every triple
    LEANSTARK_VERIFICATION_GAS (30,000) as its recursive-STARK share, which
    `recursive_share_gas=30000` selects [E, ambiguous]. `sig_bytes` enters
    nothing: the signature never travels.
    """
    work = max(1.0, k * perms_per_sig / CURRENT_PERMS)
    variables = variables_at_current + math.ceil(math.log2(work))
    header_bytes = 81 + 24 * variables
    onchain = calldata_bytes + claims_per_tx * triple_bytes
    if headers_onchain:
        onchain += claims_per_tx * header_bytes
    execution = (piop_exec_gas + pcs_tx_gas + claims_per_tx
                 * (pcs_claim_gas + recursive_share_gas))
    standard = standard_per_byte * onchain + execution
    floor = floor_per_byte * onchain
    return {
        "claims_per_tx": claims_per_tx,
        "header_bytes": header_bytes,
        "headers_onchain": headers_onchain,
        "opening_bytes": opening_bytes,
        "calldata_bytes": calldata_bytes,
        "prove_ms": prove_ms_per_tx + claims_per_tx * prove_ms_per_claim,
        "verify_ms": verify_ms,
        "gas": int(math.ceil(intrinsic_gas + max(standard, floor))),
    }


# -- network -------------------------------------------------------------------

def random_regular(nodes, degree, latency_ms, seed, jitter_frac=0.1):
    """v2's benchmark topology: a random regular graph, 10% edge jitter."""
    rng = random.Random(f"{seed}:topology")
    return Overlay.random_regular(nodes, degree, rng,
                                  base_latency=latency_ms,
                                  jitter_frac=jitter_frac, latency_seed=seed)


def small_world(nodes, degree, latency_ms, seed, rewire=0.1,
                jitter_frac=0.1):
    """A Watts-Strogatz ring: `degree` nearest neighbours, edges rewired.

    Each edge `(u, u + j)` is rewired with probability `rewire` to a uniform
    target, keeping the graph simple; degrees then vary around `degree`.
    Rewiring is retried until the graph is connected.
    """
    if degree % 2 or degree >= nodes:
        raise ValueError("small_world needs an even degree below nodes")
    rng = random.Random(f"{seed}:topology:small_world")
    for _ in range(50):
        adjacency = [set() for _ in range(nodes)]
        for node in range(nodes):
            for offset in range(1, degree // 2 + 1):
                other = (node + offset) % nodes
                adjacency[node].add(other)
                adjacency[other].add(node)
        for node in range(nodes):
            for offset in range(1, degree // 2 + 1):
                other = (node + offset) % nodes
                if other not in adjacency[node] or rng.random() >= rewire:
                    continue
                target = rng.randrange(nodes)
                if target == node or target in adjacency[node]:
                    continue
                adjacency[node].discard(other)
                adjacency[other].discard(node)
                adjacency[node].add(target)
                adjacency[target].add(node)
        overlay = Overlay.from_adjacency(adjacency, latency_ms,
                                         jitter_frac=jitter_frac,
                                         latency_seed=seed)
        if overlay.is_connected():
            return overlay
    raise RuntimeError("could not build a connected small-world overlay")


def adjacency_file(nodes, degree, latency_ms, seed, path, jitter_frac=0.1):
    """An explicit graph: a JSON list of neighbour lists, one per node.

    `nodes` and `degree` are ignored except for a size check; the file is
    the topology.
    """
    with open(path, encoding="utf-8") as handle:
        adjacency = json.load(handle)
    if len(adjacency) != nodes:
        raise ValueError(f"{path} has {len(adjacency)} nodes, not {nodes}")
    return Overlay.from_adjacency(adjacency, latency_ms,
                                  jitter_frac=jitter_frac, latency_seed=seed)


# -- selection -----------------------------------------------------------------

DEFAULT_MODELS = {
    "circuit_cost": {"fn": "bench.leansphincs.models:leanvm_circuit",
                     "kwargs": {}},
    "verify_cost": {"fn": "bench.leansphincs.models:native_verify",
                    "kwargs": {}},
    "noagg_verify_cost": {"fn": "bench.leansphincs.models:evm_verify",
                          "kwargs": {}},
    "gas_per_tx": {"fn": "bench.leansphincs.models:evm_frame_gas",
                   "kwargs": {}},
    "agg_gas_per_tx": {"fn": "bench.leansphincs.models:eip8288_gas",
                       "kwargs": {}},
    "pcs_model": {"fn": "bench.leansphincs.models:leanpcs_placeholder",
                  "kwargs": {}},
    "overlay": {"fn": "bench.leansphincs.models:random_regular",
                "kwargs": {}},
}


def resolve(spec):
    """`{"fn": "module:function", "kwargs": {...}, "path": dir}` -> callable.

    The callable returned has the spec's kwargs bound, so a caller passes
    only the positional knobs. A bare string is a spec without kwargs.
    """
    if isinstance(spec, str):
        spec = {"fn": spec}
    module_name, _, function_name = spec["fn"].partition(":")
    if not function_name:
        raise ValueError(f"model spec {spec['fn']!r} needs module:function")
    extra_path = spec.get("path")
    if extra_path and extra_path not in sys.path:
        sys.path.insert(0, extra_path)
    function = getattr(importlib.import_module(module_name), function_name)
    kwargs = dict(spec.get("kwargs", {}))

    def bound(*args, **more):
        merged = dict(kwargs)
        merged.update(more)
        return function(*args, **merged)

    bound.spec = {"fn": spec["fn"], "kwargs": kwargs}
    bound.accepts = _named_parameters(function)
    return bound


# Point knobs a cost model receives as keywords when its signature names
# them (and its spec does not already fix them): a prover model whose price
# depends on signature bytes sees the point's bytes without a per-point spec.
CONTEXT_KNOBS = ("sig_bytes",)


def _named_parameters(function):
    """The parameter names `function` declares; `**kw` names none of them."""
    try:
        parameters = inspect.signature(function).parameters.values()
    except (TypeError, ValueError):
        return frozenset()
    return frozenset(parameter.name for parameter in parameters
                     if parameter.kind in (parameter.POSITIONAL_OR_KEYWORD,
                                           parameter.KEYWORD_ONLY))


def context_kwargs(model, knobs):
    """The `CONTEXT_KNOBS` this resolved model declares and its spec leaves
    open, with their values at this point."""
    return {name: knobs[name] for name in CONTEXT_KNOBS
            if name in model.accepts and name not in model.spec["kwargs"]}


def models(overrides=None):
    """Every model, defaults overridden by a config's `models` block."""
    specs = {name: dict(spec) for name, spec in DEFAULT_MODELS.items()}
    for name, spec in (overrides or {}).items():
        if name not in specs:
            raise ValueError(f"unknown model {name!r}; one of "
                             f"{', '.join(sorted(specs))}")
        if isinstance(spec, str):
            spec = {"fn": spec}
        specs[name] = spec
    return {name: resolve(spec) for name, spec in specs.items()}


__all__ = ["CONTEXT_KNOBS", "CURRENT_PERMS", "CURRENT_SIG_BYTES",
           "DEFAULT_MODELS", "MAX_VERIFY_GAS", "PCS_KEYS", "adjacency_file",
           "context_kwargs", "eip8288_gas", "evm_frame_gas", "evm_verify",
           "evm_verify_gas", "leanpcs_placeholder", "leanvm_circuit", "leanvm_limited",
           "models", "native_verify", "precompile_gas", "random_regular",
           "resolve", "small_world"]

"""A grid of campaign points in parallel: `python3 -m bench.leansphincs.sweep`.

    python3 -m bench.leansphincs.sweep --grid grid.json --jobs 6 --out out.csv

The grid is JSON:

    {"base":   {knobs common to every point, including "set" and "models"},
     "axes":   {"scenario": ["noagg", "agg8288"], "sig_bytes": [4164, 7740],
                "perms": [355, 515], "seed": [0, 1]},
     "points": [{"scenario": "pcs", "perms": 515}]}

A `scenario` in `base` or in a point may be a campaign scenario id or the
name of one of its configurations (`python3 -m bench.leansphincs scenarios`):
the configuration is loaded below the base, and a `candidate` axis sets bytes
and permutations for any name of PHASE2B.md section 2 or of
data/phase2/candidates_v2.csv (bench/leansphincs/registry.py).
`--scenario` sets it for a grid that names none, and without `--grid` the
grid is the eight candidates of PHASE2B.md section 2, or `--axes` given as
JSON:

    python3 -m bench.leansphincs.sweep --scenario A --out a.csv
    python3 -m bench.leansphincs.sweep --scenario B_pr12616_16 --jobs 8 \
        --axes '{"sig_bytes": [4308, 5980, 7740], "perms": [283, 415, 515]}' \
        --out b.csv --phase2-csv b_tidy.csv

Every combination of `axes` (cartesian, in the listed order) and every entry
of `points` is merged over `base`; either may be absent. Knob names are those
of `bench.leansphincs.scenario.DEFAULTS`. Points run in worker processes
(`--jobs`, at most 8, every worker under `nice 10`), and rows are written in
grid order whatever the scheduling, so one grid at one code version gives a
byte-identical CSV. The columns are fixed by the first point that succeeds
(earlier failed points wait for it), and always include capacity mode's, so
run and capacity points can share one grid. `point_id` hashes a point's
resolved knobs; `--resume` skips points already in `--out` without an error
and appends the rest, so a re-run failure leaves its old row above the new
one (the last row of a `point_id` is current). Wall time per point is
printed to stderr and kept in `--jsonl` records, never in the CSV.
`--dry-run` lists the points and their batch sizes without running them.
"""

import argparse
import csv
import hashlib
import itertools
import json
import multiprocessing
import os
import sys
import time

from bench.common import _json_value
from bench.leansphincs import registry
from bench.leansphincs.scenario import CAPACITY_KEYS, evaluate, resolve_knobs
from bench.leansphincs.schema import (PHASE2_COLUMNS, fill_elasticities,
                                      phase2_row)

MAX_JOBS = 8

# Leading columns, in this order; every other result key follows sorted.
LEADING = ("point_id", "error", "scenario", "sig_bytes", "perms", "k", "seed",
           "offered_tps", "tps_included_window", "tps_included_total",
           "analytic_bound_tps", "analytic_binding", "degradation")
EXCLUDED = ("runtime_s",)


def points(grid):
    """Every point of a grid, merged over its base, in a fixed order."""
    base = grid.get("base", {})
    result = []
    axes = grid.get("axes", {})
    if axes:
        names = list(axes)
        for values in itertools.product(*(axes[name] for name in names)):
            result.append(dict(zip(names, values)))
    result.extend(grid.get("points", []))
    if not result:
        result.append({})
    resolved = []
    for point in result:
        top = registry.merged(base, point)
        if registry.is_named(top.get("scenario")):
            resolved.append(resolve_knobs(*registry.layers(top)))
        else:
            resolved.append(resolve_knobs(base, point))
    return resolved


def point_id(knobs):
    text = json.dumps(knobs, sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(text.encode()).hexdigest()[:12]


WORKER_NICENESS = 10


def _worker_init():
    """Run at niceness 10, not 10 more: spawned workers inherit the parent's
    niceness, and the parent may already run under `nice`."""
    try:
        os.nice(max(0, WORKER_NICENESS - os.nice(0)))
    except OSError:
        pass


def _run_point(knobs):
    started = time.perf_counter()
    try:
        row = evaluate(knobs)
        row["error"] = ""
    except Exception as error:  # a failed point is a row, not a dead sweep
        row = {"scenario": knobs["scenario"], "sig_bytes": knobs["sig_bytes"],
               "perms": knobs["perms"], "k": knobs["k"], "seed": knobs["seed"],
               "error": f"{type(error).__name__}: {error}"}
    row["point_id"] = point_id(knobs)
    row["runtime_s"] = time.perf_counter() - started
    return row


def columns_for(row):
    """The CSV header a successful row implies: the leading columns, then
    every other key sorted, capacity mode's included whatever the mode."""
    rest = sorted((set(row) | set(CAPACITY_KEYS)) - set(LEADING)
                  - set(EXCLUDED))
    return list(LEADING) + rest


def _cell(value):
    if isinstance(value, float):
        return "%.6f" % value
    return str(value)


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="python3 -m bench.leansphincs.sweep", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--grid", help="grid JSON; optional with --scenario")
    parser.add_argument("--scenario",
                        help="a scenario id or configuration name for a grid "
                             "whose base names no scenario")
    parser.add_argument("--axes",
                        help="axes as JSON, in place of a grid's (default "
                             "with --scenario alone: the eight candidates "
                             "of PHASE2B.md section 2)")
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--out", required=True, help="CSV output")
    parser.add_argument("--jsonl", help="also write one JSON record per point")
    parser.add_argument("--phase2-csv",
                        help="also write the PHASE2.md section 4 columns, "
                             "one row per successful point, elasticities "
                             "filled over the grid at the end")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    if args.jobs < 1:
        parser.error("--jobs must be >= 1")
    if args.jobs > MAX_JOBS:
        print(f"--jobs {args.jobs} capped at {MAX_JOBS} (shared box)",
              file=sys.stderr)
        args.jobs = MAX_JOBS
    _worker_init()
    if args.grid:
        with open(args.grid, encoding="utf-8") as handle:
            grid = json.load(handle)
    elif args.scenario:
        grid = {"axes": {"candidate": list(registry.PHASE2B_CANDIDATES)}}
    else:
        parser.error("--grid or --scenario is required")
    if args.axes:
        grid["axes"] = json.loads(args.axes)
    if args.scenario:
        grid["base"] = dict(grid.get("base", {}))
        grid["base"].setdefault("scenario", args.scenario)
    todo = points(grid)
    done = set()
    if args.resume and os.path.exists(args.out):
        with open(args.out, encoding="utf-8", newline="") as handle:
            for record in csv.DictReader(handle):
                if not record.get("error"):
                    done.add(record["point_id"])
    todo = [knobs for knobs in todo if point_id(knobs) not in done]
    print(f"{len(todo)} points to run ({len(done)} already done), "
          f"{args.jobs} jobs", file=sys.stderr)
    if args.dry_run:
        for knobs in todo:
            print(point_id(knobs), json.dumps(knobs, sort_keys=True))
        return 0
    append = args.resume and os.path.exists(args.out) and done
    csv_handle = open(args.out, "a" if append else "w", encoding="utf-8",
                      newline="")
    jsonl_handle = None
    if args.jsonl:
        jsonl_handle = open(args.jsonl, "a" if append else "w",
                            encoding="utf-8")
    writer = csv.writer(csv_handle)
    columns = None
    if append:
        with open(args.out, encoding="utf-8", newline="") as handle:
            columns = next(csv.reader(handle))
    # Rows wait here, in grid order, until a successful one fixes the header:
    # a failed point carries only the leading keys and cannot name the rest.
    waiting = []
    unknown = set()
    phase2_rows = []

    def write(row):
        unknown.update(set(row) - set(columns) - set(EXCLUDED))
        writer.writerow([_cell(row.get(column, "")) for column in columns])
    started = time.perf_counter()
    if args.jobs == 1:
        results = map(_run_point, todo)
        pool = None
    else:
        pool = multiprocessing.get_context("spawn").Pool(
            args.jobs, initializer=_worker_init)
        results = pool.imap(_run_point, todo)
    try:
        for index, row in enumerate(results, 1):
            waiting.append(row)
            if not row["error"]:
                phase2_rows.append(phase2_row(row))
            if columns is None and not row["error"]:
                columns = columns_for(row)
                writer.writerow(columns)
            if columns is not None:
                for ready in waiting:
                    write(ready)
                waiting = []
                csv_handle.flush()
            if jsonl_handle is not None:
                jsonl_handle.write(json.dumps(_json_value(row),
                                              sort_keys=True) + "\n")
                jsonl_handle.flush()
            status = row["error"] or "ok"
            print(f"[{index}/{len(todo)}] {row['point_id']} "
                  f"{row['scenario']} sig={row['sig_bytes']} "
                  f"perms={row['perms']} k={row['k']} "
                  f"{row['runtime_s']:.1f}s {status}", file=sys.stderr)
    finally:
        if pool is not None:
            pool.close()
            pool.join()
        if waiting:
            # Every point failed: the leading columns are all there is.
            if columns is None:
                columns = list(LEADING)
                writer.writerow(columns)
            for ready in waiting:
                write(ready)
        csv_handle.close()
        if jsonl_handle is not None:
            jsonl_handle.close()
    if args.phase2_csv:
        tidy = fill_elasticities(phase2_rows)
        with open(args.phase2_csv, "a" if append else "w", encoding="utf-8",
                  newline="") as handle:
            tidy_writer = csv.writer(handle)
            if not append:
                tidy_writer.writerow(PHASE2_COLUMNS)
            for record in tidy:
                tidy_writer.writerow([_cell(record[column])
                                      for column in PHASE2_COLUMNS])
    if unknown:
        print(f"columns not in the CSV header (kept in --jsonl only): "
              f"{', '.join(sorted(unknown))}", file=sys.stderr)
    print(f"done in {time.perf_counter() - started:.0f} s", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""One campaign run: knobs and models in, a flat result row out.

The three deployment scenarios share v2's overlay, relay, bandwidth, CPU and
chain machinery; they differ only in what a transaction weighs, what proving
and verifying it costs, and how a block is bounded:

- `noagg` (S1): `aggregation="none"`. A transaction carries `k` signatures
  in calldata, travels raw, and a block packs transactions under the gas
  limit and byte cap.
- `agg8288` (S2): EIP-8288 under a v2 preset. A transaction carries `k`
  dependency triples on chain; its signatures travel only in the mempool
  (raw objects and mode 0 wrappers) and are proved in-circuit at a price
  linear in permutations per signature.
- `pcs` (S3): the same machinery with leanPCS's shape: on-chain PCS claim
  headers and PIOP calldata, an opening proof that lives only in the mempool
  until a recursive STARK attests it.

A simulated leaf is a *batch* of identical transactions: every per-leaf
size, gas and cost is the per-transaction figure times `batch`, and counts
are multiplied back. Batching is the speed knob for high rates; its
accuracy cost is in sims/LEANSPHINCS-FORK.md.
"""

import json
import math
import os
import random
import statistics
import time

from bench.common import configuration, schedule_horizon
from bench.leansphincs import models as model_registry
from bench.leansphincs.schema import binding_evidence, binding_label
from starksim.arena import KIND_PQ
from starksim.block_limits import BlockLimits
from starksim.costs import (CircuitCost, CostTable, LimitedCircuitCost,
                            NativeVerifyCost)
from starksim.evidence import diffusion
from starksim.netsim import NetworkSim
from starksim.network import SizeModel, bytes_per_ms
from starksim.outcomes import (BusySample, TrafficSample, traffic_window,
                               utilisation_window)
from starksim.work_metrics import cpu_accounting

SCENARIOS = ("noagg", "agg8288", "pcs")

# Defaults. Every one is a knob; sources are in sims/LEANSPHINCS-FORK.md.
DEFAULTS = {
    "scenario": "agg8288",
    "sig_bytes": model_registry.CURRENT_SIG_BYTES,
    "perms": model_registry.CURRENT_PERMS,
    "k": 1,
    "tps": None,              # None: load_factor x the load_basis bound
    "load_factor": 2.0,
    # The bound an offered rate without `tps` scales (a capacity search
    # always starts from the ideal one). "analytic": the minimum of gas,
    # bytes, prover and the rough bandwidth estimate. "ideal": gas, bytes
    # and prover only, for runs
    # that must load the chain to its limit whatever the rough bandwidth
    # reading says (the named scenarios, bench/leansphincs/registry.py).
    "load_basis": "analytic",
    "batch": "auto",
    "leaves_per_s": 40.0,     # auto batch: about this many leaves per second
    "nodes": 40,
    "degree": 6,
    "uplink_mbps": 25.0,      # 0 means unmetered
    "latency_ms": 100.0,
    "egress_bytes": None,
    "slot_ms": 12000.0,
    # Transactions are born over warmup_slots + measured_slots slots, and
    # the row measures the measured_slots after the warm-up. `birth_slots`
    # is that sum: a layer that sets it instead fixes the measured window to
    # birth_slots - warmup_slots. Of the two, the later setting stands.
    "birth_slots": None,
    "warmup_slots": 1,
    "measured_slots": 4,
    "drain_slots": 1,
    "seed": 0,
    "gas_limit": 60_000_000,  # 0 means no gas limit
    "byte_limit": 8_388_608,  # EIP-7934 MAX_RLP_BLOCK_SIZE; 0 means none
    "header_bytes": 600,
    "tx_bytes": 200,          # non-signature bytes of one transaction
    "proof_bytes": 223_334,   # one recursive proof (leanVM 990b935)
    "preset": "eip_faithful",
    "relay_policy": "announce_fetch",
    "chain_notify": "overlay",
    "proposer_mode": "fixed",
    # A block reaching nine tenths of the nodes later than this is counted
    # late: the attestation deadline, 4 s into a 12 s slot. Reported only;
    # the model never orphans a block.
    "attest_deadline_ms": 4000.0,
    # EIP-8141's MAX_VERIFY_GAS: S1 transactions whose VERIFY gas exceeds it
    # are flagged (a k-of-n multisig crosses it first), not refused.
    "max_verify_gas": model_registry.MAX_VERIFY_GAS,
    "set": {},
    "models": {},
    # "run": one point at the offered rate. "capacity": search the offered
    # rate for the highest one the network sustains (see find_capacity).
    "mode": "run",
    "sustain_fraction": 0.95,
    "capacity_tolerance": 0.05,
    "capacity_max_runs": 12,
    # Service order of a node's waiting CPU jobs. "priority" serves a
    # received block before proving, as a client does; "fifo" is the
    # simulator's own default, under which block verification queues behind
    # proving (REPORT-PHASE2.md section 9, defect 1).
    "cpu_discipline": "priority",
    # -- phase 2 (sims/LEANSPHINCS-FORK.md, "Phase-2 settings") --------------
    # A network profile of data/network_params.json: it supplies degree,
    # uplink_mbps and latency_ms wherever a layer did not set them.
    "profile": None,
    "network_params": None,   # path; None is <campaign>/data/network_params.json
    # "uniform": every node at uplink_mbps. "heterogeneous": the profile's
    # uplinks_heterogeneous mixture. Or the mixture itself, as a dict.
    "uplinks": "uniform",
    # Blocks leave a node before its mempool traffic and a full send buffer
    # cannot refuse them ("fifo" is phase 1's shared queue).
    "egress_priority": "blocks_first",
    # None: unbounded, or drop-tail when egress_bytes is set (phase 1's
    # rule). "unbounded", "drop_tail" (needs egress_bytes) or "supersede".
    "wrapper_queue": None,
    # A node forwards a block after gossip validation ("verify" is phase 1's
    # store-and-forward after full verification).
    "block_relay": "validate",
    "block_validate_ms": 2.0,
    # Peers a node sends a block to (a gossip mesh of that degree); None
    # floods every peer. A profile supplies its block_gossip_degree.
    "block_fanout": None,
    # A block is timely when this share of the nodes holds it
    # attest_deadline_ms after it was built.
    "timely_fraction": 0.9,
    # With orphaning on, a block that fewer than orphan_fraction of the nodes
    # hold at the deadline does not count towards tps_canonical.
    "orphan_late_blocks": False,
    "orphan_fraction": 0.2,
    # "phase1" puts egress_priority, block_relay and block_validate_ms back
    # to phase 1's values wherever a layer did not set them.
    "compat": None,
    # leanPCS (the pcs class: F1, F2, F3) only: what the mempool does with a
    # client's proof (notes/phase2b/facts-leanpcs.md L10-L16).
    # "merge": the proof is relayed raw and every node that receives it
    #   folds it into its own aggregate. The preset's behaviour and what
    #   phase 2 ran; neither the leanPCS draft nor EIP-8288 describes it.
    # "draft": the flow the leanPCS draft takes from EIP-8288. The node a
    #   user sends the proof to verifies and merges it, and forwards only
    #   its own per-interval aggregate (relay_policy "wrapper_only").
    # "relay": nodes verify a client proof and relay it unmerged; only the
    #   block's builder merges (one aggregator, the proposer, and relays
    #   forward no proof of their own). Unspecified in the draft and in
    #   EIP-8288; the open EIP-8288 drafts allow an unchanged relay.
    "client_proofs": "merge",
    # Labels carried into the row and the phase-2 schema, never interpreted.
    "scenario_id": None, "variant": None, "pricing": None, "candidate": None,
    "status": None, "source": None,
    # Where the prover's rows per signature come from: counted on leanVM
    # runs or modelled (the registry sets it; NA where nothing is proved).
    "prover_cost": None,
}

PHASE1_COMPAT = {"egress_priority": "fifo", "block_relay": "verify",
                 "block_validate_ms": 0.0, "cpu_discipline": "fifo",
                 "measured_slots": 3}
LABEL_KNOBS = ("scenario_id", "variant", "pricing", "candidate", "status",
               "source", "prover_cost")
NULLABLE_KNOBS = ("tps", "egress_bytes", "profile", "network_params",
                  "wrapper_queue", "compat", "block_fanout") + LABEL_KNOBS
PROFILE_MEMPOOL = {"noagg": "public_mempool", "agg8288": "agg_mempool",
                   "pcs": "agg_mempool"}


def network_params_path(knobs):
    """The campaign's network parameters: the knob, or data/ beside sims/."""
    if knobs.get("network_params"):
        return knobs["network_params"]
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.normpath(os.path.join(here, "..", "..", "..", "..",
                                         "data", "network_params.json"))


_PARAMS_CACHE = {}


def load_profile(knobs):
    path = network_params_path(knobs)
    if path not in _PARAMS_CACHE:
        with open(path, encoding="utf-8") as handle:
            _PARAMS_CACHE[path] = json.load(handle)
    profiles = _PARAMS_CACHE[path]["profiles"]
    if knobs["profile"] not in profiles:
        raise ValueError(f"profile must be one of {', '.join(profiles)} "
                         f"(from {path})")
    return profiles[knobs["profile"]]


def profile_knobs(knobs):
    """degree, uplink_mbps and latency_ms of a named profile.

    The uplink is the profile's effective rate, (uplink - background) x
    goodput, which is what its `network_sim.capacity` holds. The degree is
    lowered to fit a small network: below the node count, with nodes x degree
    even.
    """
    profile = load_profile(knobs)
    mempool = profile[PROFILE_MEMPOOL[knobs["scenario"]]]
    degree = int(mempool["overlay"]["degree"])
    nodes = int(knobs["nodes"])
    degree = min(degree, nodes - 1)
    if (nodes * degree) % 2:
        degree -= 1
    values = {"degree": degree,
              "uplink_mbps": mempool["network_sim"]["capacity"] / 125.0,
              "latency_ms": profile["latency"]["uniform_base_latency_ms"]}
    # Blocks travel on the consensus layer's mesh, not to every
    # transaction-overlay peer: the profile's block_gossip_degree, where it
    # is narrower than the overlay. Phase 1 flooded every peer.
    fanout = mempool.get("extensions", {}).get("block_gossip_degree")
    if fanout is not None and fanout < degree and knobs["compat"] != "phase1":
        values["block_fanout"] = int(fanout)
    return values


def draw_uplinks(knobs):
    """Per-node effective uplinks in Mbit/s, or None for uniform.

    A mixture is a list of classes, each a share of the nodes at one nominal
    uplink. Classes are apportioned to the node count by largest remainder,
    so the shares are exact rather than sampled, and then dealt to node ids by
    a shuffle that depends on the seed alone. The effective rate is
    (uplink - background_mbps) x goodput_frac, never below min_mbps.
    """
    spec = knobs["uplinks"]
    if spec == "uniform":
        return None
    if spec == "heterogeneous":
        if not knobs["profile"]:
            raise ValueError("uplinks='heterogeneous' needs a profile, or "
                             "pass the mixture itself")
        profile = load_profile(knobs)
        spec = profile["uplinks_heterogeneous"]
    if not isinstance(spec, dict) or not spec.get("classes"):
        raise ValueError("uplinks must be 'uniform', 'heterogeneous' or a "
                         "mixture {classes: [{share, uplink_mbps}, ...]}")
    classes = spec["classes"]
    total = sum(float(entry["share"]) for entry in classes)
    if total <= 0:
        raise ValueError("uplink class shares must sum to a positive number")
    nodes = knobs["nodes"]
    exact = [nodes * float(entry["share"]) / total for entry in classes]
    counts = [int(value) for value in exact]
    by_remainder = sorted(range(len(classes)),
                          key=lambda index: (counts[index] - exact[index],
                                             index))
    for index in by_remainder[:nodes - sum(counts)]:
        counts[index] += 1
    background = float(spec.get("background_mbps", 0.0))
    goodput = float(spec.get("goodput_frac", 1.0))
    floor = float(spec.get("min_mbps", 1.0))
    rates = []
    for entry, count in zip(classes, counts):
        rate = max(floor, (float(entry["uplink_mbps"]) - background) * goodput)
        rates.extend([rate] * count)
    random.Random(f"{knobs['seed']}:uplinks").shuffle(rates)
    return rates

CHOICES = {"egress_priority": ("fifo", "blocks_first"),
           "wrapper_queue": (None, "unbounded", "drop_tail", "supersede"),
           "block_relay": ("verify", "validate"),
           "compat": (None, "phase1"),
           "load_basis": ("analytic", "ideal"),
           "cpu_discipline": ("fifo", "priority"),
           "client_proofs": ("merge", "draft", "relay")}

INTEGER_KNOBS = ("sig_bytes", "perms", "k", "nodes", "degree", "birth_slots",
                 "warmup_slots", "measured_slots", "drain_slots", "seed",
                 "gas_limit",
                 "byte_limit", "header_bytes", "tx_bytes", "proof_bytes",
                 "max_verify_gas")
FLOAT_KNOBS = ("load_factor", "leaves_per_s", "uplink_mbps", "latency_ms",
               "slot_ms", "sustain_fraction", "capacity_tolerance",
               "attest_deadline_ms", "block_validate_ms", "timely_fraction",
               "orphan_fraction")


def resolve_knobs(*layers):
    """Defaults, then each layer in order; types normalised, values checked."""
    knobs = json.loads(json.dumps(DEFAULTS))
    explicit = set()
    for layer in layers:
        for key, value in (layer or {}).items():
            if key not in DEFAULTS:
                raise ValueError(f"unknown knob {key!r}")
            if value is None and key not in NULLABLE_KNOBS:
                continue
            explicit.add(key)
            # The birth window and the measured window state one thing: the
            # later of the two settings stands.
            if key == "birth_slots":
                explicit.discard("measured_slots")
            elif key == "measured_slots":
                explicit.discard("birth_slots")
            if key in ("set", "models"):
                merged = dict(knobs[key])
                merged.update(value)
                knobs[key] = merged
            else:
                knobs[key] = value
    if knobs["scenario"] not in SCENARIOS:
        raise ValueError(f"scenario must be one of {', '.join(SCENARIOS)}")
    for key, allowed in CHOICES.items():
        if knobs[key] not in allowed:
            raise ValueError(f"{key} must be one of "
                             f"{', '.join(str(value) for value in allowed)}")
    if knobs["compat"] == "phase1":
        for key, value in PHASE1_COMPAT.items():
            if key not in explicit:
                knobs[key] = value
    # The measured window: a setting, or what an explicit birth window
    # leaves after the warm-up.
    if "birth_slots" in explicit:
        knobs["measured_slots"] = (int(knobs["birth_slots"])
                                   - int(knobs["warmup_slots"]))
    else:
        knobs["birth_slots"] = (int(knobs["warmup_slots"])
                                + int(knobs["measured_slots"]))
    if knobs["profile"]:
        knobs["nodes"] = int(knobs["nodes"])
        for key, value in profile_knobs(knobs).items():
            if key not in explicit:
                knobs[key] = value
    if knobs["client_proofs"] != "merge" and knobs["scenario"] != "pcs":
        raise ValueError("client_proofs is a leanPCS setting (the pcs "
                         "class: F1, F2, F3); EIP-8288 without mempool "
                         "aggregation is scenario C2")
    if knobs["block_fanout"] is not None:
        knobs["block_fanout"] = int(knobs["block_fanout"])
        if knobs["block_fanout"] < 1:
            raise ValueError("block_fanout must be >= 1, or null for every "
                             "peer")
    if knobs["block_relay"] != "validate":
        if "block_validate_ms" in explicit and knobs["block_validate_ms"]:
            raise ValueError("block_validate_ms needs block_relay='validate'")
        knobs["block_validate_ms"] = 0.0
    if knobs["wrapper_queue"] == "drop_tail" and knobs["egress_bytes"] is None:
        raise ValueError("wrapper_queue='drop_tail' needs egress_bytes")
    if knobs["wrapper_queue"] == "unbounded" and knobs["egress_bytes"]:
        raise ValueError("wrapper_queue='unbounded' contradicts egress_bytes")
    knobs["orphan_late_blocks"] = bool(knobs["orphan_late_blocks"])
    for key in INTEGER_KNOBS:
        knobs[key] = int(knobs[key])
    for key in FLOAT_KNOBS:
        knobs[key] = float(knobs[key])
    if knobs["tps"] is not None:
        knobs["tps"] = float(knobs["tps"])
    if knobs["egress_bytes"] is not None:
        knobs["egress_bytes"] = int(knobs["egress_bytes"])
    knobs["capacity_max_runs"] = int(knobs["capacity_max_runs"])
    if knobs["mode"] not in ("run", "capacity"):
        raise ValueError("mode must be 'run' or 'capacity'")
    if knobs["scenario"] not in SCENARIOS:
        raise ValueError(f"scenario must be one of {', '.join(SCENARIOS)}")
    for key in ("sig_bytes", "perms", "k", "nodes", "birth_slots"):
        if knobs[key] < 1:
            raise ValueError(f"{key} must be >= 1")
    if "birth_slots" not in explicit and knobs["measured_slots"] < 1:
        raise ValueError("measured_slots must be >= 1")
    if knobs["warmup_slots"] >= knobs["birth_slots"]:
        raise ValueError("warmup_slots must be below birth_slots")
    if knobs["batch"] != "auto":
        knobs["batch"] = int(knobs["batch"])
        if knobs["batch"] < 1:
            raise ValueError("batch must be >= 1 or 'auto'")
    return knobs


def _limit(value):
    return None if value <= 0 else value


class Shape:
    """Per-transaction figures of one scenario at one parameter point."""

    def __init__(self, knobs, resolved):
        scenario = knobs["scenario"]
        sig_bytes = knobs["sig_bytes"]
        perms = knobs["perms"]
        k = knobs["k"]
        self.scenario = scenario
        self.pcs = None
        if scenario == "noagg":
            self.triple_bytes = 0
            self.witness_bytes = k * sig_bytes
            self.body_bytes = knobs["tx_bytes"]
            self.onchain_bytes = knobs["tx_bytes"] + k * sig_bytes
            self.gas = int(resolved["gas_per_tx"](sig_bytes, perms, k))
        elif scenario == "agg8288":
            self.triple_bytes = k * model_registry.TRIPLE_BYTES
            self.witness_bytes = k * sig_bytes
            self.body_bytes = knobs["tx_bytes"]
            self.onchain_bytes = knobs["tx_bytes"] + self.triple_bytes
            self.gas = int(resolved["agg_gas_per_tx"](sig_bytes, perms, k))
        else:
            pcs = dict(resolved["pcs_model"](sig_bytes, perms, k))
            missing = [key for key in model_registry.PCS_KEYS
                       if key not in pcs]
            if missing:
                raise ValueError(f"pcs_model returned no {missing}")
            self.pcs = pcs
            claims = int(pcs["claims_per_tx"])
            self.triple_bytes = claims * model_registry.TRIPLE_BYTES
            self.witness_bytes = int(pcs["opening_bytes"])
            headers = claims * int(pcs["header_bytes"])
            self.body_bytes = (knobs["tx_bytes"] + int(pcs["calldata_bytes"])
                               + headers)
            # The block carries the triples, the calldata and, only when the
            # model says so, the headers themselves.
            self.onchain_bytes = (knobs["tx_bytes"]
                                  + int(pcs["calldata_bytes"])
                                  + self.triple_bytes)
            if pcs.get("headers_onchain", False):
                self.onchain_bytes += headers
            self.gas = int(pcs["gas"])
        # What one transaction weighs as a raw mempool object.
        self.wire_bytes = self.body_bytes + self.triple_bytes + self.witness_bytes


def _circuit(knobs, resolved, shape, batch):
    if shape.scenario == "noagg":
        return None
    sigs_per_leaf = knobs["k"] * batch
    model = resolved["circuit_cost"]
    circuit = model(knobs["perms"], sigs_per_leaf,
                    **model_registry.context_kwargs(model, knobs))
    if shape.scenario == "pcs":
        # The same calibration prices nesting and overhead; only a leaf's
        # in-circuit work is the PCS model's.
        fields = dict(
            ms_per_hash=circuit.ms_per_hash,
            overhead_hashes=circuit.overhead_hashes,
            sphincs_hashes=(batch * float(shape.pcs["prove_ms"])
                            / circuit.ms_per_hash),
            leanstark_hashes=circuit.leanstark_hashes,
            recursive_hashes=circuit.recursive_hashes,
            trace_rows_per_hash=circuit.trace_rows_per_hash,
            trace_cap=circuit.trace_cap)
        if isinstance(circuit, LimitedCircuitCost):
            # The limits and the proof size carry over, counted in PCS claim
            # slots. A leaf's price is the PCS model's, so a signature
            # staircase does not apply and the price stays linear.
            circuit = LimitedCircuitCost(
                max_children=circuit.max_children,
                max_claims=circuit.max_claims,
                claims_per_leaf=batch * int(shape.pcs["claims_per_tx"]),
                proof_size=circuit.proof_size, **fields)
        else:
            circuit = CircuitCost(**fields)
    return circuit


def _proof_bytes(knobs, shape, circuit, batch):
    """The constant proof size, and the per-content size function if the
    circuit model supplies one.

    Without one, the `proof_bytes` knob is every proof's size. With one, a
    proof's size follows what it claims, and the constant (which the block
    packer's allowance, the mode-0 comparison and the analytic bounds read)
    is the model's size for a full block's claims: the gas limit's worth of
    transactions, or one leaf when there is no gas limit.
    """
    if circuit is None or circuit.proof_bytes(1) is None:
        return knobs["proof_bytes"], None
    leaves = 1
    gas_limit = _limit(knobs["gas_limit"])
    if gas_limit is not None:
        leaves = max(1, gas_limit // (shape.gas * batch))
    return circuit.proof_bytes(leaves), circuit.proof_bytes


def _verify(knobs, resolved, shape, batch):
    name = "noagg_verify_cost" if shape.scenario == "noagg" else "verify_cost"
    model = resolved[name]
    native = model(knobs["perms"], knobs["k"] * batch,
                   **model_registry.context_kwargs(model, knobs))
    if shape.scenario == "noagg":
        return native
    if shape.scenario == "pcs":
        return NativeVerifyCost(per_signature=batch * float(
                                    shape.pcs["verify_ms"]),
                                per_stark=native.per_stark,
                                per_message=native.per_message)
    return native


def analytic_bounds(knobs, shape, circuit, settings):
    """Arithmetic bounds in transactions per second [Mo], per resource.

    - gas, bytes: a full block every slot, one transaction's gas and bytes.
    - prover (S2, S3): one node, one interval: its proving budget less the
      fixed cost and one merge of its own previous aggregate, divided by one
      transaction's in-circuit cost. Exact for a lone prover that sees every
      transaction at once; a network of provers that duplicate work does
      worse, and one that splits work could do better.
    - bandwidth (`bandwidth_estimate_tps`, an estimate and not a bound:
      realised rates exceed it): one node's uplink over its per-transaction
      egress -- raw
      relay copies (flood: degree; announce-fetch: one body plus degree
      hashes), the block forwarded to degree peers, and under aggregation
      each wrapper's proof and its per-claim triple and hash, with claims
      resident about half a slot plus one interval. A rough reading, which
      can undercount what the network carries (a folded raw object is no
      longer served), so it may be the minimum without binding.

    `analytic_bound_tps` is the minimum of the three bounds and the
    bandwidth estimate; it scales an offered rate under
    `load_basis="analytic"` and nothing else reads it. `ideal_bound_tps` is
    the minimum of gas, bytes and prover only: the throughput with
    networking assumed away, which `degradation` and `capacity_vs_ideal`
    measure against and where the capacity search starts.
    """
    slot_s = knobs["slot_ms"] / 1000.0
    bounds = {}
    gas_limit = _limit(knobs["gas_limit"])
    byte_limit = _limit(knobs["byte_limit"])
    bounds["gas_bound_tps"] = -1.0
    if gas_limit is not None:
        bounds["gas_bound_tps"] = (gas_limit // shape.gas) / slot_s
    bounds["byte_bound_tps"] = -1.0
    if byte_limit is not None:
        base = knobs["header_bytes"]
        if shape.scenario != "noagg":
            base += settings.get("_proof_bytes", knobs["proof_bytes"])
        bounds["byte_bound_tps"] = ((byte_limit - base)
                                    // shape.onchain_bytes) / slot_s
    bounds["prover_bound_tps"] = -1.0
    interval_s = settings.get("aggregation_interval", 1000.0)
    interval_s = float(interval_s) / 1000.0
    if circuit is not None:
        budget = settings.get("proving_budget")
        if budget is None:
            budget = interval_s * 1000.0
        per_tx_hashes = circuit.sphincs_hashes / _batch_of(settings)
        spare = (float(budget) / circuit.ms_per_hash - circuit.overhead_hashes
                 - circuit.recursive_hashes)
        bounds["prover_bound_tps"] = max(0.0, spare / per_tx_hashes) / interval_s
    bounds["bandwidth_estimate_tps"] = -1.0
    if knobs["uplink_mbps"] > 0:
        uplink = knobs["uplink_mbps"] * 125_000.0
        degree = knobs["degree"]
        relay = settings.get("relay_policy", "flood")
        if relay == "flood":
            per_tx = degree * shape.wire_bytes
        else:
            per_tx = shape.wire_bytes + degree * 32
        per_tx += degree * shape.onchain_bytes
        standing = 0.0
        if shape.scenario != "noagg":
            residence_s = slot_s / 2.0 + interval_s
            per_tx += (degree * residence_s * (shape.triple_bytes + 32)
                       / interval_s)
            standing = (degree * settings.get("_proof_bytes",
                                              knobs["proof_bytes"])
                        / interval_s)
        bounds["bandwidth_estimate_tps"] = (max(0.0, uplink - standing)
                                            / per_tx)
    candidates = {name: value for name, value in bounds.items() if value >= 0}
    ideal = {name: value for name, value in candidates.items()
             if name != "bandwidth_estimate_tps"}
    for prefix, pool in (("analytic", candidates), ("ideal", ideal)):
        bounds[prefix + "_bound_tps"] = -1.0
        bounds[prefix + "_binding"] = "none"
        if pool:
            binding = min(pool, key=pool.get)
            bounds[prefix + "_bound_tps"] = pool[binding]
            bounds[prefix + "_binding"] = binding.replace(
                "_bound_tps", "").replace("_tps", "")
    return bounds


def _batch_of(settings):
    return settings["_batch"]


def build(knobs):
    """The simulator and its workload plan for one run, not yet scheduled."""
    resolved = model_registry.models(knobs["models"])
    shape = Shape(knobs, resolved)
    scenario = knobs["scenario"]
    uplinks = draw_uplinks(knobs)
    if uplinks is not None:
        # The rough bandwidth estimate reads one rate: the median node's.
        knobs = dict(knobs, uplink_mbps=statistics.median(uplinks),
                     _uplinks=uplinks)
    # Pass one: the bound at batch 1 decides the offered rate, which decides
    # the batch.
    probe_settings = _settings(knobs, shape, resolved, batch=1)
    bounds = analytic_bounds(knobs, shape,
                             _circuit(knobs, resolved, shape, 1),
                             probe_settings)
    tps = knobs["tps"]
    if tps is None:
        basis = bounds[knobs["load_basis"] + "_bound_tps"]
        if basis <= 0:
            raise ValueError(f"no {knobs['load_basis']} bound to scale: "
                             "pass --tps")
        tps = knobs["load_factor"] * basis
    batch = knobs["batch"]
    if batch == "auto":
        batch = max(1, math.ceil(tps / knobs["leaves_per_s"]))
    settings = _settings(knobs, shape, resolved, batch)
    circuit = settings["_circuit"]
    overlay = resolved["overlay"](knobs["nodes"], knobs["degree"],
                                  knobs["latency_ms"], knobs["seed"])
    constructor = {key: value for key, value in settings.items()
                   if not key.startswith("_")}
    sim = NetworkSim(overlay, **constructor)
    model_specs = {name: callable_.spec for name, callable_ in resolved.items()}
    return sim, {"shape": shape, "bounds": bounds, "tps": tps, "batch": batch,
                 "circuit": circuit, "models": model_specs,
                 "scenario": scenario, "uplinks": uplinks}


def _settings(knobs, shape, resolved, batch):
    """NetworkSim keyword arguments for one batch size."""
    scenario = knobs["scenario"]
    circuit = _circuit(knobs, resolved, shape, batch)
    constant_proof, proof_size = _proof_bytes(knobs, shape, circuit, batch)
    size_model = SizeModel(triple=batch * shape.triple_bytes,
                           hash_ref=32 * batch,
                           sig_witness=batch * shape.witness_bytes,
                           tx_body=batch * shape.body_bytes,
                           recursive_proof=constant_proof,
                           proof_size=proof_size)
    proof_bytes = 0 if scenario == "noagg" else constant_proof
    limits = BlockLimits({KIND_PQ: batch * shape.gas},
                         {KIND_PQ: batch * shape.onchain_bytes},
                         gas_limit=_limit(knobs["gas_limit"]),
                         byte_limit=_limit(knobs["byte_limit"]),
                         header_bytes=knobs["header_bytes"],
                         proof_bytes=proof_bytes)
    capacity = None
    if knobs["uplink_mbps"] > 0:
        capacity = bytes_per_ms(knobs["uplink_mbps"])
    settings = {}
    if scenario != "noagg":
        settings.update(configuration(knobs["preset"]))
    settings.update({
        "seed": knobs["seed"], "size_model": size_model,
        "capacity": capacity, "egress_queue_bytes": knobs["egress_bytes"],
        "slot_length": knobs["slot_ms"], "block_limits": limits,
        "relay_policy": knobs["relay_policy"],
        "chain_notify": knobs["chain_notify"],
        "proposer_mode": knobs["proposer_mode"],
        "verify_cost": _verify(knobs, resolved, shape, batch),
        "cpu_discipline": knobs["cpu_discipline"],
    })
    if knobs.get("_uplinks") is not None:
        settings["uplinks"] = [bytes_per_ms(rate)
                               for rate in knobs["_uplinks"]]
        settings["capacity"] = None
    if knobs["wrapper_queue"] is not None:
        settings["wrapper_queue"] = knobs["wrapper_queue"]
    if knobs["chain_notify"] == "overlay":
        # Without metered notices there is no block on the wire, and the
        # simulator refuses a chosen setting that cannot act.
        settings["egress_priority"] = knobs["egress_priority"]
        settings["block_relay"] = knobs["block_relay"]
        settings["block_validate_ms"] = knobs["block_validate_ms"]
        if knobs["block_fanout"] is not None:
            settings["block_fanout"] = knobs["block_fanout"]
    if scenario == "noagg":
        settings["aggregation"] = "none"
        settings["costs"] = CostTable(seed=knobs["seed"])
    else:
        settings["prove_cost_basis"] = "circuit"
        settings["costs"] = CostTable(prove_recursive=circuit,
                                      seed=knobs["seed"])
    if scenario == "pcs" and knobs["client_proofs"] == "draft":
        # No raw relay: a client proof stops at the node it was sent to,
        # which merges it; claims spread in each node's periodic aggregate.
        settings["relay_policy"] = "wrapper_only"
    if scenario == "pcs" and knobs["client_proofs"] == "relay":
        # Builder-only merging (docs/configuration.md, relay_forwarding):
        # exactly one node aggregates, it is the proposer, and relays
        # forward raw objects -- the client proofs -- and no proof of theirs.
        settings["aggregator_share"] = 1.0 / knobs["nodes"]
        settings["proposer_role"] = "aggregator"
        settings["relay_forwarding"] = "none"
    settings.update(knobs["set"])
    if settings["chain_notify"] != "overlay":
        for field in ("egress_priority", "block_relay", "block_validate_ms",
                      "block_fanout"):
            if field not in knobs["set"]:
                settings.pop(field, None)
    for field in ("aggregation_interval", "proving_budget", "aggregator_share",
                  "fold_amortize"):
        if isinstance(settings.get(field), str):
            settings[field] = float(settings[field])
    settings["_batch"] = batch
    settings["_proof_bytes"] = constant_proof
    settings["_circuit"] = circuit
    return settings


def schedule_births(sim, knobs, tps, batch):
    """Uniform arrivals over the birth window, a function of the seed alone.

    Entry nodes come from a dedicated stream and fees cycle 0-4 by index (as
    bench.mainnet), so two runs at one seed and rate share every birth.
    """
    window = knobs["birth_slots"] * knobs["slot_ms"]
    leaves = max(1, int(round(tps * window / 1000.0 / batch)))
    entries = random.Random(f"{knobs['seed']}:entry")
    spacing = window / leaves
    for index in range(leaves):
        node = sim.entry_nodes[entries.randrange(len(sim.entry_nodes))]
        sim.schedule_birth(index * spacing, KIND_PQ, node_id=node,
                           fee=float(index % 5))
    return leaves


def run(knobs, full_metrics=False):
    """Build, schedule, run and measure one point. Returns a flat dict."""
    started = time.perf_counter()
    sim, plan = build(knobs)
    batch = plan["batch"]
    slot = knobs["slot_ms"]
    window = knobs["birth_slots"] * slot
    warmup = knobs["warmup_slots"] * slot
    horizon = (knobs["birth_slots"] + knobs["drain_slots"]) * slot
    leaves = schedule_births(sim, knobs, plan["tps"], batch)
    schedule_horizon(sim, horizon)
    sim.run(until=warmup)
    busy_start = BusySample(sim, warmup)
    traffic_start = TrafficSample(sim, warmup)
    sim.run(until=window)
    busy_end = BusySample(sim, window)
    traffic_end = TrafficSample(sim, window)
    sim.run(until=horizon)
    row = measure(sim, knobs, plan, leaves, busy_start, busy_end,
                  traffic_start, traffic_end)
    row["runtime_s"] = time.perf_counter() - started
    row["binding"] = binding_label(row)
    row["binding_evidence"] = binding_evidence(row)
    if full_metrics:
        return row, sim
    return row


def _mean(values):
    values = [value for value in values if value >= 0]
    if not values:
        return -1.0
    return statistics.fmean(values)


def measure(sim, knobs, plan, leaves, busy_start, busy_end, traffic_start,
            traffic_end):
    batch = plan["batch"]
    shape = plan["shape"]
    slot = knobs["slot_ms"]
    slot_s = slot / 1000.0
    measured_slots = knobs["birth_slots"] - knobs["warmup_slots"]
    window_blocks = [block for block in sim.chain.blocks
                     if knobs["warmup_slots"] < block.slot
                     <= knobs["birth_slots"]]
    window_included = sum(block.count() for block in window_blocks) * batch
    tps_window = window_included / (measured_slots * slot_s)
    offered_tps = leaves * batch / (knobs["birth_slots"] * slot_s)
    metrics = sim.metrics()
    included = metrics["included_txs"] * batch
    arrived = metrics["arrived_txs"] * batch
    bounds = plan["bounds"]
    # What an ideal network would include at this offered rate.
    reference = offered_tps
    if bounds["ideal_bound_tps"] >= 0:
        reference = min(offered_tps, bounds["ideal_bound_tps"])
    row = {
        "scenario": plan["scenario"], "sig_bytes": knobs["sig_bytes"],
        "perms": knobs["perms"], "k": knobs["k"], "seed": knobs["seed"],
        "nodes": knobs["nodes"], "degree": knobs["degree"],
        "uplink_mbps": knobs["uplink_mbps"], "latency_ms": knobs["latency_ms"],
        "slot_ms": slot, "birth_slots": knobs["birth_slots"],
        "warmup_slots": knobs["warmup_slots"],
        "measured_slots": measured_slots,
        "drain_slots": knobs["drain_slots"],
        "cpu_discipline": sim.cpu_discipline,
        "client_proofs": (knobs["client_proofs"]
                          if plan["scenario"] == "pcs" else "-"),
        "aggregators": len(sim.aggregator_nodes),
        "gas_limit": knobs["gas_limit"], "byte_limit": knobs["byte_limit"],
        "preset": knobs["preset"] if plan["scenario"] != "noagg" else "-",
        "relay_policy": sim.relay_policy, "chain_notify": sim.notifier.kind,
        "profile": knobs["profile"] or "-",
        "uplinks": (knobs["uplinks"] if isinstance(knobs["uplinks"], str)
                    else "custom"),
        "egress_priority": sim.egress_priority,
        "wrapper_queue": sim.queue_policy(),
        "egress_bytes": (-1 if sim.egress_queue_bytes is None
                         else sim.egress_queue_bytes),
        "block_relay": sim.block_relay,
        "block_validate_ms": sim.block_validate_ms,
        "block_fanout": -1 if sim.block_fanout is None else sim.block_fanout,
        "orphan_late_blocks": int(knobs["orphan_late_blocks"]),
        "batch": batch, "leaves": leaves,
        "tx_gas": shape.gas, "tx_onchain_bytes": shape.onchain_bytes,
        "tx_wire_bytes": shape.wire_bytes,
        "offered_tps": offered_tps,
        "tps_included_window": tps_window,
        "tps_included_total": included / (knobs["birth_slots"] * slot_s),
        "included_txs": included, "arrived_txs": arrived,
        "inclusion_fraction": included / arrived if arrived else -1.0,
        "degradation": tps_window / reference if reference > 0 else -1.0,
        "delay_mean_s": (metrics["delay_mean_slots"] * slot_s
                         if metrics["included_txs"] else -1.0),
        "delay_p95_s": (metrics["delay_p95_slots"] * slot_s
                        if metrics["included_txs"] else -1.0),
    }
    for label in LABEL_KNOBS:
        row[label] = knobs[label] if knobs[label] is not None else "NA"
    rates = plan.get("uplinks") or [knobs["uplink_mbps"]] * knobs["nodes"]
    ordered = sorted(rates)
    if plan.get("uplinks"):
        # The knob is one figure; with per-node uplinks the row reports the
        # median node's, the figure the analytic bounds read.
        row["uplink_mbps"] = statistics.median(ordered)
    row["uplink_min_mbps"] = ordered[0]
    row["uplink_median_mbps"] = statistics.median(ordered)
    row["uplink_mean_mbps"] = statistics.fmean(ordered)
    row["uplink_max_mbps"] = ordered[-1]
    row["uplink_node0_mbps"] = rates[0]
    row.update(bounds)
    if plan["circuit"] is not None:
        circuit = plan["circuit"]
        row["prove_ms_per_tx"] = (circuit.ms_per_hash * circuit.sphincs_hashes
                                  / batch)
        row["prove_ms_per_child"] = (circuit.ms_per_hash
                                     * circuit.recursive_hashes)
    else:
        row["prove_ms_per_tx"] = -1.0
        row["prove_ms_per_child"] = -1.0
    # The prover's limits and where a proof's size comes from.
    row["proof_bytes_constant"] = (sim.size_model.recursive_proof
                                   if plan["circuit"] is not None else -1)
    row["proof_bytes_source"] = "-"
    row["circuit_max_children"] = -1
    row["circuit_max_claims"] = -1
    row["circuit_price"] = "-"
    if plan["circuit"] is not None:
        circuit = plan["circuit"]
        row["proof_bytes_source"] = ("knob" if sim.size_model.proof_size is None
                                     else "circuit_cost")
        row["circuit_price"] = "linear"
        if isinstance(circuit, LimitedCircuitCost):
            if circuit.max_children is not None:
                row["circuit_max_children"] = circuit.max_children
            if circuit.max_claims is not None:
                row["circuit_max_claims"] = circuit.max_claims
            if circuit.price is not None:
                row["circuit_price"] = getattr(circuit.price, "label",
                                               "plugin")
    row["verify_ms_per_tx"] = sim.verify_cost.per_signature / batch
    row["verify_gas_per_tx"] = -1.0
    row["exceeds_max_verify_gas"] = -1
    if plan["scenario"] == "noagg":
        verify_gas = knobs["k"] * model_registry.evm_verify_gas(knobs["perms"])
        row["verify_gas_per_tx"] = verify_gas
        row["exceeds_max_verify_gas"] = int(verify_gas
                                            > knobs["max_verify_gas"])
    # Blocks.
    fill = metrics["block_fill"]
    blocks = fill["per_block"] if fill != -1 else []
    # Block statistics are over the blocks of the measured window. Warm-up
    # and drain blocks are part full: averaged in, they understated a full
    # block's bytes by about a fifth and let a run far below its gas bound
    # count as gas-bound. The `_all` figures keep every block of the run.
    window = [record for record in blocks
              if knobs["warmup_slots"] < record["slot"]
              <= knobs["birth_slots"]]
    row["blocks"] = len(sim.chain.blocks)
    row["window_blocks"] = len(window_blocks)
    row["txs_per_block"] = _mean([record["txs"] * batch for record in window])
    row["block_bytes_mean"] = _mean([record["bytes_used"]
                                     for record in window])
    row["block_bytes_mean_all"] = _mean([record["bytes_used"]
                                         for record in blocks])
    row["block_gas_fill"] = _mean([record["gas_fill"] for record in window])
    row["block_byte_fill"] = _mean([record["byte_fill"] for record in window])
    for bound in ("gas", "bytes", "supply"):
        row["blocks_bound_by_" + bound] = sum(
            1 for record in window if record["bound_by"] == bound)
        row[f"blocks_bound_by_{bound}_all"] = sum(
            1 for record in blocks if record["bound_by"] == bound)
    reach = metrics["block_reach"]
    for key in ("mean_t50_ms", "mean_t90_ms", "mean_t100_ms"):
        row["block_" + key] = reach[key] if reach != -1 else -1.0
    # The 99 % reach time: the mean, over the blocks that got there, of the
    # time until 99 % of the nodes (rounded up) had admitted the block. On
    # fewer than 100 nodes that is every node. `blocks_unreached` counts the
    # blocks, built at least a slot before the run ended, that some node
    # never admitted: a block lost on the way shows here, in every run.
    row["block_mean_t99_ms"] = -1.0
    row["blocks_unreached"] = -1
    if reach != -1:
        needed = math.ceil(0.99 * len(sim.nodes))
        times = []
        unreached = 0
        for record in reach["per_block"]:
            built_at = record["built_ms"]
            delays = sorted(time - built_at for time in
                            sim.block_reach.admitted[record["block"]].values())
            if len(delays) >= needed:
                times.append(delays[needed - 1])
            if (len(delays) < len(sim.nodes)
                    and sim.engine.now - built_at >= slot):
                unreached += 1
        row["block_mean_t99_ms"] = _mean(times)
        row["blocks_unreached"] = unreached
    # Late: nine tenths of the nodes reached after the deadline, or not
    # reached although the run watched it for longer than the deadline. A
    # block built too close to the horizon to tell is not counted.
    row["blocks_late_t90"] = -1
    if reach != -1:
        deadline = knobs["attest_deadline_ms"]
        late = 0
        for record in reach["per_block"]:
            watched = sim.engine.now - record["built_ms"]
            if record["t90_ms"] > deadline:
                late += 1
            elif record["t90_ms"] < 0 and watched > deadline:
                late += 1
        row["blocks_late_t90"] = late
    # Timely and canonical throughput over the measured window. A block is
    # timely when timely_fraction of the nodes held it at the deadline; with
    # orphaning on, a block held by fewer than orphan_fraction of them is
    # orphaned and its transactions do not count as canonical. Orphaned
    # transactions are not returned to the mempool (a stated limit), so
    # under saturation tps_canonical is the chain's rate and delays are not.
    for key in ("tps_timely", "timely_share", "orphan_rate", "tps_canonical"):
        row[key] = -1.0
    row["blocks_timely"] = -1
    row["blocks_orphaned"] = -1
    if reach != -1:
        timeliness = sim.block_reach.timeliness(
            knobs["attest_deadline_ms"], knobs["timely_fraction"],
            knobs["orphan_fraction"] if knobs["orphan_late_blocks"] else None,
            now=sim.engine.now)
        verdicts = {record["block"]: record
                    for record in timeliness["per_block"]}
        timely_txs = canonical_txs = 0
        timely_blocks = orphaned_blocks = 0
        for block_id, block in enumerate(sim.chain.blocks):
            if not knobs["warmup_slots"] < block.slot <= knobs["birth_slots"]:
                continue
            verdict = verdicts.get(block_id)
            if verdict is None:
                continue
            if verdict["timely"]:
                timely_txs += block.count() * batch
                timely_blocks += 1
            if verdict["orphaned"]:
                orphaned_blocks += 1
            else:
                canonical_txs += block.count() * batch
        seconds = measured_slots * slot_s
        row["tps_timely"] = timely_txs / seconds
        row["tps_canonical"] = canonical_txs / seconds
        row["blocks_timely"] = timely_blocks
        row["blocks_orphaned"] = orphaned_blocks
        if window_blocks:
            row["timely_share"] = timely_blocks / len(window_blocks)
            row["orphan_rate"] = orphaned_blocks / len(window_blocks)
    else:
        # Instant notification: every node learns at the boundary.
        row["tps_canonical"] = tps_window
    # Transactions reaching nodes: first evidence and first body.
    for kind in ("evidence", "body"):
        for fraction in (0.5, 0.9, 0.99):
            reached = diffusion(sim, fraction, kind=kind)
            label = f"tx_{kind}_t{int(fraction * 100)}_ms"
            row[label] = reached["mean_ms"]
    # Bandwidth over the steady window, per node.
    traffic = traffic_window(traffic_start, traffic_end)
    per_kind = traffic["completed_bytes_per_second_by_kind"]
    row["egress_Bps_per_node"] = traffic["wire_bytes_per_second"]
    for kind in ("object", "wrapper", "block", "announce", "want"):
        row[f"egress_{kind}_Bps_per_node"] = per_kind.get(kind, -1.0)
    row["refused_Bps_per_node"] = traffic["refused_bytes_per_second"]
    ingress = metrics["ingress_bytes"]
    row["duplicate_bytes_share"] = (metrics["duplicate_bytes"] / ingress
                                    if ingress else -1.0)
    row["dropped_messages"] = metrics["dropped_messages"]
    # What each uplink queue shed, per payload kind, messages and bytes.
    shed = metrics["egress_shed"]
    for kind in ("object", "wrapper", "block", "announce", "want"):
        row[f"shed_dropped_msgs_{kind}"] = shed[kind]["dropped_messages"]
        row[f"shed_dropped_bytes_{kind}"] = shed[kind]["dropped_bytes"]
    row["shed_superseded_msgs_wrapper"] = shed["wrapper"]["superseded_messages"]
    row["shed_superseded_bytes_wrapper"] = shed["wrapper"]["superseded_bytes"]
    row["wire_bytes_total"] = metrics["wire_bytes"]
    utilisation = utilisation_window(busy_start, busy_end)
    row["cpu_utilisation"] = utilisation["cpu_utilisation"]
    row["egress_utilisation"] = utilisation["egress_utilisation"]
    # The CPU of the nodes that built the window's blocks: where one
    # builder proves or merges alone (C2, client proofs relayed unmerged) it
    # saturates while the mean over all nodes stays low.
    cpu_by_node = utilisation["cpu_utilisation_by_node"]
    builders = sorted({block.proposer for block in window_blocks
                       if block.proposer is not None})
    row["cpu_utilisation_builder"] = (
        max(cpu_by_node[node] for node in builders) if builders else -1.0)
    # The share of nodes whose uplink was busy nine tenths of the window:
    # with unequal uplinks the slow class saturates before the mean does.
    by_node = utilisation["egress_utilisation_by_node"]
    row["egress_saturated_share"] = (
        sum(1 for value in by_node if value >= 0.9) / len(by_node)
        if by_node else -1.0)
    accounting = cpu_accounting(sim)["cpu_accounting"]["total"]
    prove_ms = accounting["prove_recursive"]["service_ms"]
    verify_ms = accounting["verify_recv"]["service_ms"]
    elapsed = sim.engine.now * len(sim.nodes)
    row["cpu_prove_share"] = prove_ms / elapsed if elapsed else -1.0
    row["cpu_verify_share"] = verify_ms / elapsed if elapsed else -1.0
    # Duplicate proving work: in-circuit leaf verifications per included
    # transaction, and the share of proving service spent re-folding leaves.
    row["proofs_completed"] = metrics["proofs_completed"]
    row["wrappers_emitted"] = metrics["wrappers_emitted"]
    folds = metrics["leaf_folds"]
    if folds != -1 and metrics["included_txs"]:
        total = folds["total"]
        row["leaf_folds_per_included"] = (total["fold_events"]
                                          / metrics["included_txs"])
        row["repeat_service_share"] = total["repeat_service_share"]
    else:
        row["leaf_folds_per_included"] = -1.0
        row["repeat_service_share"] = -1.0
    # Waste, in every family. Bytes: what arrived at a node that already
    # had it, plus what a send queue shed, over everything put on or shed
    # from the wire. Proving: the share of proving service spent on leaves
    # already folded (-1 where nothing is proved). `wasted_share` is the
    # family's scarce resource: proving under aggregation, bytes without.
    shed_bytes = sum(shed[kind]["dropped_bytes"] for kind in
                     ("object", "wrapper", "block", "announce", "want"))
    shed_bytes += shed["wrapper"]["superseded_bytes"]
    carried = metrics["wire_bytes"] + shed_bytes
    row["wasted_bytes_share"] = (
        (metrics["duplicate_bytes"] + shed_bytes) / carried
        if carried else -1.0)
    row["wasted_prove_share"] = row["repeat_service_share"]
    row["wasted_share"] = (row["wasted_bytes_share"]
                           if plan["scenario"] == "noagg"
                           else row["wasted_prove_share"])
    row["stale_deps_proved"] = metrics["stale_deps_proved"]
    row["mode_zero_wrappers"] = metrics["mode_zero_wrappers"]
    row["models"] = json.dumps(plan["models"], sort_keys=True)
    row["set"] = json.dumps(knobs["set"], sort_keys=True)
    return row


# The keys capacity mode adds to a row (see find_capacity).
CAPACITY_KEYS = ("capacity_tps", "capacity_offered_tps", "capacity_upper_tps",
                 "capacity_vs_ideal", "capacity_runs", "capacity_probes",
                 "capacity_bracketed", "capacity_start_tps",
                 "capacity_start_basis")


def sustained(row, fraction):
    """Whether a run kept up: the steady window included nearly all offered
    load, and nearly every arrival was included by the end of the drain."""
    return (row["tps_included_window"] >= fraction * row["offered_tps"]
            and row["inclusion_fraction"] >= fraction)


def find_capacity(knobs):
    """The highest offered rate the network sustains, bracketed by probes.

    The search trusts no estimate. It starts at the network-free bound
    (`ideal_bound_tps`: gas, bytes, prover), never at the rough bandwidth
    estimate, which realised rates exceed. A rate that is not sustained is
    halved until one is; a rate that is sustained is doubled until one is
    not, or until the block's own limit (gas or bytes), above which no rate
    can be sustained. The prover bound is one node's, which a network that
    splits work can pass, so the search climbs through it. Bisection then
    narrows the bracket to `capacity_tolerance` (relative), within
    `capacity_max_runs` runs. Without any bound the climb starts at 10
    transactions per second.

    Each probe is a full run at one seed, so the search is paired: only the
    rate moves. Throughput need not be monotonic in offered load --
    congestion can collapse it -- so this finds a sustained rate with a
    failing rate (or the block's limit) above it, not a guaranteed maximum;
    the returned row is the run at that rate, with the search recorded
    beside it. `capacity_bracketed` is 1 when both ends were established.
    """
    fraction = knobs["sustain_fraction"]
    _sim, plan = build(dict(knobs, tps=1.0, batch=1))
    bounds = plan["bounds"]
    # What a block can hold at most: no offered rate above it is sustained.
    block_limit = min((bounds[name] for name in ("gas_bound_tps",
                                                 "byte_bound_tps")
                       if bounds[name] > 0), default=None)
    start = bounds["ideal_bound_tps"]
    start_basis = "ideal_bound:" + bounds["ideal_binding"]
    if start <= 0:
        start = 10.0
        start_basis = "default"
    probes = []

    def probe(rate):
        row = run(dict(knobs, tps=rate))
        probes.append((rate, row["tps_included_window"],
                       row["inclusion_fraction"]))
        return row

    def runs_left():
        return len(probes) < knobs["capacity_max_runs"]

    low = None
    high = None
    best = None
    at_limit = False
    rate = start
    row = probe(rate)
    if sustained(row, fraction):
        low, best = rate, row
        while True:
            if block_limit is not None and rate >= block_limit:
                at_limit = True
                break
            if not runs_left():
                break
            rate *= 2.0
            if block_limit is not None:
                rate = min(rate, block_limit)
            row = probe(rate)
            if not sustained(row, fraction):
                high = rate
                break
            low, best = rate, row
    else:
        high = rate
        while runs_left():
            rate /= 2.0
            row = probe(rate)
            if sustained(row, fraction):
                low, best = rate, row
                break
            high = rate
    while (low is not None and high is not None
           and high - low > knobs["capacity_tolerance"] * low
           and runs_left()):
        middle = (low + high) / 2.0
        row = probe(middle)
        if sustained(row, fraction):
            low, best = middle, row
        else:
            high = middle
    if best is None:
        best = row
    best = dict(best)
    # What the network carried at the highest sustained rate, which may sit
    # up to 1 - sustain_fraction below the rate offered there.
    best["capacity_tps"] = -1.0
    if low is not None:
        best["capacity_tps"] = min(low, best["tps_included_window"])
    best["capacity_offered_tps"] = low if low is not None else -1.0
    # Capacity over the throughput with networking assumed away: below 1 by
    # what relay, bandwidth, latency and duplicated proving cost.
    ideal = best.get("ideal_bound_tps", -1.0)
    best["capacity_vs_ideal"] = -1.0
    if best["capacity_tps"] >= 0 and ideal > 0:
        best["capacity_vs_ideal"] = best["capacity_tps"] / ideal
    # The bracket's upper end: the lowest rate seen to fail, or the block's
    # own limit when the network sustained it.
    best["capacity_upper_tps"] = -1.0
    if high is not None:
        best["capacity_upper_tps"] = high
    elif at_limit:
        best["capacity_upper_tps"] = block_limit
    best["capacity_bracketed"] = int(low is not None
                                     and (high is not None or at_limit))
    best["capacity_start_tps"] = start
    best["capacity_start_basis"] = start_basis
    best["capacity_runs"] = len(probes)
    best["capacity_probes"] = json.dumps(
        [[round(r, 3), round(t, 3), round(i, 4)] for r, t, i in probes])
    best["binding"] = binding_label(best)
    best["binding_evidence"] = binding_evidence(best)
    return best


def evaluate(knobs):
    """One point in the configured mode."""
    if knobs["mode"] == "capacity":
        started = time.perf_counter()
        row = find_capacity(knobs)
        row["runtime_s"] = time.perf_counter() - started
        return row
    return run(knobs)

"""The campaign's scenarios by id: `python3 -m bench.leansphincs scenarios`.

PHASE2.md section 3 names the deployment scenarios E0 (routes E0a, E0b, E0c),
A, B, C1, C2, D, E and F (F1, F2, F3). Each id has one or more configurations
in `bench/leansphincs/scenarios/<name>.json`: the knob layers the phase-2
sweeps ran (sims/runs2/noagg/configs and sims/runs2/agg at 567633c), copied
with two changes. The absolute directory of a model module became `@models`
(the campaign's data/phase2, or `$LEANSPHINCS_MODELS`) or `@scenarios` (this
directory), and `load_basis` records what the sweeps did outside the harness:
they offered load against the gas-or-byte bound, not the rough bandwidth one.

    --scenario B                  the id's default configuration
    --scenario B_pr12616_16       one configuration by name
    --candidate P99r              any name of PHASE2B.md section 2 or of
                                  data/phase2/candidates_v2.csv: bytes,
                                  permutations and what follows from them
                                  (see `candidate` and `layers`)

A configuration is one cell of a sweep, not a result: the gas limit, profile,
uplinks, seed and mode are ordinary knobs to override.
"""

import csv
import importlib
import json
import os
import sys

from bench.leansphincs.scenario import SCENARIOS

SCENARIO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "scenarios")

# Scenario id -> the configuration `--scenario <id>` runs. E0: today's
# pricing (EIP-7623). B: EIPs PR #12616 as written (G(P), 64 gas per byte).
# C1 has no public text; flat 3,000 gas at 64 gas per byte is the reading
# closest to EIP-8288. C2, D, E: EIP-8288's 33,000 gas per dependency; the
# `-dep3000` configurations charge the leanPCS draft's 3,000.
DEFAULT_CONFIGURATION = {
    "E0a": "E0a_7623", "E0b": "E0b_7623", "E0c": "E0c_7623", "A": "A",
    "B": "B_pr12616_64", "C1": "C1_flat_64", "C2": "C2", "D": "D", "E": "E",
    "F1": "F1", "F2": "F2", "F3": "F3",
}
IDS = tuple(DEFAULT_CONFIGURATION)

# PHASE2.md section 4. `impl` is the EVM verifier models_noagg prices
# ("layered" hypertree or the single-layer "lean" one), and B0 is priced on
# EthLib's 492 permutations where a gas model takes `p_scale` (PR #12616).
# What is stated here wins over what `candidate` derives for the name.
CANDIDATES = {
    "B0": {"sig_bytes": 7740, "perms": 515, "impl": "layered",
           "p_scale": 492 / 515},
    "P99a": {"sig_bytes": 4308, "perms": 283, "impl": "lean"},
    "N2": {"sig_bytes": 5980, "perms": 415, "impl": "layered"},
}
CLAIM_SLOTS = 65536   # leanVM, one proof; F3 fills a bundle to it

# PHASE2B.md section 2: the candidates of every table of that pass, as
# (parameters, signature bytes, verify permutations). They are built in so
# the names resolve without the campaign's data directory; where
# data/phase2/candidates_v2.csv is present its rows must agree (tested).
PHASE2B_CANDIDATES = {
    "B0": ("10+8+8|fors|a10|k24|w4|T128", 7740, 515),
    "P99r": ("24|fors|a10|k17|w4|T127|b11", 4420, 289),
    "P99a": ("24|fors|a11|k15|w4|T126|b11", 4308, 283),
    "S24-minB": ("24|fors|a11|k15|w8|T199|b11", 3972, 317),
    "S22-minP-5K": ("22|fors|a12|k13|w4|T124|b11", 4100, 271),
    "S22-minB-5K": ("22|fors|a12|k13|w8|T195|b11", 3764, 307),
    "N2": ("11+8+7|fors+c|a10|k15|w4|T124", 5980, 415),
    "N3r": ("11+8+7|fors|a10|k15|w4|T124", 6156, 426),
}
CANDIDATES_FILE = "candidates_v2.csv"
GUEST_COUNTS_FILE = "guest_counts.json"
# guest_counts.json's row names -> the prover model's table names.
COUNTED_TABLES = (("XOR", "XOR"), ("MUL", "MUL"), ("SET", "SET"),
                  ("DEREF", "DEREF"), ("JUMP", "JUMP"), ("KECCAK", "K"))
PROVER_MODELLED = "modelled [Mo]"

_FILE_CACHE = {}


def _campaign_file(name, load):
    """A file of the model directory, parsed once; None when absent."""
    path = os.path.join(models_dir(), name)
    if path not in _FILE_CACHE:
        _FILE_CACHE[path] = None
        if os.path.exists(path):
            with open(path, encoding="utf-8", newline="") as handle:
                _FILE_CACHE[path] = load(handle)
    return _FILE_CACHE[path]


def _impl(params):
    """The EVM verifier models_noagg prices: a hypertree of several layers
    ("layered") or the single-layer one ("lean")."""
    return "layered" if "+" in params.split("|")[0] else "lean"


def file_candidates():
    """name -> (parameters, bytes, permutations) of candidates_v2.csv.

    A row's `name` lists its aliases separated by `/`; each is a name.
    Bytes are column `B`, permutations column `P_F` (the verifier's count
    with FORS, the figure PHASE2B.md section 2 tabulates). Empty when the
    file is not there.
    """
    rows = _campaign_file(CANDIDATES_FILE,
                          lambda handle: list(csv.DictReader(handle)))
    result = {}
    for row in rows or ():
        for alias in row["name"].split("/"):
            result.setdefault(alias.strip(), (row["params"], int(row["B"]),
                                              int(row["P_F"])))
    return result


def counted_rows(params):
    """The counted leanVM rows of one signature with these parameters.

    `(shape name, rows)` from the first shape of guest_counts.json whose
    `params` equal the candidate's, or None: the candidate's prover cost is
    then the model's composition at its permutations and bytes. `rows` holds
    the prover model's tables (XOR, MUL, SET, DEREF, JUMP, K) and MEM, per
    signature [C].
    """
    counts = _campaign_file(GUEST_COUNTS_FILE, json.load)
    for shape in (counts or {}).get("shapes", ()):
        if shape.get("params") != params or "rows_per_sig" not in shape:
            continue
        rows = {target: float(shape["rows_per_sig"][source])
                for source, target in COUNTED_TABLES}
        rows["MEM"] = float(shape["memory_cells_per_sig"])
        return shape["name"], rows
    return None


def candidate_names():
    """Every name `--candidate` resolves, PHASE2B's first."""
    result = list(PHASE2B_CANDIDATES)
    result.extend(name for name in file_candidates() if name not in result)
    return result


def candidate(name):
    """What a candidate name stands for, or None for a bare label.

    `sig_bytes`, `perms`, `params`, the gas model's `impl` (and B0's
    `p_scale`), and `counted`: `(shape name, rows)` where guest_counts.json
    counted this parameter set on real proof runs, else None.
    """
    known = PHASE2B_CANDIDATES.get(name) or file_candidates().get(name)
    if known is None:
        return None
    params, sig_bytes, perms = known
    result = {"params": params, "sig_bytes": sig_bytes, "perms": perms,
              "impl": _impl(params), "counted": counted_rows(params)}
    result.update(CANDIDATES.get(name, {}))
    return result


def bundle_cap(perms):
    """Signatures in one F3 bundle (sims/runs2/agg/make_grids.py)."""
    return CLAIM_SLOTS // (perms + 10)


def models_dir():
    """The directory of models_noagg.py and models_agg.py."""
    return os.environ.get("LEANSPHINCS_MODELS") or os.path.normpath(
        os.path.join(SCENARIO_DIR, "..", "..", "..", "..", "..", "data",
                     "phase2"))


def _with_paths(value):
    if isinstance(value, dict):
        return {key: _with_paths(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_with_paths(item) for item in value]
    if value == "@models":
        return models_dir()
    if value == "@scenarios":
        return SCENARIO_DIR
    return value


def names():
    """Every configuration name, sorted."""
    return sorted(entry[:-5] for entry in os.listdir(SCENARIO_DIR)
                  if entry.endswith(".json"))


def is_named(scenario):
    """True for an id or configuration name, False for a harness class."""
    return scenario is not None and scenario not in SCENARIOS


def configuration_name(scenario):
    """An id or a configuration name -> the configuration name."""
    name = DEFAULT_CONFIGURATION.get(scenario, scenario)
    if not os.path.exists(os.path.join(SCENARIO_DIR, f"{name}.json")):
        raise ValueError(
            f"unknown scenario {scenario!r}: a class ({', '.join(SCENARIOS)}"
            f"), an id ({', '.join(IDS)}) or a configuration name "
            "(`python3 -m bench.leansphincs scenarios`)")
    return name


def configuration(scenario):
    """The knob layer of an id or configuration name, model paths resolved."""
    name = configuration_name(scenario)
    with open(os.path.join(SCENARIO_DIR, f"{name}.json"),
              encoding="utf-8") as handle:
        return _with_paths(json.load(handle))


def entries():
    """One record per configuration, ids in PHASE2 order, default first."""
    result = []
    for name in names():
        knobs = configuration(name)
        scenario_id = knobs["scenario_id"]
        result.append({
            "id": scenario_id, "configuration": name,
            "default": DEFAULT_CONFIGURATION.get(scenario_id) == name,
            "class": knobs["scenario"], "mode": knobs["mode"],
            "pricing": knobs["pricing"], "variant": knobs["variant"],
            "gas_limit": knobs["gas_limit"], "profile": knobs["profile"],
            "uplinks": knobs["uplinks"],
            "models": sorted(spec["fn"] for spec in knobs["models"].values()),
        })
    result.sort(key=lambda entry: (IDS.index(entry["id"]),
                                   not entry["default"],
                                   entry["configuration"]))
    return result


def _noagg_tx_bytes(variant, sig_bytes, perms, k):
    path = models_dir()
    if path not in sys.path:
        sys.path.insert(0, path)
    module = importlib.import_module("models_noagg")
    return module.sim_knobs(variant, sig_bytes, perms, k)["tx_bytes"]


def layers(layer):
    """The knob layers for a layer whose `scenario` is an id or a name.

    Returns `[configuration, derived, layer]` for `resolve_knobs`, with the
    layer's `scenario` dropped (the configuration names the class). `derived`
    holds what follows from the layer's candidate, bytes, permutations and k,
    as the sweeps derived it (sims/runs2/noagg/gen.py:point,
    sims/runs2/agg/make_grids.py:f):

    - `candidate`, any name `candidate` knows (PHASE2B.md section 2 and
      data/phase2/candidates_v2.csv), sets `sig_bytes` and `perms`. A layer
      that also moves either gets the label `<candidate>@B<bytes>/P<perms>`.
      Any other candidate is a label, as it is without a registry scenario.
    - EIP-8288 configurations priced by `leanvm_limited`: at a candidate
      whose parameter set guest_counts.json counted, the circuit model gets
      those rows (`counted_rows`) and `prover_cost` says `counted [C]`;
      otherwise it says `modelled [Mo]`.
    - No-aggregation configurations: the gas model's `impl` and `p_scale`
      follow the candidate, and `tx_bytes` (the non-signature bytes) comes
      from `models_noagg.sim_knobs` for the point's bytes, permutations and k.
    - F3: `k`, the bundle, is `bundle_cap(perms)` unless the layer sets k,
      and the `bundle=` part of the variant label follows it.
    - F1, F2, F3 with `client_proofs` "draft" or "relay": the variant label
      gains `;client_proofs=<value>`.

    `source` names the configuration file, not the sweep it was copied from.
    The layer's own values win over all of these.
    """
    name = configuration_name(layer["scenario"])
    base = configuration(name)
    rest = {key: value for key, value in layer.items() if key != "scenario"}
    # The stored `source` names the sweep the file came from; a run through
    # the registry is not that sweep's row.
    derived = {"source": f"bench/leansphincs/scenarios/{name}.json"}
    named = rest.get("candidate") or base["candidate"]
    known = candidate(named)
    if known is not None:
        derived["sig_bytes"] = known["sig_bytes"]
        derived["perms"] = known["perms"]
    sig_bytes = rest.get("sig_bytes") or derived.get("sig_bytes",
                                                     base["sig_bytes"])
    perms = rest.get("perms") or derived.get("perms", base["perms"])
    at_candidate = False
    if known is not None:
        rest.pop("candidate", None)
        at_candidate = (sig_bytes, perms) == (known["sig_bytes"],
                                              known["perms"])
        derived["candidate"] = (named if at_candidate
                                else f"{named}@B{sig_bytes}/P{perms}")
    # The prover's rows per signature: counted on real proof runs where
    # guest_counts.json has this parameter set, else the model's composition
    # at the point's permutations and bytes. Only a signature priced in the
    # circuit has them: without aggregation nothing is proved, and a leanPCS
    # leaf's price is the PCS model's.
    circuit = base["models"].get("circuit_cost", {})
    if base["scenario"] == "agg8288" and circuit.get("fn", "").endswith(
            ":leanvm_limited"):
        derived["prover_cost"] = PROVER_MODELLED
        if at_candidate and known["counted"] is not None:
            shape, rows = known["counted"]
            derived["prover_cost"] = (f"counted [C] {GUEST_COUNTS_FILE}:"
                                      f"{shape}")
            derived["models"] = {"circuit_cost": dict(
                circuit, kwargs=dict(circuit.get("kwargs", {}),
                                     counted_rows=rows))}
    elif base["scenario"] == "pcs":
        derived["prover_cost"] = PROVER_MODELLED
    k = rest.get("k")
    if base["scenario_id"] == "F3":
        if k is None:
            k = bundle_cap(perms)
            derived["k"] = k
        if "variant" not in rest:
            parts = [f"bundle={k}" if part.startswith("bundle=") else part
                     for part in base["variant"].split(";")]
            derived["variant"] = ";".join(parts)
    if (base["scenario"] == "pcs" and "variant" not in rest
            and rest.get("client_proofs") in ("draft", "relay")):
        # The tidy row has no column for it, and it decides the regime.
        derived["variant"] = (derived.get("variant", base["variant"])
                              + f";client_proofs={rest['client_proofs']}")
    if base["scenario"] == "noagg":
        k = k or base["k"]
        if known is not None:
            kwargs = {"impl": known["impl"]}
            if "p_scale" in known:
                kwargs["p_scale"] = known["p_scale"]
            derived["models"] = {"gas_per_tx": dict(
                base["models"]["gas_per_tx"], kwargs=kwargs)}
        if "tx_bytes" not in rest:
            derived["tx_bytes"] = _noagg_tx_bytes(base["variant"], sig_bytes,
                                                  perms, k)
    return [base, derived, rest]


def merged(*layers_):
    """Layers merged as `resolve_knobs` merges them, without the defaults."""
    result = {}
    for layer in layers_:
        for key, value in (layer or {}).items():
            if key in ("set", "models") and key in result:
                result[key] = dict(result[key], **value)
            else:
                result[key] = value
    return result


def listing():
    """The text `python3 -m bench.leansphincs scenarios` prints."""
    lines = ["id   configuration (* = the id's default)  class    mode"
             "      pricing; variant"]
    for entry in entries():
        mark = "*" if entry["default"] else " "
        lines.append(
            f"{entry['id']:<4} {mark} {entry['configuration']:<34} "
            f"{entry['class']:<8} {entry['mode']:<9} {entry['pricing']}; "
            f"{entry['variant']}")
    lines.append("")
    lines.append("candidates (--candidate; prover rows counted on leanVM "
                 "runs, or modelled):")
    for name in PHASE2B_CANDIDATES:
        spec = candidate(name)
        rows = "counted" if spec["counted"] else "modelled"
        lines.append(f"  {name:<12} {spec['params']:<32} "
                     f"{spec['sig_bytes']:>5} B {spec['perms']:>4} "
                     f"permutations, prover rows {rows}")
    more = len(candidate_names()) - len(PHASE2B_CANDIDATES)
    lines.append(f"  and {more} more names from {CANDIDATES_FILE}")
    lines.append(f"model modules: {models_dir()} "
                 "(models_noagg.py, models_agg.py; $LEANSPHINCS_MODELS)")
    return "\n".join(lines)

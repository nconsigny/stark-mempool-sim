"""Plug-in of the phase-2 aggregation scenarios (F1, F2, F3). [Mo] throughout.

Copied from the campaign's sims/runs2/agg/agg_models.py; only the lookup of
the campaign's model directory changed (it was an absolute path).

`pcs_model_hw` is data/phase2/models_agg.py:pcs_model with the mempool's
per-transaction merge (one 6-claim child, `prove_ms`) and the STARK
verification priced on a named node class instead of the M4 that models_agg
hard-wires. Signature unchanged (sims/LEANSPHINCS-FORK.md).
"""
import os
import sys


def _models_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.environ.get("LEANSPHINCS_MODELS") or os.path.normpath(
        os.path.join(here, "..", "..", "..", "..", "..", "data", "phase2"))


def pcs_model_hw(sig_bytes, perms_per_sig, k, *, node_hw="eip7870", **kwargs):
    path = _models_dir()
    if path not in sys.path:
        sys.path.insert(0, path)
    import models_agg
    result = dict(models_agg.pcs_model(sig_bytes, perms_per_sig, k, **kwargs))
    pm = models_agg.pm
    result["prove_ms"] = 1e3 * pm._t_child(node_hw, claims=models_agg.F["claims"], mu=24)
    result["verify_ms"] = 1e3 * pm.verify_time(node_hw)
    result["node_hw"] = node_hw
    return result

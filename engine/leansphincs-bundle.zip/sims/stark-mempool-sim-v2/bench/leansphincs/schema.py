"""The campaign's one result schema (PHASE2.md section 4).

`phase2_row` turns any harness row into the tidy columns every phase-2
scenario table shares, with `NA` where a column does not apply.
`binding_label` names the constraint that held a run's throughput where it
is, from the run's own measured columns. `fill_elasticities` computes the
elasticity columns over a grid of rows.

    python3 -m bench.leansphincs --scenario agg8288 --phase2-row
    python3 -m bench.leansphincs.sweep --grid g.json --out raw.csv \\
        --phase2-csv data/phase2/scenario_table_x.csv
"""

import math

NA = "NA"

PHASE2_COLUMNS = (
    "scenario", "variant", "pricing", "gas_limit", "profile", "uplinks",
    "nodes", "candidate", "B", "P", "k", "tps_tx", "tps_sig", "tps_timely",
    "binding", "eps_B", "eps_P", "dB10", "dB25", "dB50", "dB100", "dP10",
    "dP25", "dP50", "dP100", "block_bytes", "t90_block_s", "t99_block_s",
    "bw_node_mbit", "dup_share", "wasted_share", "degradation", "status",
    "source")

ELASTICITY_COLUMNS = ("eps_B", "eps_P", "dB10", "dB25", "dB50", "dB100",
                      "dP10", "dP25", "dP50", "dP100")
STEPS = (10, 25, 50, 100)

# A resource binds when the nodes' mean utilisation of it reaches this.
UTILISATION_BINDS = 0.9
# A run kept up when it included this share of the offered load.
SUSTAINED = 0.95

BINDINGS = ("gas", "bytes", "prover", "verify", "bandwidth", "propagation",
            "block_timeliness", "offered")


def _number(row, key, default=-1.0):
    value = row.get(key, default)
    if value in ("", None, NA):
        return default
    return float(value)


# Uplinks bind when this share of the nodes has a saturated uplink, also
# where the mean over unequal uplinks stays below UTILISATION_BINDS.
SATURATED_NODES_BIND = 0.5


def _upstream(row):
    """What starves the chain when blocks are not full: a saturated CPU
    (proving under aggregation, signature checks without; the mean over the
    nodes, or the CPU of the node that built the window's blocks), saturated
    uplinks (`bandwidth`), or neither (`propagation`: latency and relay
    rounds, with uplinks that still have room). The two network labels are
    told apart by the uplinks' measured utilisation alone, so a table must
    not rename one into the other."""
    if (_number(row, "cpu_utilisation") >= UTILISATION_BINDS
            or _number(row, "cpu_utilisation_builder") >= UTILISATION_BINDS):
        prove = _number(row, "cpu_prove_share", 0.0)
        verify = _number(row, "cpu_verify_share", 0.0)
        return "prover" if prove >= verify else "verify"
    if (_number(row, "egress_utilisation") >= UTILISATION_BINDS
            or _number(row, "egress_saturated_share")
            >= SATURATED_NODES_BIND):
        return "bandwidth"
    return "propagation"


def _window_blocks(row):
    """Blocks of the measured window: the row's count, else its slots."""
    blocks = _number(row, "window_blocks")
    if blocks >= 0:
        return max(1.0, blocks)
    measured = _number(row, "measured_slots")
    if measured < 0:
        measured = (_number(row, "birth_slots", 1.0)
                    - _number(row, "warmup_slots", 0.0))
    return max(1.0, measured)


def binding_evidence(row):
    """The measured columns `binding_label` read, as text for the row."""
    parts = [f"window_blocks={int(_window_blocks(row))}"]
    for name in ("blocks_bound_by_gas", "blocks_bound_by_bytes"):
        parts.append(f"{name}={int(_number(row, name, 0.0))}")
    for name in ("cpu_utilisation", "cpu_utilisation_builder",
                 "egress_utilisation", "egress_saturated_share",
                 "capacity_vs_ideal"):
        value = _number(row, name)
        if value >= 0:
            parts.append(f"{name}={value:.2f}")
    return ";".join(parts)


def binding_label(row):
    """The constraint that holds this run's throughput where it is [Mo].

    A rule over the run's measured columns, in this order:

    1. `block_timeliness`: orphaning is on and the canonical rate is below
       0.95 of the included rate.
    2. `gas` or `bytes`: at least half the measured window's blocks were
       packed to that limit. Only blocks of the measured window count:
       `blocks_bound_by_*` no longer include warm-up and drain blocks.
    3. Capacity mode, at the highest sustained rate: the network-free
       bound's constraint (`gas`, `bytes` or `prover`) when capacity is
       within 0.95 of it; otherwise what is saturated upstream.
    4. Run mode, load not sustained: what is saturated upstream of the
       chain, `prover` or `verify` (mean CPU utilisation >= 0.9, by the
       larger CPU share; also when the builder's CPU alone is saturated,
       `cpu_utilisation_builder`), `bandwidth` (mean uplink utilisation >=
       0.9, or
       half the nodes with a saturated uplink), else `propagation` (latency
       and relay rounds, the uplinks not full).
    5. `offered`: the run included 0.95 of what was offered, so nothing
       binds at this load.

    The evidence columns stay in the row: `window_blocks`,
    `blocks_bound_by_*`, `cpu_utilisation`, `egress_utilisation`,
    `egress_saturated_share`, `capacity_vs_ideal`, and `binding_evidence`
    spells them out.
    """
    included = _number(row, "tps_included_window", 0.0)
    canonical = _number(row, "tps_canonical")
    if (_number(row, "orphan_late_blocks", 0.0) and canonical >= 0
            and canonical < SUSTAINED * included):
        return "block_timeliness"
    window = _window_blocks(row)
    for limit in ("gas", "bytes"):
        if _number(row, "blocks_bound_by_" + limit, 0.0) >= window / 2.0:
            return limit
    capacity = _number(row, "capacity_tps")
    if capacity >= 0:
        ideal = _number(row, "ideal_bound_tps")
        if ideal > 0 and capacity >= SUSTAINED * ideal:
            return str(row.get("ideal_binding", "offered"))
        return _upstream(row)
    offered = _number(row, "offered_tps", 0.0)
    if (included >= SUSTAINED * offered
            and _number(row, "inclusion_fraction", 0.0) >= SUSTAINED):
        return "offered"
    return _upstream(row)


def _cell(value, scale=1.0):
    """A measured value, or NA for the harness's -1 (structural absence)."""
    if value in ("", None, NA):
        return NA
    if isinstance(value, str):
        # A row read back from a CSV holds text: the same rule and the same
        # unit conversion must apply, or milliseconds pass for seconds.
        try:
            value = float(value)
        except ValueError:
            return value
    if isinstance(value, (int, float)):
        if value < 0 or (isinstance(value, float) and math.isnan(value)):
            return NA
        return value * scale if scale != 1.0 else value
    return value


def _whole(value):
    """An integer grid coordinate, also from CSV text; NA stays NA."""
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return NA


def phase2_row(row, **labels):
    """One PHASE2.md section 4 row from a harness row.

    `labels` override any column: `scenario="D"`, `variant=...`,
    `pricing=...`, `candidate=...`, `status=...`, `source=...`. Without
    them the row's own label knobs are used, then defaults: the harness
    scenario name, the variant `queue=<policy>` under aggregation (the queue
    policy decides the regime and has no column), status `[C]` (a count
    from a simulation run) and a source naming the mode and seed. `tps_tx` is the capacity where the row
    has one, else the canonical rate of the measured window. The elasticity
    columns are `NA` in a single row: `fill_elasticities` computes them
    over a grid.
    """
    def label(name, default):
        if labels.get(name) not in (None, ""):
            return labels[name]
        if row.get(name) not in (None, "", NA):
            return row[name]
        return default

    k = int(_number(row, "k", 1))
    tps = _number(row, "capacity_tps")
    mode = "capacity"
    if tps < 0:
        mode = "run"
        tps = _number(row, "tps_canonical")
        if tps < 0:
            tps = _number(row, "tps_included_window", 0.0)
    profile = row.get("profile", "-")
    # Unlabelled aggregation rows are told apart by their queue policy, which
    # decides the regime and has no column of its own.
    default_variant = NA
    if row.get("scenario") in ("agg8288", "pcs") and row.get("wrapper_queue"):
        default_variant = f"queue={row['wrapper_queue']}"
    result = {
        "scenario": (labels.get("scenario")
                     or (row.get("scenario_id")
                         if row.get("scenario_id") not in (None, "", NA)
                         else row.get("scenario", NA))),
        "variant": label("variant", default_variant),
        "pricing": label("pricing", NA),
        "gas_limit": row.get("gas_limit", NA) or "none",
        "profile": "custom" if profile in ("-", None, "") else profile,
        "uplinks": row.get("uplinks", "uniform"),
        "nodes": row.get("nodes", NA),
        "candidate": label("candidate", NA),
        "B": _whole(row.get("sig_bytes", NA)),
        "P": _whole(row.get("perms", NA)), "k": k,
        "tps_tx": tps, "tps_sig": tps * k,
        "tps_timely": _cell(row.get("tps_timely", -1.0)),
        "binding": row.get("binding") or binding_label(row),
        "block_bytes": _cell(row.get("block_bytes_mean", -1.0)),
        "t90_block_s": _cell(row.get("block_mean_t90_ms", -1.0), 0.001),
        "t99_block_s": _cell(row.get("block_mean_t99_ms", -1.0), 0.001),
        "bw_node_mbit": _cell(row.get("egress_Bps_per_node", -1.0), 8e-6),
        "dup_share": _cell(row.get("duplicate_bytes_share", -1.0)),
        "wasted_share": _cell(row.get(
            "wasted_share", row.get("repeat_service_share", -1.0))),
        "degradation": _cell(row.get("degradation", -1.0)),
        "status": label("status", "[C]"),
        "source": label("source", f"bench.leansphincs {mode} "
                                  f"seed={row.get('seed', NA)}"),
    }
    for column in ELASTICITY_COLUMNS:
        result[column] = labels.get(column, NA)
    return {column: result[column] for column in PHASE2_COLUMNS}


def _interpolate(points, target):
    """TPS at `target` from (x, tps) points, linear in log-log between the
    two grid points around it. None outside the grid or at zero TPS."""
    points = sorted(points)
    for (low, low_tps), (high, high_tps) in zip(points, points[1:]):
        if low <= target <= high:
            if low_tps <= 0 or high_tps <= 0:
                return None
            if high == low:
                return low_tps
            share = math.log(target / low) / math.log(high / low)
            return math.exp(math.log(low_tps)
                            + share * math.log(high_tps / low_tps))
    return None


def _axis(points, at):
    """(elasticity, {step: percent change}) of TPS along one axis at `at`.

    The local elasticity is the log-log slope between the grid neighbours
    of `at` (one-sided at an end of the grid). A step's change is read by
    log-log interpolation; NA when `at` x (1 + step) leaves the grid.
    """
    values = dict(points)
    if at not in values or values[at] <= 0 or len(values) < 2:
        return NA, dict.fromkeys(STEPS, NA)
    grid = sorted(values)
    index = grid.index(at)
    below = grid[max(0, index - 1)]
    above = grid[min(len(grid) - 1, index + 1)]
    elasticity = NA
    if values[below] > 0 and values[above] > 0 and above != below:
        elasticity = (math.log(values[above] / values[below])
                      / math.log(above / below))
    changes = {}
    for step in STEPS:
        there = _interpolate(points, at * (1 + step / 100.0))
        changes[step] = (NA if there is None
                         else 100.0 * (there / values[at] - 1.0))
    return elasticity, changes


GROUP_COLUMNS = ("scenario", "variant", "pricing", "gas_limit", "profile",
                 "uplinks", "nodes", "k")


def fill_elasticities(rows, tps="tps_tx"):
    """Fill eps_B, eps_P and the dB / dP columns of phase-2 rows, in place.

    Rows are grouped by every column that is not the swept one
    (`GROUP_COLUMNS`). Along B, a row's neighbours are the rows of its group
    with the same P, and along P those with the same B; several rows at one
    grid point (seeds) are averaged. A row whose axis has a single grid
    point keeps `NA`.
    """
    def series(axis, other, row):
        group = tuple(row[column] for column in GROUP_COLUMNS)
        sums = {}
        for candidate in rows:
            if (tuple(candidate[column] for column in GROUP_COLUMNS) == group
                    and candidate[other] == row[other]):
                total, count = sums.get(candidate[axis], (0.0, 0))
                sums[candidate[axis]] = (total + float(candidate[tps]),
                                         count + 1)
        return [(value, total / count)
                for value, (total, count) in sums.items()]

    for row in rows:
        for axis, other, name in (("B", "P", "B"), ("P", "B", "P")):
            elasticity, changes = _axis(series(axis, other, row), row[axis])
            row["eps_" + name] = elasticity
            for step in STEPS:
                row[f"d{name}{step}"] = changes[step]
    return rows

"""The leanSPHINCS parameter campaign's harness on top of starksim.

Three deployment scenarios -- S1 `noagg`, S2 `agg8288`, S3 `pcs` -- run on
v2's overlay, relay, bandwidth, CPU and chain machinery, with signature
bytes, permutations per signature and signatures per transaction as
first-class knobs. `models` holds the pluggable cost, gas and network models,
`scenario` builds and measures one run, `python3 -m bench.leansphincs` runs
one point and `python3 -m bench.leansphincs.sweep` a grid.
sims/LEANSPHINCS-FORK.md is the guide.
"""

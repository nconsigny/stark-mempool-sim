"""One leanSPHINCS campaign point: `python3 -m bench.leansphincs`.

    python3 -m bench.leansphincs --scenario noagg --sig-bytes 7740 --perms 515
    python3 -m bench.leansphincs --scenario agg8288 --k 2 --out run.json
    python3 -m bench.leansphincs --scenario pcs --config my.json

    python3 -m bench.leansphincs scenarios              # the named scenarios
    python3 -m bench.leansphincs run --scenario A --candidate P99a
    python3 -m bench.leansphincs sweep --scenario A --out a.csv

`--scenario` takes a harness class (noagg, agg8288, pcs), a campaign scenario
id (E0a, E0b, E0c, A, B, C1, C2, D, E, F1, F2, F3) or the name of one of its
configurations; `scenarios` lists them (`--json` for records). An id loads
its configuration from bench/leansphincs/scenarios/ below `--config` and the
flags, and `--candidate` then sets the signature's bytes and permutations
for any name of PHASE2B.md section 2 (B0, P99r, P99a, S24-minB, S22-minP-5K,
S22-minB-5K, N2, N3r) or of the campaign's data/phase2/candidates_v2.csv
(bench/leansphincs/registry.py). `run` is the default command;
`sweep` is `python3 -m bench.leansphincs.sweep`.

Precedence: built-in defaults, then a named scenario's configuration, then
`--config` JSON (any knob of
`bench.leansphincs.scenario.DEFAULTS`, plus `set` -- NetworkSim keyword
overrides -- and `models` -- model specs), then flags. `--preset` names a v2
preset for S2/S3 (`name+field=value` overrides allowed). Without `--tps` the
offered rate is `--load-factor` times the analytic bound, so the run measures
saturated throughput. The output is one flat JSON object; `--out` writes it
to a file as well as stdout, `--full` adds the simulator's complete metrics.

Phase 2: `--profile` names a network profile, `--uplinks heterogeneous` draws
per-node uplinks from it, `--wrapper-queue` names the send-buffer policy,
`--block-relay`, `--egress-priority` and `--block-fanout` set how blocks
travel, `--orphan-late-blocks` orphans late ones in the accounting,
`--compat phase1` restores phase 1's behaviour, and `--phase2-row` prints the
PHASE2.md section 4 columns. Phase 2b: `--cpu-discipline` (priority by
default), `--measured-slots` (4 by default) and, for the leanPCS scenarios,
`--client-proofs merge|draft|relay`. Defaults and sources: sims/LEANSPHINCS-FORK.md,
"Phase-2 settings".
"""

import argparse
import json
import sys

from bench.common import _json_value
from bench.leansphincs import registry
from bench.leansphincs.scenario import (DEFAULTS, SCENARIOS, evaluate,
                                        resolve_knobs, run)
from bench.leansphincs.schema import phase2_row


def parser():
    result = argparse.ArgumentParser(
        prog="python3 -m bench.leansphincs", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    result.add_argument("--scenario",
                        help=f"a class ({', '.join(SCENARIOS)}), a scenario "
                             f"id ({', '.join(registry.IDS)}) or a "
                             "configuration name")
    result.add_argument("--sig-bytes", type=int,
                        help=f"signature bytes (default {DEFAULTS['sig_bytes']})")
    result.add_argument("--perms", type=int,
                        help="Keccak-f permutations to verify one signature "
                             f"(default {DEFAULTS['perms']})")
    result.add_argument("--k", type=int,
                        help="signatures per transaction (multisig k-of-n)")
    result.add_argument("--preset",
                        help="v2 preset for agg8288/pcs (default eip_faithful)")
    result.add_argument("--config", help="JSON file of knobs, set and models")
    result.add_argument("--out", help="also write the result JSON here")
    result.add_argument("--tps", type=float,
                        help="offered transactions per second")
    result.add_argument("--load-factor", type=float,
                        help="without --tps: offered = factor x the bound")
    result.add_argument("--load-basis", choices=("analytic", "ideal"),
                        help="the bound --load-factor scales: analytic (with "
                             "the rough bandwidth estimate) or ideal (gas, "
                             "bytes, prover). A capacity search always "
                             "starts from the ideal one")
    result.add_argument("--batch",
                        help="transactions per simulated leaf, or 'auto'")
    result.add_argument("--nodes", type=int)
    result.add_argument("--degree", type=int)
    result.add_argument("--uplink-mbps", type=float, help="0 = unmetered")
    result.add_argument("--latency-ms", type=float)
    result.add_argument("--slot-ms", type=float)
    result.add_argument("--birth-slots", type=int)
    result.add_argument("--warmup-slots", type=int)
    result.add_argument("--measured-slots", type=int,
                        help="slots measured after the warm-up (default "
                             f"{DEFAULTS['measured_slots']}); births span "
                             "warm-up plus these unless --birth-slots is "
                             "given")
    result.add_argument("--cpu-discipline", choices=("fifo", "priority"),
                        help="service order of a node's CPU (default "
                             f"{DEFAULTS['cpu_discipline']})")
    result.add_argument("--drain-slots", type=int)
    result.add_argument("--gas-limit", type=int, help="0 = no gas limit")
    result.add_argument("--byte-limit", type=int, help="0 = no byte cap")
    result.add_argument("--relay-policy",
                        choices=("flood", "announce_fetch", "wrapper_only"))
    result.add_argument("--chain-notify", choices=("instant", "overlay"))
    result.add_argument("--seed", type=int)
    result.add_argument("--set", action="append", default=[],
                        metavar="FIELD=JSON",
                        help="a NetworkSim keyword override; the value is "
                             "parsed as JSON, else kept as a string")
    result.add_argument("--mode", choices=("run", "capacity"),
                        help="capacity: search the highest sustained rate")
    result.add_argument("--full", action="store_true",
                        help="include the simulator's complete metrics")
    # Phase 2 (sims/LEANSPHINCS-FORK.md, "Phase-2 settings").
    result.add_argument("--profile",
                        help="optimistic, baseline or pessimistic of "
                             "data/network_params.json: degree, uplink and "
                             "latency wherever no flag or config sets them")
    result.add_argument("--network-params", help="another parameters file")
    result.add_argument("--uplinks",
                        help="uniform (default), heterogeneous (the "
                             "profile's mixture) or a JSON mixture")
    result.add_argument("--egress-priority", choices=("fifo", "blocks_first"))
    result.add_argument("--wrapper-queue",
                        choices=("unbounded", "drop_tail", "supersede"))
    result.add_argument("--egress-bytes", type=int,
                        help="send-buffer bound in bytes (drop-tail)")
    result.add_argument("--block-relay", choices=("verify", "validate"))
    result.add_argument("--block-validate-ms", type=float)
    result.add_argument("--block-fanout", type=int,
                        help="peers a node sends a block to (default: the "
                             "profile's block_gossip_degree, else all)")
    result.add_argument("--attest-deadline-ms", type=float,
                        help="the timeliness and orphan deadline")
    result.add_argument("--timely-fraction", type=float)
    result.add_argument("--orphan-late-blocks", action="store_true",
                        default=None)
    result.add_argument("--orphan-fraction", type=float)
    result.add_argument("--client-proofs",
                        choices=("merge", "draft", "relay"),
                        help="leanPCS scenarios: every node merges each "
                             "client proof (merge, the default, phase 2's "
                             "preset); the entry node merges it and "
                             "forwards its aggregate (draft, the leanPCS "
                             "draft's flow); or nodes relay it unmerged "
                             "and the builder alone merges (relay)")
    result.add_argument("--compat", choices=("phase1",),
                        help="phase 1's egress and block-relay behaviour")
    for label in ("scenario-id", "variant", "pricing", "candidate", "status",
                  "source"):
        result.add_argument("--" + label,
                            help="a label carried into the row, as given")
    result.add_argument("--phase2-row", action="store_true",
                        help="print the PHASE2.md section 4 row instead")
    return result


FLAG_KNOBS = ("scenario", "sig_bytes", "perms", "k", "preset", "tps",
              "load_factor", "load_basis", "batch", "nodes", "degree", "uplink_mbps",
              "latency_ms", "slot_ms", "birth_slots", "warmup_slots",
              "measured_slots", "cpu_discipline", "drain_slots", "gas_limit", "byte_limit", "relay_policy",
              "chain_notify", "seed", "mode", "profile", "network_params",
              "uplinks", "egress_priority", "wrapper_queue", "egress_bytes",
              "block_relay", "block_validate_ms", "block_fanout",
              "attest_deadline_ms",
              "timely_fraction", "orphan_late_blocks", "orphan_fraction",
              "compat", "client_proofs", "scenario_id", "variant", "pricing", "candidate",
              "status", "source")


def _parse_value(text):
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def knobs_from(args):
    config = {}
    if args.config:
        with open(args.config, encoding="utf-8") as handle:
            config = json.load(handle)
    flags = {}
    for key in FLAG_KNOBS:
        value = getattr(args, key)
        if value is not None:
            if key == "uplinks" and value.lstrip().startswith("{"):
                value = json.loads(value)
            flags[key] = value
    overrides = {}
    for item in args.set:
        field, separator, value = item.partition("=")
        if not separator:
            raise SystemExit(f"--set {item!r}: expected FIELD=VALUE")
        overrides[field] = _parse_value(value)
    if overrides:
        flags["set"] = overrides
    top = registry.merged(config, flags)
    if registry.is_named(top.get("scenario")):
        return resolve_knobs(*registry.layers(top))
    return resolve_knobs(config, flags)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    command = argv[0] if argv else None
    if command == "scenarios":
        if argv[1:] not in ([], ["--json"]):
            raise SystemExit("usage: python3 -m bench.leansphincs scenarios "
                             "[--json]")
        if argv[1:]:
            print(json.dumps(registry.entries(), indent=1))
        else:
            print(registry.listing())
        return 0
    if command == "sweep":
        from bench.leansphincs import sweep
        return sweep.main(argv[1:])
    if command == "run":
        argv = argv[1:]
    args = parser().parse_args(argv)
    knobs = knobs_from(args)
    if args.full:
        row, sim = run(knobs, full_metrics=True)
        row["metrics"] = sim.metrics()
        row["variant"] = sim.variant()
    else:
        row = evaluate(knobs)
    row["knobs"] = knobs
    if args.phase2_row:
        row = phase2_row(row)
    text = json.dumps(_json_value(row), sort_keys=not args.phase2_row,
                      allow_nan=False)
    print(text)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
Block limits: a gas limit, a byte cap, and the packing rule that respects both.

The fold budget (`block_budget`) bounds how many *objects* a proposer selects,
which is the question EIP-8288 asks. It says nothing about what the chain can
carry. A block is also bounded by its gas limit and by a byte cap
(`MAX_RLP_BLOCK_SIZE` in EIP-7934), and without aggregation those are the only
bounds there are: every signature sits in its transaction's calldata and is
paid for in gas and bytes.

A `BlockLimits` is injected like `NativeVerifyCost`: the core never prices a
transaction itself. Each leaf kind carries one gas figure and one on-chain
byte figure, computed by whatever model the caller chose; leaves of one kind
are identical, which is what the workload generates. Packing is pure and
schedules nothing, so the wiring decides when it runs and what it does with
the result.
"""

from dataclasses import dataclass

BOUND_GAS = "gas"
BOUND_BYTES = "bytes"
BOUND_SUPPLY = "supply"
BOUNDS = (BOUND_GAS, BOUND_BYTES, BOUND_SUPPLY)


@dataclass(frozen=True, slots=True)
class PackResult:
    """What one block carries, and which constraint stopped it.

    `bound_by` is `gas` or `bytes` when a candidate was refused for that cap,
    and `supply` when every candidate fitted -- the block was not full, the
    proposer simply held nothing more. When both caps refuse candidates, the
    first refusal names the bound.
    """

    included: int       # leaf mask
    count: int
    gas_used: int
    bytes_used: int     # base bytes plus every packed transaction
    bound_by: str


class BlockLimits:
    """A gas limit and a byte cap, with per-kind transaction gas and bytes.

    `None` for a limit means that dimension does not bind. Every block
    carries `header_bytes` and `proof_bytes` whatever it includes -- the
    header, and under aggregation the block's one recursive proof -- and
    their sum, `base_bytes`, counts against the byte cap and is the size of
    an empty block notice.

    `tx_gas` and `tx_bytes` map a leaf kind (`'q'`, `'p'`) to the gas one
    such leaf consumes and the bytes it adds to the block. A kind missing
    from either map cannot be included: refusing loudly beats pricing it at
    zero.
    """

    __slots__ = ("gas_limit", "byte_limit", "header_bytes", "proof_bytes",
                 "base_bytes", "tx_gas", "tx_bytes")

    def __init__(self, tx_gas, tx_bytes, gas_limit=None, byte_limit=None,
                 header_bytes=0, proof_bytes=0):
        if gas_limit is not None and gas_limit <= 0:
            raise ValueError("gas_limit must be > 0, or None for no limit")
        if byte_limit is not None and byte_limit <= 0:
            raise ValueError("byte_limit must be > 0, or None for no cap")
        if header_bytes < 0 or proof_bytes < 0:
            raise ValueError("header_bytes and proof_bytes must be >= 0")
        base_bytes = header_bytes + proof_bytes
        if byte_limit is not None and base_bytes > byte_limit:
            raise ValueError("base_bytes exceed byte_limit: no block fits")
        for name, table in (("tx_gas", tx_gas), ("tx_bytes", tx_bytes)):
            if not table:
                raise ValueError(f"{name} must price at least one kind")
            for kind, value in table.items():
                if value < 0:
                    raise ValueError(f"{name}[{kind!r}] must be >= 0")
        self.gas_limit = gas_limit
        self.byte_limit = byte_limit
        self.header_bytes = int(header_bytes)
        self.proof_bytes = int(proof_bytes)
        self.base_bytes = self.header_bytes + self.proof_bytes
        self.tx_gas = dict(tx_gas)
        self.tx_bytes = dict(tx_bytes)

    def identity(self):
        """Every number that changes what a block holds, for the variant."""
        return {
            "block_gas_limit": -1 if self.gas_limit is None else self.gas_limit,
            "block_byte_limit": (-1 if self.byte_limit is None
                                 else self.byte_limit),
            "block_header_bytes": self.header_bytes,
            "block_proof_bytes": self.proof_bytes,
            "block_tx_gas": dict(sorted(self.tx_gas.items())),
            "block_tx_bytes": dict(sorted(self.tx_bytes.items())),
        }

    def capacity(self, kind):
        """How many leaves of one kind an otherwise empty block holds.

        Arithmetic, for analytic bounds: the smaller of the gas and byte
        quotients, either one unbounded when its limit is `None`. Returns
        `None` when neither limit binds.
        """
        counts = []
        if self.gas_limit is not None and self.tx_gas[kind] > 0:
            counts.append(self.gas_limit // self.tx_gas[kind])
        if self.byte_limit is not None and self.tx_bytes[kind] > 0:
            counts.append((self.byte_limit - self.base_bytes)
                          // self.tx_bytes[kind])
        if not counts:
            return None
        return min(counts)

    def pack(self, candidates):
        """Greedy fill in the given priority order.

        `candidates` is an iterable of `(leaf_index, kind)` already ordered by
        the proposer's preference. A candidate that does not fit is skipped
        rather than ending the block, so a smaller transaction behind a large
        one can still be included; the scan stops early once neither cap could
        admit even the smallest priced kind.
        """
        gas_used = 0
        bytes_used = self.base_bytes
        included = 0
        count = 0
        bound_by = BOUND_SUPPLY
        smallest_gas = min(self.tx_gas.values())
        smallest_bytes = min(self.tx_bytes.values())
        for leaf_index, kind in candidates:
            if kind not in self.tx_gas or kind not in self.tx_bytes:
                raise ValueError(
                    f"block limits price no {kind!r} transaction: add it to "
                    "tx_gas and tx_bytes")
            gas = self.tx_gas[kind]
            size = self.tx_bytes[kind]
            if self.gas_limit is not None and gas_used + gas > self.gas_limit:
                if bound_by == BOUND_SUPPLY:
                    bound_by = BOUND_GAS
                if self._full(gas_used, bytes_used, smallest_gas,
                              smallest_bytes):
                    break
                continue
            if (self.byte_limit is not None
                    and bytes_used + size > self.byte_limit):
                if bound_by == BOUND_SUPPLY:
                    bound_by = BOUND_BYTES
                if self._full(gas_used, bytes_used, smallest_gas,
                              smallest_bytes):
                    break
                continue
            gas_used += gas
            bytes_used += size
            included |= 1 << leaf_index
            count += 1
        return PackResult(included, count, gas_used, bytes_used, bound_by)

    def _full(self, gas_used, bytes_used, smallest_gas, smallest_bytes):
        """Whether no priced kind could still fit under either cap."""
        if (self.gas_limit is not None
                and gas_used + smallest_gas > self.gas_limit):
            return True
        if (self.byte_limit is not None
                and bytes_used + smallest_bytes > self.byte_limit):
            return True
        return False

    def bytes_of(self, kinds_count):
        """Block bytes for these per-kind counts: base plus transactions."""
        total = self.base_bytes
        for kind, count in kinds_count.items():
            total += self.tx_bytes[kind] * count
        return total


class BlockFill:
    """Per-block gas, bytes and binding constraint, for the metrics.

    An observer: it schedules nothing and reads only what packing returned.
    """

    __slots__ = ("records",)

    def __init__(self):
        self.records = []

    def record(self, slot, result, limits):
        self.records.append({
            "slot": slot,
            "txs": result.count,
            "gas_used": result.gas_used,
            "bytes_used": result.bytes_used,
            "gas_fill": (-1.0 if limits.gas_limit is None
                         else result.gas_used / limits.gas_limit),
            "byte_fill": (-1.0 if limits.byte_limit is None
                          else result.bytes_used / limits.byte_limit),
            "bound_by": result.bound_by,
        })

    def metrics(self):
        bound_counts = dict.fromkeys(BOUNDS, 0)
        for record in self.records:
            bound_counts[record["bound_by"]] += 1
        blocks = len(self.records)
        mean_gas = -1.0
        mean_bytes = -1.0
        if blocks:
            mean_gas = sum(r["gas_used"] for r in self.records) / blocks
            mean_bytes = sum(r["bytes_used"] for r in self.records) / blocks
        return {"blocks": blocks, "bound_by": bound_counts,
                "mean_gas_used": mean_gas, "mean_bytes_used": mean_bytes,
                "per_block": [dict(record) for record in self.records]}

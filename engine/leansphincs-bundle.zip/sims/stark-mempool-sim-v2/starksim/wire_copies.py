"""Completed uplink copies, separate from receiver admission and reach."""

from starksim.statistics import Moments, POWER_MINIMUMS


COPY_CLASSES = ("raw_object_bodies", "wrapper_bodies", "wrapper_claim_mentions")


class WireCopies:
    """Three sparse leaf-indexed counters, O(transactions x fixed classes).

    No message history or arena provenance is retained. A raw object costs
    one increment. A wrapper's two payload masks are tallied by value and
    expanded into per-transaction counts only when read, or when the tally
    grows past `PENDING_LIMIT` distinct masks: one wrapper core goes to every
    peer with the same claim mask, so expanding each copy as it left (one
    dictionary update per named bit per copy) was a third of an aggregation
    run's wall time. The counts are the same either way. The masks, not the
    aggregate DAG, define which transactions crossed egress. Queries include
    zero-copy births.
    """

    PENDING_LIMIT = 8192

    def __init__(self):
        self._counts = {kind: {} for kind in COPY_CLASSES}
        self._pending = {"wrapper_bodies": {}, "wrapper_claim_mentions": {}}

    @property
    def counts(self):
        self._flush()
        return self._counts

    def raw_body(self, leaf_index):
        table = self._counts["raw_object_bodies"]
        table[leaf_index] = table.get(leaf_index, 0) + 1

    def wrapper(self, body_mask, tx_mask):
        if body_mask:
            pending = self._pending["wrapper_bodies"]
            pending[body_mask] = pending.get(body_mask, 0) + 1
        if tx_mask:
            pending = self._pending["wrapper_claim_mentions"]
            pending[tx_mask] = pending.get(tx_mask, 0) + 1
            if len(pending) > self.PENDING_LIMIT:
                self._flush()

    def _flush(self):
        for kind, pending in self._pending.items():
            if not pending:
                continue
            table = self._counts[kind]
            for mask, copies in pending.items():
                self._increment(table, mask, copies)
            pending.clear()

    @staticmethod
    def _increment(table, mask, copies=1):
        # Bits low to high: the binary text reversed, one C-level search per
        # set bit.
        bits = bin(mask)[:1:-1]
        tx = bits.find("1")
        while tx >= 0:
            table[tx] = table.get(tx, 0) + copies
            tx = bits.find("1", tx + 1)


def wire_copies(sim, per_transaction=False):
    """Summary over every born leaf, with optional leaf-indexed rows.

    A disabled observer returns -1. An enabled empty population has count
    and sum zero but undefined mean/max (-1). Each class histogram has the
    fixed power-of-two buckets of starksim.statistics, including zero.
    Query time is O(transactions x classes); default output is fixed-size.
    """
    if sim.wire_copies is None:
        return -1
    transactions = len(sim.arena.leaves)
    classes = {}
    for kind, table in sim.wire_copies.counts.items():
        moments = Moments()
        for tx in range(transactions):
            moments.record(table.get(tx, 0))
        record = moments.record_dict()
        record["mean"] = -1.0
        if transactions:
            record["mean"] = moments.sum / transactions
        classes[kind] = record
    result = {
        "observed_until_ms": sim.engine.now,
        "total_txs": transactions,
        "histogram_power_minimums": list(POWER_MINIMUMS),
        "classes": classes,
    }
    if per_transaction:
        rows = []
        for tx in range(transactions):
            row = {"tx": tx}
            for kind, table in sim.wire_copies.counts.items():
                row[kind] = table.get(tx, 0)
            rows.append(row)
        result["by_transaction"] = rows
    return result
